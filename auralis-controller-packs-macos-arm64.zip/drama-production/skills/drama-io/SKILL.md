---
name: drama-io
description: 按当前轮作用域使用短剧工作台 CLI。
---

CLI 路径由本轮上下文提供。使用 context 定位，inspect 按 ID 读取，apply 携带 requestId 和 expectedRevision，job 查询同一任务。可用操作以 context.allowedOperations 为准。

只读当前阶段文件。命名时按需读取本轮给出的 assetNamingFile；不要遍历项目、其他集或所有阶段说明。
