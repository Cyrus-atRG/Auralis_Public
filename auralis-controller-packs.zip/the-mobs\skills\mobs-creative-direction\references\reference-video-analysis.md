# Mobs 参考视频分析

只如实拆解用户提供的源视频，不设计新题材，不提出改编方案，不写图片、视频或口播 Prompt。

先记录看见和听见的事实，再解释其作用与吸引力。保留具体角色、场景、道具、动作、状态变化、UI 和声音；不确定的信息明确写“不确定”。

`actual_shots` 只表示真实剪辑或镜头边界；`functional_arc` 表示镜头内或跨镜头的功能推进。两者必须分开。FFmpeg scene-change 与 contact sheet 只是定位候选，闪光、遮挡或运动会误检，缓慢边界也可能漏检；最终边界必须结合完整视频确认。一镜到底时 `actual_shot_count` 必须为 1，镜头内阶段写进 `functional_arc.time_ranges`。

完整结构化结果使用 `mobs.reference-analysis.v1`，由 Auralis 保存在源 Luna 的 `mediaAnalysis` 中，必须包含：

- `source_summary`
- `source_visual_observation`：`visual_style`、`camera_and_presentation`、`composition_patterns`、`continuity`、`style_reference`
- `actual_shot_count` 与 `actual_shots`：每项含 `shot_id`、`start_time`、`end_time`、`transition_in`、`concrete_visuals`、`actor_action`、`visible_feedback`、`shot_function`、`appeal`、`audio_or_text`
- `functional_arc_count` 与 `functional_arc`：每项含 `arc_id`、`shot_ids`、`time_ranges`、`function`、`progression`、`appeal_contribution`
- `appeal_analysis`：钩子、核心循环、游戏驱动力、因果变化、可读性、情绪曲线与回报，每项引用 `shot_id`
- `validation_notes`：候选切点的采用/排除、漏检边界和仍不确定部分

这些字段是机器可读的深层分析，不是 `Comet.referenceBrief` 的显示格式。不得把完整对象、JSON、YAML、代码块或英文 schema 字段名复制到 Brief 正文。

`Comet.referenceBrief` 只生成便于用户扫读的短 Markdown，顺序为：

1. **参考概况**：片长、题材、主要玩法与整体情绪，一小段。
2. **有效吸引力**：钩子、核心循环、因果变化与回报，最多五条。
3. **镜头与功能推进**：按真实镜头顺序，每个镜头一条短句；一镜到底时按功能阶段概括，不伪造剪辑。
4. **视觉和声音特点**：只留会影响判断的视角、构图、节奏、UI、字幕和声音规律，最多五条。
5. **不确定项**：只在确有不确定内容时保留。

正文默认不超过 1200 个中文字符。超出的逐帧事实、证据引用、切点验证和细项观察继续留在 `mediaAnalysis`，不要为了“完整”重复铺到画布上。

禁止输出创意方向、目标题材、改编规则、推荐段数或任何下游 Prompt。
