---
name: mobs-creative-direction
description: 为 the-mobs Aura 完成游戏广告的创意理解、参考素材借鉴和可生产方案设计。读取或修改 Polaris.creativeBrief，解释参考视频真实镜头与功能推进，决定改编强度，或检查方案是否像实际游戏画面时使用。
---

# Mobs Creative Direction

把当前画布中的完整输入作为事实源。先 inspect 现有 `Polaris.creativeBrief`、相关 `Comet.referenceBrief`、参考 Sol/Luna 与 links；不要依赖旧摘要重建方案。

## 适应指引密度

- 指引充分时严格保留题材、段数、结构、画风与取舍，只补足生产细节。
- 指引部分明确时固定已明确内容，对空白处主动做最强选择。
- 指引稀少时承担创意决策，给出一个完整鲜明的方向；只有关键缺失会产生完全不同作品时才提问。
- 用户当前表达始终高于参考惯性与方法偏好。

## 借鉴参考素材

- 需要分析参考视频时，完整读取 [reference-video-analysis.md](references/reference-video-analysis.md) 与 [gameplay-driver-model.md](references/gameplay-driver-model.md)，调用 `analyzeReferenceVideo` 并传 `analysisProfile: "mobs-reference-v1"`。完整 `mobs.reference-analysis.v1` 只保留在源 Luna 的 `mediaAnalysis`；分析完成后 inspect 对应 `Comet.referenceBrief`，若正文含原始 JSON、schema 字段或过长逐项记录，使用 `setAstraContent` 和最新预期版本改写为短 Markdown，不复制完整分析对象。
- 读取完整分析。把 `actual_shots` 视为真实镜头结构，把 `functional_arc` 视为镜头内或跨镜头的功能推进，不混为段数。
- 先识别钩子、玩家幻想、因果机制、阅读顺序、升级曲线和回报，再决定如何改造。
- 借鉴吸引力与结构，不默认继承原片题材、角色、地点、道具、台词或品牌表皮。
- 原片架构有效时优先让目标段对应真实镜头。只有新方案明显更强时才合并、拆分或重排，并在 Brief 中说明理由。
- 用户要求保留段数、顺序或逐段功能时，把它当作硬要求。

## 落成实际游戏画面

- 每段只承载一个主要玩法读点，写成 `玩家动作 → 可见反馈 → 状态变化`。
- 指定施动者、动作方式和受作用对象；不让建造、清理、战斗、升级或奖励像环境自动发生。
- 给出可玩的空间、明确操作对象、可理解规则、持续世界状态和即时反馈，避免概念海报或只有氛围的电影镜头。
- 把抽象卖点翻译成角色、环境、道具、构图、动作、状态差异和结果。
- 只锁跨段真正需要识别的身份、布局、状态、画风和镜头呈现；不为独立片段强造连续性。

## 分层落到画布

不要把参考拆解、创意判断、逐段方案、逐镜头执行和生产备注写进同一张卡：

- `Comet.referenceBrief`：只供人快速阅读参考片，使用“参考概况 / 有效吸引力 / 镜头与功能推进 / 视觉和声音特点 / 不确定项”的短 Markdown。每个真实镜头最多一条短句，正文默认不超过 1200 个中文字符；禁止 JSON、YAML、代码围栏和内部字段名。
- `Polaris.creativeBrief`：只保存已经决定的项目核心，作为后续共同入口。
- `Comet.segmentPlan`：保存某一段的玩法动作、反馈、状态变化、关键静帧、视频演变与生产注意事项。
- `Comet.shotScript`：只有确实需要逐镜头执行时才创建，保存镜头级画面、动作、反馈、机位和节奏。
- `Polaris.customPolaris`：只保存跨多个片段或阶段反复使用的项目级规则，例如参考结构映射、角色与世界连续性、UI 阅读规则。创建时设置具体 `title`，正文写清适用时机和规则；不要用“补充信息”之类空泛标题，也不要复制 Creative Brief 或片段方案。

已有同主题 Astra 时更新原节点，不按章节重复新建。分析或创意内容太长时先按以上职责拆分，再写入画布。

## 写唯一 Creative Brief

创建或更新同一个 `Polaris.creativeBrief`，并保持：

```text
meta.contentSchema = "mobs.creative-plan.v1"
```

正文固定为精简 Markdown，默认不超过 900 个中文字符，只包含：

- **一句话方案**：题材、玩家行为与结果。
- **核心 Hook**：开场吸引力和方案成立原因。
- **整体呈现**：游戏视角、核心视觉特征和全片读法。
- **硬要求**：用户必须保留或避免的内容；没有就省略。
- **段落弧线**：段数及每段一行的功能推进，不写逐镜头细节。

不要在 Creative Brief 中写完整参考逐镜映射、长篇镜头语言、逐段关键帧、图片/视频 Prompt、模型参数或生产清单。参考映射若会跨阶段复用，写入有明确标题的 `Polaris.customPolaris`；片段与镜头执行细节在用户确认方向后写入对应 `Comet.segmentPlan` / `Comet.shotScript`。

已有 Brief 时先 inspect 最新版本，用 `setAstraContent` 和预期版本精确更新；不要另建第二份当前方案。若旧 Brief 已经很长，先提炼核心再覆盖，并把仍有后续价值的细节按职责迁移到现有 segment、shot 或 custom Polaris。内部反看一次钩子、因果、可玩性和动作施动者，直接修正明显问题。

写入后在聊天中给出短摘要并停在创意软检查点。用户已明确授权连续执行时才进入图片阶段。
