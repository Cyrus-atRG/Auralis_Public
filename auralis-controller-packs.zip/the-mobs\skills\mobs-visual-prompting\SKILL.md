---
name: mobs-visual-prompting
description: 把 the-mobs Aura 中已确认的 Polaris.creativeBrief 转成独立可执行的图片或视频 Prompt Astra，并规划真实的输入资产、links 与生成目标。创建或修改 Comet.imagePrompt、Comet.videoPrompt、首尾帧、参考关系，或准备 Auralis 图片和视频生成时使用。
---

# Mobs Visual Prompting

完整读取当前 `Polaris.creativeBrief` 和相关 segment、Prompt、Sol/Luna、links。直接翻译已确认创意，不重新发明结构，也不把 Prompt 打包到画布外。

## 规划真实资产

- 为每段选择当前 Auralis capability 能执行的最简单输入方式。
- 只在跨段需要同一身份、物件、场景或布局时引用 reference Astra。
- 独立片段通常使用独立首帧。只有方案明确设计两个状态端点且当前能力支持时才连接首尾帧。
- 每个 Prompt、媒体目标与 link 都必须指向真实 Astra；缺少输入或能力时说明限制，不在文字里假装已解决。
- 不设置模型或服务默认值。继承当前 Aura 的 Auralis 设置。

## 写独立 Prompt

每条图片与视频 Prompt 都按无对话历史的独立请求编写，完整说清主体、环境、镜头、构图、动作、状态和必要视觉方向。禁止使用“同上”“沿用之前”“如参考所示”等隐藏上下文；只引用该生成目标真实连接的可见资产。

图片 Prompt：

- 设计一个信息清楚的静止游戏状态，不把整段时间过程塞进一张图。
- 写清视角、距离、前中后景、主体大小、空间关系、动作瞬间、反馈位置和变化后的状态。
- 让玩家动作成为因果中心，优先保证玩法读点，控制特效、烟雾、强光和巨大物件的视觉面积。
- 默认把字幕、固定 HUD 和口播文字留给后期；只有局部 UI 本身是玩法反馈时才写入画面。

视频 Prompt：

- 从真实连接的输入图片状态出发，依次写施动者、动作路径、反馈、状态变化和稳定结束状态。
- 一段突出一个主要玩法读点；镜头运动服务玩法阅读，不无意义环绕、推拉或切换主体。
- 首尾帧模式只描述两个端点之间缺失的演变，不发明与端点冲突的内容。
- reference 只负责身份或布局锚定，不把它冒充未提供的首帧或尾帧。

## 落到画布

- 每段按需创建或更新 `Comet.segmentPlan`、`Comet.imagePrompt`、`Comet.videoPrompt`。
- 用 `setAstraContent` 写完整 Prompt；更新前携带最新预期版本，冲突后保留用户改稿并重新规划。
- 创建 `Sol.genImage` 或 `Luna.genVideo` 目标，用 `connectAstra` 建立 prompt、first_frame、last_frame 与 ref 关系，再调用 `generateMedia`。
- 画幅和其他生成设置按用户明确要求，其次读取当前 Auralis 设置；不在 Skill 中补一套 fallback。
- 生成前 inspect 节点和 links，确认段数、输入、比例、首尾帧和 reference 关系真实一致。

图片阶段完成后停在图片软检查点。用户选择或修改图片后，以最新有效图片和 Prompt 写视频阶段；视频完成后停在视频软检查点。用户明确授权连续执行时可跨软检查点，但用户直接编辑永远优先。
