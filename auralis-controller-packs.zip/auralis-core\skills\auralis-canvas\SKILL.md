---
name: auralis-canvas
description: 通过 Auralis Canvas CLI 查询或修改当前 Aura 的 Astra、links、媒体任务与参考分析。创建、编辑、连接、布局或生成 Astra，读取画布上下文，等待或取消 action，以及处理用户与 Agent 并发编辑时使用。
---

# Auralis Canvas

把 CLI 当作 Auralis operation runner 的薄入口，不在本地重建画布状态或媒体能力。

## 先定位，再按需读取

从 turn context 取得 `auraId`。`context` 返回供决策使用的紧凑目录，包括 Astra id、短摘要、关系线索与能力信息；它不是完整画布正文：

```text
auralis-canvas context --aura-id <aura-id> --request-id <read-id>
auralis-canvas inspect --aura-id <aura-id> --request-id <inspect-id> --selector-json '{"ids":["<astra-id>"]}'
```

先以用户当前指令和明确的 @引用为锚点，再从目录中挑选少量可能相关的 Astra。优先按明确 id inspect；只有读到的新信息表明确有必要时，才继续读取其直接上下游、links 或 action。画布里未被任务指向的大多数 Astra 不属于本轮上下文。

- 禁止为“先了解项目”默认遍历全部 Astra、links、action 或逐个 inspect 整张画布。
- 不要用 `--include` 或重复查询拼出完整项目转储。长正文、媒体分析和生成详情应在确定相关后定点 inspect。
- 同一 turn 没有新增用户指令、operation 结果或已知画布变化时，继续使用已有目录，不重复调用 `context`。
- `context` 或 `inspect` 返回 `pending` / 等待超时时，使用原 `requestId` 执行 `wait`；确需重新提交时也复用原 id，不创建重复读取。
- 自己完成 apply 后只 inspect 受影响的 ids，不为确认结果重新读取全局 context。

修改已有 Astra 前再次精确 inspect 目标，记录其 id、content、version 与 content hash；目录摘要不能代替写前并发检查。

## 提交 Operation

用一次 `apply` 提交一组有序操作：

```text
auralis-canvas apply --aura-id <aura-id> --request-id <unique-id> --operations-file <path|->
```

- 每个 mutation 使用明确 Aura 与全局唯一 request id；重试同一请求时复用原 id。
- 精确写文本或 prompt 使用 `setAstraContent`。不要使用会再次请求 LLM 的草拟或改写 operation。
- 修改已有内容时传 `expectedVersion` 或 `expectedContentHash`。冲突后重新 inspect，保留用户新内容，再决定是否生成新的写入。
- 创建使用真实 Astra family/role；连接使用真实节点 id 或同批 operation result selector。
- 仅在用户要求或新节点需要可读摆放时使用 `layoutAstra`。内容更新与布局更新分开。

常用 operation 语义和 JSON 示例见 [operation-contract.md](references/operation-contract.md)。以运行时 `context` 返回的 capability 为最终准则；不可用时返回明确限制，不伪造执行结果。

## 媒体与分析

- 用 `generateMedia` 生成图片或视频，继承 Auralis 当前设置。只有用户明确指定时才传覆盖参数。
- 用 `upscaleVideo` 超清一个或多个现有视频 Astra；默认按源视频真实尺寸选择 720/768 到 1080p、1080 到 2k，也可显式传 `targetResolution`。
- 用 `extractVideoFrames` 执行视频手动切帧、场景抽帧或 contact sheet；不要另跑私有抽帧脚本。
- 用 `analyzeReferenceVideo` 调用 Auralis 配置的参考视频分析能力。
- `generateMedia`、`generateMediaVariants`、`upscaleVideo`、`extractVideoFrames`、`analyzeReferenceVideo` 可能超过一次 CLI 等待时长。对这些操作先给 apply 加 `--no-wait`，然后用同一个 request id 跟踪：

```text
auralis-canvas wait --aura-id <aura-id> --request-id <request-id>
auralis-canvas cancel --aura-id <aura-id> --request-id <request-id>
```

`request-id` 是提交 apply 时使用的同一个唯一 id。等待结果时不锁用户画布。返回的媒体若基于旧 prompt 版本，保留为候选并说明来源，不修改当前 prompt。

`wait` 超时时会返回 `status: "pending"` 和 `waitTimedOut: true`，这不是操作失败。继续使用同一个 request id 等待；不要换新 id 重复提交。

## 完成检查

重新 inspect 受影响节点，确认内容、links、状态和 action 结果真实存在。把长内容留在 Astra；聊天只报告结果、检查点、冲突或所需选择。
