---
name: mobs-spoken-script
description: 为 the-mobs Aura 创建或修改游戏广告口播稿 Astra。用户要求 narration、voiceover copy、口播钩子或修改现有 Comet.spokenScript 时使用，尤其适合面向冷用户的自然英文短视频口播。
---

# Mobs Spoken Script

## 准备内容

1. inspect 当前 `Polaris.creativeBrief`、最终采用的片段与已有 `Comet.spokenScript`。
2. 确认说话者身份或视角、核心情境和开场钩子。只有缺失选择会实质改变文稿时才提问。
3. 读取 [hook.md](references/hook.md)。按视频可用时长控制篇幅；没有精确时长时写简洁可编辑的短稿，并在聊天中说明假设。

## 写稿

- 遵守用户指定语言。英文冷启动广告优先使用自然口语，而不是标题、功能清单或中文直译。
- 从指定身份与视角说话，以钩子开场，沿 setup、tension/desire、progression、payoff 推进一个连贯想法。
- 写成连续口播，不逐镜头解说。画面是口播观点的证据，文稿本身也应独立可懂。
- 每个口播句以一个有表演意义的小写英文情绪标签开头，例如 `[curious]`；不要为装饰堆标签。
- 让每句推进上一句，避免重复命令、功能罗列、内部 Astra 名称和项目术语。
- 按自然语速适配总时长；缩短时删弱句，不牺牲钩子与回报。

## 写入 Astra

创建或更新一个 `Comet.spokenScript`，正文只保留最终连续口播。可在 meta 中记录语言、说话视角、估计时长与开场钩子，但不要建立另一份重复正文。

已有口播稿时先读取最新版，用 `setAstraContent` 和预期版本写入。用户已经手改时保留其内容并基于最新版修订。本 Skill 不生成音频，也不调用画布外的语音工具。

交付前检查：开场与确认的钩子一致；冷用户无需游戏背景也能理解；句间连贯；每句有有效情绪标签；估算朗读时长适配可用画面。
