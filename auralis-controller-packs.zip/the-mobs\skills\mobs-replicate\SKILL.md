---
name: mobs-replicate
description: 为 the-mobs Aura 执行参考视频复刻、还原或反推流程。仅在用户明确要求贴近参考视频时使用，处理自动场景切点、用户指定首尾帧时间、contact sheet 确认、逐段帧映射和视觉 Prompt 还原。
---

# Mobs Replicate

复刻专注于物理切点、逐段映射和忠实度。写图片或视频 Prompt 前同时完整读取 `../mobs-visual-prompting/SKILL.md`。

## 理解与切帧

1. inspect 参考 `Luna.refVideo`，需要功能理解时调用 `analyzeReferenceVideo`。
2. 自动复刻调用 `extractVideoFrames` 的 `scene` 模式，保持默认 `referenceMode: single_frame`，把检测结果只视为候选。scene 返回 N 个起始帧时就是 N 个候选片段，最后一段明确延伸到源视频时长。
3. 用户明确给出时间点时使用手动切帧模式，原样保留其时间点。
4. 展示 operation 产生的 `Sol.contactSheet`、时间戳和片段数，等待用户确认或修正物理切点。

contact sheet 确认是硬检查点；即使用户此前允许连续执行，也不能跳过。真实物理切点与功能阶段分开：功能分析可分组理解，但不能替换、合并、隐藏或重新编号已确认片段。

用户确认后，以确认的边界再次调用 `extractVideoFrames`：`mode: timestamps`，并按制作方式传 `referenceMode: first_frame` 或 `first_last`。此时才创建实际片段、Planner 和 Prompt 占位；确认前不要反推 Prompt 或生成媒体。

手动提供 N 个时间点时，应有 N 个共享边界帧和 N-1 个视频段。每个内部边界帧同时作为前段尾帧和后段首帧，只保留一份 Astra。

## 还原与改编

- 用户未要求改题材时保留参考视频的主体与语义，不自动套用其他题材。
- 保留确认后的顺序、逐段功能、可见动作、状态变化、反馈和回报，只改变用户明确要求的部分。
- 反推内容是证据，不是可直接复制的 Prompt；每段保持真实差异，同时维持共同视觉语言。
- 用 Auralis 切帧产物作为真实 Sol 输入，按 visual prompting Skill 创建独立图片/视频 Prompt 和 links。
- 自动切点通常为逐段独立首帧；手动相邻时间点映射为共享首尾帧。生成前核对帧数、段数、顺序、输入关系与用户改编要求。

切点确认后仍遵守创意、图片、视频软检查点。局部返修只更新受影响的 Prompt、输入或媒体目标，不重做整条流程。
