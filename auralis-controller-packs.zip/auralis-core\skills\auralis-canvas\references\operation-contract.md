# Auralis operation 约定

## Apply envelope

把 JSON 通过 `--operations-file` 传给 `auralis-canvas apply`：

```json
{
  "operations": [
    {
      "id": "create-brief",
      "op": "createAstra",
      "payload": {
        "astra": {
          "family": "Polaris",
          "role": "creativeBrief",
          "content": "可直接编辑的方案正文",
          "meta": {
            "contentSchema": "example.v1"
          }
        }
      }
    }
  ]
}
```

顶层 Aura 与 request id 由 CLI 参数传递。Operation `id` 只用于同批结果引用和诊断，必须在批内唯一。

## 读取与并发更新

读取已有节点后，用 `setAstraContent` 写入已经确定的完整内容：

```json
{
  "operations": [
    {
      "id": "update-prompt",
      "op": "setAstraContent",
      "payload": {
        "target": { "ids": ["<astra-id>"] },
        "content": "完整、独立可执行的 prompt",
        "expectedVersion": 7
      }
    }
  ]
}
```

也可以使用 `expectedContentHash`。二者表示“只在用户尚未修改此版本时写入”，不是失败后可移除的装饰字段。`updateAstraFields` 只合并非正文属性；同样为涉及用户可编辑值的目标附带预期版本。

## 创建、连接与生成

常用 mutation：

- `createAstra`：创建指定 family/role 的 Astra。
- `setAstraContent`：精确写入文本或 prompt，不触发二次生成。
- `updateAstraFields`：更新状态、meta 或其他非正文属性。
- `connectAstra`：建立 prompt、首帧、尾帧或 reference 等输入关系。
- `layoutAstra`：显式布局，不改变用户 selection 或 viewport。
- `generateMedia`：从已经连接的 prompt 与输入生成 Sol 或 Luna 结果。
- `upscaleVideo`：超清一个或多个现有 Luna 视频，产出新的 Luna.genVideo，并以 `upscale` 连线连接源视频。省略 `targetResolution` 时自动按真实源尺寸选档；可显式传 `720p`、`1080p`、`2k` 或 `4k`。
- `extractVideoFrames`：从 Luna 视频创建切帧、参考片段和 contact sheet 产物。
- `analyzeReferenceVideo`：分析 Luna 参考视频并把结果落入 Auralis 状态。

创建后连接时优先使用同批 result selector，避免猜测新节点 id。生成前 inspect 目标节点和 links，确认 prompt、首帧、尾帧与 reference 都是真实存在的输入。

## 失败处理

- `conflict`：用户已修改目标；重新读取，不覆盖。
- `unsupported`：当前 Auralis capability 不支持该动作；说明真实限制。
- `offline`：页面不在线，画布 mutation 会等待或失败；不要在文件系统伪造结果。
- action 失败：保留 prompt 与输入 Astra，报告失败原因，只返修受影响节点。
