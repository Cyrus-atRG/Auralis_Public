'use strict';

const crypto = require('crypto');
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const path = require('path');
const zlib = require('zlib');
const { spawn } = require('child_process');
const { Readable } = require('stream');

const MAX_MANIFEST_BYTES = 2 * 1024 * 1024;
const MAX_COMPONENT_BYTES = 2 * 1024 * 1024 * 1024;
const MAX_EXPANDED_BYTES = 4 * 1024 * 1024 * 1024;
const REQUIRED_COMPONENTS = new Map([
  ['html', 'file'],
  ['runtime', 'zip'],
  ['controller-packs', 'zip']
]);

function isWebLocation(value) {
  return /^https?:\/\//i.test(String(value || ''));
}

function sha256(filePath) {
  const hash = crypto.createHash('sha256');
  const fd = fs.openSync(filePath, 'r');
  const buffer = Buffer.allocUnsafe(1024 * 1024);
  try {
    for (;;) {
      const read = fs.readSync(fd, buffer, 0, buffer.length, null);
      if (!read) break;
      hash.update(buffer.subarray(0, read));
    }
  } finally {
    fs.closeSync(fd);
  }
  return hash.digest('hex');
}

function bundleFingerprint(bundlePath) {
  const root = path.resolve(bundlePath);
  const hash = crypto.createHash('sha256');
  const files = [];
  function visit(directory) {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const absolute = path.join(directory, entry.name);
      const relative = path.relative(root, absolute).replace(/\\/g, '/');
      if (relative === 'Contents/Resources/bootstrap' || relative.startsWith('Contents/Resources/bootstrap/')) continue;
      if (relative === 'Contents/Resources/launcher/bundle-fingerprint') continue;
      if (entry.isSymbolicLink()) throw new Error(`Launcher bundle contains a symbolic link: ${relative}`);
      if (entry.isDirectory()) visit(absolute);
      else if (entry.isFile()) files.push({ absolute, relative });
      else throw new Error(`Launcher bundle contains an unsupported entry: ${relative}`);
    }
  }
  visit(root);
  files.sort((left, right) => left.relative.localeCompare(right.relative, 'en'));
  for (const file of files) {
    const stat = fs.statSync(file.absolute);
    hash.update(file.relative);
    hash.update('\0');
    hash.update(String(stat.size));
    hash.update('\0');
    const fd = fs.openSync(file.absolute, 'r');
    const buffer = Buffer.allocUnsafe(1024 * 1024);
    try {
      for (;;) {
        const read = fs.readSync(fd, buffer, 0, buffer.length, null);
        if (!read) break;
        hash.update(buffer.subarray(0, read));
      }
    } finally {
      fs.closeSync(fd);
    }
    hash.update('\0');
  }
  return hash.digest('hex');
}

function safeChildPath(root, relativePath) {
  if (!relativePath || path.isAbsolute(relativePath)) {
    throw new Error(`Unsafe relative path: ${relativePath || '(empty)'}`);
  }
  const resolvedRoot = path.resolve(root);
  const candidate = path.resolve(resolvedRoot, relativePath);
  const relative = path.relative(resolvedRoot, candidate);
  if (!relative || relative === '..' || relative.startsWith(`..${path.sep}`) || path.isAbsolute(relative)) {
    throw new Error(`Path escapes root: ${relativePath}`);
  }
  return candidate;
}

function componentById(manifest, id) {
  return manifest.components.find(component => component && component.id === id) || null;
}

function validateManifest(manifest, options = {}) {
  if (!manifest || typeof manifest !== 'object') throw new Error('Release manifest is empty.');
  if (manifest.schemaVersion !== 2) throw new Error('macOS launcher requires release manifest schemaVersion 2.');
  if (manifest.platform !== 'macos-arm64') throw new Error('Release manifest platform must be macos-arm64.');
  if (typeof manifest.releaseVersion !== 'string' || !manifest.releaseVersion.trim()) {
    throw new Error('Release manifest is missing releaseVersion.');
  }
  if (!manifest.publishedAt || Number.isNaN(Date.parse(manifest.publishedAt))) {
    throw new Error('Release manifest has an invalid publishedAt.');
  }
  if (!Array.isArray(manifest.changelog) || !manifest.changelog.length
      || manifest.changelog.some(item => typeof item !== 'string' || !item.trim())) {
    throw new Error('Release manifest is missing changelog.');
  }
  if (!Array.isArray(manifest.components) || manifest.components.length < 3) {
    throw new Error('Release manifest is missing components.');
  }

  const seen = new Set();
  for (const component of manifest.components) {
    if (!component || typeof component.id !== 'string' || !component.id || seen.has(component.id)) {
      throw new Error('Release manifest contains a missing or duplicate component id.');
    }
    seen.add(component.id);
    if (typeof component.version !== 'string' || !component.version
        || typeof component.url !== 'string' || !component.url
        || !Number.isSafeInteger(component.size) || component.size <= 0 || component.size > MAX_COMPONENT_BYTES
        || !/^[a-f0-9]{64}$/i.test(component.sha256 || '')
        || !['file', 'zip'].includes(component.format)) {
      throw new Error(`Release component metadata is incomplete: ${component.id}`);
    }
    if (REQUIRED_COMPONENTS.has(component.id) && component.version !== manifest.releaseVersion) {
      throw new Error(`Release component version does not match releaseVersion: ${component.id}`);
    }
  }

  for (const [id, format] of REQUIRED_COMPONENTS) {
    const component = componentById(manifest, id);
    if (!component || component.format !== format) {
      throw new Error(`Release manifest requires ${id} with format ${format}.`);
    }
  }
  const launcher = componentById(manifest, 'launcher');
  if (launcher) {
    if (launcher.format !== 'zip') throw new Error('macOS launcher component must use zip format.');
    if (!Number.isSafeInteger(launcher.executableSize) || launcher.executableSize <= 0
        || !/^[a-f0-9]{64}$/i.test(launcher.executableSha256 || '')
        || !/^[a-f0-9]{64}$/i.test(launcher.bundleSha256 || '')) {
      throw new Error('macOS launcher component is missing executable verification metadata.');
    }
  }

  if (options.remote) {
    for (const component of manifest.components) {
      const resolved = new URL(component.url, options.source);
      if (resolved.protocol !== 'https:') {
        throw new Error('Remote release components must use HTTPS.');
      }
    }
  }
  return manifest;
}

async function readResponseLimited(response, maxBytes) {
  if (!response.ok) {
    const error = new Error(`HTTP ${response.status} while loading ${response.url}`);
    error.statusCode = response.status;
    throw error;
  }
  const contentLength = Number(response.headers.get('content-length') || 0);
  if (contentLength > maxBytes) throw new Error('Response is larger than allowed.');
  const chunks = [];
  let total = 0;
  for await (const chunk of Readable.fromWeb(response.body)) {
    total += chunk.length;
    if (total > maxBytes) throw new Error('Response is larger than allowed.');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks, total);
}

async function loadManifest(location) {
  let raw;
  let remote = false;
  if (isWebLocation(location)) {
    const url = new URL(location);
    if (url.protocol !== 'https:') throw new Error('Remote release manifests must use HTTPS.');
    const response = await fetch(url, {
      redirect: 'follow',
      signal: AbortSignal.timeout(60_000),
      headers: { 'user-agent': 'Auralis-Launcher-macOS/1' }
    });
    if (new URL(response.url).protocol !== 'https:') {
      throw new Error('Remote release manifest redirected away from HTTPS.');
    }
    raw = await readResponseLimited(response, MAX_MANIFEST_BYTES);
    remote = true;
  } else {
    raw = await fsp.readFile(path.resolve(location));
    if (raw.length > MAX_MANIFEST_BYTES) throw new Error('Release manifest is too large.');
  }
  let manifest;
  try {
    manifest = JSON.parse(raw.toString('utf8'));
  } catch (_) {
    throw new Error('Release manifest is not valid JSON.');
  }
  return validateManifest(manifest, { remote, source: location });
}

function resolveArtifact(manifestSource, componentUrl) {
  if (isWebLocation(manifestSource)) {
    const resolved = new URL(componentUrl, manifestSource);
    if (resolved.protocol !== 'https:') throw new Error('Remote release components must use HTTPS.');
    return { remote: true, value: resolved.href };
  }
  const manifestPath = path.resolve(manifestSource);
  return { remote: false, value: safeChildPath(path.dirname(manifestPath), componentUrl) };
}

async function downloadAndVerify(component, manifestSource, destination) {
  await fsp.mkdir(path.dirname(destination), { recursive: true });
  const artifact = resolveArtifact(manifestSource, component.url);
  if (artifact.remote) {
    const response = await fetch(artifact.value, {
      redirect: 'follow',
      signal: AbortSignal.timeout(10 * 60_000),
      headers: { 'user-agent': 'Auralis-Launcher-macOS/1' }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status} while downloading ${component.id}.`);
    if (new URL(response.url).protocol !== 'https:') {
      throw new Error(`Remote ${component.id} redirected away from HTTPS.`);
    }
    const advertised = Number(response.headers.get('content-length') || 0);
    if (advertised && advertised !== component.size) {
      throw new Error(`${component.id} size verification failed.`);
    }
    const temporary = `${destination}.download-${crypto.randomUUID()}`;
    let file;
    try {
      file = await fsp.open(temporary, 'wx', 0o600);
      let downloaded = 0;
      for await (const chunk of Readable.fromWeb(response.body)) {
        downloaded += chunk.length;
        if (downloaded > component.size) throw new Error(`${component.id} exceeded its declared size.`);
        let offset = 0;
        while (offset < chunk.length) {
          const result = await file.write(chunk, offset, chunk.length - offset, null);
          if (!result.bytesWritten) throw new Error(`${component.id} download stopped before completion.`);
          offset += result.bytesWritten;
        }
      }
      await file.sync();
      await file.close();
      file = null;
      if (downloaded !== component.size) throw new Error(`${component.id} size verification failed.`);
      await fsp.rename(temporary, destination);
    } finally {
      if (file) await file.close().catch(() => {});
      await fsp.rm(temporary, { force: true }).catch(() => {});
    }
  } else {
    await fsp.copyFile(artifact.value, destination);
  }
  const stat = await fsp.stat(destination);
  if (stat.size !== component.size) throw new Error(`${component.id} size verification failed.`);
  if (sha256(destination).toLowerCase() !== component.sha256.toLowerCase()) {
    throw new Error(`${component.id} SHA-256 verification failed.`);
  }
}

function listZipEntries(archivePath) {
  const data = fs.readFileSync(archivePath);
  const minEocd = Math.max(0, data.length - 65_557);
  let eocd = -1;
  for (let offset = data.length - 22; offset >= minEocd; offset--) {
    if (data.readUInt32LE(offset) === 0x06054b50) {
      eocd = offset;
      break;
    }
  }
  if (eocd < 0) throw new Error('ZIP end record was not found.');
  const entryCount = data.readUInt16LE(eocd + 10);
  const centralSize = data.readUInt32LE(eocd + 12);
  const centralOffset = data.readUInt32LE(eocd + 16);
  if (entryCount === 0xffff || centralSize === 0xffffffff || centralOffset === 0xffffffff) {
    throw new Error('ZIP64 archives are not supported.');
  }
  if (centralOffset + centralSize > eocd) throw new Error('ZIP central directory is invalid.');

  const entries = [];
  let offset = centralOffset;
  let expanded = 0;
  for (let index = 0; index < entryCount; index++) {
    if (offset + 46 > data.length || data.readUInt32LE(offset) !== 0x02014b50) {
      throw new Error('ZIP central directory entry is invalid.');
    }
    const flags = data.readUInt16LE(offset + 8);
    const method = data.readUInt16LE(offset + 10);
    const compressedSize = data.readUInt32LE(offset + 20);
    const uncompressedSize = data.readUInt32LE(offset + 24);
    const nameLength = data.readUInt16LE(offset + 28);
    const extraLength = data.readUInt16LE(offset + 30);
    const commentLength = data.readUInt16LE(offset + 32);
    const externalAttributes = data.readUInt32LE(offset + 38);
    const localOffset = data.readUInt32LE(offset + 42);
    const nameStart = offset + 46;
    const nameEnd = nameStart + nameLength;
    if (nameEnd > data.length) throw new Error('ZIP entry name is truncated.');
    const encoding = flags & 0x800 ? 'utf8' : 'latin1';
    const name = data.subarray(nameStart, nameEnd).toString(encoding).replace(/\\/g, '/');
    expanded += uncompressedSize;
    if (expanded > MAX_EXPANDED_BYTES) throw new Error('Release archive expands beyond the allowed size.');
    const unixMode = (externalAttributes >>> 16) & 0xffff;
    entries.push({ name, flags, method, compressedSize, uncompressedSize, unixMode, localOffset });
    offset = nameEnd + extraLength + commentLength;
  }
  return entries;
}

function readZipEntry(archivePath, wantedName) {
  const data = fs.readFileSync(archivePath);
  const entry = listZipEntries(archivePath).find(item => item.name === wantedName);
  if (!entry) throw new Error(`ZIP entry was not found: ${wantedName}`);
  if (data.readUInt32LE(entry.localOffset) !== 0x04034b50) throw new Error('ZIP local entry is invalid.');
  const nameLength = data.readUInt16LE(entry.localOffset + 26);
  const extraLength = data.readUInt16LE(entry.localOffset + 28);
  const start = entry.localOffset + 30 + nameLength + extraLength;
  const end = start + entry.compressedSize;
  if (end > data.length) throw new Error('ZIP entry data is truncated.');
  const compressed = data.subarray(start, end);
  if (entry.method === 0) return Buffer.from(compressed);
  if (entry.method === 8) return zlib.inflateRawSync(compressed);
  throw new Error(`Unsupported ZIP compression method: ${entry.method}`);
}

function validateArchive(archivePath, options = {}) {
  const entries = listZipEntries(archivePath);
  let files = 0;
  for (const entry of entries) {
    const name = entry.name;
    if (!name || name.startsWith('/') || name.includes('\0') || /^[A-Za-z]:/.test(name)) {
      throw new Error('Release archive contains an unsafe path.');
    }
    const parts = name.split('/');
    if (parts.some(part => part === '.' || part === '..')) {
      throw new Error('Release archive contains path traversal.');
    }
    if (entry.flags & 0x1) throw new Error('Encrypted ZIP entries are not supported.');
    if ((entry.unixMode & 0o170000) === 0o120000) {
      throw new Error('Release archive contains a symbolic link.');
    }
    if (!name.endsWith('/')) files++;
    if (options.runtime) {
      const forbidden = new Set(['bootstrap', 'controller-packs', 'data', 'overrides', 'releases', 'updates', 'current.json']);
      if (forbidden.has((parts[0] || '').toLowerCase())) {
        throw new Error(`Runtime archive contains a reserved top-level path: ${parts[0]}`);
      }
    }
  }
  if (!files) throw new Error('Release archive does not contain any files.');
  return entries;
}

function run(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {
      cwd: options.cwd,
      env: options.env || process.env,
      stdio: options.stdio || ['ignore', 'pipe', 'pipe']
    });
    let stdout = '';
    let stderr = '';
    if (child.stdout) child.stdout.on('data', chunk => { stdout += chunk.toString(); });
    if (child.stderr) child.stderr.on('data', chunk => { stderr += chunk.toString(); });
    child.once('error', reject);
    child.once('exit', code => {
      if (code === 0) resolve({ stdout, stderr });
      else reject(new Error(`${path.basename(command)} exited ${code}: ${(stderr || stdout).trim()}`));
    });
  });
}

async function extractArchive(archivePath, destination, options = {}) {
  validateArchive(archivePath, options);
  await fsp.mkdir(destination, { recursive: true });
  if (process.platform !== 'darwin') {
    throw new Error('Archive extraction for the macOS launcher must run on macOS.');
  }
  await run('/usr/bin/ditto', ['-x', '-k', '--noqtn', archivePath, destination]);
}

function extractHtmlVersion(htmlPath) {
  if (!fs.existsSync(htmlPath)) return '';
  const match = fs.readFileSync(htmlPath, 'utf8').match(/const\s+AURALIS_VERSION\s*=\s*['"]([^'"]+)['"]/);
  return match ? match[1].trim() : '';
}

function readJson(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (_) {
    return null;
  }
}

function atomicWriteJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temporary = `${filePath}.tmp-${crypto.randomUUID()}`;
  fs.writeFileSync(temporary, `${JSON.stringify(value, null, 2)}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' });
  fs.renameSync(temporary, filePath);
}

function compareComponent(pointer, manifest) {
  const runtime = componentById(manifest, 'runtime');
  const packs = componentById(manifest, 'controller-packs');
  return pointer && pointer.schemaVersion === 1
    && pointer.releaseVersion === manifest.releaseVersion
    && String(pointer.runtimeSha256 || '').toLowerCase() === runtime.sha256.toLowerCase()
    && String(pointer.controllerPacksSha256 || '').toLowerCase() === packs.sha256.toLowerCase();
}

function compareVersions(left, right) {
  const parts = value => String(value || '').trim().replace(/^Auralis\s+/i, '').replace(/^v/i, '').split('.').map(Number);
  const a = parts(left);
  const b = parts(right);
  if ([...a, ...b].some(value => !Number.isFinite(value))) return 0;
  for (let i = 0; i < Math.max(a.length, b.length); i++) {
    const difference = (a[i] || 0) - (b[i] || 0);
    if (difference) return Math.sign(difference);
  }
  return 0;
}

class UpdateEngine {
  constructor(options) {
    this.appDataRoot = path.resolve(options.appDataRoot);
    this.product = options.product || 'canvas';
    if (!['canvas', 'drama'].includes(this.product)) throw new Error('Unknown launcher product.');
    this.supportRoot = path.join(this.appDataRoot, '.launcher', ...(this.product === 'drama' ? ['drama'] : []));
    this.runtimeRoot = path.join(this.supportRoot, 'runtime');
    this.releasesRoot = path.join(this.runtimeRoot, 'releases');
    this.pointerPath = path.join(this.runtimeRoot, 'current.json');
    this.updatesRoot = path.join(this.supportRoot, 'updates');
    this.dataRoot = path.join(this.supportRoot, 'data');
    this.installHtmlPath = path.join(this.appDataRoot, this.product === 'drama' ? 'AuralisDrama.html' : 'Auralis.html');
    this.currentAppBundle = path.resolve(options.currentAppBundle);
    this.currentExecutable = path.resolve(options.currentExecutable);
    this.archiveExtractor = options.archiveExtractor || extractArchive;
    this.afterStep = typeof options.afterStep === 'function' ? options.afterStep : () => {};
    for (const directory of [this.appDataRoot, this.supportRoot, this.releasesRoot, this.updatesRoot, this.dataRoot]) {
      fs.mkdirSync(directory, { recursive: true });
    }
  }

  readPointer() {
    const pointer = readJson(this.pointerPath);
    if (!pointer || pointer.schemaVersion !== 1 || !pointer.directory) return null;
    try {
      safeChildPath(this.releasesRoot, pointer.directory);
      return pointer;
    } catch (_) {
      return null;
    }
  }

  currentRuntimeRoot() {
    const pointer = this.readPointer();
    if (!pointer) return this.runtimeRoot;
    try {
      const candidate = safeChildPath(this.releasesRoot, pointer.directory);
      return fs.existsSync(candidate) ? candidate : this.runtimeRoot;
    } catch (_) {
      return this.runtimeRoot;
    }
  }

  needsContentUpdate(manifest) {
    if (extractHtmlVersion(this.installHtmlPath) !== manifest.releaseVersion) return true;
    const pointer = this.readPointer();
    if (!compareComponent(pointer, manifest)) return true;
    try {
      return !fs.existsSync(safeChildPath(this.releasesRoot, pointer.directory));
    } catch (_) {
      return true;
    }
  }

  needsLauncherUpdate(manifest) {
    const launcher = componentById(manifest, 'launcher');
    if (!launcher || !fs.existsSync(this.currentExecutable)) return false;
    const installed = readJson(path.join(this.currentAppBundle, 'Contents', 'Resources', 'launcher', 'launcher-version.json'));
    if (installed && compareVersions(installed.version, launcher.version) > 0) return false;
    const stat = fs.statSync(this.currentExecutable);
    return stat.size !== launcher.executableSize
      || sha256(this.currentExecutable).toLowerCase() !== launcher.executableSha256.toLowerCase()
      || bundleFingerprint(this.currentAppBundle).toLowerCase() !== launcher.bundleSha256.toLowerCase();
  }

  hasInstalledRelease() {
    return fs.existsSync(this.installHtmlPath) && this.currentRuntimeRoot() !== this.runtimeRoot;
  }

  async checkForUpdate(manifestUrl, bootstrapManifestPath) {
    let remoteError = null;
    if (manifestUrl) {
      try {
        const remote = await loadManifest(manifestUrl);
        if (bootstrapManifestPath && fs.existsSync(bootstrapManifestPath)) {
          try {
            const bundled = await loadManifest(bootstrapManifestPath);
            if (compareVersions(bundled.releaseVersion, remote.releaseVersion) > 0) {
              return this.createCheck(bundled, bootstrapManifestPath, true, 'bundled-newer');
            }
            if (bundled.releaseVersion === remote.releaseVersion
                && Date.parse(bundled.publishedAt) >= Date.parse(remote.publishedAt)
                && manifestPayloadDiffers(remote, bundled)) {
              return this.createCheck(bundled, bootstrapManifestPath, true, 'bundled-variant');
            }
          } catch (_) {
            // A valid remote release remains usable if optional bootstrap metadata is damaged.
          }
        }
        return this.createCheck(remote, manifestUrl, false, '');
      } catch (error) {
        remoteError = error;
      }
    }
    if (bootstrapManifestPath && fs.existsSync(bootstrapManifestPath)) {
      try {
        const bundled = await loadManifest(bootstrapManifestPath);
        return this.createCheck(bundled, bootstrapManifestPath, true, remoteError ? 'offline' : 'not-configured');
      } catch (bootstrapError) {
        throw new Error(`Remote update check failed and bundled release is invalid: ${bootstrapError.message}`);
      }
    }
    if (remoteError) throw remoteError;
    throw new Error('Missing manifestUrl and bootstrap release.');
  }

  createCheck(manifest, source, usedBootstrap, fallbackReason) {
    let contentUpdate = this.needsContentUpdate(manifest);
    const installedVersion = extractHtmlVersion(this.installHtmlPath);
    if (installedVersion && compareVersions(installedVersion, manifest.releaseVersion) > 0) contentUpdate = false;
    if (usedBootstrap && this.hasInstalledRelease()) {
      contentUpdate = compareVersions(installedVersion, manifest.releaseVersion) <= 0 && contentUpdate;
    }
    const launcherUpdate = this.needsLauncherUpdate(manifest);
    return {
      manifest,
      source,
      usedBootstrap,
      fallbackReason,
      contentUpdate,
      launcherUpdate,
      updateAvailable: contentUpdate || launcherUpdate
    };
  }

  async apply(check) {
    validateManifest(check.manifest);
    let launcherUpdate = null;
    if (check.launcherUpdate) launcherUpdate = await this.stageLauncher(check);
    if (!check.contentUpdate) return { launcherUpdate };

    const transactionId = crypto.randomUUID().replace(/-/g, '');
    const stagingRoot = path.join(this.updatesRoot, 'staging', transactionId);
    const downloadsRoot = path.join(stagingRoot, 'downloads');
    const releaseTree = path.join(stagingRoot, 'release');
    const htmlStage = path.join(stagingRoot, 'Auralis.html');
    await fsp.mkdir(downloadsRoot, { recursive: true });
    await fsp.mkdir(releaseTree, { recursive: true });

    let installedRelease = '';
    const htmlBackup = `${this.installHtmlPath}.update-backup-${transactionId}`;
    const pointerBackup = fs.existsSync(this.pointerPath) ? fs.readFileSync(this.pointerPath) : null;
    const htmlExisted = fs.existsSync(this.installHtmlPath);
    let htmlChanged = false;
    let pointerChanged = false;
    try {
      const html = componentById(check.manifest, 'html');
      const runtime = componentById(check.manifest, 'runtime');
      const packs = componentById(check.manifest, 'controller-packs');
      await downloadAndVerify(html, check.source, htmlStage);
      const runtimeArchive = path.join(downloadsRoot, 'runtime.zip');
      await downloadAndVerify(runtime, check.source, runtimeArchive);
      await this.archiveExtractor(runtimeArchive, releaseTree, { runtime: true });
      const packsArchive = path.join(downloadsRoot, 'controller-packs.zip');
      await downloadAndVerify(packs, check.source, packsArchive);
      const packsRoot = path.join(releaseTree, 'controller-packs');
      await this.archiveExtractor(packsArchive, packsRoot);
      this.validateReleaseTree(releaseTree, check.manifest.releaseVersion, htmlStage);

      const safeVersion = check.manifest.releaseVersion.replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '') || 'release';
      const directory = `${safeVersion}-${runtime.sha256.slice(0, 8)}-${packs.sha256.slice(0, 8)}-${transactionId.slice(0, 8)}`;
      installedRelease = safeChildPath(this.releasesRoot, directory);
      await fsp.rename(releaseTree, installedRelease);
      this.afterStep('runtime');

      if (htmlExisted) await fsp.copyFile(this.installHtmlPath, htmlBackup);
      await fsp.rename(htmlStage, this.installHtmlPath);
      htmlChanged = true;
      this.afterStep('html');

      atomicWriteJson(this.pointerPath, {
        schemaVersion: 1,
        releaseVersion: check.manifest.releaseVersion,
        directory,
        runtimeSha256: runtime.sha256.toLowerCase(),
        controllerPacksSha256: packs.sha256.toLowerCase()
      });
      pointerChanged = true;
      this.afterStep('pointer');
      await fsp.rm(htmlBackup, { force: true });
      return { launcherUpdate };
    } catch (error) {
      if (pointerChanged) {
        if (pointerBackup) fs.writeFileSync(this.pointerPath, pointerBackup);
        else await fsp.rm(this.pointerPath, { force: true });
      }
      if (htmlChanged) {
        if (htmlExisted && fs.existsSync(htmlBackup)) await fsp.rename(htmlBackup, this.installHtmlPath);
        else if (!htmlExisted) await fsp.rm(this.installHtmlPath, { force: true });
      }
      if (installedRelease) await fsp.rm(installedRelease, { recursive: true, force: true });
      if (launcherUpdate) await fsp.rm(launcherUpdate.transactionRoot, { recursive: true, force: true });
      throw error;
    } finally {
      await fsp.rm(htmlBackup, { force: true }).catch(() => {});
      await fsp.rm(stagingRoot, { recursive: true, force: true }).catch(() => {});
    }
  }

  validateReleaseTree(releaseTree, expectedVersion, htmlPath) {
    if (extractHtmlVersion(htmlPath) !== expectedVersion) throw new Error('HTML version does not match releaseVersion.');
    if (this.product === 'drama') {
      for (const relative of ['Auralis.html', 'drama-workbench/server.cjs', 'drama-workbench/index.html',
        'drama-workbench/version.json', 'drama-workbench/agents/setting.md', 'drama-workbench/agents/production.md',
        'tools/shared-api-settings.cjs', 'tools/local-codex-bridge.js', 'tools/local-media-bridge.js',
        'controller-packs/auralis-core/pack.json']) {
        if (!fs.existsSync(safeChildPath(releaseTree, relative))) throw new Error(`Runtime release is missing ${relative}.`);
      }
      if (readJson(path.join(releaseTree, 'drama-workbench/version.json'))?.version !== expectedVersion) {
        throw new Error('Drama runtime version does not match releaseVersion.');
      }
      fs.chmodSync(safeChildPath(releaseTree, 'tools/auralis-canvas'), 0o755);
      return;
    }
    const required = [
      'tools/setup-auralis-local.sh',
      'tools/local-media-bridge.js',
      'tools/local-codex-bridge.js',
      'tools/auralis-canvas-cli.js',
      'tools/auralis-canvas',
      'node/bin/node',
      'controller-packs/auralis-core/pack.json',
      'controller-packs/the-mobs/pack.json'
    ];
    for (const relative of required) {
      if (!fs.existsSync(safeChildPath(releaseTree, relative))) {
        throw new Error(`Runtime release is missing ${relative}.`);
      }
    }
    for (const relative of ['tools/setup-auralis-local.sh', 'tools/auralis-canvas', 'node/bin/node']) {
      fs.chmodSync(safeChildPath(releaseTree, relative), 0o755);
    }
  }

  async stageLauncher(check) {
    const launcher = componentById(check.manifest, 'launcher');
    if (!launcher) throw new Error('Launcher update metadata is missing.');
    const transactionId = crypto.randomUUID().replace(/-/g, '');
    const transactionRoot = path.join(this.updatesRoot, 'launcher', transactionId);
    const archive = path.join(transactionRoot, 'Auralis Launcher macOS.zip');
    const extracted = path.join(transactionRoot, 'extracted');
    await fsp.mkdir(transactionRoot, { recursive: true });
    try {
      await downloadAndVerify(launcher, check.source, archive);
      await extractArchive(archive, extracted);
      const stagedBundle = path.join(extracted, 'Auralis Launcher.app');
      const stagedExecutable = path.join(stagedBundle, 'Contents', 'MacOS', 'Auralis Launcher');
      if (!fs.statSync(stagedBundle).isDirectory() || !fs.statSync(stagedExecutable).isFile()) {
        throw new Error('Launcher archive is missing Auralis Launcher.app.');
      }
      const stagedStat = fs.statSync(stagedExecutable);
      if (stagedStat.size !== launcher.executableSize
          || sha256(stagedExecutable).toLowerCase() !== launcher.executableSha256.toLowerCase()
          || bundleFingerprint(stagedBundle).toLowerCase() !== launcher.bundleSha256.toLowerCase()) {
        throw new Error('Staged launcher executable verification failed.');
      }
      const currentStat = fs.statSync(this.currentExecutable);
      return {
        transactionId,
        transactionRoot,
        stagedBundle,
        launcherVersion: launcher.version,
        expectedNewExecutableSize: launcher.executableSize,
        expectedNewExecutableSha256: launcher.executableSha256.toLowerCase(),
        expectedNewBundleSha256: launcher.bundleSha256.toLowerCase(),
        expectedCurrentExecutableSize: currentStat.size,
        expectedCurrentExecutableSha256: sha256(this.currentExecutable).toLowerCase(),
        expectedCurrentBundleSha256: bundleFingerprint(this.currentAppBundle).toLowerCase()
      };
    } catch (error) {
      await fsp.rm(transactionRoot, { recursive: true, force: true });
      throw error;
    }
  }
}

function manifestPayloadDiffers(left, right) {
  const ids = new Set([...left.components.map(item => item.id), ...right.components.map(item => item.id)]);
  for (const id of ids) {
    const a = componentById(left, id);
    const b = componentById(right, id);
    if (!a || !b || a.size !== b.size || a.sha256.toLowerCase() !== b.sha256.toLowerCase()) return true;
  }
  return false;
}

function defaultAppDataRoot() {
  return path.join(os.homedir(), 'Library', 'Application Support', 'Auralis');
}

module.exports = {
  UpdateEngine,
  compareVersions,
  atomicWriteJson,
  bundleFingerprint,
  componentById,
  defaultAppDataRoot,
  downloadAndVerify,
  extractHtmlVersion,
  isWebLocation,
  listZipEntries,
  loadManifest,
  manifestPayloadDiffers,
  readJson,
  readZipEntry,
  resolveArtifact,
  safeChildPath,
  sha256,
  validateArchive,
  validateManifest
};
