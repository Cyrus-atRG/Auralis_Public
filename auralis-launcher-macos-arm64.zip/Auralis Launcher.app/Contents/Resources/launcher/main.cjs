'use strict';

const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { pathToFileURL } = require('url');
const { spawn, spawnSync } = require('child_process');
const { localToolEnvironment } = require('./local-tools.cjs');
const { startDrama } = require('./drama-service.cjs');
const {
  UpdateEngine,
  atomicWriteJson,
  bundleFingerprint,
  defaultAppDataRoot,
  readJson,
  sha256
} = require('./update-engine.cjs');

const launcherResources = __dirname;
const resourcesRoot = path.resolve(launcherResources, '..');
const contentsRoot = path.resolve(resourcesRoot, '..');
const appBundleRoot = path.resolve(contentsRoot, '..');
const currentExecutable = path.join(contentsRoot, 'MacOS', 'Auralis Launcher');
const configPath = path.join(launcherResources, 'config.json');
const versionPath = path.join(launcherResources, 'launcher-version.json');
const appDataRoot = process.env.AURALIS_APP_DATA_ROOT
  ? path.resolve(process.env.AURALIS_APP_DATA_ROOT)
  : defaultAppDataRoot();
let engine = new UpdateEngine({ appDataRoot, currentAppBundle: appBundleRoot, currentExecutable });
let productName = '自由画布';
const tokenPath = path.join(engine.dataRoot, 'bridge-token');
const logsRoot = path.join(engine.dataRoot, 'logs');

function launcherVersion() {
  return String((readJson(versionPath) || {}).version || 'unknown');
}

function loadConfig() {
  const config = readJson(configPath);
  if (!config || typeof config !== 'object') throw new Error('Launcher config.json is missing or invalid.');
  const forbidden = ['localCodexBridgeToken', 'localCodexToken', 'codexBridgeToken', 'localMediaToken'];
  for (const key of forbidden) {
    if (config[key]) throw new Error(`Launcher config must not persist local bridge tokens: ${key}`);
  }
  return config;
}

function ensureToken() {
  fs.mkdirSync(path.dirname(tokenPath), { recursive: true, mode: 0o700 });
  try {
    const saved = fs.readFileSync(tokenPath, 'utf8').trim();
    if (saved) {
      try { fs.chmodSync(tokenPath, 0o600); } catch (_) {}
      return saved;
    }
  } catch (_) {}
  const generated = crypto.randomBytes(32).toString('base64url');
  try {
    fs.writeFileSync(tokenPath, `${generated}\n`, { encoding: 'utf8', mode: 0o600, flag: 'wx' });
    return generated;
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
    return fs.readFileSync(tokenPath, 'utf8').trim();
  }
}

function configServiceRoot(config, key, fallback) {
  return String(config[key] || fallback).replace(/\/v1\/?$/i, '').replace(/\/+$/, '');
}

function launchUrl(config) {
  if (!fs.existsSync(engine.installHtmlPath)) throw new Error('Auralis has not been installed yet.');
  const token = ensureToken();
  const payload = {
    baseUrl: String(config.companyApiUrl || ''),
    telemetryUsageWebhookUrl: String(config.telemetryUsageWebhookUrl || ''),
    telemetryFeedbackWebhookUrl: String(config.telemetryFeedbackWebhookUrl || ''),
    configVersion: String(config.configVersion || ''),
    localCodexBridgeUrl: `${configServiceRoot(config, 'localCodexBridgeUrl', 'http://127.0.0.1:17876')}/v1`,
    localCodexBridgeToken: token,
    localMediaUrl: `${configServiceRoot(config, 'localMediaUrl', 'http://127.0.0.1:17877')}/v1`,
    localMediaToken: token
  };
  return `${pathToFileURL(engine.installHtmlPath).href}#auralis_config=${Buffer.from(JSON.stringify(payload)).toString('base64url')}`;
}

function run(command, args, options = {}) {
  const result = spawnSync(command, args, {
    encoding: 'utf8',
    timeout: options.timeout || 30_000,
    env: options.env || process.env
  });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error((result.stderr || result.stdout || `${command} failed`).trim());
  return String(result.stdout || '').trim();
}

function appleScriptString(value) {
  return `"${String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r?\n/g, '\\n')}"`;
}

function shellQuote(value) {
  return `'${String(value).replace(/'/g, `'\\''`)}'`;
}

function dialog(message, buttons, defaultButton, title = 'Auralis Launcher') {
  if (process.platform !== 'darwin') throw new Error('Launcher dialogs require macOS.');
  const buttonList = buttons.map(appleScriptString).join(', ');
  const script = `button returned of (display dialog ${appleScriptString(message)} with title ${appleScriptString(title)} buttons {${buttonList}} default button ${appleScriptString(defaultButton)} with icon note)`;
  return run('/usr/bin/osascript', ['-e', script]);
}

function notify(message, title = 'Auralis Launcher') {
  if (process.platform !== 'darwin') return;
  try {
    run('/usr/bin/osascript', ['-e', `display notification ${appleScriptString(message)} with title ${appleScriptString(title)}`]);
  } catch (_) {}
}

async function openAuralis(config) {
  const url = engine.product === 'drama' ? await startDrama({
    runtimeRoot: engine.currentRuntimeRoot(), htmlPath: engine.installHtmlPath,
    appDataRoot, nodePath: path.join(launcherResources, 'node'),
    env: localToolEnvironment(engine.currentRuntimeRoot())
  }) : launchUrl(config);
  const child = spawn('/usr/bin/open', [url], {
    detached: true,
    stdio: 'ignore'
  });
  child.unref();
}

async function bridgeStatus(url, token) {
  try {
    const response = await fetch(url, {
      headers: token ? { authorization: `Bearer ${token}` } : {},
      signal: AbortSignal.timeout(2_000)
    });
    return response.ok;
  } catch (_) {
    return false;
  }
}

function spawnBridge(nodePath, scriptPath, logPath, env) {
  fs.mkdirSync(path.dirname(logPath), { recursive: true });
  const output = fs.openSync(logPath, 'a', 0o600);
  const child = spawn(nodePath, [scriptPath], {
    cwd: path.dirname(path.dirname(scriptPath)),
    detached: true,
    env: { ...process.env, ...env },
    stdio: ['ignore', output, output]
  });
  child.unref();
  fs.closeSync(output);
}

async function waitForBridge(url, token) {
  for (let attempt = 0; attempt < 20; attempt++) {
    if (await bridgeStatus(url, token)) return true;
    await new Promise(resolve => setTimeout(resolve, 250));
  }
  return false;
}

async function connectLocalTools(config) {
  const runtimeRoot = engine.currentRuntimeRoot();
  const nodePath = path.join(launcherResources, 'node');
  const toolEnv = localToolEnvironment(runtimeRoot);
  const token = ensureToken();
  if (!fs.existsSync(nodePath)) throw new Error('Auralis runtime is missing its bundled Node.js.');
  const mediaRoot = configServiceRoot(config, 'localMediaUrl', 'http://127.0.0.1:17877');
  const codexRoot = configServiceRoot(config, 'localCodexBridgeUrl', 'http://127.0.0.1:17876');
  const mediaStatus = `${mediaRoot}/v1/status`;
  const codexStatus = `${codexRoot}/v1/status`;
  const results = [];

  if (!(await bridgeStatus(mediaStatus, token))) {
    const ffmpeg = toolEnv.AURALIS_FFMPEG_PATH;
    const mediaUri = new URL(mediaRoot);
    spawnBridge(
      nodePath,
      path.join(runtimeRoot, 'tools', 'local-media-bridge.js'),
      path.join(logsRoot, 'media-bridge.log'),
      {
        ...toolEnv,
        AURALIS_MEDIA_BRIDGE_MAX_BODY_BYTES: '1073741824',
        AURALIS_MEDIA_BRIDGE_TOKEN: token,
        AURALIS_MEDIA_BRIDGE_HOST: mediaUri.hostname,
        AURALIS_MEDIA_BRIDGE_PORT: mediaUri.port || '17877'
      }
    );
    results.push(await waitForBridge(mediaStatus, token)
      ? (ffmpeg ? '媒体工具已连接' : 'API 设置已连接；音视频处理需安装 FFmpeg')
      : '本地服务启动失败（请查看日志）');
  } else {
    results.push('本地服务已连接');
  }

  // The workbench owns its scoped Codex bridge; company mode needs no Codex CLI.
  if (engine.product === 'drama') return results.join('\n');
  if (!(await bridgeStatus(codexStatus, token))) {
    const codex = toolEnv.CODEX_CLI_PATH;
    if (codex) {
      const codexUri = new URL(codexRoot);
      spawnBridge(
        nodePath,
        path.join(runtimeRoot, 'tools', 'local-codex-bridge.js'),
        path.join(logsRoot, 'codex-bridge.log'),
        {
          ...toolEnv,
          CODEX_CLI_PATH: codex,
          AURALIS_DATA_DIR: engine.dataRoot,
          AURALIS_BRIDGE_TOKEN_FILE: tokenPath,
          AURALIS_BRIDGE_URL: codexRoot,
          CREATION_CRAZE_BRIDGE_HOST: codexUri.hostname,
          CREATION_CRAZE_BRIDGE_PORT: codexUri.port || '17876'
        }
      );
      results.push(await waitForBridge(codexStatus, token) ? 'Codex 已连接' : 'Codex 启动失败（请查看日志）');
    } else {
      results.push('未找到 Codex CLI；Codex 桥未启动');
    }
  } else {
    results.push('Codex 已连接');
  }
  return results.join('\n');
}

function bootstrapManifestPath(config) {
  const relative = String(config.bootstrapManifestPath || '');
  if (!relative) return '';
  const candidate = path.resolve(resourcesRoot, relative);
  const relation = path.relative(resourcesRoot, candidate);
  if (relation === '..' || relation.startsWith(`..${path.sep}`) || path.isAbsolute(relation)) {
    throw new Error('bootstrapManifestPath escapes launcher resources.');
  }
  return candidate;
}

function writePostUpdateAck(args) {
  const index = args.indexOf('--post-update-ack');
  if (index < 0 || !args[index + 1]) return;
  const ackPath = path.resolve(args[index + 1]);
  const expectedRoot = path.resolve(engine.updatesRoot, 'launcher');
  const relation = path.relative(expectedRoot, ackPath);
  if (relation === '..' || relation.startsWith(`..${path.sep}`) || path.isAbsolute(relation)) {
    throw new Error('Post-update acknowledgement path is outside the launcher update root.');
  }
  atomicWriteJson(ackPath, {
    schemaVersion: 1,
    launcherVersion: launcherVersion(),
    executableSha256: sha256(currentExecutable),
    bundleSha256: bundleFingerprint(appBundleRoot),
    pid: process.pid,
    acknowledgedAt: new Date().toISOString()
  });
}

function startLauncherUpdater(staged) {
  const runnerRoot = path.join(staged.transactionRoot, 'updater-run');
  fs.mkdirSync(runnerRoot, { recursive: true });
  const runnerNode = path.join(runnerRoot, 'node');
  const runnerScript = path.join(runnerRoot, 'updater.cjs');
  fs.copyFileSync(path.join(launcherResources, 'node'), runnerNode);
  fs.copyFileSync(path.join(launcherResources, 'updater.cjs'), runnerScript);
  fs.chmodSync(runnerNode, 0o755);
  fs.chmodSync(runnerScript, 0o644);
  const planPath = path.join(staged.transactionRoot, 'update-plan.json');
  const ackPath = path.join(staged.transactionRoot, 'startup-ack.json');
  atomicWriteJson(planPath, {
    schemaVersion: 1,
    transactionRoot: staged.transactionRoot,
    stagedBundle: staged.stagedBundle,
    targetBundle: appBundleRoot,
    targetExecutable: currentExecutable,
    expectedCurrentExecutableSize: staged.expectedCurrentExecutableSize,
    expectedCurrentExecutableSha256: staged.expectedCurrentExecutableSha256,
    expectedCurrentBundleSha256: staged.expectedCurrentBundleSha256,
    expectedNewExecutableSize: staged.expectedNewExecutableSize,
    expectedNewExecutableSha256: staged.expectedNewExecutableSha256,
    expectedNewBundleSha256: staged.expectedNewBundleSha256,
    launcherVersion: staged.launcherVersion,
    parentPid: process.pid,
    userUid: typeof process.getuid === 'function' ? process.getuid() : -1,
    ackPath
  });

  let parentWritable = true;
  try {
    fs.accessSync(path.dirname(appBundleRoot), fs.constants.W_OK);
  } catch (_) {
    parentWritable = false;
  }
  if (parentWritable) {
    const child = spawn(runnerNode, [runnerScript, '--plan', planPath], {
      detached: true,
      stdio: 'ignore'
    });
    child.unref();
    return;
  }

  const command = [runnerNode, runnerScript, '--plan', planPath].map(shellQuote).join(' ');
  const script = `do shell script ${appleScriptString(command)} with administrator privileges`;
  const child = spawn('/usr/bin/osascript', ['-e', script], {
    detached: true,
    stdio: 'ignore'
  });
  child.unref();
}

function releaseSummary(check) {
  const changes = check.manifest.changelog.slice(0, 6).map(item => `• ${item}`).join('\n');
  const launcherLine = check.launcherUpdate ? '\n\n启动器本身也会安全更新并自动重启。' : '';
  return `当前${productName}：${extractInstalledVersion() || '未安装'}\n可用版本：${check.manifest.releaseVersion}${launcherLine}\n\n${changes}`;
}

function extractInstalledVersion() {
  try {
    const html = fs.readFileSync(engine.installHtmlPath, 'utf8');
    return (html.match(/const\s+AURALIS_VERSION\s*=\s*['"]([^'"]+)['"]/) || [])[1] || '';
  } catch (_) {
    return '';
  }
}

async function runSmokeReport(destination) {
  const config = loadConfig();
  const report = {
    schemaVersion: 1,
    platform: process.platform,
    arch: process.arch,
    appBundleRoot,
    appDataRoot,
    installHtmlPath: engine.installHtmlPath,
    runtimeRoot: engine.currentRuntimeRoot(),
    manifestUrl: config.manifestUrl,
    bootstrapManifestPath: bootstrapManifestPath(config),
    dramaManifestUrl: config.dramaManifestUrl,
    dramaBootstrapManifestPath: config.dramaBootstrapManifestPath,
    launcherVersion: launcherVersion(),
    currentExecutableExists: fs.existsSync(currentExecutable),
    configHasPersistedToken: ['localCodexBridgeToken', 'localCodexToken', 'codexBridgeToken', 'localMediaToken'].some(key => Boolean(config[key]))
  };
  atomicWriteJson(path.resolve(destination), report);
}

async function main() {
  const args = process.argv.slice(2);
  const smokeIndex = args.indexOf('--smoke-report');
  if (smokeIndex >= 0) {
    if (!args[smokeIndex + 1]) throw new Error('--smoke-report requires an output path.');
    await runSmokeReport(args[smokeIndex + 1]);
    return;
  }
  writePostUpdateAck(args);
  if (process.platform !== 'darwin') throw new Error('Auralis Launcher for macOS can only run on macOS.');

  let config = loadConfig();
  const product = args.includes('--drama') ? '短剧工作台' : args.includes('--canvas') ? '自由画布'
    : dialog('选择要打开的工作区。', ['退出', '自由画布', '短剧工作台'], '短剧工作台');
  if (product === '退出') return;
  if (product === '短剧工作台') {
    productName = product;
    engine = new UpdateEngine({ appDataRoot, currentAppBundle: appBundleRoot, currentExecutable, product: 'drama' });
    config = { ...config, manifestUrl: config.dramaManifestUrl, bootstrapManifestPath: config.dramaBootstrapManifestPath };
  }
  ensureToken();
  let check;
  try {
    check = await engine.checkForUpdate(config.manifestUrl, bootstrapManifestPath(config));
  } catch (error) {
    if (!fs.existsSync(engine.installHtmlPath)) throw error;
    const choice = dialog(`更新检查失败，但已安装的 Auralis 仍可打开。\n\n${error.message}`, ['退出', '打开现有版本'], '打开现有版本');
    if (choice === '打开现有版本') {
      await connectLocalTools(config).catch(() => '');
      await openAuralis(config);
    }
    return;
  }

  if (check.updateAvailable) {
    const hasCurrent = fs.existsSync(engine.installHtmlPath);
    const buttons = hasCurrent ? ['退出', '先打开现有版本', '更新并打开'] : ['退出', '安装'];
    const choice = dialog(releaseSummary(check), buttons, hasCurrent ? '更新并打开' : '安装');
    if (choice === '退出') return;
    if (choice === '先打开现有版本') {
      await connectLocalTools(config).catch(() => '');
      await openAuralis(config);
      return;
    }
    const result = await engine.apply(check);
    if (result.launcherUpdate) {
      startLauncherUpdater(result.launcherUpdate);
      return;
    }
    notify(`${productName} ${check.manifest.releaseVersion} 已安装`);
    await connectLocalTools(config).catch(() => '');
    await openAuralis(config);
    return;
  }

  const choice = dialog(
    `${productName} ${extractInstalledVersion() || check.manifest.releaseVersion} 已就绪。\n\n打开并连接会同时启用共享 API 设置和可用的本地工具。`,
    ['退出', '只打开', '打开并连接'],
    '打开并连接'
  );
  if (choice === '只打开') {
    await openAuralis(config);
  } else if (choice === '打开并连接') {
    const result = await connectLocalTools(config);
    notify(result);
    await openAuralis(config);
  }
}

main().catch(error => {
  if (process.platform === 'darwin') {
    try {
      dialog(`操作失败：\n\n${error.message}`, ['确定'], '确定');
      return;
    } catch (_) {}
  }
  console.error(error.stack || error.message || error);
  process.exitCode = 1;
});
