'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const crypto = require('crypto');

function sha256(filePath) {
  const hash = crypto.createHash('sha256');
  const fd = fs.openSync(filePath, 'r');
  const buffer = Buffer.allocUnsafe(1024 * 1024);
  try {
    for (;;) {
      const read = fs.readSync(fd, buffer, 0, buffer.length, null);
      if (!read) break;
      hash.update(buffer.subarray(0, read));
    }
  } finally {
    fs.closeSync(fd);
  }
  return hash.digest('hex');
}

function bundleFingerprint(bundlePath) {
  const root = path.resolve(bundlePath);
  const hash = crypto.createHash('sha256');
  const files = [];
  function visit(directory) {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const absolute = path.join(directory, entry.name);
      const relative = path.relative(root, absolute).replace(/\\/g, '/');
      if (relative === 'Contents/Resources/bootstrap' || relative.startsWith('Contents/Resources/bootstrap/')) continue;
      if (relative === 'Contents/Resources/launcher/bundle-fingerprint') continue;
      if (entry.isSymbolicLink()) throw new Error(`Launcher bundle contains a symbolic link: ${relative}`);
      if (entry.isDirectory()) visit(absolute);
      else if (entry.isFile()) files.push({ absolute, relative });
      else throw new Error(`Launcher bundle contains an unsupported entry: ${relative}`);
    }
  }
  visit(root);
  files.sort((left, right) => left.relative.localeCompare(right.relative, 'en'));
  for (const file of files) {
    const stat = fs.statSync(file.absolute);
    hash.update(file.relative);
    hash.update('\0');
    hash.update(String(stat.size));
    hash.update('\0');
    hash.update(fs.readFileSync(file.absolute));
    hash.update('\0');
  }
  return hash.digest('hex');
}

function isInside(root, candidate) {
  const relation = path.relative(path.resolve(root), path.resolve(candidate));
  return relation && relation !== '..' && !relation.startsWith(`..${path.sep}`) && !path.isAbsolute(relation);
}

function assertNoSymlinks(root) {
  const stack = [path.resolve(root)];
  while (stack.length) {
    const current = stack.pop();
    const stat = fs.lstatSync(current);
    if (stat.isSymbolicLink()) throw new Error(`Launcher bundle contains a symbolic link: ${current}`);
    if (!stat.isDirectory()) continue;
    for (const entry of fs.readdirSync(current)) stack.push(path.join(current, entry));
  }
}

function bundleExecutable(bundlePath) {
  return path.join(bundlePath, 'Contents', 'MacOS', 'Auralis Launcher');
}

function validateBundle(bundlePath, expectedSize, expectedHash, expectedBundleHash, requireCanonicalName = true) {
  const resolved = path.resolve(bundlePath);
  if (requireCanonicalName && path.basename(resolved) !== 'Auralis Launcher.app') {
    throw new Error('Unexpected launcher bundle name.');
  }
  assertNoSymlinks(resolved);
  const plist = path.join(resolved, 'Contents', 'Info.plist');
  const executable = bundleExecutable(resolved);
  if (!fs.statSync(plist).isFile() || !fs.statSync(executable).isFile()) {
    throw new Error('Launcher bundle structure is incomplete.');
  }
  const plistText = fs.readFileSync(plist, 'utf8');
  if (!/<string>ai\.auralis\.launcher<\/string>/.test(plistText)) {
    throw new Error('Launcher bundle identifier is invalid.');
  }
  const stat = fs.statSync(executable);
  if (stat.size !== expectedSize || sha256(executable).toLowerCase() !== String(expectedHash).toLowerCase()) {
    throw new Error('Launcher executable verification failed.');
  }
  if (bundleFingerprint(resolved).toLowerCase() !== String(expectedBundleHash).toLowerCase()) {
    throw new Error('Launcher bundle verification failed.');
  }
}

function validatePlan(planPath, plan) {
  if (!plan || plan.schemaVersion !== 1) throw new Error('Launcher update plan is invalid.');
  const requiredStrings = [
    'transactionRoot',
    'stagedBundle',
    'targetBundle',
    'targetExecutable',
    'expectedCurrentExecutableSha256',
    'expectedNewExecutableSha256',
    'expectedCurrentBundleSha256',
    'expectedNewBundleSha256',
    'launcherVersion',
    'ackPath'
  ];
  for (const key of requiredStrings) {
    if (typeof plan[key] !== 'string' || !plan[key]) throw new Error(`Launcher update plan is missing ${key}.`);
  }
  for (const key of ['expectedCurrentExecutableSize', 'expectedNewExecutableSize', 'parentPid', 'userUid']) {
    if (!Number.isInteger(plan[key])) throw new Error(`Launcher update plan is missing ${key}.`);
  }
  if (!/^[a-f0-9]{64}$/i.test(plan.expectedCurrentExecutableSha256)
      || !/^[a-f0-9]{64}$/i.test(plan.expectedNewExecutableSha256)
      || !/^[a-f0-9]{64}$/i.test(plan.expectedCurrentBundleSha256)
      || !/^[a-f0-9]{64}$/i.test(plan.expectedNewBundleSha256)) {
    throw new Error('Launcher update plan contains an invalid hash.');
  }

  const transactionRoot = path.resolve(plan.transactionRoot);
  const normalized = transactionRoot.replace(/\\/g, '/');
  if (!/\/Library\/Application Support\/Auralis\/\.launcher\/updates\/launcher\/[a-f0-9]{32}$/.test(normalized)) {
    throw new Error('Launcher transaction root is outside the allowed update location.');
  }
  if (path.resolve(planPath) !== path.join(transactionRoot, 'update-plan.json')) {
    throw new Error('Launcher update plan path is invalid.');
  }
  if (!isInside(transactionRoot, plan.stagedBundle) || !isInside(transactionRoot, plan.ackPath)) {
    throw new Error('Launcher update staging path escapes the transaction root.');
  }
  if (path.basename(path.resolve(plan.targetBundle)) !== 'Auralis Launcher.app') {
    throw new Error('Launcher target bundle name is invalid.');
  }
  if (path.resolve(plan.targetExecutable) !== bundleExecutable(path.resolve(plan.targetBundle))) {
    throw new Error('Launcher target executable path is invalid.');
  }
  if (isInside(transactionRoot, plan.targetBundle) || isInside(plan.targetBundle, transactionRoot)) {
    throw new Error('Launcher target overlaps its update transaction.');
  }
  const transactionStat = fs.statSync(transactionRoot);
  if (process.platform === 'darwin' && plan.userUid >= 0 && transactionStat.uid !== plan.userUid) {
    throw new Error('Launcher update transaction owner does not match the requesting user.');
  }
  return plan;
}

function waitForExit(pid, timeoutMs = 60_000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      process.kill(pid, 0);
    } catch (error) {
      if (error.code === 'ESRCH') return;
      throw error;
    }
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 250);
  }
  throw new Error('Timed out waiting for the old launcher to exit.');
}

function run(command, args) {
  const result = spawnSync(command, args, { encoding: 'utf8', timeout: 120_000 });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error((result.stderr || result.stdout || `${command} failed`).trim());
}

function copyBundle(source, destination) {
  if (process.platform === 'darwin') {
    run('/usr/bin/ditto', ['--noqtn', source, destination]);
    return;
  }
  fs.cpSync(source, destination, { recursive: true, errorOnExist: true, force: false });
}

function relaunch(bundlePath, ackPath, userUid) {
  const args = ['-n', bundlePath, '--args', '--post-update-ack', ackPath];
  if (typeof process.getuid === 'function' && process.getuid() === 0 && userUid > 0) {
    run('/bin/launchctl', ['asuser', String(userUid), '/usr/bin/open', ...args]);
  } else {
    run('/usr/bin/open', args);
  }
}

function waitForAck(ackPath, expectedHash, expectedBundleHash, timeoutMs = 30_000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    try {
      const ack = JSON.parse(fs.readFileSync(ackPath, 'utf8'));
      if (ack.schemaVersion === 1
          && String(ack.executableSha256 || '').toLowerCase() === expectedHash.toLowerCase()
          && String(ack.bundleSha256 || '').toLowerCase() === expectedBundleHash.toLowerCase()) {
        return true;
      }
    } catch (_) {}
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 250);
  }
  return false;
}

function applyUpdate(planPath, options = {}) {
  const plan = validatePlan(planPath, JSON.parse(fs.readFileSync(planPath, 'utf8')));
  const transactionRoot = path.resolve(plan.transactionRoot);
  const target = path.resolve(plan.targetBundle);
  const parent = path.dirname(target);
  const replacement = path.join(parent, `.Auralis Launcher.update-${plan.launcherVersion}-${plan.transactionRoot.slice(-8)}.app`);
  const oldTarget = path.join(parent, `.Auralis Launcher.previous-${plan.transactionRoot.slice(-8)}.app`);
  const backup = path.join(transactionRoot, 'backup', 'Auralis Launcher.app');

  if (options.skipParentWait !== true) waitForExit(plan.parentPid, options.parentWaitMs || 60_000);
  validateBundle(target, plan.expectedCurrentExecutableSize, plan.expectedCurrentExecutableSha256, plan.expectedCurrentBundleSha256);
  validateBundle(plan.stagedBundle, plan.expectedNewExecutableSize, plan.expectedNewExecutableSha256, plan.expectedNewBundleSha256);
  if (fs.existsSync(replacement) || fs.existsSync(oldTarget) || fs.existsSync(backup)) {
    throw new Error('Launcher update temporary target already exists.');
  }

  fs.mkdirSync(path.dirname(backup), { recursive: true });
  copyBundle(target, backup);
  validateBundle(backup, plan.expectedCurrentExecutableSize, plan.expectedCurrentExecutableSha256, plan.expectedCurrentBundleSha256, false);
  copyBundle(plan.stagedBundle, replacement);
  validateBundle(replacement, plan.expectedNewExecutableSize, plan.expectedNewExecutableSha256, plan.expectedNewBundleSha256, false);

  let targetMoved = false;
  let replacementMoved = false;
  try {
    fs.renameSync(target, oldTarget);
    targetMoved = true;
    fs.renameSync(replacement, target);
    replacementMoved = true;
    validateBundle(target, plan.expectedNewExecutableSize, plan.expectedNewExecutableSha256, plan.expectedNewBundleSha256);
    if (options.failAfterReplacement === true) throw new Error('Injected post-replacement failure.');
    if (options.skipRelaunch !== true) {
      relaunch(target, plan.ackPath, plan.userUid);
      if (!waitForAck(plan.ackPath, plan.expectedNewExecutableSha256, plan.expectedNewBundleSha256, options.ackWaitMs || 30_000)) {
        throw new Error('Updated launcher did not acknowledge startup.');
      }
    }
    fs.rmSync(oldTarget, { recursive: true, force: true });
    fs.rmSync(transactionRoot, { recursive: true, force: true });
    return { updated: true, target };
  } catch (error) {
    try {
      if (replacementMoved && fs.existsSync(target)) fs.rmSync(target, { recursive: true, force: true });
      if (targetMoved && fs.existsSync(oldTarget)) fs.renameSync(oldTarget, target);
      else if (!fs.existsSync(target) && fs.existsSync(backup)) copyBundle(backup, target);
      validateBundle(target, plan.expectedCurrentExecutableSize, plan.expectedCurrentExecutableSha256, plan.expectedCurrentBundleSha256);
      if (options.skipRelaunch !== true) {
        const args = ['-n', target];
        if (typeof process.getuid === 'function' && process.getuid() === 0 && plan.userUid > 0) {
          run('/bin/launchctl', ['asuser', String(plan.userUid), '/usr/bin/open', ...args]);
        } else {
          run('/usr/bin/open', args);
        }
      }
    } catch (rollbackError) {
      error.message += ` Rollback also failed: ${rollbackError.message}`;
    }
    throw error;
  } finally {
    if (fs.existsSync(replacement)) fs.rmSync(replacement, { recursive: true, force: true });
  }
}

function main() {
  const index = process.argv.indexOf('--plan');
  if (index < 0 || !process.argv[index + 1]) throw new Error('--plan is required.');
  applyUpdate(path.resolve(process.argv[index + 1]));
}

if (require.main === module) {
  try {
    main();
  } catch (error) {
    console.error(error.stack || error.message || error);
    process.exitCode = 1;
  }
}

module.exports = {
  applyUpdate,
  assertNoSymlinks,
  bundleFingerprint,
  bundleExecutable,
  isInside,
  sha256,
  validateBundle,
  validatePlan,
  waitForAck,
  waitForExit
};
