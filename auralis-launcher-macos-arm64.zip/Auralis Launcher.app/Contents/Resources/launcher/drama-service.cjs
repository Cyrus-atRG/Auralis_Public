'use strict';

const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { atomicWriteJson, readJson } = require('./update-engine.cjs');
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));

async function startDrama(options) {
  const { runtimeRoot, htmlPath, appDataRoot, nodePath, env = {} } = options;
  const base = `http://127.0.0.1:${options.port || 17887}`;
  const pointer = path.join(appDataRoot, '.launcher', 'drama-data.json');
  const request = async (route, init) => {
    const response = await fetch(base + route, { ...init, signal: AbortSignal.timeout(3_000) });
    if (!response.ok) throw new Error(`工作台请求失败：${response.status}`);
    return response.json();
  };
  const status = () => request('/launcher/status').catch(() => null);
  let dataRoot = path.join(appDataRoot, '.launcher', 'drama', 'data');
  const saved = readJson(pointer);
  if (saved?.root && fs.existsSync(saved.root)) dataRoot = path.resolve(saved.root);
  const current = await status();
  if (current?.app === 'auralis-drama') {
    if (current.dataRoot) dataRoot = path.resolve(current.dataRoot);
    atomicWriteJson(pointer, { root: dataRoot });
    if (current.runtimeRoot === runtimeRoot || current.active) return base;
    const bootstrap = await request('/api/bootstrap');
    await request('/api/shutdown', { method: 'POST', headers: { authorization: `Bearer ${bootstrap.token}`, 'content-type': 'application/json' }, body: '{}' });
    const deadline = Date.now() + 30_000;
    while (await status()) {
      if (Date.now() >= deadline) throw new Error('旧工作台尚未关闭，请稍后重试。');
      await pause(200);
    }
  } else if (await request('/api/bootstrap').catch(() => null)) {
    // Older services have no launcher status endpoint. Preserve their work.
    return base;
  }
  const script = path.join(runtimeRoot, 'drama-workbench', 'server.cjs');
  if (![script, nodePath, htmlPath].every(file => fs.existsSync(file))) throw new Error('短剧工作台安装不完整，请重新更新。');
  fs.mkdirSync(dataRoot, { recursive: true, mode: 0o700 });
  atomicWriteJson(pointer, { root: dataRoot });
  const output = fs.openSync(path.join(dataRoot, 'server.log'), 'a', 0o600);
  const errorOutput = fs.openSync(path.join(dataRoot, 'server-error.log'), 'a', 0o600);
  let child;
  try {
    child = spawn(nodePath, [script], {
      cwd: runtimeRoot, detached: true, windowsHide: true,
      env: { ...process.env, ...env, AURALIS_DRAMA_PORT: String(options.port || 17887), AURALIS_DRAMA_DATA_DIR: dataRoot, AURALIS_DRAMA_HTML: htmlPath },
      stdio: ['ignore', output, errorOutput]
    });
  } finally {
    fs.closeSync(output); fs.closeSync(errorOutput);
  }
  let failure;
  child.once('error', error => { failure = error; });
  child.once('exit', code => { failure = new Error(`短剧工作台启动失败（${code}），请查看 ${path.join(dataRoot, 'server-error.log')}。`); });
  child.unref();
  const deadline = Date.now() + 30_000;
  while (Date.now() < deadline) {
    if (failure) throw failure;
    const ready = await status();
    if (ready?.runtimeRoot === runtimeRoot) return base;
    await pause(250);
  }
  throw new Error('短剧工作台启动超时，请查看数据文件夹中的 server-error.log。');
}

module.exports = { startDrama };
