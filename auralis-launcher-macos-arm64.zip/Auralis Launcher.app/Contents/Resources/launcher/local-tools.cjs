'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');

// Finder does not inherit the interactive shell's Homebrew/npm PATH.
function localToolEnvironment(runtimeRoot, env = process.env, home = os.homedir()) {
  const directories = [...new Set([
    path.dirname(process.execPath),
    path.join(runtimeRoot, 'tools', 'bin'), path.join(runtimeRoot, 'tools'),
    '/opt/homebrew/bin', '/usr/local/bin', path.join(home, '.local', 'bin'),
    path.join(home, '.npm-global', 'bin'), ...(env.PATH || '/usr/bin:/bin:/usr/sbin:/sbin').split(':')
  ])];
  const find = (name, explicit, extra = []) => [explicit, ...directories.map(dir => path.join(dir, name)), ...extra]
    .find(file => {
      if (!file) return false;
      try { fs.accessSync(file, fs.constants.X_OK); return fs.statSync(file).isFile(); } catch (_) { return false; }
    }) || '';
  const ffmpeg = find('ffmpeg', env.AURALIS_FFMPEG_PATH || env.FFMPEG_PATH);
  const ffprobe = find('ffprobe', env.FFPROBE_PATH, ffmpeg ? [path.join(path.dirname(ffmpeg), 'ffprobe')] : []);
  const codex = find('codex', env.CODEX_CLI_PATH, [
    '/Applications/Codex.app/Contents/Resources/codex',
    '/Applications/ChatGPT.app/Contents/Resources/codex',
    '/Applications/Codex.app/Contents/MacOS/codex',
    path.join(home, 'Applications', 'Codex.app', 'Contents', 'Resources', 'codex')
  ]);
  return {
    PATH: directories.join(':'),
    AURALIS_NODE_PATH: process.execPath,
    ...(ffmpeg ? { FFMPEG_PATH: ffmpeg, AURALIS_FFMPEG_PATH: ffmpeg } : {}),
    ...(ffprobe ? { FFPROBE_PATH: ffprobe } : {}),
    ...(codex ? { CODEX_CLI_PATH: codex } : {})
  };
}

module.exports = { localToolEnvironment };
