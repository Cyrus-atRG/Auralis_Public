const fs = require("node:fs"), path = require("node:path"), crypto = require("node:crypto");
const { execFile } = require("node:child_process"), { promisify } = require("node:util");
const { mediaFile, cachedImage, ffmpeg } = require("./asset-images.cjs");
const { FileInput } = require("./media-transfer.cjs");
const { videoReferenceImageMaxDimension: maxDimension } = require("./generation.cjs");
const exec = promisify(execFile);
const stamp = stat => [stat.dev, stat.ino, stat.size, stat.mtimeNs, stat.ctimeNs].join(":");
const targetBytes = 1350000; // About 1.8M Base64 characters, like the canvas's small-image threshold.

// The embedded canvas delegates media transport to the backend. Prepare its
// local video references here, without changing the pinned original media.
async function videoImageInput(projectDir, media) {
  const source = mediaFile(projectDir, media), original = new FileInput(source, media.mime);
  try {
    const stat = await fs.promises.stat(source, { bigint: true });
    const key = crypto.createHash("sha256").update([source, stamp(stat), maxDimension, targetBytes, "jpeg-q2-white-v2"].join(":")).digest("hex");
    const file = path.join(projectDir, "media", "video-reference-" + key + ".jpg");
    const { stdout } = await exec(process.env.AURALIS_FFPROBE_PATH || process.env.FFPROBE_PATH || "ffprobe",
      ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,pix_fmt", "-of", "json", source],
      { encoding: "utf8", windowsHide: true, timeout: 20000, maxBuffer: 65536 });
    const { width, height, pix_fmt: pixelFormat } = JSON.parse(stdout).streams?.[0] || {};
    if (!(width > 0 && height > 0)) throw new Error("无法读取图片分辨率");
    const oversized = Math.max(width, height) > maxDimension;
    if (original.size < targetBytes) return original;
    await cachedImage(file, async output => {
      const scale = `scale='min(${maxDimension},iw)':'min(${maxDimension},ih)':force_original_aspect_ratio=decrease:flags=lanczos`;
      const alpha = /^(rgba|bgra|argb|abgr|ya\d|gbrap|yuva|pal8)/.test(pixelFormat || "");
      const filter = alpha
        ? "format=rgba,split[fg][bg];[bg]drawbox=c=white:t=fill:replace=1[white];[white][fg]overlay=shortest=1:format=auto,format=yuvj444p"
        : "format=yuvj444p";
      const render = resize => ffmpeg(["-threads", "1", "-i", source, "-filter_complex_threads", "1", "-filter_complex", (resize ? scale + "," : "") + filter,
        "-frames:v", "1", "-q:v", "2", "-threads", "1", output]);
      // Preserve reference detail first; only resize if high-quality JPEG is still large.
      await render(false);
      if (oversized && (await fs.promises.stat(output)).size > targetBytes) await render(true);
      if (stamp(await fs.promises.stat(source, { bigint: true })) !== stamp(stat)) throw new Error("参考文件已改变，请重新提交");
    });
    const prepared = new FileInput(file, "image/jpeg");
    return prepared.size >= original.size ? original : prepared;
  } catch (error) {
    throw Object.assign(new Error("视频参考图处理失败：" + error.message, { cause: error }), { code: "invalid", definite: true });
  }
}

module.exports = { videoImageInput };
