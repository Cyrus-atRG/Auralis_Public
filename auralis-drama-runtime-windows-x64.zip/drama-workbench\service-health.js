(() => {
  const status = document.getElementById("serviceStatus");
  const label = document.getElementById("serviceLabel");
  const notice = document.getElementById("serviceNotice");
  const detail = document.getElementById("serviceNoticeText");
  const retry = document.getElementById("serviceRetry");
  let instanceId = "", checking = false, timer;

  function show(state) {
    const previous = status.dataset.state;
    status.dataset.state = state;
    label.textContent = { connecting: "正在连接后台", online: "后台已连接", offline: "后台已断开", restarted: "后台已重启" }[state];
    notice.hidden = state === "online" || state === "connecting";
    detail.textContent = state === "restarted"
      ? "后台已重启。请先复制未保存的文字，再刷新页面继续。"
      : "无法连接后台，任务状态暂时无法更新。请从启动器重新打开短剧工作台。";
    retry.textContent = state === "restarted" ? "刷新页面" : "重新连接";
    if (state === "offline" && previous !== "offline") toast(detail.textContent, true);
  }

  async function check() {
    if (checking) return;
    checking = true;
    clearTimeout(timer);
    retry.disabled = true;
    try {
      const response = await fetch("/api/health", { cache: "no-store", signal: AbortSignal.timeout(4000) });
      if (!response.ok) throw new Error("health check failed");
      const health = await response.json();
      if (health.app !== "auralis-drama" || !health.instanceId) throw new Error("invalid health response");
      show(instanceId && instanceId !== health.instanceId ? "restarted" : "online");
      instanceId ||= health.instanceId;
    } catch {
      show("offline");
    } finally {
      checking = false;
      retry.disabled = false;
      timer = setTimeout(check, 5000);
    }
  }

  retry.addEventListener("click", () => {
    if (status.dataset.state === "restarted") location.reload();
    else check();
  });
  window.addEventListener("auralis:service-offline", () => show("offline"));
  window.addEventListener("online", check);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) check(); });
  check();
})();
