const fs = require("node:fs");
const path = require("node:path");
const { Script } = require("node:vm");

// Auralis.html remains the source of truth. Serve only its viewer functions,
// model controls and styles, without shipping the canvas/controller/DB boot.
// Explicit boundaries fail closed on source drift; browser tests exercise the
// resulting entry point against the same review/generation contract as canvas.
function section(source, start, end) {
  const from = source.indexOf(start), to = source.indexOf(end, from + start.length);
  if (from < 0 || to < 0) throw new Error("Missing viewer source section: " + start);
  return source.slice(from, to);
}

const functions = `
  escapeHtml arrayFrom uniqueIds uniqueNodes nowText
  assetDisplayUrl normalizeMediaUrl normalizeDataUrl dataUrlFromBase64 compactBase64Payload
  nodeHasAsset isImageAstra isVideoAstra isAudioAstra isPreviewableMediaNode isGeneratedReviewMedia
  isPromptPlaceholder promptTextFromNode isInlineEditableNode isTextInputTarget
  mediaPromptGroupKeyForSort reviewAssetStateRank sortMediaPreviewNodes
  mediaViewerBatchForOpening mediaViewerBatchNodes mediaViewerIndex moveMediaViewer
  mediaPromptNodeForReview mediaPromptReviewState mediaReviewPromptChanged
  updateMediaPromptFromEditor updateDetachedMediaPromptFromEditor
  renderMediaReviewPanel renderReviewQualityButtons reviewQualityKey setReviewQuality
  openMediaViewer closeMediaViewer defaultMediaViewerTransform mediaViewerImageTransform
  clampMediaViewerImagePan applyMediaViewerImageTransform attachMediaViewerImageInteractions
  renderMediaViewerPanel attachMediaViewerEvents renderMediaViewer handleMediaViewerKeydown attachSegmentPlayback
  renderPromptGenerationControls renderPromptGenerationControlButton imageResolutionCompactLabel
  normalizeOutpaintRatio outpaintRatioValue outpaintRatioLabel
  promptGenerationControlChoices promptGenerationControlValue
  isImageGenerationPromptAstra isVideoGenerationPromptAstra promptGenerationKind promptGenerationSettings
  mergeMediaSettings updatePromptGenerationControl
  activeImageModels activeVideoModels visibleMediaModel compactMediaModelLabel canonicalModelValue modelAliasKey modelDisplayLabel
  mediaModelConfig mediaModelFamily plannerImageResolutionOptions plannerVideoResolutionOptions plannerVideoAspectRatioOptions
  normalizePlannerImageResolution normalizePlannerVideoResolution normalizePlannerVideoAspectRatio normalizePlannerImageAspectRatio
  clampPlannerSegmentCount videoDurationRange clampVideoDuration clampSeedance2Duration
  renderGenerationControlContextMenu clampContextMenuPoint openPromptGenerationControlMenu closeContextMenu
  renderMentionMenu renderMentionThumb updatePromptMentionMenuForEditor promptMentionTriggerAtCursor textareaCaretClientRect
  handlePromptMentionKeydown insertPromptReferenceMention closePromptMentionMenu
  filteredPromptReferenceCandidates promptReferenceCandidates upstreamInputsFor
  isMentionableMediaAstra mediaMentionKind inputRoleForPromptReference canonicalPromptReferenceAlias
  promptMentionBindingMap dedupeMentionBindings promptMentionBindingsForText rememberPromptMentionBinding
  resolvePromptMentionReferences resolveAstraMention resolveAstraMentionFromNodes
  buildWaveSpeedVideoRequest buildVideoGenerationBody buildCompanySeedanceVideoBody
  videoReferenceNodesForExecution resolveWaveSpeedVideoModel waveSpeedVideoExecutionMode
  mediaSettingsForExecution videoDurationForMediaSettings waveSpeedVideoDuration
  mediaModelRequestModel isRgSeedanceSoraRequestModel buildGeminiOmniWaveSpeedVideoBody knownVideoDurationSeconds
`.trim().split(/\s+/);

function buildMediaViewerPage(html, adapter, decoration) {
  // Scan the large shipped source once, rather than once for every dependency.
  const declarations = new Map();
  for (const match of html.matchAll(/^    (?:async )?function (\w+)\([^]*?^    }/gm)) {
    const entries = declarations.get(match[1]) || [];
    entries.push(match[0]);
    declarations.set(match[1], entries);
  }
  const native = functions.map((name) => {
    // Shipped top-level functions have a four-space declaration and closing brace.
    const matches = declarations.get(name);
    if (matches?.length !== 1) throw new Error("Expected one viewer function: " + name);
    return matches[0];
  }).join("\n\n");
  const constants = section(html, "    const IMAGE_MODELS =", "    const DEFAULT_LLM_TIMEOUT_MS =")
    + section(html, "    const REVIEW_QUALITY_OPTIONS =", "    const NEW_ASTRA_MENU_GROUPS =");
  const css = [
    ["    :root {", "    .app {"],
    ["    button, input, textarea, select {", "    .app {"],
    ["    .astra-chip {", "    .astra-chip.analysis {"],
    ["    .mention-menu {", "    .audio-cues {"],
    ["    .media-viewer-backdrop {", "    .annotation-editor-backdrop {"],
    ["    .prompt-generation-controls {", "    .card-foot-actions {"],
    ["    .small-btn {", "    .small-btn.link-mode {"],
    ["    .context-menu {", "    .context-menu.has-submenus {"],
    ["    .context-menu button {", "    .context-menu-item {"],
    ["    .context-menu button.active {", "    .context-menu button.danger {"],
  ].map(([start, end]) => section(html, start, end)).join("\n");
  const script = constants + "\n" + native + "\n" + adapter + "\n" + decoration;
  new Script(script, { filename: "auralis-media-viewer.js" });
  return `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Auralis 素材查看器</title><style>${css}</style></head>
<body><div id="contextMenuRoot"></div><div id="mentionMenuRoot"></div><div id="mediaViewerRoot"></div>
<script>${script.replace(/<\/script/gi, "<\\/script")}</script></body></html>`;
}

function createMediaViewerPage(runtimeRoot) {
  let cached;
  return () => cached ||= buildMediaViewerPage(
    fs.readFileSync(path.join(runtimeRoot, "Auralis.html"), "utf8"),
    fs.readFileSync(path.join(__dirname, "media-viewer-runtime.js"), "utf8"),
    fs.readFileSync(path.join(__dirname, "media-viewer.js"), "utf8"),
  );
}

module.exports = { buildMediaViewerPage, createMediaViewerPage };
