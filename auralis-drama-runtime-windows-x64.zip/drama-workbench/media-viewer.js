// Bind the shipped Auralis viewer to workbench review/generation authority.
// Zoom, pan, keyboard navigation, prompt editing, @ mentions and model controls stay native.
const dramaViewerOnly =
  new URL(location.href).searchParams.get("viewer") === "1";
if (dramaViewerOnly) {
  const style = document.createElement("style");
  style.textContent = `
    .app{display:none}
    .media-viewer-backdrop{padding:0;background:var(--bg)}
    .media-viewer{width:100vw;height:100dvh;max-width:none;border:0;border-radius:0;box-shadow:none}
    .generation-control-menu,.mention-menu{z-index:100}
    .media-review-panel{grid-template-columns:minmax(0,1fr);max-height:44dvh;overflow:auto}
    .media-review-toolbar{gap:12px;flex-wrap:wrap}
    .media-prompt-action-group [data-prompt-delete],.media-prompt-action-group [data-prompt-jump]{display:none}
    .drama-viewer-status{font-size:13px;color:var(--muted)}
    .drama-review-actions{display:flex;gap:8px;flex-wrap:wrap}
    .drama-version-strip,.drama-ref-strip{display:flex;gap:8px;min-width:0;max-width:100%;overflow-x:auto;overflow-y:hidden;overscroll-behavior-x:contain;padding:8px 0}
    .drama-version-strip button{flex:none;padding:2px;border:1px solid var(--line);border-radius:4px;background:transparent}
    .drama-version-strip button[aria-current=true]{border-color:var(--primary)}
    .drama-version-strip video,.drama-version-strip img,.drama-ref-strip img,.drama-ref-strip video{width:64px;height:48px;object-fit:contain;display:block}
    .drama-version-strip span{display:block;font-size:11px}
    .drama-ref-strip label{flex:none;width:96px;font-size:11px;cursor:pointer}
    .drama-ref-strip label span{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .drama-ref-strip input{margin:0 4px 0 0}
    .drama-refs summary{cursor:pointer;font-size:12px}
    .drama-refs p{font-size:12px;color:var(--muted);margin:6px 0}
    .drama-viewer-notice{font-size:13px;color:var(--primary);min-height:1.4em}
    .drama-viewer-notice.error{color:#f1a294}
    .drama-job{width:72px;height:70px;display:flex;flex:none;align-items:center;justify-content:center;flex-direction:column;gap:6px;border:1px solid var(--line);font-size:11px;color:#bdcee8}
    .drama-job.failed{color:#efb3a4}
    .drama-spinner{width:18px;height:18px;border:2px solid currentColor;border-right-color:transparent;border-radius:50%;animation:drama-spin .85s linear infinite}
    @keyframes drama-spin{to{transform:rotate(360deg)}}

    .drama-video-viewer{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);grid-template-rows:auto minmax(0,1fr) auto}
    .drama-video-viewer .media-viewer-head{grid-column:1/-1}
    .drama-video-viewer .media-review-panel{grid-column:1;grid-row:2/4;max-height:none;min-height:0;padding:20px;display:flex;flex-direction:column;overflow:auto;border-top:0;border-right:1px solid var(--line)}
    .drama-video-viewer .media-prompt-editor{display:flex;flex:1;flex-direction:column;min-height:0;gap:16px}
    .drama-video-viewer .media-prompt-textarea{flex:1;min-height:200px;max-height:none;resize:none;line-height:1.75;font-size:14px}
    .drama-video-viewer .media-viewer-body{grid-column:2;grid-row:2;min-height:0;padding:20px;background:#0b0e0c}
    .drama-video-viewer .media-viewer-body video{width:100%;height:100%;object-fit:contain;max-height:100%}
    .drama-video-footer{grid-column:2;grid-row:3;min-width:0;padding:16px 20px;border-top:1px solid var(--line)}
    .drama-video-footer .drama-version-strip{margin-top:10px;min-height:86px}
    .drama-video-footer .drama-version-strip video{width:96px;height:60px;object-fit:cover;pointer-events:none}
    .drama-video-footer .media-review-toolbar{justify-content:space-between}
    .drama-video-viewer .drama-selected-refs{display:flex;gap:10px;overflow:auto;max-height:155px;padding:4px 0 8px}
    .drama-selected-refs figure{margin:0;width:108px;flex:none}
    .drama-selected-refs img,.drama-selected-refs video{width:108px;height:76px;object-fit:contain;background:#101410}
    .drama-selected-refs figure:has(audio){width:180px}
    .drama-selected-refs audio{width:180px;height:76px}
    .drama-selected-refs figcaption{font-size:11px;line-height:1.5;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    .drama-video-viewer .drama-refs h3{font-size:13px;font-weight:500;margin:0 0 4px}
    .drama-video-viewer .drama-ref-picker{margin-top:4px}
    .drama-speakers{margin-top:10px;font-size:12px;display:flex;gap:10px;flex-wrap:wrap}
    .drama-speakers label{display:flex;align-items:center;gap:4px}
    .drama-video-viewer .drama-ref-strip{flex-wrap:wrap;max-height:180px;overflow:auto}
    .drama-video-viewer .media-prompt-actions{margin-top:auto;flex-wrap:wrap;gap:12px}
    .drama-video-viewer .media-prompt-action-group{margin-left:auto}
    .drama-video-viewer .media-viewer-nav{display:none}
    .drama-video-empty{color:var(--muted);text-align:center;padding:24px;max-width:100%;overflow-wrap:anywhere}
    .drama-plan-tile{width:96px;height:60px;display:grid!important;place-items:center}
    @media(max-width:800px){
      .drama-video-viewer{display:flex;flex-direction:column;overflow:auto}
      .drama-video-viewer .media-viewer-head{order:0;flex:none}
      .drama-video-viewer .media-viewer-body{order:1;flex:none;height:28dvh;min-height:160px;padding:12px}
      .drama-video-viewer .drama-video-footer{order:2;padding:12px;flex:none}
      .drama-video-viewer .media-review-panel{order:3;overflow:visible;flex:none;border-right:0;padding:12px}
      .drama-video-viewer .media-prompt-textarea{height:300px;flex:none}
      .drama-video-viewer .media-prompt-editor{flex:none}
    }
    @media(prefers-reduced-motion:reduce){.drama-spinner{animation:none}}
    @media(max-width:680px){.media-review-panel{max-height:53dvh}.media-prompt-textarea{min-height:84px}.drama-review-actions{gap:4px}.drama-review-actions button{padding:7px 9px}}
  `;
  document.head.append(style);
  const escape = (value) =>
    String(value ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
  let opened = false,
    displayedId = "",
    busy = false,
    notice = "",
    error = false;
  const pendingRequests = new Map();
  function sendAction(action) {
    if (busy) return;
    const review = window.AuralisCanvas.mediaReview();
    if (!review) return;
    const requestId = crypto.randomUUID();
    const settings = review.settings?.mediaSettings;
    const input =
      action === "generate"
        ? {
            prompt: review.prompt.content,
            ...(review.node.meta.dramaKind === "clip"
              ? {
                  speakingAssetIds:
                    review.prompt.meta?.dramaSpeakingAssetIds || [],
                }
              : {}),
            refs: review.inputs.map((n) => n.meta?.dramaRef).filter(Boolean),
            generation: {
              model: review.settings.model,
              ...(review.node.meta.dramaKind === "clip"
                ? {
                    resolution: settings.videoResolution,
                    aspectRatio: settings.videoAspectRatio,
                    duration: settings.segmentDurationSeconds,
                  }
                : {
                    resolution: settings.imageResolution,
                    aspectRatio: settings.imageAspectRatio,
                  }),
            },
          }
        : null;
    if (action === "generate")
      pendingRequests.set(requestId, review.node.meta.dramaTargetId);
    else busy = true;
    notice = action === "generate" ? "正在提交生成…" : "正在处理…";
    error = false;
    decorate();
    parent.postMessage(
      {
        type: "drama-media-action",
        action,
        versionId: review.node.id,
        targetId: review.node.meta.dramaTargetId,
        kind: review.node.meta.dramaKind,
        requestId,
        input,
      },
      location.origin,
    );
  }
  function decorate() {
    const root = document.getElementById("mediaViewerRoot");
    const panel = root.querySelector(".media-review-panel"),
      review = window.AuralisCanvas?.mediaReview();
    if (!panel || !review) {
      if (opened && !root.children.length) {
        opened = false;
        parent.postMessage(
          { type: "drama-media-action", action: "close" },
          location.origin,
        );
      }
      return;
    }
    opened = true;
    const node = review.node,
      meta = node.meta,
      snapshot = window.AuralisCanvas.snapshot();
    if (displayedId !== node.id) {
      displayedId = node.id;
      notice = "";
      error = false;
    }
    const isVideo = meta.dramaKind === "clip";
    const viewer = root.querySelector(".media-viewer");
    viewer.classList.toggle("drama-video-viewer", isVideo);
    const toolbar = root.querySelector(".media-review-toolbar");
    if (isVideo) {
      let footer = viewer.querySelector(".drama-video-footer");
      if (!footer) {
        footer = document.createElement("div");
        footer.className = "drama-video-footer";
        viewer.append(footer);
      }
      footer.prepend(toolbar);
      root.querySelector("[data-media-download]").disabled =
        !!meta.dramaPlaceholder;
      panel
        .querySelector(".media-prompt-textarea")
        ?.setAttribute("aria-label", "视频提示词");
    }
    const button = (label, action, disabled = false) =>
      `<button class="small-btn" data-drama-action="${action}" ${disabled || busy ? "disabled" : ""}>${label}</button>`;
    toolbar.innerHTML =
      `<span class="drama-viewer-status">${{ draft: "当前计划", queued: "排队中", submitting: "生成中", submitted: "生成中", polling: "生成中", downloading: "生成中", failed: "生成失败", pending: "待选择", accepted: "已通过", alternative: "备选", rejected: "备选" }[meta.dramaStatus] || "备选"}${meta.dramaSource === "import" ? " · 自行上传" : ""}</span><div class="drama-review-actions">` +
      (isVideo ? button("打开画布", "canvas") + button("下载", "download", !!meta.dramaPlaceholder) : "") +
      button(
        meta.dramaStatus === "accepted" ? "已通过" : "通过",
        "accepted",
        meta.dramaStatus === "accepted" || !!meta.dramaPlaceholder,
      ) +
      (meta.dramaKind === "asset" && node.mime.startsWith("image/")
        ? button("引用", "cite")
        : "") +
      button(
        "删除备选",
        "delete",
        meta.dramaStatus === "accepted" || !!meta.dramaPlaceholder,
      ) +
      "</div>";
    root.querySelector(".drama-version-strip")?.remove();
    const strip = document.createElement("div");
    strip.className = "drama-version-strip";
    strip.setAttribute("aria-label", "切换候选");
    strip.innerHTML = snapshot.nodes
      .filter(
        (n) =>
          n.meta?.dramaTargetId === meta.dramaTargetId &&
          /^(image|video)\//.test(n.mime || "") &&
          !n.meta?.dramaJobId,
      )
      .map(
        (n, i) =>
          `<button type="button" data-drama-version="${escape(n.id)}" aria-label="查看候选 ${i + 1}" aria-current="${n.id === node.id}" ${busy ? "disabled" : ""}>` +
          (n.mime.startsWith("image/")
            ? `<img loading="lazy" decoding="async" src="${escape(n.displayUrl || n.meta?.remoteAssetUrl || n.assetUrl)}" alt="${escape(n.title)}">`
            : n.meta.dramaPlan
              ? '<span class="drama-plan-tile">当前计划</span>'
              : `<video src="${escape(n.displayUrl || n.meta?.remoteAssetUrl || n.assetUrl)}#t=0.1" preload="metadata" muted playsinline></video>`) +
          `<span>${n.meta.dramaPlan ? "生成新版本" : "版本 " + (n.meta.dramaVersionNumber || i + 1)}</span></button>`,
      )
      .join("");
    const jobs = (snapshot.jobs || []).filter(
      (j) => j.targetId === meta.dramaTargetId,
    );
    for (const [requestId, targetId] of pendingRequests)
      if (targetId === meta.dramaTargetId)
        jobs.push({ id: requestId, status: "submitting" });
    strip.innerHTML += jobs
      .map((j) => {
        const failed = ["failed", "submission_unknown"].includes(j.status);
        const selectable = isVideo && snapshot.nodes.some((n) => n.id === j.id);
        const tag = selectable ? "button" : "div";
        const attrs = selectable
          ? `type="button" data-drama-version="${escape(j.id)}" aria-current="${j.id === node.id}"`
          : 'role="status"';
        return `<${tag} class="drama-job ${failed ? "failed" : ""}" data-job="${escape(j.id)}" ${attrs} title="${escape(j.error || "")}">${failed ? "" : '<span class="drama-spinner" aria-hidden="true"></span>'}<span>${failed ? "生成失败" : j.status === "queued" ? "排队中" : "生成中"}</span></${tag}>`;
      })
      .join("");
    toolbar.after(strip);
    // Reuse native graph references: checked items become real inputs and appear in the native @ picker.
    const oldRefs = panel.querySelector(".drama-refs");
    const refsWereOpen = isVideo
      ? oldRefs?.querySelector(".drama-ref-picker")?.open
      : oldRefs?.open;
    oldRefs?.remove();
    const refs = document.createElement(isVideo ? "div" : "details");
    refs.className = "drama-refs";
    const selected = new Set(
      review.inputs.filter((n) => n.meta?.dramaRef).map((n) => n.id),
    );
    const available = snapshot.nodes.filter(
      (n) =>
        n.meta?.dramaRef &&
        (n.meta.dramaReferenceEligible || selected.has(n.id)) &&
        n.id !== node.id &&
        (meta.dramaKind !== "asset" || n.mime.startsWith("image/")),
    );
    refs.open = refsWereOpen ?? selected.size > 0;
    refs.innerHTML =
      `<summary>引用素材 · ${selected.size} 个</summary>` +
      (available.length
        ? '<div class="drama-ref-strip">' +
          available
            .map(
              (n) =>
                `<label><input type="checkbox" data-drama-ref="${escape(n.id)}" ${selected.has(n.id) ? "checked" : ""} ${busy ? "disabled" : ""}>` +
                (n.mime.startsWith("image/")
                  ? `<img loading="lazy" decoding="async" data-drama-src="${escape(n.displayUrl || n.meta?.remoteAssetUrl || n.assetUrl)}" alt="">`
                  : `<span>${n.mime.startsWith("audio/") ? "音频" : "视频"}</span>`) +
                `<span title="${escape(n.title)}">${escape(n.title)}</span></label>`,
            )
            .join("") +
          "</div><p>在提示词中输入 @，可引用已勾选素材。</p>"
        : "<p>暂无可用参考。上传的图片和通过的素材可直接使用。</p>");
    if (isVideo) {
      const selectedNodes = review.inputs.filter((n) => n.meta?.dramaRef);
      const choices = refs.innerHTML.replace(/<summary>.*?<\/summary>/, "");
      refs.innerHTML =
        `<h3>参考资产 · ${selectedNodes.length}</h3><div class="drama-selected-refs">` +
        selectedNodes
          .map(
            (n) =>
              `<figure>${n.mime.startsWith("image/") ? `<img src="${escape(n.displayUrl || n.meta?.remoteAssetUrl || n.assetUrl)}" alt="${escape(n.title)}">` : n.mime.startsWith("audio/") ? `<audio src="${escape(n.displayUrl || n.assetUrl)}" controls preload="none"></audio>` : `<video src="${escape(n.displayUrl || n.assetUrl)}" controls preload="metadata"></video>`}<figcaption title="${escape(n.title)}">${escape(n.title)}</figcaption></figure>`,
          )
          .join("") +
        `</div><details class="drama-ref-picker" ${refsWereOpen ? "open" : ""}><summary>修改参考</summary>${choices}</details>`;
      const speakers = meta.dramaVoiceCharacters || [];
      if (speakers.length)
        refs.insertAdjacentHTML(
          "beforeend",
          '<div class="drama-speakers"><span>说话角色</span>' +
            speakers
              .map(
                (c) =>
                  `<label><input type="checkbox" data-drama-speaker="${escape(c.id)}" ${(review.prompt.meta?.dramaSpeakingAssetIds || []).includes(c.id) ? "checked" : ""} ${busy ? "disabled" : ""}>${escape(c.name)}</label>`,
              )
              .join("") +
            '<span class="drama-viewer-status">无对白时不选</span></div>',
        );
      panel.querySelector(".media-prompt-actions").before(refs);
    } else strip.after(refs);
    // Collapsed reference choices must not load/decode the rest of the asset library.
    const picker = isVideo ? refs.querySelector(".drama-ref-picker") : refs;
    const loadReferencePreviews = () => {
      if (!picker.open) return;
      picker.querySelectorAll("img[data-drama-src]").forEach((img) => {
        img.src = img.dataset.dramaSrc;
        delete img.dataset.dramaSrc;
      });
    };
    picker.addEventListener("toggle", loadReferencePreviews);
    loadReferencePreviews();
    const generate = panel.querySelector("[data-prompt-generate]");
    if (generate) {
      generate.textContent = meta.dramaPlan ? "生成视频" : "再次生成";
      generate.disabled = busy || !meta.dramaCanEdit;
    }
    let message = panel.querySelector(".drama-viewer-notice");
    if (!message) {
      message = document.createElement("div");
      panel.append(message);
    }
    message.className = "drama-viewer-notice" + (error ? " error" : "");
    message.setAttribute("role", "status");
    message.textContent = notice;
  }
  document.addEventListener(
    "click",
    (event) => {
      if (
        busy &&
        event.target.closest(
          "[data-media-prev],[data-media-next],[data-drama-version],[data-generation-control]",
        )
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return;
      }
      const action = event.target.closest(
        "[data-drama-action],[data-prompt-generate]",
      );
      if (action) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return sendAction(action.dataset.dramaAction || "generate");
      }
      const version = event.target.closest("[data-drama-version]");
      if (version && !busy) {
        event.preventDefault();
        event.stopImmediatePropagation();
        notice = "";
        const batch = window.AuralisCanvas.mediaReview().batchIds;
        window.AuralisCanvas.openMedia(version.dataset.dramaVersion, batch);
      }
    },
    true,
  );
  document.addEventListener(
    "keydown",
    (event) => {
      if (
        busy &&
        ["ArrowLeft", "ArrowRight", "a", "A", "d", "D"].includes(event.key) &&
        !event.target.matches("input,textarea")
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    },
    true,
  );
  document.addEventListener(
    "pointerdown",
    (event) => {
      if (
        event.target.closest(
          "[data-drama-action],[data-drama-version],.generation-control-menu",
        )
      )
        event.preventDefault();
    },
    true,
  );
  document.addEventListener("change", (event) => {
    if (event.target.matches("[data-drama-speaker]")) {
      const api = window.AuralisCanvas,
        review = api.mediaReview();
      const chosen = [
        ...document.querySelectorAll("[data-drama-speaker]:checked"),
      ].map((el) => el.dataset.dramaSpeaker);
      review.prompt.meta.dramaSpeakingAssetIds = chosen;
      const characters = review.node.meta.dramaVoiceCharacters;
      const ids = review.inputs
        .filter(
          (n) =>
            !characters.some((c) => c.assetId === n.meta?.dramaRef?.assetId),
        )
        .map((n) => n.id);
      characters
        .filter((c) => chosen.includes(c.id) && c.versionId)
        .forEach((c) => ids.push(c.versionId));
      api.setMediaReferences(ids);
      return;
    }
    if (!event.target.matches("[data-drama-ref]")) return;
    const ids = [...document.querySelectorAll("[data-drama-ref]:checked")].map(
      (input) => input.dataset.dramaRef,
    );
    window.AuralisCanvas.setMediaReferences(ids);
  });
  window.addEventListener("message", (event) => {
    if (event.origin !== location.origin || event.source !== parent) return;
    if (event.data?.type === "drama-media-open") {
      busy = false;
      notice = "";
      error = false;
      pendingRequests.clear();
      return decorate();
    }
    if (event.data?.type === "drama-media-updated") return decorate();
    if (event.data?.type !== "drama-media-result") return;
    pendingRequests.delete(event.data.requestId);
    busy = false;
    notice = event.data.error || event.data.message;
    error = !!event.data.error;
    const node = window.AuralisCanvas.snapshot().nodes.find(
      (n) => n.id === event.data.versionId,
    );
    if (node && event.data.status) {
      node.meta.dramaStatus = event.data.status;
      node.meta.dramaReferenceEligible = event.data.eligible;
      node.assetState =
        event.data.status === "accepted" ? "official" : "candidate";
    }
    decorate();
  });
  new MutationObserver(decorate).observe(
    document.getElementById("mediaViewerRoot"),
    { childList: true },
  );
}
