const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { Readable } = require("node:stream");
const { pipeline } = require("node:stream/promises");

const REFERENCE_LIMIT = 200 * 1024 * 1024;
const RESULT_LIMIT = 250 * 1024 * 1024;
class FileInput {
  constructor(file, mime) {
    const stat = fs.statSync(file);
    if (!stat.isFile() || stat.size > REFERENCE_LIMIT) throw new Error("参考文件超过 200 MiB 或不是文件");
    if (!/^image\/[\w.+-]+$/.test(mime)) throw new Error("本地图片类型无效");
    Object.assign(this, { file, mime, size: stat.size, mtimeMs: stat.mtimeMs });
  }
}
const isFileInput = value => value instanceof FileInput;

// Only the small JSON structure is serialized. Image bytes are encoded on the wire.
function jsonPayload(body) {
  const files = [], prefix = "auralis-file-" + crypto.randomUUID() + "-";
  const json = JSON.stringify(body, (_, value) => {
    if (!isFileInput(value)) return value;
    const index = files.push(value) - 1;
    return prefix + index;
  });
  if (!files.length) return { body: json };
  const parts = [], pattern = new RegExp('"' + prefix + '(\\d+)"', 'g');
  let offset = 0, length = 0;
  for (const match of json.matchAll(pattern)) {
    const text = json.slice(offset, match.index), file = files[Number(match[1])];
    parts.push(text, file);
    length += Buffer.byteLength(text) + Buffer.byteLength('"data:' + file.mime + ';base64,') + 4 * Math.ceil(file.size / 3) + 1;
    offset = match.index + match[0].length;
  }
  parts.push(json.slice(offset)); length += Buffer.byteLength(json.slice(offset));
  async function* chunks() {
    for (const part of parts) {
      if (typeof part === "string") { yield part; continue; }
      const stat = await fs.promises.stat(part.file);
      if (stat.size !== part.size || stat.mtimeMs !== part.mtimeMs) throw new Error("参考文件已改变，请重新提交");
      yield '"data:' + part.mime + ';base64,';
      let carry = Buffer.alloc(0);
      for await (const chunk of fs.createReadStream(part.file, { highWaterMark: 48 * 1024 })) {
        const bytes = carry.length ? Buffer.concat([carry, chunk]) : chunk;
        const end = bytes.length - bytes.length % 3;
        if (end) yield bytes.subarray(0, end).toString("base64");
        carry = Buffer.from(bytes.subarray(end));
      }
      if (carry.length) yield carry.toString("base64");
      yield '"';
    }
  }
  return { body: Readable.from(chunks(), { objectMode: false, highWaterMark: 64 * 1024 }), duplex: "half", contentLength: String(length) };
}

async function saveMedia(folder, mime, source, remoteUrl = "") {
  const ext = { "image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "video/mp4": ".mp4" }[mime] || (mime.startsWith("video/") ? ".mp4" : ".png");
  const relative = "media/generated-" + crypto.randomUUID() + ext;
  const file = path.join(folder, relative), temp = file + ".part";
  fs.mkdirSync(path.dirname(file), { recursive: true });
  let size = 0;
  const digest = crypto.createHash("sha256");
  async function* bounded() {
    for await (const chunk of source) {
      const bytes = Buffer.from(chunk);
      size += bytes.length;
      if (size > RESULT_LIMIT) throw new Error("生成素材过大");
      digest.update(bytes); yield bytes;
    }
  }
  try {
    await pipeline(Readable.from(bounded()), fs.createWriteStream(temp, { flags: "wx" }));
    fs.renameSync(temp, file);
    return { path: relative, mime, size, sha256: digest.digest("hex"), remoteUrl };
  } catch (error) {
    fs.rmSync(temp, { force: true });
    throw error;
  }
}

async function saveInlineImage(folder, url) {
  const comma = url.indexOf(","), header = url.slice(0, comma);
  if (!/^data:image\/[\w.+-]+;base64$/.test(header)) throw new Error("生成图片数据格式无效");
  async function* decoded() {
    for (let start = comma + 1; start < url.length; start += 64 * 1024)
      yield Buffer.from(url.slice(start, start + 64 * 1024), "base64");
  }
  return saveMedia(folder, header.slice(5, -7), decoded());
}

class UploadCache {
  constructor() { this.pending = new Map(); }
  async get(folder, file, scope, upload) {
    const stat = fs.statSync(file);
    if (stat.size > REFERENCE_LIMIT) throw new Error("参考文件超过 200 MiB");
    const key = crypto.createHash("sha256").update(JSON.stringify([scope, file, stat.size, stat.mtimeMs])).digest("hex");
    const cacheFile = path.join(folder, "cache", "uploads.json");
    const read = () => { try { return JSON.parse(fs.readFileSync(cacheFile, "utf8")); } catch { return {}; } };
    const saved = read()[key];
    if (saved?.expiresAt > Date.now() && /^https:\/\//.test(saved.url)) return saved.url;
    if (this.pending.has(key)) return this.pending.get(key);
    const pending = (async () => {
      const url = await upload(stat.size);
      const entries = Object.fromEntries(Object.entries(read()).filter(([, entry]) => entry.expiresAt > Date.now()));
      // URLs are temporary; refresh after six hours or a file/account change.
      entries[key] = { url, expiresAt: Date.now() + 6 * 60 * 60 * 1000 };
      fs.mkdirSync(path.dirname(cacheFile), { recursive: true });
      const temp = cacheFile + "." + crypto.randomUUID() + ".tmp";
      fs.writeFileSync(temp, JSON.stringify(entries), "utf8"); fs.renameSync(temp, cacheFile);
      return url;
    })();
    this.pending.set(key, pending);
    try { return await pending; } finally { this.pending.delete(key); }
  }
}

module.exports = { FileInput, isFileInput, jsonPayload, saveMedia, saveInlineImage, UploadCache };
