// Gateways may put the upstream JSON error inside a JSON string in `message`.
function errorDetails(value, depth = 0) {
  if (depth > 6 || value == null) return {};
  if (typeof value === "string") {
    try { return errorDetails(JSON.parse(value), depth + 1); }
    catch { return { message: value }; }
  }
  if (typeof value !== "object") return {};
  const nested = errorDetails(value.error || value.message || value.detail, depth + 1);
  return { code: nested.code || value.code, message: nested.message || "" };
}
async function responseError(response, provider, secrets = []) {
  let details = {};
  try { details = errorDetails((await response.text()).slice(0, 64000)); } catch {}
  const hint = details.code === "InputImageSensitiveContentDetected.PrivacyInformation"
    ? "参考图被供应商判定可能包含真人。" : "";
  let message = provider + " 返回 HTTP " + response.status;
  if (details.message || details.code) message += "：" + hint + [details.code, details.message].filter(Boolean).join(" · ");
  for (const secret of secrets.filter(Boolean)) message = message.replaceAll(secret, "[Key]");
  message = message.replace(/data:[^\s,]+;base64,[a-zA-Z0-9+/=]+/g, "[素材]").replace(/\s+/g, " ").slice(0, 600);
  return Object.assign(new Error(message), { definite: response.status >= 400 && response.status < 500 });
}
module.exports = { responseError };
