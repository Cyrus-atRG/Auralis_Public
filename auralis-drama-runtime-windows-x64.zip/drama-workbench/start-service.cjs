const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

// The service outlives the startup helper and writes to its own log files.
const root = process.env.AURALIS_DRAMA_DATA_DIR;
if (!root) throw new Error('AURALIS_DRAMA_DATA_DIR is required');
const output = fs.openSync(path.join(root, 'server.log'), 'a');
const error = fs.openSync(path.join(root, 'server-error.log'), 'a');
const child = spawn(process.execPath, [path.join(__dirname, 'server.cjs')], {
  cwd: path.resolve(__dirname, '..'),
  detached: true,
  windowsHide: true,
  stdio: ['ignore', output, error],
});
fs.closeSync(output);
fs.closeSync(error);
child.once('error', error => { console.error(error.message); process.exitCode = 1; });
child.once('spawn', () => {
  console.log(JSON.stringify({ pid: child.pid }));
  child.unref();
});
