function productionProgress() {
  if (!S.project || !ep() || !["assets", "video"].includes(S.stage)) return "";
  const run = S.project.agentRuns?.[agentScopeKey()];
  const jobs = S.project.jobs.filter(
    (j) =>
      j.episodeId === S.episodeId &&
      j.targetType === (S.stage === "assets" ? "asset" : "clip") &&
      (activeMediaStates.has(j.status) ||
        !run?.startedAt ||
        j.createdAt >= run.startedAt),
  );
  if (!jobs.length) return "";
  const completed = jobs.filter((j) => j.status === "completed").length;
  const active = jobs.filter((j) => activeMediaStates.has(j.status)).length;
  const failed = jobs.filter((j) =>
    ["failed", "submission_unknown"].includes(j.status),
  ).length;
  const targets = S.stage === "assets" ? boardAssets() : ep().clips;
  const pending = targets
    .filter(
      (a) =>
        !a.acceptedVersionId && a.versions.some((v) => !v.deletedAt && v.media),
    )
    .map((a) => a.name || a.title);
  const names =
    pending.slice(0, 3).join("、") +
    (pending.length > 3 ? "等 " + pending.length + " 项" : "");
  return (
    '<div class="production-status" role="status">' +
    (active ? '<span class="running">制作中：' + active + " 个</span>" : "") +
    (completed
      ? '<span class="complete">制作完成：' +
        completed +
        (S.stage === "assets" ? " 张" : " 个片段") +
        "</span>"
      : "") +
    (failed ? '<span class="failed">生成失败：' + failed + " 个</span>" : "") +
    (names
      ? '<span class="pending">待用户确认：' + esc(names) + "</span>"
      : "") +
    "</div>"
  );
}
function renderAgentTranscript() {
  const summary = productionProgress();
  const final = S.messages.findLast((m) => m.role === "agent" && m.final);
  const messages = S.messages.filter(
    (m) => m.role === "user" || m.role === "notice" || (m.final && (!summary || m !== final)),
  );
  const box = $("agentMessages"),
    atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
  const html =
    messages
      .map(
        (m) =>
          '<div class="agent-message ' +
          esc(m.role) +
          '">' +
          (m.references?.length
            ? '<div class="message-images">' +
              m.references
                .map(r => '<div class="message-reference" title="' + esc(r.name) + '">' + referenceThumbnail(r) + (r.source?.clipId ? '<span>' + esc(r.name) + '</span>' : '') + '</div>')
                .join("") +
              "</div>"
            : "") +
          esc(m.text) +
          "</div>",
      )
      .join("") +
    summary +
    (summary && final
      ? '<details class="agent-full-reply"><summary>查看完整回复</summary><pre>' +
        esc(final.text) +
        "</pre></details>"
      : "");
  patchProductionHTML(box, html);
  if (atBottom) box.scrollTop = box.scrollHeight;
}
