// Asset selection, versions and generation progress share one board and one chat selection.
S.cardVersions = new Map();
S.assetSelection = new Map();
const activeMediaStates = new Set([
  "queued",
  "preparing",
  "submitting",
  "submitted",
  "polling",
  "downloading",
]);
function mediaJobs(kind, targetId) {
  return S.project.jobs.filter(
    (j) =>
      j.targetType === kind &&
      j.targetId === targetId &&
      !j.resultVersionId &&
      (activeMediaStates.has(j.status) ||
        ["failed", "submission_unknown"].includes(j.status)),
  );
}
function selectedVersion(target, pin) {
  const choice = S.cardVersions.get(target.id);
  const selectedJob = S.project.jobs.find((j) => j.id === choice);
  if (selectedJob && !selectedJob.resultVersionId) return null;
  const result = selectedJob?.resultVersionId;
  return (
    target.versions.find((v) => v.id === (result || choice) && !v.deletedAt) ||
    visibleVersion(target, pin)
  );
}
function boardAssets() {
  if (S.stage === "library" || !ep()) return S.project.assets;
  return ep().assetRefs.map((r) => S.project.assets.find((a) => a.id === r.assetId)).filter(Boolean);
}
function selectedAssetInputs() {
  return [...S.assetSelection].flatMap(([assetId, versionId]) => {
    const asset = S.project.assets.find((a) => a.id === assetId),
      v = asset?.versions.find((v) => v.id === versionId && !v.deletedAt);
    return v?.media?.mime.startsWith("image/")
      ? [
          {
            id: "asset-" + versionId,
            name: asset.name,
            media: v.media,
            source: { assetId, versionId },
          },
        ]
      : [];
  });
}
function selectAsset(assetId, versionId, selected = true) {
  if (selected) S.assetSelection.set(assetId, versionId);
  else S.assetSelection.delete(assetId);
  render();
}
function assetCategory(asset) {
  if (["character", "costume"].includes(asset.kind)) return "人物";
  if (asset.kind === "scene") return "场景";
  if (asset.kind === "prop") return "道具";
  return "其他素材";
}
function isDerivedAsset(asset) {
  return (
    !!asset.parentAssetId ||
    (asset.refs || []).some((r) => r.assetId !== asset.id)
  );
}
function generationTile(job, large = false) {
  const active = activeMediaStates.has(job.status);
  return (
    '<span class="generation-placeholder ' +
    (large ? "large " : "") +
    (active ? "running" : "failed") +
    '" data-job="' +
    job.id +
    '" role="status" title="' +
    esc(job.error || statusNames[job.status]) +
    '">' +
    (active ? '<span class="spinner" aria-hidden="true"></span>' : "") +
    "<span>" +
    esc(statusNames[job.status] || "生成中") +
    "</span></span>"
  );
}
function assetCard(asset) {
  const pin = ep()?.assetRefs.find((r) => r.assetId === asset.id)?.versionId;
  const v = selectedVersion(asset, pin),
    versions = asset.versions.filter((v) => !v.deletedAt);
  const jobs = mediaJobs("asset", asset.id),
    chosenJob = jobs.find((j) => j.id === S.cardVersions.get(asset.id));
  const selected = S.assetSelection.has(asset.id),
    current = !chosenJob && v;
  return (
    '<article class="asset-card' +
    (selected ? " selected" : "") +
    '" data-asset-card="' +
    asset.id +
    '" tabindex="0" aria-label="选择 ' +
    esc(asset.name) +
    '">' +
    '<button type="button" class="cover" data-action="' +
    (chosenJob ? "ignore" : current ? "preview" : "canvas") +
    '" data-kind="asset" data-id="' +
    asset.id +
    '" data-version="' +
    (current?.id || "") +
    '" aria-label="查看 ' +
    esc(asset.name) +
    '">' +
    (chosenJob
      ? generationTile(chosenJob, true)
      : current
        ? media(current.media, false)
        : jobs.length
          ? generationTile(jobs.at(-1), true)
          : media(null)) +
    (current?.id === asset.acceptedVersionId
      ? '<span class="badge accepted">已通过</span>'
      : "") +
    "</button>" +
    '<div class="card-body"><div class="row spread"><h3>' +
    esc(asset.name) +
    "</h3>" +
    (current?.media.mime.startsWith("image/")
      ? '<input type="checkbox" class="asset-select" data-action="toggleAsset" data-id="' +
        asset.id +
        '" aria-label="引用 ' +
        esc(asset.name) +
        '" ' +
        (selected ? "checked" : "") +
        ">"
      : "") +
    "</div>" +
    '<div class="candidate-thumbnails" aria-label="' +
    esc(asset.name) +
    '的版本">' +
    versions
      .map(
        (version, i) =>
          '<button type="button" data-action="selectVariant" data-id="' +
          asset.id +
          '" data-version="' +
          version.id +
          '" aria-label="切换版本 ' +
          (i + 1) +
          '" aria-pressed="' +
          (current?.id === version.id) +
          '" title="版本 ' +
          (i + 1) +
          (version.id === asset.acceptedVersionId ? " · 已通过" : " · 备选") +
          '">' +
          media(version.media, false) +
          "</button>",
      )
      .join("") +
    jobs
      .map(
        (j) =>
          '<button type="button" data-action="selectVariant" data-id="' +
          asset.id +
          '" data-version="' +
          j.id +
          '" aria-label="查看生成任务">' +
          generationTile(j) +
          "</button>",
      )
      .join("") +
    "</div>" +
    '<div class="actions">' +
    btn("打开画布", "canvas", 'data-kind="asset" data-id="' + asset.id + '"') +
    (asset.kind === "character"
      ? btn(
          asset.voice?.hasDialogue
            ? "音色"
            : asset.voice
              ? "无台词"
              : "设置音色",
          asset.voice?.hasDialogue ? "focusVoice" : "editVoice",
          'data-id="' + asset.id + '"',
        )
      : "") +
    btn(
      current?.id === asset.acceptedVersionId ? "已通过" : "通过",
      "approveAsset",
      'data-id="' +
        asset.id +
        '" data-version="' +
        (current?.id || "") +
        '" ' +
        (!current || current.id === asset.acceptedVersionId ? "disabled" : ""),
      "primary",
    ) +
    "</div></div></article>"
  );
}
function assetBoard() {
  const items = boardAssets();
  const voiceCount = items.filter(
    (a) => a.kind === "character" && a.voice?.hasDialogue,
  ).length;
  const selected = [...S.assetSelection.keys()].filter((id) =>
    items.some((a) => a.id === id),
  );
  const toolbar = selected.length
    ? '<div class="selection-toolbar" role="toolbar" aria-label="已选素材操作"><strong>已选 ' +
      selected.length +
      " 项</strong>" +
      btn("全选", "selectAllAssets") +
      btn("反选", "invertAssets") +
      btn("取消选择", "clearAssets") +
      btn("批量通过", "approveAssets", "", "primary") +
      "</div>"
    : "";
  const renderRound = (derived) => {
    const round = items.filter(
      (a) =>
        isDerivedAsset(a) === derived &&
        !(
          a.kind === "audio" &&
          a.purpose === "voice" &&
          S.project.assets.some((c) => c.voiceAssetId === a.id)
        ),
    );
    if (!round.length) return "";
    return (
      '<section class="asset-round" data-round="' +
      (derived ? "derived" : "first") +
      '"><h2>' +
      (derived ? "次轮 · 基于首轮制作" : "首轮") +
      "</h2>" +
      ["人物", "场景", "道具", "其他素材"]
        .map((category) => {
          const group = round.filter((a) => assetCategory(a) === category);
          return group.length
            ? '<section class="asset-category" data-category="' +
                category +
                '"><h3>' +
                category +
                '</h3><div class="cards">' +
                group.map(assetCard).join("") +
                "</div></section>"
            : "";
        })
        .join("") +
      "</section>"
    );
  };
  return (
    toolbar +
    '<div class="row spread board-heading"><h2>' +
    (S.stage === "library" ? "公共资产库" : "本集资产") +
    '</h2><div class="actions">' +
    (voiceCount
      ? btn(
          S.assetView === "voices" ? "全部资产" : "角色音色 · " + voiceCount,
          "toggleVoices",
        )
      : "") +
    (S.stage !== "library"
      ? '<div class="actions">' +
        btn("继续制作", "continueProduction") +
        btn("＋ 添加资产", "editAsset") +
        "</div>"
      : "") +
    "</div></div>" +
    (items.length
      ? S.assetView === "voices" && voiceCount
        ? voiceBoard()
        : renderRound(false) + renderRound(true) + voiceBoard()
      : empty("还没有资产", "通过文字分镜后，开始准备本集素材。")) +
    (S.stage !== "library" ? jobs() : "")
  );
}
async function approveAssets(ids) {
  const operations = ids.flatMap((id) => {
    const a = S.project.assets.find((a) => a.id === id),
      v = selectedVersion(
        a,
        ep()?.assetRefs.find((r) => r.assetId === id)?.versionId,
      );
    return v &&
      !mediaJobs("asset", id).some((j) => j.id === S.cardVersions.get(id))
      ? [
          {
            type: "review",
            targetType: "asset",
            targetId: id,
            versionId: v.id,
            episodeId: ep()?.id,
            decision: "accepted",
          },
        ]
      : [];
  });
  if (!operations.length) return;
  await apply(operations);
  for (const op of operations) S.assetSelection.delete(op.targetId);
  refreshProductionUI();
  const last = operations.at(-1);
  await advanceAfterReview("asset", last.versionId, last.targetId);
}
async function assetBoardAction(action, d) {
  if (action === "ignore") return;
  if (action === "selectVariant") {
    S.cardVersions.set(d.id, d.version);
    if (S.assetSelection.has(d.id)) {
      const v = S.project.assets
        .find((a) => a.id === d.id)
        .versions.find((v) => v.id === d.version);
      if (v?.media.mime.startsWith("image/")) S.assetSelection.set(d.id, v.id);
      else S.assetSelection.delete(d.id);
    }
    return render();
  }
  if (action === "toggleAsset") {
    const a = S.project.assets.find((a) => a.id === d.id),
      v = selectedVersion(
        a,
        ep()?.assetRefs.find((r) => r.assetId === a.id)?.versionId,
      );
    if (v?.media.mime.startsWith("image/"))
      selectAsset(a.id, v.id, !S.assetSelection.has(a.id));
    return;
  }
  if (action === "clearAssets") {
    S.assetSelection.clear();
    return render();
  }
  if (["selectAllAssets", "invertAssets"].includes(action)) {
    for (const a of boardAssets()) {
      const v = selectedVersion(
        a,
        ep()?.assetRefs.find((r) => r.assetId === a.id)?.versionId,
      );
      if (action === "invertAssets" && S.assetSelection.has(a.id))
        S.assetSelection.delete(a.id);
      else if (v?.media.mime.startsWith("image/"))
        S.assetSelection.set(a.id, v.id);
    }
    return render();
  }
  if (action === "approveAsset") return approveAssets([d.id]);
  if (action === "approveAssets")
    return approveAssets([...S.assetSelection.keys()]);
}
const boardActions = new Set([
  "ignore",
  "selectVariant",
  "toggleAsset",
  "clearAssets",
  "selectAllAssets",
  "invertAssets",
  "approveAsset",
  "approveAssets",
]);
document.addEventListener("click", (event) => {
  const card = event.target.closest("[data-asset-card]");
  if (card && !event.target.closest("button,input,a"))
    assetBoardAction("toggleAsset", { id: card.dataset.assetCard });
});
document.addEventListener("keydown", (event) => {
  if (
    event.target.matches("[data-asset-card]") &&
    [" ", "Enter"].includes(event.key)
  ) {
    event.preventDefault();
    assetBoardAction("toggleAsset", { id: event.target.dataset.assetCard });
  }
});
