const fields = {
  setSetting: "id title text character", deleteSetting: "id", restoreSetting: "id", reorderSettings: "ids",
  updateProject: "title premise", addReference: "name note media", updateReference: "id name note", removeReference: "id",
  setSynopsis: "episodeId text", setStoryboard: "episodeId text bindings", patchDocument: "targetType baseVersionId edits",
  updateEpisode: "episodeId title number", ensureAsset: "episodeId name kind description parentAssetId purpose settingId voice",
  bindAsset: "episodeId name assetId", setAssetPrompt: "episodeId assetId prompt refs generation", renameAsset: "assetId name",
  generate: "episodeId targetType targetId model", retryJob: "jobId", cancelJob: "jobId", setVoiceProfile: "episodeId assetId voice",
  updateAsset: "assetId description parentAssetId purpose", deleteAsset: "episodeId assetId", restoreAsset: "episodeId assetId",
  reorderAssets: "episodeId ids", setGeneration: "image video", searchVoices: "assetId", importAsset: "episodeId assetId canvasNodeId media",
  deleteMediaVersion: "targetType targetId versionId", generateAssetVariation: "episodeId assetId canvasNodeId prompt refs generation",
  promoteVariant: "episodeId targetType assetId clipId versionId title description parentAssetId purpose",
  saveAssetCanvas: "assetId graph", saveCanvasLayout: "episodeId targetType targetId positions", attachAssetReference: "assetId versionId",
  planClip: "episodeId id title prompt refs speakingAssetIds model duration aspectRatio resolution",
  deleteClip: "episodeId id", restoreClip: "episodeId id", reorderClips: "episodeId ids",
};
const string = description => ({ type: "string", ...(description ? { description } : {}) });
const voice = { type: "object", properties: { hasDialogue: { type: "boolean" }, description: string("音色特质；有对白必填"),
  language: string("en、zh 等语言代码"), gender: { type: "string", enum: ["", "female", "male", "neutral"] }, age: { type: "string", enum: ["", "young", "middle_aged", "old"] } }, required: ["hasDialogue"], additionalProperties: false };
const generation = { type: "object", properties: { model: string(), duration: { type: "number" }, aspectRatio: string(), resolution: string() }, additionalProperties: false };
const refs = { type: "array", items: { type: "object", properties: { assetId: string(), versionId: string(), role: string("image、audio、video；按当前模型能力选择") }, required: ["assetId", "versionId", "role"], additionalProperties: false } };
const properties = {
  id: string("更新已有条目时填真实 ID；setSetting/planClip 新建时省略"), ids: { type: "array", items: string(), description: "当前范围内完整、不重复的排序 ID" },
  episodeId: string("默认当前集"), title: string(), text: string("完整正文；局部修改使用 patchDocument"), premise: string(),
  name: string(), note: string(), description: string(), purpose: string(), parentAssetId: { type: ["string", "null"] },
  assetId: string(), settingId: string(), clipId: string(), versionId: string(), jobId: string(), targetId: string(), canvasNodeId: string(),
  targetType: { type: "string", enum: ["asset", "clip", "synopsis", "storyboard"] },
  number: { type: "integer", minimum: 1 }, kind: string("资产类型，使用当前阶段规范的取值"),
  voice, character: { ...voice, properties: { name: string(), ...voice.properties }, required: ["name", "hasDialogue"] },
  prompt: string(), refs, generation, image: generation, video: generation, model: string("context.generationModels 中可用模型"),
  duration: { type: "number", minimum: 1, maximum: 30 }, aspectRatio: string(), resolution: string(),
  speakingAssetIds: { type: "array", items: string(), description: "本片段说话角色 ID；无对白明确填 []" },
  bindings: { type: "object", additionalProperties: string(), description: "分镜中的资产名到真实资产 ID" },
  media: { type: "object", properties: { path: string("已上传的 media/文件名"), mime: string(), sha256: string(), size: { type: "number" }, duration: { type: "number" } }, required: ["path", "mime"], additionalProperties: false },
  graph: { type: "object", additionalProperties: true, description: "资产画布完整 graph；沿用当前节点 ID" },
  positions: { type: "array", items: { type: "object", properties: { id: string(), x: { type: "number" }, y: { type: "number" } }, required: ["id", "x", "y"], additionalProperties: false } },
};
function operationProperties(allowed) {
  const names = new Set(allowed.flatMap(type => (fields[type] || "").split(" ")));
  return Object.fromEntries([...names].filter(name => properties[name]).map(name => [name, properties[name]]));
}
function operationDescription(allowed) { return allowed.map(type => `${type}: ${fields[type] || "见阶段规范"}`).join("；"); }
module.exports = { operationProperties, operationDescription, fields };
