// Preserve both sides: a creator's "use option two" may depend on an older reply.
// Rebuilds omit tools and stale automatic notices, not unrecorded creative decisions.
function discussionHistory(messages) {
  return messages.filter(m => ["user", "agent"].includes(m.role)).map(({ role, text }) => ({ role, text }));
}

function inputManifest(prompts, context, history, rotated) {
  const materials = [];
  const add = (kind, title, versionId, mode = "全文") => materials.push({ kind, title, versionId, mode });
  add("project", "剧名与故事起点", null);
  for (const item of context.settings) add("setting", item.title, item.versionId);
  for (const item of context.previousSynopses) add("previousSynopsis", item.title, item.versionId,
    item.status === "adopted" ? "全文 · 剧情承接" : item.status === "episode_missing" ? "该集尚未创建" : "尚无已采用梗概");
  for (const name of ["synopsis", "storyboard"]) {
    const doc = context.episode?.[name];
    for (const [key, label] of [["current", "当前稿"], ["accepted", "已采用稿"]]) {
      if (doc?.[key]) add(name, `第 ${context.episode.number} 集${name === "synopsis" ? "梗概" : "分镜"} · ${doc.acceptedIsCurrent ? "当前已采用稿" : label}`, doc[key].id);
    }
  }
  for (const item of context.assets) add("asset", item.name, item.pinnedVersionId, "资料全文 · 固定版本" + (context.scope.stage === "assets" ? " · 制作计划" : ""));
  for (const item of context.clips) add("clip", item.title, item.planRevision, item.plan ? "计划全文" : "索引");
  for (const item of context.references) add("reference", item.name, item.source?.versionId, item.kind === "clip" ? "视频引用路径" : "图片附件");
  return { prompts, materials, assetIndexCount: context.assetLibrary.length, contextCharacters: JSON.stringify(context).length,
    history: { userMessages: history.filter(m => m.role === "user").length, agentMessages: history.filter(m => m.role === "agent").length,
      characters: JSON.stringify(history).length, rotated },
  };
}

module.exports = { discussionHistory, inputManifest };
