@echo off
chcp 65001 >nul
cd /d "%~dp0.."
set AURALIS_DRAMA_SANDBOX=danger-full-access
node drama-workbench\server.cjs
