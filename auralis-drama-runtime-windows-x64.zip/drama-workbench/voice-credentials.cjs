const fs = require("node:fs");
const path = require("node:path");
const os = require("node:os");
const { spawnSync } = require("node:child_process");

// Shared by local workbench checkouts, never part of a project or controller context.
const credentialFile = () =>
  process.env.AURALIS_ELEVENLABS_CREDENTIAL_FILE ||
  path.join(
    process.env.LOCALAPPDATA || path.join(os.homedir(), ".config"),
    "Auralis",
    "credentials",
    "elevenlabs.local.json",
  );
function protect(value, decrypt = false) {
  const script =
    "Add-Type -AssemblyName System.Security; " +
    "$v=[Console]::In.ReadToEnd(); " +
    (decrypt
      ? "$b=[Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($v),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Write([Text.Encoding]::UTF8.GetString($b))"
      : "$b=[Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($v),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Write([Convert]::ToBase64String($b))");
  const r = spawnSync(
    "powershell.exe",
    ["-NoProfile", "-NonInteractive", "-Command", script],
    { input: value, encoding: "utf8", windowsHide: true, timeout: 15000 },
  );
  if (r.error || r.status !== 0 || !r.stdout.trim())
    throw new Error("无法读写本地 ElevenLabs 凭据");
  return r.stdout.trim();
}
function loadKey(file = credentialFile()) {
  if (!fs.existsSync(file)) return "";
  const data = JSON.parse(fs.readFileSync(file, "utf8"));
  return data.encoding === "dpapi"
    ? protect(data.value, true)
    : data.value || "";
}
function saveKey(key, file = credentialFile()) {
  if (typeof key !== "string" || !key.trim() || key.length > 512)
    throw new Error("ElevenLabs API Key 无效");
  const encoding = process.platform === "win32" ? "dpapi" : "private-file";
  const value = encoding === "dpapi" ? protect(key.trim()) : key.trim();
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  fs.writeFileSync(file + ".tmp", JSON.stringify({ encoding, value }), {
    encoding: "utf8",
    mode: 0o600,
  });
  fs.renameSync(file + ".tmp", file);
}
module.exports = { loadKey, saveKey, credentialFile };
