const fs = require("node:fs");
const path = require("node:path");
const { find, requireValue } = require("./store.cjs");

const filename = (value) =>
  String(value)
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "_")
    .replace(/[. ]+$/g, "")
    .slice(0, 100);
const disposition = (name) =>
  "attachment; filename=\"download\"; filename*=UTF-8''" +
  encodeURIComponent(name);
function clipDownloads(store, project, episodeId, selections) {
  const episode = find(project.episodes, episodeId);
  requireValue(
    Array.isArray(selections) &&
      selections.length > 0 &&
      selections.length <= 100,
    "请选择要下载的视频",
  );
  const mediaRoot = path.resolve(path.dirname(store.file(project.id)), "media");
  return selections.map(({ clipId, versionId }) => {
    const clip = find(episode.clips, clipId),
      version = find(clip.versions, versionId);
    requireValue(
      !version.deletedAt && version.media?.mime.startsWith("video/"),
      "所选视频已删除或尚未生成",
    );
    const file = path.resolve(
      path.dirname(store.file(project.id)),
      version.media.path,
    );
    requireValue(
      file.startsWith(mediaRoot + path.sep) && fs.existsSync(file),
      "视频文件不存在",
    );
    return {
      file,
      name:
        filename(
          "第" +
            episode.number +
            "集_" +
            String(episode.clips.indexOf(clip) + 1).padStart(2, "0") +
            "_" +
            clip.title,
        ) +
        "_v" +
        (clip.versions.indexOf(version) + 1) +
        path.extname(file),
      size: fs.statSync(file).size,
      mime: version.media.mime,
    };
  });
}

// Stored ZIP, like Auralis media exports. Stream videos with CRC/data descriptors
// so a batch does not have to be loaded into server or browser memory first.
const crcTable = Uint32Array.from({ length: 256 }, (_, n) => {
  for (let i = 0; i < 8; i++) n = n & 1 ? 0xedb88320 ^ (n >>> 1) : n >>> 1;
  return n >>> 0;
});
async function sendClipZip(res, files, name) {
  const entries = files.map((f) => ({
    ...f,
    encodedName: Buffer.from(f.name, "utf8"),
  }));
  const bytes = entries.reduce(
    (n, f) => n + 30 + 16 + 46 + f.encodedName.length * 2 + f.size,
    22,
  );
  requireValue(bytes < 0xffffffff, "下载包超过 4 GB，请分批下载");
  res.writeHead(200, {
    "Content-Type": "application/zip",
    "Content-Length": bytes,
    "Content-Disposition": disposition(name),
    "Cache-Control": "no-store",
  });
  const write = (data) =>
    new Promise((resolve, reject) =>
      res.write(data, (error) => (error ? reject(error) : resolve())),
    );
  const central = [];
  let offset = 0;
  for (const file of entries) {
    const name = file.encodedName,
      local = Buffer.alloc(30 + name.length);
    local.writeUInt32LE(0x04034b50, 0);
    local.writeUInt16LE(20, 4);
    local.writeUInt16LE(0x808, 6);
    local.writeUInt16LE(33, 12);
    local.writeUInt16LE(name.length, 26);
    name.copy(local, 30);
    await write(local);
    let crc = 0xffffffff;
    for await (const chunk of fs.createReadStream(file.file)) {
      for (const byte of chunk)
        crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
      await write(chunk);
    }
    crc = (crc ^ 0xffffffff) >>> 0;
    const descriptor = Buffer.alloc(16);
    descriptor.writeUInt32LE(0x08074b50, 0);
    descriptor.writeUInt32LE(crc, 4);
    descriptor.writeUInt32LE(file.size, 8);
    descriptor.writeUInt32LE(file.size, 12);
    await write(descriptor);
    const entry = Buffer.alloc(46 + name.length);
    entry.writeUInt32LE(0x02014b50, 0);
    entry.writeUInt16LE(20, 4);
    entry.writeUInt16LE(20, 6);
    entry.writeUInt16LE(0x808, 8);
    entry.writeUInt16LE(33, 14);
    entry.writeUInt32LE(crc, 16);
    entry.writeUInt32LE(file.size, 20);
    entry.writeUInt32LE(file.size, 24);
    entry.writeUInt16LE(name.length, 28);
    entry.writeUInt32LE(offset, 42);
    name.copy(entry, 46);
    central.push(entry);
    offset += local.length + file.size + descriptor.length;
  }
  for (const entry of central) await write(entry);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(files.length, 8);
  end.writeUInt16LE(files.length, 10);
  end.writeUInt32LE(
    central.reduce((n, b) => n + b.length, 0),
    12,
  );
  end.writeUInt32LE(offset, 16);
  res.end(end);
}
module.exports = { clipDownloads, sendClipZip, disposition, filename };
