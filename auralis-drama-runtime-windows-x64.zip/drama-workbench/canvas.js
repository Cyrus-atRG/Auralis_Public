// Preserve the original Auralis canvas interactions while hiding unrelated app chrome.
const style = document.createElement("style");
style.textContent =
  ".rail,.sidebar,.chat-panel,.chat-rail,.topbar,.app-header,.inspector,.inspector-fab,.inspector-resize-handle{display:none!important}.app{grid-template-columns:1fr!important;grid-template-rows:1fr!important}.canvas-shell{grid-column:1!important;grid-row:1!important}";
document.head.append(style);

// Candidate decisions are routed to the workbench's human review endpoints.
document.addEventListener(
  "contextmenu",
  (event) => {
    const nodeId = event.target.closest(".card[data-node-id]")?.dataset.nodeId;
    const node = window.AuralisCanvas?.snapshot().nodes.find(
      (n) => n.id === nodeId,
    );
    if (!node?.meta?.dramaVersionId) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    document.getElementById("dramaCandidateMenu")?.remove();
    const menu = document.createElement("div");
    menu.id = "dramaCandidateMenu";
    Object.assign(menu.style, {
      position: "fixed",
      zIndex: 9999,
      left: Math.min(event.clientX, innerWidth - 220) + "px",
      top: Math.min(event.clientY, innerHeight - 110) + "px",
      background: "#252e22",
      border: "1px solid #657451",
      padding: "6px",
      borderRadius: "6px",
      display: "grid",
      gap: "4px",
    });
    for (const [action, label] of [
      ["reviewVariant", "通过"],
      ["deleteVariant", "删除备选"],
      ["promote", "独立成为上层正式内容"],
    ]) {
      if (action === "deleteVariant" && node.assetState === "official")
        continue;
      const button = document.createElement("button");
      button.textContent = label;
      button.onclick = () => {
        parent.postMessage(
          {
            type: "drama-candidate-action",
            action,
            versionId: node.meta.dramaVersionId,
          },
          location.origin,
        );
        menu.remove();
      };
      menu.append(button);
    }
    document.body.append(menu);
  },
  true,
);
document.addEventListener(
  "pointerdown",
  (event) => {
    const menu = document.getElementById("dramaCandidateMenu");
    if (menu && !menu.contains(event.target)) menu.remove();
  },
  true,
);

// The visible native approval button uses the same authoritative selection as the board.
document.addEventListener(
  "click",
  (event) => {
    const button = event.target.closest('[data-action="promote"]');
    if (!button) return;
    const nodeId = button.closest(".card[data-node-id]")?.dataset.nodeId;
    const node = window.AuralisCanvas?.snapshot().nodes.find(
      (n) => n.id === nodeId,
    );
    if (!node?.meta?.dramaVersionId) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    parent.postMessage(
      {
        type: "drama-candidate-action",
        action: "reviewVariant",
        versionId: node.meta.dramaVersionId,
      },
      location.origin,
    );
  },
  true,
);
