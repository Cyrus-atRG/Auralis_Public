const fs = require("node:fs");
const path = require("node:path");
const { spawn } = require("node:child_process");
const { id, hash, now, find, requireValue } = require("./store.cjs");
const { probe } = require("./provider.cjs");
const { loadKey } = require("./voice-credentials.cjs");

const SAMPLE_SECONDS = 4.8;
function previewURL(value) {
  const u = new URL(value);
  requireValue(
    u.protocol === "https:" &&
      !u.username &&
      !u.password &&
      (u.hostname === "storage.googleapis.com" ||
        u.hostname === "api.elevenlabs.io" ||
        u.hostname.endsWith(".elevenlabs.io")),
    "音色试听地址无效",
  );
  return u.href;
}
async function boundedAudio(response) {
  requireValue(response.ok, "试听下载失败，请重试");
  requireValue(
    /^(audio\/|application\/octet-stream|text\/plain(?:;|$))/.test(
      response.headers.get("content-type") || "",
    ),
    "试听返回的不是音频",
  );
  const parts = [];
  let size = 0;
  for await (const part of response.body) {
    size += part.length;
    requireValue(size <= 20 * 1024 * 1024, "试听文件超过 20 MiB");
    parts.push(part);
  }
  requireValue(size > 0, "试听文件为空");
  // Some ElevenLabs GCS previews are MP3 bytes labelled text/plain. ffmpeg and
  // ffprobe below validate the actual audio before any asset version is saved.
  return Buffer.concat(parts);
}
async function trimAudio(source, destination) {
  await new Promise((resolve, reject) => {
    const child = spawn(
      process.env.FFMPEG_PATH || "ffmpeg",
      [
        "-v",
        "error",
        "-nostdin",
        "-y",
        "-i",
        source,
        "-t",
        String(SAMPLE_SECONDS),
        "-vn",
        "-ac",
        "1",
        "-ar",
        "44100",
        "-codec:a",
        "libmp3lame",
        "-b:a",
        "128k",
        destination,
      ],
      { windowsHide: true, stdio: "ignore" },
    );
    const timer = setTimeout(() => child.kill(), 30000);
    child.once("error", () => {
      clearTimeout(timer);
      reject(new Error("需要 ffmpeg 才能准备音色参考"));
    });
    child.once("close", (code) => {
      clearTimeout(timer);
      code === 0 ? resolve() : reject(new Error("音色试听处理失败，请重试"));
    });
  });
  return probe(destination, "audio/mpeg");
}

class VoiceProvider {
  constructor(store, options = {}) {
    this.store = store;
    this.fetch = options.fetch || fetch;
    this.key = options.key ?? process.env.ELEVENLABS_API_KEY ?? loadKey();
    this.credentials = options.credentials || (() => ({}));
    this.trim = options.trim || trimAudio;
    this.active = new Set();
    this.pending = new Set();
  }
  start() {
    for (const item of this.store.list()) {
      const p = this.store.read(item.id);
      if (p.assets.some((a) => a.voiceSearch?.status === "searching"))
        this.store.internal(p.id, (doc) => {
          for (const a of doc.assets)
            if (a.voiceSearch?.status === "searching")
              a.voiceSearch.status = "queued";
        }, { contentChanged: false });
    }
    this.timer = setInterval(() => this.tick(), 2500);
    this.timer.unref();
    this.tick();
  }
  async stop() {
    clearInterval(this.timer);
    await Promise.allSettled([...this.pending]);
  }
  tick() {
    for (const p of this.store.list())
      for (const a of this.store.read(p.id).assets) {
        if (
          a.voiceSearch?.status !== "queued" ||
          this.active.has(a.id) ||
          this.active.size >= 2
        )
          continue;
        this.active.add(a.id);
        const task = this.run(p.id, a.id)
          .catch(() => {})
          .finally(() => {
            this.active.delete(a.id);
            this.pending.delete(task);
          });
        this.pending.add(task);
      }
  }
  update(pid, aid, sid, fn) {
    const a = find(this.store.read(pid).assets, aid);
    if (a.voiceSearch?.id !== sid) return false;
    this.store.internal(pid, (p) => fn(find(p.assets, aid), p), { contentChanged: false });
    return true;
  }
  async search(profile, query, page) {
    const url = new URL("https://api.elevenlabs.io/v1/shared-voices");
    for (const [key, value] of Object.entries({
      search: query,
      page_size: 30,
      page,
      sort: "trending",
      language: profile.language,
      gender: profile.gender,
      age: profile.age,
    }))
      if (value !== "" && value != null) url.searchParams.set(key, value);
    const r = await this.fetch(url.href, {
      headers: { "xi-api-key": this.key },
      signal: AbortSignal.timeout(30000),
    });
    if (!r.ok)
      throw new Error(
        r.status === 401 || r.status === 403
          ? "ElevenLabs 密钥无效或无音色库权限，请在生成设置检查"
          : r.status === 429
            ? "ElevenLabs 请求频繁，请稍后重试"
            : "ElevenLabs 搜索失败（HTTP " + r.status + "），请重试",
      );
    const body = await r.json();
    requireValue(Array.isArray(body.voices), "ElevenLabs 未返回音色列表");
    return body;
  }
  async run(pid, aid) {
    const initial = find(this.store.read(pid).assets, aid);
    const search = structuredClone(initial.voiceSearch);
    if (search?.status !== "queued") return;
    const sid = search.id;
    try {
      const shared = this.credentials();
      if (Object.hasOwn(shared, "elevenLabsApiKey")) this.key = shared.elevenLabsApiKey;
      requireValue(this.key, "请先在共享 API 设置配置 ElevenLabs，再重试");
      this.update(pid, aid, sid, (a) => {
        a.voiceSearch.status = "searching";
        a.voiceSearch.error = null;
      });
      const terms = [
        ...new Set(
          search.profile.description.split(/[\s,，;；]+/).filter(Boolean),
        ),
      ].slice(0, 4);
      const queries = [...new Set([search.profile.description, ...terms])];
      const seen = new Set(
        initial.versions
          .filter((v) => !v.deletedAt)
          .map((v) => v.voice?.voiceId),
      );
      let count = initial.versions.filter(
        (v) => v.voice?.searchId === sid,
      ).length;
      let failedDownloads = 0;
      let visited = 0;
      // Try native voices across every trait before multilingual fallbacks.
      // Cache the bounded search pages; retries never add LLM or TTS calls.
      const searchResults = new Map();
      for (const nativeOnly of [true, false]) {
        for (const query of queries) {
          for (let page = 0; page < 3 && count < 4; page++) {
            if (find(this.store.read(pid).assets, aid).voiceSearch?.id !== sid)
              return;
            const cacheKey = JSON.stringify([query, page]);
            if (!searchResults.has(cacheKey))
              searchResults.set(cacheKey, await this.search(search.profile, query, page));
            const result = searchResults.get(cacheKey);
            const ranked = result.voices
              .filter((v) => nativeOnly
                ? v.language === search.profile.language
                : v.verified_languages?.some((l) => l.language === search.profile.language && l.preview_url))
              .map((v, index) => ({
                v,
                index,
                score: (v.language === search.profile.language ? 10 : 0) + terms.filter((t) =>
                  (v.name + " " + v.description + " " + v.descriptive)
                    .toLowerCase()
                    .includes(t.toLowerCase()),
                ).length,
              }))
              .sort((a, b) => b.score - a.score || a.index - b.index);
            for (const { v } of ranked) {
              if (count >= 4 || visited >= 16) break;
              const languagePreview = v.verified_languages?.find(
                (l) => l.language === search.profile.language && l.preview_url,
              )?.preview_url;
              const url = languagePreview || v.preview_url;
              if (!v.voice_id || seen.has(v.voice_id) || !url) continue;
              seen.add(v.voice_id);
              visited++;
              const folder = path.join(
                path.dirname(this.store.file(pid)),
                "media",
              );
              fs.mkdirSync(folder, { recursive: true });
              const filename = id("voice") + ".mp3",
                destination = path.join(folder, filename),
                source = destination + ".source";
              try {
                const bytes = await boundedAudio(
                  await this.fetch(previewURL(url), {
                    signal: AbortSignal.timeout(30000),
                    redirect: "error",
                  }),
                );
                fs.writeFileSync(source, bytes);
                const info = await this.trim(source, destination);
                requireValue(
                  Number.isFinite(info.duration) &&
                    info.duration > 0 &&
                    info.duration <= 5,
                  "音色参考须为 5 秒以内的有效音频",
                );
                const output = fs.readFileSync(destination);
                const saved = this.update(pid, aid, sid, (a) => {
                  const version = {
                    id: id("v"),
                    createdAt: now(),
                    status: a.acceptedVersionId ? "alternative" : "pending",
                    source: "elevenlabs-preview",
                    media: {
                      path: "media/" + filename,
                      mime: "audio/mpeg",
                      size: output.length,
                      sha256: hash(output.toString("base64")),
                      duration: info.duration,
                    },
                    voice: {
                      provider: "elevenlabs",
                      voiceId: v.voice_id,
                      publicOwnerId: v.public_owner_id,
                      name: v.name,
                      description: v.description || "",
                      language: v.language,
                      gender: v.gender,
                      age: v.age,
                      searchId: sid,
                      keywords: search.profile.description,
                      matchedQuery: query,
                    },
                  };
                  a.versions.push(version);
                  a.voiceSearch.resultVersionIds.push(version.id);
                });
                if (!saved) {
                  fs.unlinkSync(destination);
                  return;
                }
                count++;
              } catch {
                failedDownloads++;
                if (fs.existsSync(destination)) fs.unlinkSync(destination);
              } finally {
                if (fs.existsSync(source)) fs.unlinkSync(source);
              }
            }
            if (!result.has_more || visited >= 16) break;
          }
          if (count >= 4 || visited >= 16) break;
        }
        if (count >= 4 || visited >= 16) break;
      }
      this.update(pid, aid, sid, (a) => {
        a.voiceSearch.status = count
          ? "completed"
          : failedDownloads
            ? "failed"
            : "empty";
        a.voiceSearch.error =
          failedDownloads && count < 4
            ? "部分试听未能下载或处理，可重试或更换关键词。"
            : null;
        a.voiceSearch.finishedAt = now();
      });
    } catch (error) {
      this.update(pid, aid, sid, (a) => {
        a.voiceSearch.status = "failed";
        a.voiceSearch.error = error.message;
      });
    }
  }
}
module.exports = { VoiceProvider, trimAudio, previewURL, SAMPLE_SECONDS };
