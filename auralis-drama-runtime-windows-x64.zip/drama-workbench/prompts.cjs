const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const titles = {
  'setting.md': '设定 Agent', 'production.md': '制作 Agent', 'canvas-io.md': '工作台操作规范',
  'asset-naming.md': '资产命名', 'turn.md': '每轮执行规范',
  'stages/synopsis.md': '梗概阶段', 'stages/storyboard.md': '文字分镜阶段',
  'stages/assets.md': '资产准备阶段', 'stages/video.md': '视频片段阶段',
  'guides/development.md': '世界观与走向', 'guides/episode-writing.md': '单集写作',
  'guides/shot-design.md': '镜头设计', 'guides/reference-assets.md': '参考资产制作',
  'guides/video-direction.md': '视频导演规范', 'guides/repair.md': '修改与修复',
  'voice-binding.md': '角色音色绑定',
};
const stageGuides = {
  setting: 'guides/development.md', synopsis: 'guides/episode-writing.md',
  storyboard: 'guides/shot-design.md', assets: 'guides/reference-assets.md', video: 'guides/video-direction.md',
};
class PromptLibrary {
  constructor(root, official = path.join(__dirname, 'agents')) {
    this.root = root; this.official = official; this.file = path.join(root, 'prompts.json');
  }
  overrides() { return fs.existsSync(this.file) ? JSON.parse(fs.readFileSync(this.file, 'utf8')) : {}; }
  list() {
    const overrides = this.overrides();
    return Object.entries(titles).filter(([id]) => fs.existsSync(path.join(this.official, id))).map(([id, title]) => {
      const official = fs.readFileSync(path.join(this.official, id), 'utf8'), saved = overrides[id] || {};
      return { id, title, official, custom: saved.custom ?? official, mode: saved.mode === 'custom' ? 'custom' : 'official' };
    });
  }
  save(id, custom, mode) {
    if (!this.list().some(item => item.id === id) || !['official', 'custom'].includes(mode) || typeof custom !== 'string' || custom.length > 100000 || (mode === 'custom' && !custom.trim())) throw new Error('提示词内容或模式无效');
    const data = this.overrides();
    data[id] = { custom, mode };
    fs.mkdirSync(this.root, { recursive: true });
    fs.writeFileSync(this.file + '.tmp', JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(this.file + '.tmp', this.file);
    return this.list();
  }
  snapshot() {
    const entries = this.list(), content = entries.map(p => [p.id, p[p.mode]]);
    const revision = crypto.createHash('sha256').update(JSON.stringify(content)).digest('hex');
    const root = path.join(this.root, 'prompt-snapshots', revision);
    if (!fs.existsSync(path.join(root, '.complete'))) {
      for (const [id, text] of content) {
        const file = path.join(root, id);
        fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, text, 'utf8');
      }
      fs.writeFileSync(path.join(root, '.complete'), revision, 'utf8');
    }
    const text = id => content.find(([key]) => key === id)?.[1] || '';
    return { root, revision, text, forStage(stage) {
      const role = stage === 'setting' ? 'setting.md' : 'production.md';
      const stageFile = stage === 'setting' ? role : 'stages/' + stage + '.md';
      const files = new Set([role, 'canvas-io.md', 'turn.md', stageFile, stageGuides[stage]]);
      // Include on-demand guide dependencies in invalidation, but never other stages.
      for (const file of files) for (const match of text(file).matchAll(/`((?:guides\/)?[\w-]+\.md)`/g)) {
        if (content.some(([key]) => key === match[1])) files.add(match[1]);
      }
      const revision = crypto.createHash('sha256').update(JSON.stringify([...files].sort().map(id => [id, text(id)]))).digest('hex');
      const manifest = [...files].map(id => ({ id, title: titles[id], mode: entries.find(p => p.id === id).mode,
        revision: crypto.createHash('sha256').update(text(id)).digest('hex'), characters: text(id).length }));
      const instructions = '以下规范已全文提供，文件名仅标识来源，无需再次打开相同文件。仅在内容缺失、版本变化或出现冲突时补读。\n\n' +
        manifest.map(file => `[已全文载入：${file.id}｜${file.title}｜${file.mode}｜版本 ${file.revision}]\n${text(file.id)}`).join('\n\n');
      return { revision, manifest, instructions, apiInstructions: instructions };
    } };
  }
}
module.exports = { PromptLibrary };
