// Reconcile only the production area; preserve unchanged images, focus and scroll.
function patchProductionHTML(container, html) {
  const template = document.createElement("template");
  template.innerHTML = html;
  const key = (node) =>
    node.nodeType === 1
      ? [
          "id",
          "data-asset-card",
          "data-clip-card",
          "data-version",
          "data-job",
          "data-round",
          "data-category",
        ]
          .map((a) => node.getAttribute(a) || "")
          .join("|")
      : "";
  function patch(old, next) {
    if (old.nodeType !== next.nodeType || old.nodeName !== next.nodeName) {
      old.replaceWith(next);
      return;
    }
    if (old.nodeType !== 1) {
      if (old.textContent !== next.textContent)
        old.textContent = next.textContent;
      return;
    }
    if (old.matches("input[type=checkbox]")) old.checked = next.checked;
    if (old.isEqualNode(next)) return;
    for (const a of [...old.attributes])
      if (
        !next.hasAttribute(a.name) &&
        !(old.tagName === "DETAILS" && a.name === "open")
      )
        old.removeAttribute(a.name);
    for (const a of next.attributes)
      if (old.getAttribute(a.name) !== a.value)
        old.setAttribute(a.name, a.value);
    children(old, next);
  }
  function children(old, next) {
    const keyed = new Map(
      [...old.childNodes]
        .map((n) => [key(n), n])
        .filter(([k]) => k && k.replace(/\|/g, "")),
    );
    let cursor = old.firstChild;
    for (const node of [...next.childNodes]) {
      const match =
        keyed.get(key(node)) ||
        (key(cursor || {}) === key(node) ? cursor : null);
      if (match) {
        if (match !== cursor) old.insertBefore(match, cursor);
        patch(match, node);
        cursor =
          match.parentNode === old ? match.nextSibling : node.nextSibling;
      } else old.insertBefore(node, cursor);
    }
    while (cursor) {
      const next = cursor.nextSibling;
      cursor.remove();
      cursor = next;
    }
  }
  children(container, template.content);
}
function refreshProductionUI() {
  if (["assets", "library", "video"].includes(S.stage)) {
    patchProductionHTML(
      $("workspace"),
      S.stage === "video" ? videos() : assetBoard(),
    );
    renderAttachments();
    renderAgentStatus();
    renderMessages();
  }
  refreshMediaReview();
  refreshAssetCanvas();
}
