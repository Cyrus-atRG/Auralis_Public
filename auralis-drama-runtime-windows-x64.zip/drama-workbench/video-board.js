S.clipSelection = new Set();
S.clipSubmissions = new Set();
const videoBoardActions = new Set([
  "clipSelectAll",
  "clipInvert",
  "clipClear",
  "clipVersion",
  "approveClip",
  "approveClips",
  "regenerateClips",
  "downloadClips",
  "downloadClip",
]);
function selectedClipInputs() {
  if (S.stage !== "video") return [];
  return (ep()?.clips || [])
    .filter((c) => S.clipSelection.has(c.id))
    .map((c) => {
      const version = selectedVersion(c);
      const number = version ? c.versions.indexOf(version) + 1 : null;
      return {
        id: "clip-" + c.id,
        name: c.title + (number ? " · 版本 " + number : " · 当前计划"),
        media: version?.media || null,
        source: { clipId: c.id, versionId: version?.id || null },
      };
    });
}
function downloadClips(selections) {
  const items = selections.filter((r) => r.versionId);
  if (!items.length) return toast("所选片段尚未生成视频");
  const link = document.createElement("a");
  link.href =
    "/downloads/" +
    S.project.id +
    "/" +
    ep().id +
    "?items=" +
    items.map((r) => r.clipId + ":" + r.versionId).join(",");
  link.download = "";
  document.body.append(link);
  link.click();
  link.remove();
}
function clipCard(clip) {
  const versions = clip.versions.filter((v) => !v.deletedAt && v.media);
  const jobs = mediaJobs("clip", clip.id);
  const selected = S.clipSelection.has(clip.id);
  const chosenJob = jobs.find((j) => j.id === S.cardVersions.get(clip.id));
  const version = selectedVersion(clip);
  const choice = chosenJob?.id || version?.id || jobs.at(-1)?.id || "";
  const attributes = `data-kind="clip" data-id="${clip.id}"`;
  return `<article class="asset-card clip-card${selected ? " selected" : ""}" data-clip-card="${clip.id}" tabindex="0" aria-label="选择 ${esc(clip.title)}">
    <button class="cover" type="button" data-action="preview" ${attributes} data-version="${choice}" aria-label="查看 ${esc(clip.title)}">
      ${chosenJob ? generationTile(chosenJob, true) : version ? media(version.media, false) : jobs.length ? generationTile(jobs.at(-1), true) : '<span class="clip-empty">查看提示词与参考</span>'}
      ${version?.id === clip.acceptedVersionId ? '<span class="badge accepted">已通过</span>' : ""}
    </button><div class="card-body"><div class="clip-heading"><input class="asset-select" type="checkbox" data-clip="${clip.id}" aria-label="选择 ${esc(clip.title)}" ${selected ? "checked" : ""}><h3>${esc(clip.title)}</h3></div>
    <p class="muted clip-summary">${clip.plan.duration} 秒 · ${esc(generationDescription("video", clip.plan))}<br>${clip.plan.refs.length} 个参考${clip.plan.pendingVoiceAssetIds?.length ? " · 待选音色" : ""}</p>
    <div class="candidate-thumbnails" aria-label="${esc(clip.title)}的版本">${versions.map((v, i) => `<button type="button" data-action="clipVersion" data-id="${clip.id}" data-version="${v.id}" aria-pressed="${choice === v.id}" aria-label="版本 ${i + 1}">${media(v.media, false)}<span class="clip-version-label">${i + 1}</span></button>`).join("")}${jobs.map((j) => `<div class="candidate-job"><button type="button" data-action="clipVersion" data-id="${clip.id}" data-version="${j.id}" aria-pressed="${choice === j.id}" aria-label="${esc(statusNames[j.status])}">${generationTile(j)}</button>${retryJobButton(j)}</div>`).join("")}</div>
    ${generationFailure(jobs)}<div class="actions">${btn("打开画布", "canvas", attributes)}${btn(version?.id === clip.acceptedVersionId ? "已通过" : "通过", "approveClip", `data-id="${clip.id}" ${!version ? "disabled" : 'title="点击切换通过状态"'}`, "primary")}${btn("下载", "downloadClip", `data-id="${clip.id}" ${!version ? "disabled" : ""}`)}</div></div></article>`;
}
function videoBoard() {
  const clips = ep().clips;
  const selected = clips.filter((c) => S.clipSelection.has(c.id));
  const submitting = S.clipSubmissions.has(S.project.id + "/" + ep().id);
  return (
    impacts() +
    `<div class="row spread board-heading"><h2>视频片段</h2><div class="actions">${clearFailedJobsButton()}${btn("全选", "clipSelectAll")}${btn("＋ 规划片段", "editClip")}</div></div>` +
    (selected.length
      ? `<div id="clipSelectionToolbar" class="selection-toolbar" role="toolbar" aria-label="已选片段操作"><strong>已选 ${selected.length} 个片段</strong>${btn("全选", "clipSelectAll")}${btn("反选", "clipInvert")}${btn("取消选择", "clipClear")}${btn("批量通过", "approveClips")}${selected.some((c) => selectedVersion(c)) ? btn(submitting ? "正在提交…" : "重新生成", "regenerateClips", submitting ? 'disabled aria-busy="true"' : "", "primary") : btn("确认所选片段并生成", "batch", "", "primary")}${btn("下载", "downloadClips", selected.some((c) => selectedVersion(c)) ? "" : "disabled")}</div>`
      : "") +
    (clips.length
      ? `<div id="videoClipGrid" class="cards">${clips.map(clipCard).join("")}</div>`
      : empty(
          "还没有视频片段",
          "通过文字分镜和所需资产后，让 Agent 规划片段。",
        )) +
    jobs()
  );
}
async function videoBoardAction(action, data) {
  const clips = ep().clips;
  if (action === "clipSelectAll")
    clips.forEach((c) => S.clipSelection.add(c.id));
  if (action === "clipInvert")
    clips.forEach((c) =>
      S.clipSelection.has(c.id)
        ? S.clipSelection.delete(c.id)
        : S.clipSelection.add(c.id),
    );
  if (action === "clipClear") S.clipSelection.clear();
  if (action === "clipVersion") S.cardVersions.set(data.id, data.version);
  if (action === "downloadClip") {
    const clip = clips.find((c) => c.id === data.id);
    return downloadClips([
      { clipId: clip.id, versionId: selectedVersion(clip)?.id },
    ]);
  }
  if (action === "downloadClips")
    return downloadClips(selectedClipInputs().map((r) => r.source));
  if (action === "regenerateClips") {
    const pid = S.project.id, eid = ep().id, scope = pid + "/" + eid;
    if (S.clipSubmissions.has(scope)) return;
    const selected = clips.filter((c) => S.clipSelection.has(c.id));
    if (!selected.length) return;
    S.clipSubmissions.add(scope);
    refreshProductionUI();
    try {
      await apply(
        selected.map((c) => {
          // Generate from the current plan, regardless of the previewed version.
          const plan = c.plan;
          return {
            type: "generateClipVariation",
            episodeId: eid,
            clipId: c.id,
            expectedPlanRevision: c.planRevision,
            prompt: plan.prompt,
            refs: plan.refs,
            speakingAssetIds: plan.speakingAssetIds || [],
            generation: {
              model: plan.model,
              duration: plan.duration,
              resolution: plan.resolution,
              aspectRatio: plan.aspectRatio,
            },
          };
        }),
      );
      if (S.project?.id === pid && S.episodeId === eid) {
        selected.forEach((c) => S.clipSelection.delete(c.id));
        toast("已加入 " + selected.length + " 个生成任务");
      }
    } finally {
      S.clipSubmissions.delete(scope);
      if (S.project?.id === pid && S.episodeId === eid) refreshProductionUI();
    }
    return;
  }
  if (["approveClip", "approveClips"].includes(action)) {
    const targets = clips.filter((c) =>
      action === "approveClip" ? c.id === data.id : S.clipSelection.has(c.id),
    );
    const operations = targets.flatMap((c) => {
      const version = selectedVersion(c);
      return version
        ? [
            {
              type: "review",
              targetType: "clip",
              targetId: c.id,
              episodeId: ep().id,
              versionId: version.id,
              decision: action === "approveClip" && c.acceptedVersionId === version.id ? "unaccepted" : "accepted",
            },
          ]
        : [];
    });
    if (!operations.length) return toast("先选择已生成的视频版本");
    await apply(operations);
    if (action === "approveClips") S.clipSelection.clear();
    else for (const op of operations) S.clipSelection.delete(op.targetId);
  }
  refreshProductionUI();
}
function toggleClip(id) {
  S.clipSelection.has(id)
    ? S.clipSelection.delete(id)
    : S.clipSelection.add(id);
  refreshProductionUI();
}
document.addEventListener("click", (event) => {
  const card = event.target.closest("[data-clip-card]");
  if (!card || event.target.closest("button,a,input,video,textarea,select"))
    return;
  toggleClip(card.dataset.clipCard);
});
document.addEventListener("change", (event) => {
  if (!event.target.matches("[data-clip]")) return;
  const id = event.target.dataset.clip;
  event.target.checked ? S.clipSelection.add(id) : S.clipSelection.delete(id);
  refreshProductionUI();
});
document.addEventListener("keydown", (event) => {
  if (
    !event.target.matches("[data-clip-card]") ||
    !["Enter", " "].includes(event.key)
  )
    return;
  event.preventDefault();
  toggleClip(event.target.dataset.clipCard);
});
