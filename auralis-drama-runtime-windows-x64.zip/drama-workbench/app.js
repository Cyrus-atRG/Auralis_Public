/* Standalone workbench: the server owns review, version and generation authority. */
const $ = (id) => document.getElementById(id),
  esc = (v) =>
    String(v ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
const stageNames = {
  setting: "共享设定",
  synopsis: "梗概",
  storyboard: "文字分镜",
  assets: "资产准备",
  video: "视频片段",
};
const kindNames = {
  unclassified: "待分类",
  character: "人物",
  costume: "服装变体",
  scene: "场景",
  prop: "道具",
  audio: "声音",
  video: "视频参考",
};
const statusNames = {
  queued: "排队",
  preparing: "准备参考",
  submitting: "正在提交",
  polling: "生成中",
  downloading: "保存素材",
  completed: "完成",
  failed: "失败",
  cancelled: "已停止",
  submission_unknown: "提交结果未知",
  superseded: "输入已改，请重确认",
};
const S = {
  token: "",
  projects: [],
  project: null,
  episodeId: null,
  stage: "setting",
  drafts: {},
  documentBases: {},
  documentSaving: {},
  documentConflicts: {},
  models: {},
  defaults: {},
  after: 0,
  agentRunning: false,
  agentStatus: "idle",
  agentDetail: "",
  selectedReferences: new Set(),
  messages: [],
  agentDrafts: {},
  agentPending: {},
  selectedSettings: new Set(),
  modal: null,
};
const ep = () => S.project?.episodes.find((e) => e.id === S.episodeId),
  latest = (d) => d?.versions.at(-1),
  adopted = (d) => d?.versions.find((v) => v.id === d.acceptedVersionId);
function visibleVersion(target, pinnedVersionId) {
  if (!target) return null;
  return (
    target.versions.find(
      (v) =>
        !v.deletedAt &&
        v.id === (pinnedVersionId || target.acceptedVersionId) &&
        v.media,
    ) ||
    target.versions.findLast(
      (v) => !v.deletedAt && v.media && v.status !== "rejected",
    ) ||
    target.versions.findLast((v) => !v.deletedAt && v.media)
  );
}
function candidateThumbnails(kind, target) {
  return (
    '<div class="candidate-thumbnails" aria-label="' +
    esc(target.name || target.title) +
    '的候选">' +
    target.versions
      .filter((v) => !v.deletedAt && v.media)
      .map(
        (v, i) =>
          '<button type="button" data-action="preview" data-kind="' +
          kind +
          '" data-id="' +
          target.id +
          '" data-version="' +
          v.id +
          '" title="版本 ' +
          (i + 1) +
          " · " +
          (v.status === "accepted"
            ? "已采用"
            : ["rejected", "alternative"].includes(v.status)
              ? "备选"
              : "待审核") +
          '" aria-label="查看版本 ' +
          (i + 1) +
          '">' +
          media(v.media, false) +
          "</button>",
      )
      .join("") +
    "</div>"
  );
}
const mediaUrl = (m) =>
  "/media/" + S.project.id + "/" + m.path.split("/").at(-1);
const btn = (label, action, attrs = "", cls = "") =>
  '<button class="' +
  cls +
  '" data-action="' +
  action +
  '" ' +
  attrs +
  ">" +
  label +
  "</button>";
const badge = (v) =>
  v
    ? '<span class="badge ' +
      (v.status || "") +
      '">' +
      ({
        pending: "待审核",
        accepted: "已通过",
        alternative: "备选",
        rejected: "备选",
      }[v.status] || v.status) +
      "</span>"
    : '<span class="badge pending">待制作</span>';
function media(m, controls = true) {
  if (!m) return '<span class="placeholder">尚未生成</span>';
  const src = esc(mediaUrl(m));
  if (m.mime.startsWith("image/"))
    return '<img loading="lazy" src="' + src + '" alt="素材预览">';
  if (m.mime.startsWith("video/"))
    return (
      '<video src="' +
      src +
      '" ' +
      (controls ? "controls" : 'muted preload="metadata"') +
      "></video>"
    );
  return '<audio src="' + src + '" controls></audio>';
}
async function api(route, body, raw = false) {
  const r = await fetch("/api/" + route, {
    method: body === undefined ? "GET" : "POST",
    headers: {
      Authorization: "Bearer " + S.token,
      ...(body === undefined
        ? {}
        : { "Content-Type": raw ? body.type : "application/json" }),
    },
    ...(body === undefined ? {} : { body: raw ? body : JSON.stringify(body) }),
  });
  const result = await r.json();
  if (!r.ok)
    throw Object.assign(new Error(result.error?.message || "请求失败"), {
      code: result.error?.code,
    });
  return result;
}
function toast(message, error = false) {
  $("toast").textContent = message;
  $("toast").className = error ? "error" : "";
  $("toast").style.display = "block";
  clearTimeout(S.toastTimer);
  S.toastTimer = setTimeout(() => ($("toast").style.display = "none"), 6500);
}
// Full snapshots may arrive out of order from media, navigation and agent requests.
function acceptProjectSnapshot(project, select = false) {
  const sameProject = S.project?.id === project.id;
  if (!sameProject && !select) return false;
  const minimum = sameProject ? Math.max(S.project.revision, S.projectRevisionFloor || 0) : 0;
  if (project.revision < minimum || (sameProject && (project.activityRevision || 0) < Math.max(S.project.activityRevision || 0, S.projectActivityFloor || 0))) return false;
  S.project = project;
  S.projectRevisionFloor = project.revision;
  S.projectActivityFloor = project.activityRevision || 0;
  return true;
}
function requestAgentSync() {
  const run = S.project?.agentRuns?.[agentScopeKey()];
  if (!S.agentPending[S.agentKey] && run?.turnId &&
      (run.turnId !== S.agentTurn || run.status !== S.agentStatus)) S.agentNeedsSync = true;
}
async function loadProject(id, renderNow = true) {
  const request = S.projectLoad = (S.projectLoad || 0) + 1;
  const [project, projects] = await Promise.all([api("projects/" + id), api("projects")]);
  if (request !== S.projectLoad) return;
  if (!acceptProjectSnapshot(project, true)) return;
  S.projects = projects;
  if (S.episodeId && !ep()) S.episodeId = null;
  // Media refreshes never assign the active agent turn or its status.
  requestAgentSync();
  if (renderNow) render();
}
function agentScopeKey() {
  return S.stage === "library" ? "library" : S.episodeId ? S.episodeId + "/" + S.stage : "setting";
}
function renderControllerChoice() {
  const selected = S.controller || { mode: "local-codex" };
  const label = selected.mode === "company" ? "公司 API · " + selected.companyModel : "本地 Codex";
  const run = S.project?.agentRuns?.[agentScopeKey()];
  const activeLabel = run?.provider === "company" ? "公司 API · " + run.model : "本地 Codex";
  $("agentController").textContent = run?.status === "running" && activeLabel !== label
    ? "本轮：" + activeLabel + "；下轮：" + label : "主控：" + label;
  $("agentController").hidden = S.stage === "library";
}
function mergeAgentMessages(messages) {
  const ids = new Set(messages.map(m => m.id));
  const persistedTurns = new Set(messages.filter(m => m.role === "agent").map(m => m.turnId));
  S.messages = [...messages, ...S.messages.filter(m => !ids.has(m.id) && m.turnId === S.agentTurn && !persistedTurns.has(m.turnId))];
}
async function apply(operations, expectedRevision = S.project.revision) {
  const pid = S.project.id;
  try {
    const result = await api("projects/" + pid + "/apply", {
      requestId: crypto.randomUUID(),
      expectedRevision,
      operations,
    });
    const localMedia = operations.every(
      (op) =>
        [
          "generateAssetVariation",
          "generateClipVariation",
          "approveBatch",
          "deleteMediaVersion",
          "saveAssetCanvas",
          "importAsset",
          "generate",
          "retryJob",
          "cancelJob",
        ].includes(op.type) ||
        (op.type === "review" && ["asset", "clip"].includes(op.targetType)),
    );
    if (S.project?.id !== pid) return result;
    await loadProject(pid, !localMedia);
    if (localMedia) refreshProductionUI();
    return result;
  } catch (error) {
    if (S.project?.id !== pid) throw error;
    if (error.code === "plan_conflict") {
      const refreshed = await api("projects/" + pid);
      if (S.project?.id !== pid) throw error;
      acceptProjectSnapshot(refreshed);
      const clip = ep()?.clips.find(c => c.id === operations[0].clipId);
      if (clip && S.modal?.mediaViewer) {
        S.modal.revision = S.project.revision;
        S.modal.planRevision = clip.planRevision;
        error.message = "片段计划已更新。当前提示词：" + clip.plan.prompt + "\n你的输入已保留，核对后可再次生成。";
      }
      refreshProductionUI();
    }
    if (error.code === "revision_conflict") {
      const refreshed = await api("projects/" + pid);
      if (S.project?.id !== pid) throw error;
      acceptProjectSnapshot(refreshed);
      const e = ep();
      const current = operations
        .map((op) => {
          if (op.type === "setSynopsis") return latest(e.synopsis)?.text;
          if (op.type === "setStoryboard") return latest(e.storyboard)?.text;
          if (op.type === "setSetting")
            return latest(S.project.settings.find((x) => x.id === op.id))?.text;
          if (op.assetId)
            return S.project.assets.find((a) => a.id === op.assetId)?.prompt;
          if (op.id) return e?.clips.find((c) => c.id === op.id)?.plan.prompt;
          return "项目状态已经更新，请重新核对所选内容。";
        })
        .filter(Boolean)
        .join("\n\n");
      document
        .querySelectorAll(".concurrent-change")
        .forEach((x) => x.remove());
      const notice = document.createElement("div");
      notice.className = "notice concurrent-change";
      notice.innerHTML =
        "<strong>服务端已有新内容。你的输入保留在下方，核对后再保存。</strong><pre>" +
        esc(current) +
        "</pre>";
      if ($("dialog").open) {
        $("dialogBody").querySelector(".dialog-head").after(notice);
        if (S.modal) S.modal.revision = S.project.revision;
      } else {
        const form = $("documentForm");
        if (form) {
          form.dataset.revision = S.project.revision;
          form.prepend(notice);
        } else render();
      }
      error.message = "内容有并发修改，已展示当前版本；请核对保留的输入。";
    }
    throw error;
  }
}
function openDialog(title, html, wide = false) {
  $("dialogBody").hidden = false;
  if ($("mediaFrame")) $("mediaFrame").hidden = true;
  $("dialog").className = wide ? "wide" : "";
  $("dialogBody").innerHTML =
    '<div class="dialog-head"><h2>' +
    esc(title) +
    "</h2>" +
    btn("×", "close", 'aria-label="关闭"') +
    "</div>" +
    html;
  if (!$("dialog").open) $("dialog").showModal();
}
function closeDialog() {
  stashMediaDrafts();
  stashCanvasDraft();
  if (S.modal?.mediaViewer) $("mediaFrame")?.contentWindow.AuralisCanvas?.closeMedia();
  $("dialog").close();
  S.modal = null;
}
$("dialog").addEventListener("click", (event) => {
  if (event.target !== $("dialog")) return;
  const bounds = $("dialog").getBoundingClientRect();
  if (
    event.clientX < bounds.left ||
    event.clientX > bounds.right ||
    event.clientY < bounds.top ||
    event.clientY > bounds.bottom
  )
    closeDialog();
});
$("dialog").addEventListener("cancel", (event) => {
  event.preventDefault();
  closeDialog();
});
function field(name, label, value = "", type = "text", required = true) {
  return (
    "<label>" +
    label +
    '<input name="' +
    name +
    '" type="' +
    type +
    '" value="' +
    esc(value) +
    '"' +
    (required ? " required" : "") +
    "></label>"
  );
}
function textField(name, label, value = "", rows = 7) {
  return (
    "<label>" +
    label +
    '<textarea name="' +
    name +
    '" rows="' +
    rows +
    '" required>' +
    esc(value) +
    "</textarea></label>"
  );
}
function empty(title, detail, action = "") {
  return (
    '<div class="empty"><div class="symbol">✧</div><h3>' +
    title +
    "</h3><p>" +
    detail +
    "</p>" +
    action +
    "</div>"
  );
}
function render() {
  const editor = $("documentText"),
    caret = editor && document.activeElement === editor
      ? { key: editor.dataset.draft, start: editor.selectionStart, end: editor.selectionEnd, scroll: editor.scrollTop } : null;
  const p = S.project,
    e = ep();
  const agentKey = (p?.id || "") + "/" + agentScopeKey();
  if (S.agentKey !== agentKey) {
    if (S.agentKey) S.agentDrafts[S.agentKey] = {
      text: $("agentInput").value,
      settings: [...S.selectedSettings], references: [...S.selectedReferences],
      assets: [...S.assetSelection], clips: [...S.clipSelection],
    };
    S.agentKey = agentKey;
    S.agentRevision = p?.revision || 0;
    S.agentActivityRevision = p?.activityRevision || 0;
    const draft = S.agentDrafts[agentKey];
    $("agentInput").value = draft?.text || "";
    S.selectedSettings = new Set(draft?.settings || []);
    S.selectedReferences = new Set(draft?.references || []);
    S.assetSelection = new Map(draft?.assets || []);
    S.clipSelection = new Set(draft?.clips || []);
    const run = p?.agentRuns?.[agentScopeKey()];
    S.agentRunning = run?.status === "running";
    S.agentStatus = S.agentPending[agentKey] === "starting" ? "starting" : run?.status || "idle";
    S.agentStartedAt = run?.startedAt;
    S.agentFinishedAt = run?.finishedAt;
    S.agentDetail = "";
    S.agentError = run?.error;
    S.agentNeedsSync = !!run?.turnId;
    S.agentTurn = run?.turnId;
    S.agentAura = run?.auraId;
    S.after = 0;
    S.messages = [...(p?.agentConversations?.[agentScopeKey()]?.messages || [])];
    renderMessages();
  }
  // A background agent may remove an item that is still selected in a draft.
  S.selectedSettings = new Set([...S.selectedSettings].filter((id) => p?.settings.some((s) => s.id === id)));
  S.selectedReferences = new Set([...S.selectedReferences].filter((id) => p?.references.some((r) => r.id === id)));
  $("navigation").innerHTML =
    btn("所有短剧", "home", "", "nav-item " + (!p ? "active" : "")) +
    (!p
      ? ""
      : '<div class="rail-label">' +
        esc(p.title) +
        "</div>" +
        btn(
          "设定与走向",
          "setting",
          "",
          "nav-item " + (!e && S.stage === "setting" ? "active" : ""),
        ) +
        btn(
          "公共资产库",
          "library",
          "",
          "nav-item " + (S.stage === "library" ? "active" : ""),
        ) +
        '<div class="rail-label">分集画布</div>' +
        p.episodes
          .slice()
          .sort((a, b) => a.number - b.number)
          .map((x) =>
            btn(
              '<span class="episode-num">' +
                String(x.number).padStart(2, "0") +
                "</span>" +
                esc(x.title),
              "episode",
              'data-id="' + x.id + '"',
              "nav-item " + (e?.id === x.id ? "active" : ""),
            ),
          )
          .join("") +
        btn("＋ 开始一集", "newEpisode", "", "nav-item"));
  $("stages").innerHTML = e
    ? Object.entries(stageNames)
        .filter(([s]) => s !== "setting")
        .map(([s, label], i) =>
          btn(
            '<span class="stage-number">0' + (i + 1) + "</span>" + label,
            "stage",
            'data-stage="' + s + '"',
            S.stage === s ? "active" : "",
          ),
        )
        .join("")
    : "";
  $("header").innerHTML = p
    ? '<div class="title-action"><div><span class="eyebrow">' +
      (e
        ? "EPISODE " + String(e.number).padStart(2, "0")
        : "SERIES WORKSPACE") +
      "</span><h1>" +
      esc(e?.title || p.title) +
      '</h1><span class="muted">' +
      (e ? esc(stageNames[S.stage]) : "共享的世界、人物与故事走向") +
      "</span></div>" +
      '<div class="actions">' +
      btn("生成设置", "settings") +
      btn("↻", "refresh", 'aria-label="刷新项目"', "quiet") +
      "</div>" +
      "</div>"
    : '<span class="eyebrow">YOUR STORIES, IN PRODUCTION</span>';
  $("workspace").innerHTML = !p
    ? home()
    : S.stage === "library"
      ? assets(true)
      : !e
        ? settings()
        : ["synopsis", "storyboard"].includes(S.stage)
          ? documentStage()
          : S.stage === "assets"
            ? assets()
            : videos();
  document
    .querySelector("main")
    .classList.toggle(
      "document-workspace",
      !!e && ["synopsis", "storyboard"].includes(S.stage),
    );
  $("agentRole").textContent = S.stage === "library" ? "公共资产库" : (stageNames[S.stage] || "设定") + " Agent";
  renderControllerChoice();
  $("agentScope").textContent = S.stage === "library" ? "选择分集的资产准备或视频页面，与对应 Agent 继续。" : e
    ? "只处理本集的" + (stageNames[S.stage] || "资产") + "。"
    : "建立世界观、人物和整体走向。";
  $("agentForm").hidden = S.stage === "library";
  $("settingSelection").innerHTML = p
    ? p.settings
        .map(
          (d) =>
            '<label><input type="checkbox" data-setting="' +
            d.id +
            '" ' +
            (S.selectedSettings.has(d.id) ? "checked" : "") +
            ">" +
            esc(d.title) +
            "</label>",
        )
        .join("")
    : "创建项目后可选择。";
  $("agentForm").querySelector("button[type=submit]").disabled =
    !p || S.stage === "library";
  renderAgentStatus();
  renderAttachments();
  renderMessages();
  if (caret && $("documentText")?.dataset.draft === caret.key) {
    $("documentText").focus({ preventScroll: true });
    $("documentText").setSelectionRange(caret.start, caret.end);
    $("documentText").scrollTop = caret.scroll;
  }
}
function generationModel(kind, value) {
  if (S.models[value]?.kind === kind) return value;
  return (
    Object.keys(S.models).find((key) => {
      const m = S.models[key];
      return (
        m.kind === kind &&
        [m.endpointModel, m.textEndpointModel, m.editEndpointModel].includes(
          value,
        )
      );
    }) || S.defaults[kind].model
  );
}
function selectField(name, label, options, value, attrs = "") {
  return (
    "<label>" +
    label +
    '<select name="' +
    name +
    '" ' +
    attrs +
    ">" +
    options
      .map(
        ([key, title]) =>
          '<option value="' +
          esc(key) +
          '"' +
          (key === value ? " selected" : "") +
          ">" +
          esc(title) +
          "</option>",
      )
      .join("") +
    "</select></label>"
  );
}
function generationOptions(kind, config) {
  const model = S.models[config.model];
  const resolution = model.resolutions.includes(config.resolution)
    ? config.resolution
    : model.resolutions[0];
  const aspect = model.aspectRatios.includes(config.aspectRatio)
    ? config.aspectRatio
    : model.aspectRatios[0];
  let html =
    '<div class="two">' +
    selectField(
      kind + "Resolution",
      "清晰度",
      model.resolutions.map((x) => [x, x === "1080" ? "1K" : x.toUpperCase()]),
      resolution,
    ) +
    selectField(
      kind + "AspectRatio",
      "比例",
      model.aspectRatios.map((x) => [x, x]),
      aspect,
    ) +
    "</div>";
  if (kind === "video")
    html +=
      "<label>时长（" +
      model.durationMin +
      "–" +
      model.durationMax +
      ' 秒）<input name="videoDuration" type="number" min="' +
      model.durationMin +
      '" max="' +
      model.durationMax +
      '" step="1" value="' +
      Math.min(
        model.durationMax,
        Math.max(model.durationMin, config.duration || 8),
      ) +
      '" required></label>';
  return html;
}
function generationFields(kind, value) {
  const config = {
    ...S.defaults[kind],
    ...value,
    model: generationModel(kind, value.model),
  };
  return (
    '<fieldset class="generation-fields" data-generation="' +
    kind +
    '"><legend>' +
    (kind === "image" ? "生图" : "生视频") +
    "</legend>" +
    selectField(
      kind + "Model",
      "模型",
      Object.entries(S.models)
        .filter(([, m]) => m.kind === kind)
        .map(([key, m]) => [key, m.label]),
      config.model,
      'data-generation-model="' + kind + '"',
    ) +
    '<div class="generation-options">' +
    generationOptions(kind, config) +
    "</div></fieldset>"
  );
}
function generationFromForm(form, kind) {
  const f = new FormData(form);
  return {
    model: f.get(kind + "Model"),
    resolution: f.get(kind + "Resolution"),
    aspectRatio: f.get(kind + "AspectRatio"),
    ...(kind === "video" ? { duration: Number(f.get("videoDuration")) } : {}),
  };
}
function generationDescription(kind, config) {
  const values = { ...S.defaults[kind], ...config };
  const m = S.models[generationModel(kind, values.model)];
  return esc(
    m.label +
      " · " +
      (values.resolution === "1080" ? "1K" : values.resolution.toUpperCase()) +
      " · " +
      values.aspectRatio,
  );
}
function renderAgentInputs() {
  const run = S.project?.agentRuns?.[agentScopeKey()];
  const manifest = run?.inputManifest;
  $("agentInputs").hidden = !manifest || S.stage === "library";
  if (!manifest) return;
  if ($("agentInputManifest").dataset.turn === run.turnId) return;
  $("agentInputManifest").dataset.turn = run.turnId;
  $("agentInputManifest").innerHTML = '<p>规范已全文提供，无需重复读文件。</p><ul>' + manifest.prompts.map(p =>
    '<li title="' + esc(p.id + ' · ' + p.revision) + '">' + esc(p.title) + (p.mode === 'custom' ? '（自定义）' : '') + '</li>').join('') +
    '</ul><p>作品与参考</p><ul>' + manifest.materials.map(m => '<li title="' + esc(String(m.versionId || '')) + '">' + esc(m.title) + ' <span class="muted">' + esc(m.mode) +
      (m.versionId ? ' · ' + esc(String(m.versionId).slice(0, 12)) : '') + '</span></li>').join('') + '</ul>' +
    '<p class="muted">另有公共资产目录 ' + manifest.assetIndexCount + ' 项。' + (manifest.history.continued ? '本轮沿用本环节执行会话。' :
      '本轮带入历史用户消息 ' + manifest.history.userMessages + ' 条、Agent 回复 ' + manifest.history.agentMessages + ' 条。') +
    (manifest.history.rotated ? '已换用新执行会话，移除旧工具记录。' : '') + '</p>';
}
function renderAgentStatus() {
  renderAgentInputs();
  const state = S.agentStatus || "idle";
  const labels = {
    idle: "等待输入",
    starting: "正在启动",
    running: "正在运行",
    stopping: "正在停止",
    completed: "本轮已完成",
    interrupted: "已停止",
    failed: "运行失败",
    disconnected: "连接中断，正在重连",
    unknown: "正在确认运行状态",
  };
  const active = [
    "starting",
    "running",
    "stopping",
    "disconnected",
    "unknown",
  ].includes(state);
  S.agentRunning = active;
  const elapsed = S.agentStartedAt
    ? Math.max(
        0,
        Math.floor(
          ((S.agentFinishedAt ? Date.parse(S.agentFinishedAt) : Date.now()) -
            Date.parse(S.agentStartedAt)) /
            1000,
        ),
      )
    : 0;
  $("agentStatus").dataset.state = state;
  $("agentCompactStatus").textContent = labels[state] || labels.unknown;
  $("agentStatus").innerHTML =
    '<div class="status-line"><span class="status-indicator"></span><strong>' +
    (labels[state] || labels.unknown) +
    "</strong>" +
    (S.agentStartedAt
      ? "<time>" +
        Math.floor(elapsed / 60) +
        ":" +
        String(elapsed % 60).padStart(2, "0") +
        "</time>"
      : "") +
    "</div>" +
    (S.agentError || (active && S.agentDetail)
      ? '<span class="status-detail">' +
        esc(S.agentError || S.agentDetail) +
        "</span>"
      : "");
  $("agentStop").disabled =
    !S.project || !S.agentTurn || !active || !!S.agentPending[S.agentKey] || ["starting", "stopping"].includes(state);
  const submit = $("agentForm").querySelector("button[type=submit]");
  submit.disabled = !S.project || S.stage === "library" || !!S.agentPending[S.agentKey] ||
    (active && state !== "running") || S.uploadingReferences || S.documentSaving[S.episodeId + "-" + S.stage];
  submit.textContent = S.agentPending[S.agentKey] === "appending" ? "追加中…" : state === "running" ? "追加消息 ↗" : "发送 ↗";
  submit.title = (state === "running" ? "追加消息" : "发送") + "（Ctrl+Enter / ⌘+Enter）";
  $("agentInput").placeholder = state === "running" ? "还可以补充要求，创作搭档会接着处理…" : "告诉它你想怎么改…";
  $("agentForm").querySelector("[data-action=addReference]").disabled =
    !S.project || !!S.uploadingReferences;
}
function referenceThumbnail(r) {
  if (!r.media) return '<span class="attachment-plan">片段计划</span>';
  if (r.media.mime.startsWith("video/"))
    return '<video src="' + mediaUrl(r.media) + '#t=0.1" muted playsinline preload="metadata" aria-label="' + esc(r.name) + '"></video>';
  return '<img src="' + mediaUrl(r.media) + '" alt="' + esc(r.name) + '">';
}
function renderAttachments() {
  const refs = S.project?.references || [];
  S.selectedReferences = new Set(
    [...S.selectedReferences].filter((id) => refs.some((r) => r.id === id)),
  );
  $("agentAttachments").innerHTML =
    [
      ...refs.filter((r) => S.selectedReferences.has(r.id)),
      ...selectedAssetInputs(),
      ...selectedClipInputs(),
    ]
      .map(
        (r) =>
          '<div class="attachment" title="' + esc(r.name) + '">' + referenceThumbnail(r) +
          '<button type="button" data-action="detachReference" data-id="' +
          (r.source?.clipId || (r.source && S.assetSelection.has(r.source.assetId)
            ? r.source.assetId
            : r.id)) +
          '" aria-label="取消带入 ' +
          esc(r.name) +
          '">×</button><span>' +
          esc(r.name) +
          "</span></div>",
      )
      .join("") +
    (S.uploadingReferences ? '<span role="status">正在上传图片…</span>' : "");
  document.querySelectorAll("[data-reference]").forEach((input) => {
    input.checked = S.selectedReferences.has(input.dataset.reference);
  });
}
function referenceGallery() {
  return (
    '<section class="reference-section" data-image-drop><div class="row spread"><div><h2>参考与灵感</h2><p class="muted">上传、粘贴或拖入图片，选中后带入本轮对话。</p></div>' +
    btn("添加图片", "addReference") +
    "</div>" +
    (S.project.references.length
      ? '<div class="reference-gallery">' +
        S.project.references
          .map(
            (r) =>
              '<article class="reference-item"><a href="' +
              mediaUrl(r.media) +
              '" target="_blank" rel="noopener"><img src="' +
              mediaUrl(r.media) +
              '" alt="' +
              esc(r.name) +
              '"></a><label><input type="checkbox" data-reference="' +
              r.id +
              '"' +
              (S.selectedReferences.has(r.id) ? " checked" : "") +
              ">带入本轮</label><strong>" +
              esc(r.name) +
              "</strong>" +
              (r.note ? "<p>" + esc(r.note) + "</p>" : "") +
              '<div class="actions">' +
              (S.project.assets.some((a) => a.id === (r.importedAssetId || r.source?.assetId))
                ? '<button type="button" disabled>已在资产库</button>'
                : btn("导入资产库", "importReferenceAsset", 'data-id="' + r.id + '"', "quiet")) +
              btn("说明", "editReference", 'data-id="' + r.id + '"', "quiet") +
              btn(
                "移除",
                "removeReference",
                'data-id="' + r.id + '"',
                "quiet",
              ) +
              "</div></article>",
          )
          .join("") +
        "</div>"
      : '<button class="reference-drop" data-action="addReference">把参考图放进来<span>人物、画风、场景，或想一起讨论的灵感</span></button>') +
    "</section>"
  );
}
async function uploadReferences(files) {
  if (!S.project) return toast("先创建或打开一个短剧");
  if (S.uploadingReferences) return toast("图片正在上传，请稍候");
  const items = [...files];
  if (!items.length) return;
  if (
    items.some(
      (file) => !["image/png", "image/jpeg", "image/webp"].includes(file.type),
    )
  )
    return toast("参考图片支持 PNG、JPG、WebP", true);
  const pid = S.project.id;
  S.uploadingReferences = true;
  renderAttachments();
  renderAgentStatus();
  try {
    for (const file of items) {
      const media = await api("projects/" + pid + "/upload", file, true);
      const project = await api("projects/" + pid);
      const result = await api("projects/" + pid + "/apply", {
        requestId: crypto.randomUUID(),
        expectedRevision: project.revision,
        operations: [
          { type: "addReference", name: file.name || "粘贴的参考图", media },
        ],
      });
      if (S.project?.id === pid) S.selectedReferences.add(result.results[0].id);
    }
    if (S.project?.id === pid) await loadProject(pid);
    toast("图片已保存，发送时会带给 Agent");
  } catch (error) {
    toast(error.message, true);
  } finally {
    S.uploadingReferences = false;
    $("referenceFiles").value = "";
    renderAttachments();
    renderAgentStatus();
  }
}
function home() {
  return (
    '<section class="welcome"><span class="eyebrow">AURALIS / DRAMA STUDIO</span><h1>让一个设定，<br>长成<em>一段故事。</em></h1><p>世界和人物放在一起。每次专注一集，逐步审阅文字、设定图与视频。</p>' +
    btn("＋ 新建短剧", "newProject", "", "primary") +
    '</section><div class="project-grid">' +
    S.projects
      .map(
        (p, i) =>
          '<button class="project-card" data-action="project" data-id="' +
          p.id +
          '" aria-haspopup="menu"><span class="number">' +
          String(i + 1).padStart(2, "0") +
          "</span><h3>" +
          esc(p.title) +
          '</h3><span class="muted">' +
          p.episodes +
          " 集 · 本地保存</span></button>",
      )
      .join("") +
    "</div>"
  );
}
function settings() {
  const p = S.project;
  return (
    '<div class="project-premise"><span class="eyebrow">最初的设定</span><p style="margin:8px 0 0">' +
    esc(p.premise) +
    "</p></div>" +
    referenceGallery() +
    '<div class="row spread"><h2>故事的共同底稿</h2>' +
    btn("＋ 添加设定", "editSetting") +
    "</div>" +
    (p.settings.length
      ? p.settings
          .map(
            (s) =>
              '<section class="setting-block"><div class="row spread"><h3>' +
              esc(s.title) +
              '</h3><div class="actions">' +
              btn("编辑", "editSetting", 'data-id="' + s.id + '"', "quiet") +
              btn("删除", "deleteSetting", 'data-id="' + s.id + '" aria-label="删除设定：' + esc(s.title) + '"', "quiet danger") +
              "</div></div><p>" +
              esc(latest(s).text) +
              "</p>" +
              settingVoiceSummary(s) +
              "</section>",
          )
          .join("")
      : empty(
          "从世界、人物和走向开始",
          "告诉右侧创作搭档你的想法，或直接写下设定。",
        )) +
    '<div class="actions">' +
    btn(
      p.settingComplete ? "设定已就绪，开始一集" : "设定完成",
      "completeSetting",
      "",
      "primary",
    ) +
    "</div>"
  );
}
function impacts() {
  const p = S.project,
    e = ep(),
    rows = p.impacts[e.id] || [];
  return rows.length
    ? '<div class="notice">共享内容有更新。本集仍保留原先采用的版本。<div>' +
        rows
          .map(
            (r) =>
              esc(r.title) +
              (!["setting", "asset"].includes(r.type)
                ? " · 上游已更新"
                : " " +
                  btn(
                    "查看并更新引用",
                    "repin",
                    'data-kind="' +
                      r.type +
                      '" data-id="' +
                      r.id +
                      '" data-version="' +
                      r.latest +
                      '"',
                  )),
          )
          .join("　") +
        "</div></div>"
    : "";
}
function documentActions() {
  const doc = ep()[S.stage], v = latest(doc), key = ep().id + "-" + S.stage,
    body = S.drafts[key] ?? v?.text ?? "",
    dirty = body.trim() !== (v?.text || ""), saving = S.documentSaving[key],
    disabled = saving || !body.trim() ? " disabled" : "";
  return (dirty ? '<span class="badge">未保存</span>' : badge(v)) +
    '<button type="submit"' + (!dirty || disabled ? " disabled" : "") + '>' + (saving ? "保存中…" : "保存修改") + '</button>' +
    (!dirty && v && v.status !== "accepted" ? btn("退回修改", "reviewDoc", 'data-decision="rejected"' + disabled, "quiet") : "") +
    (v || dirty ? btn(dirty ? "保存并继续" : doc.acceptedVersionId === v?.id
      ? (S.stage === "synopsis" ? "继续文字分镜" : "继续准备设定图") : "采用这一版",
      "reviewDoc", 'data-decision="accepted"' + disabled, "primary") : "");
}
function documentStage() {
  const e = ep(), d = e[S.stage], v = latest(d), key = e.id + "-" + S.stage,
    base = S.documentBases[key],
    conflict = (base && base.versionId !== (v?.id || null)) || S.documentConflicts[key];
  return impacts() +
    '<form id="documentForm" data-revision="' + S.project.revision +
    '" data-version="' + (base ? base.versionId || "" : v?.id || "") +
    '" data-synopsis-version="' + (base ? base.synopsisVersionId || "" : e.synopsis.acceptedVersionId || "") + '">' +
    (conflict ? '<div class="notice concurrent-change"><strong>正文已有新版本；你的未保存修改保留在下方。</strong>' +
      '<details open><summary>查看新版本</summary><pre>' + esc(v?.text || "") + '</pre></details>' +
      btn("使用新版本", "useLatestDocument", 'type="button"') + '</div>' : "") +
    '<div class="paper"><div class="row spread"><h2>' + stageNames[S.stage] +
    '</h2><span class="muted">' + (v ? "版本 " + d.versions.length : "初稿") +
    '</span></div><label class="sr-only" for="documentText">' + stageNames[S.stage] +
    '</label><textarea id="documentText" name="text" data-draft="' + key + '" placeholder="' +
    (S.stage === "storyboard" ? "每段写清动作、对白和声音；参考资产用 {名称} 标出。" : "本集发生什么，人物做出什么选择，结尾留下什么。") +
    '">' + esc(S.drafts[key] ?? v?.text ?? "") + '</textarea></div><div class="review-bar">' +
    documentActions() + '</div></form><p class="editor-note">手动修改保存后直接采用。发给 Agent 时会自动带上当前正文。</p>';
}
function captureDocumentDraft() {
  if (!ep() || !["synopsis", "storyboard"].includes(S.stage) || !$("documentText")) return null;
  const form = $("documentForm"), body = $("documentText").value;
  if (body.trim() === (latest(ep()[S.stage])?.text || "")) return null;
  return { pid: S.project.id, key: ep().id + "-" + S.stage, revision: S.project.revision,
    operation: { type: "saveDocument", targetType: S.stage, episodeId: ep().id, text: body,
      baseVersionId: form.dataset.version || null, baseSynopsisVersionId: form.dataset.synopsisVersion || null } };
}
async function saveDocumentDraft(draft) {
  if (!draft) return null;
  const { pid, key, operation } = draft;
  if (S.documentSaving[key]) throw new Error("正文正在保存，请稍候");
  S.documentSaving[key] = true;
  if ($("documentText")?.dataset.draft === key) $("documentForm").querySelector(".review-bar").innerHTML = documentActions();
  renderAgentStatus();
  try {
    const result = await api("projects/" + pid + "/apply", {
      requestId: crypto.randomUUID(), expectedRevision: draft.revision, operations: [operation],
    });
    // Only clear the submitted text; typing during the request remains a separate draft.
    if (S.drafts[key] === operation.text) {
      delete S.drafts[key];
      delete S.documentBases[key];
    } else if (Object.hasOwn(S.drafts, key)) {
      S.documentBases[key] = { versionId: result.results[0].id, synopsisVersionId: operation.baseSynopsisVersionId };
    }
    delete S.documentConflicts[key];
    const project = await api("projects/" + pid).catch(() => null);
    if (S.project?.id === pid) {
      if (project && project.revision >= S.project.revision) S.project = project;
      else if (!project && result.revision >= S.project.revision) {
        const doc = S.project.episodes.find(e => e.id === operation.episodeId)[operation.targetType];
        if (!doc.versions.some(v => v.id === result.results[0].id)) doc.versions.push(result.results[0].version);
        doc.acceptedVersionId = result.results[0].id;
        S.project.revision = result.revision;
      }
    }
    return result.results[0].id;
  } catch (error) {
    if (error.code === "document_conflict") {
      const project = await api("projects/" + pid), e = project.episodes.find(e => e.id === operation.episodeId);
      S.documentBases[key] = { versionId: latest(e[operation.targetType])?.id || null, synopsisVersionId: e.synopsis.acceptedVersionId };
      S.documentConflicts[key] = true;
      if (S.project?.id === pid && project.revision >= S.project.revision) S.project = project;
    }
    throw error;
  } finally {
    delete S.documentSaving[key];
    if (S.project?.id === pid) render();
  }
}
function assets() {
  return assetBoard();
}
function videos() {
  return videoBoard();
}
function jobs() {
  const items = S.project.jobs
    .filter((j) => j.episodeId === S.episodeId)
    .slice()
    .reverse();
  return items.length
    ? '<details class="inline-details"><summary>制作任务 · ' +
        items.length +
        "</summary>" +
        items
          .map(
            (j) =>
              '<div class="job"><span>' +
              esc(statusNames[j.status]) +
              " · " +
              esc((j.snapshot.prompt || "").slice(0, 28)) +
              (j.error ? '<div class="error">' + esc(j.error) + "</div>" : "") +
              "</span>" +
              (["failed", "cancelled"].includes(j.status) &&
              (j.targetType === "asset" || j.remoteId)
                ? btn("重试", "retry", 'data-id="' + j.id + '"')
                : "") +
              ([
                "queued",
                "preparing",
                "submitting",
                "polling",
                "downloading",
              ].includes(j.status)
                ? btn("停止", "cancelJob", 'data-id="' + j.id + '"')
                : "") +
              (j.status === "submission_unknown"
                ? btn("恢复任务", "recoverJob", 'data-id="' + j.id + '"')
                : "") +
              btn("输入记录", "job", 'data-id="' + j.id + '"') +
              "</div>",
          )
          .join("") +
        "</details>"
    : "";
}
function referenceOptions(selected = [], exclude, excludeVoices = false) {
  return (
    '<div class="stack">' +
    S.project.assets
      .filter(
        (a) =>
          a.id !== exclude &&
          !(
            excludeVoices &&
            a.purpose === "voice" &&
            S.project.assets.some((c) => c.voiceAssetId === a.id)
          ) &&
          ep()?.assetRefs.find((r) => r.assetId === a.id)?.versionId,
      )
      .map((a) => {
        const r = ep().assetRefs.find((r) => r.assetId === a.id),
          v = a.versions.find((v) => v.id === r.versionId);
        return (
          '<label class="ref-check"><input type="checkbox" name="ref" value="' +
          a.id +
          '" ' +
          (selected.some((s) => s.assetId === a.id) ? "checked" : "") +
          ">" +
          esc(a.name) +
          "<small>" +
          esc(a.purpose || kindNames[a.kind]) +
          "</small></label>"
        );
      })
      .join("") +
    "</div>"
  );
}
function refsFromForm(form) {
  return [...form.querySelectorAll("[name=ref]:checked")].map((input) => {
    const a = S.project.assets.find((a) => a.id === input.value),
      r = ep().assetRefs.find((r) => r.assetId === a.id),
      v = a.versions.find((v) => v.id === r.versionId);
    return {
      assetId: a.id,
      versionId: v.id,
      role: v.media.mime.split("/")[0],
      purpose: a.purpose || a.kind,
    };
  });
}
function editAsset(assetId) {
  if (!ep()) return toast("进入具体一集后编辑生成前置");
  const a = S.project.assets.find((a) => a.id === assetId);
  S.modal = { kind: "asset", id: assetId, revision: S.project.revision };
  openDialog(
    a ? "资产与生成前置" : "添加本集资产",
    '<form id="assetForm">' +
      field("name", "资产名称", a?.name || "") +
      '<div class="two"><label>类型<select name="kind">' +
      Object.entries(kindNames)
        .filter(([k]) => k !== "unclassified")
        .map(
          ([k, n]) =>
            '<option value="' +
            k +
            '" ' +
            (a?.kind === k ? "selected" : "") +
            ">" +
            n +
            "</option>",
        )
        .join("") +
      "</select></label>" +
      field("purpose", "用途（如 face / body / voice）", a?.purpose || "body") +
      '</div><label>所属人物 / 对象<select name="parent"><option value="">独立对象</option>' +
      S.project.assets
        .filter((x) => x.id !== a?.id)
        .map(
          (x) =>
            '<option value="' +
            x.id +
            '" ' +
            (a?.parentAssetId === x.id ? "selected" : "") +
            ">" +
            esc(x.name) +
            "</option>",
        )
        .join("") +
      "</select></label>" +
      textField("prompt", "生成提示词", a?.prompt || "", 6) +
      generationFields("image", a?.generation || S.project.generation.image) +
      "<label>使用已采用素材作为参考</label>" +
      referenceOptions(a?.refs || [], assetId) +
      '<div class="actions"><button class="primary" type="submit">保存前置</button></div></form>',
  );
}
function editClip(clipId) {
  const c = ep().clips.find((c) => c.id === clipId);
  S.modal = { kind: "clip", id: clipId, revision: S.project.revision };
  openDialog(
    c ? "修改片段计划" : "规划视频片段",
    '<form id="clipForm">' +
      field(
        "title",
        "片段名称",
        c?.title || "片段 " + (ep().clips.length + 1),
      ) +
      generationFields("video", c?.plan || S.project.generation.video) +
      textField("prompt", "完整视频提示词", c?.plan.prompt || "", 8) +
      speakingFields(c) +
      "<label>真实参考素材 · 仅列出本集已采用版本</label>" +
      referenceOptions(c?.plan.refs || [], undefined, true) +
      '<p class="editor-note">按列表顺序，以 @Image 1、@Audio 1、@Video 1 指明用途。</p><div class="actions"><button class="primary" type="submit">保存计划</button></div></form>',
  );
}
function detail(kind, targetId) {
  return previewMedia(kind, targetId);
}
function canvas(kind, targetId, draft) {
  const target =
      kind === "asset"
        ? S.project.assets.find((a) => a.id === targetId)
        : ep().clips.find((c) => c.id === targetId),
    plan =
      kind === "asset"
        ? { prompt: target.prompt, refs: target.refs || [] }
        : target.plan;
  S.modal = { kind, id: targetId, revision: S.project.revision };
  const nodes = [
      {
        id: "prompt",
        type: kind === "asset" ? "imagePrompt" : "videoPrompt",
        family: "Comet",
        role: kind === "asset" ? "imagePrompt" : "videoPrompt",
        title: "生成提示词",
        content: draft?.prompt ?? plan.prompt,
        meta: { dramaSpeakingAssetIds: draft?.speakingAssetIds ?? plan.speakingAssetIds ?? [] },
        generation:
          draft?.generation ||
          reviewGeneration(
            kind === "asset" ? "image" : "video",
            target.generation || target.plan,
          ),
        x: 480,
        y: 200,
        status: "completed",
        width: 310,
      },
    ],
    links = [];
  for (const [i, ref] of (draft?.refs || plan.refs).entries()) {
    const a = S.project.assets.find((x) => x.id === ref.assetId),
      v = a.versions.find((v) => v.id === ref.versionId),
      type =
        ref.role === "image"
          ? "image"
          : ref.role === "video"
            ? "video"
            : "audio";
    nodes.push({
      id: ref.assetId,
      type: type === "audio" ? "spokenAudio" : type,
      family: type === "image" ? "Sol" : type === "video" ? "Luna" : "Meteor",
      role:
        type === "image"
          ? "refImage"
          : type === "video"
            ? "refVideo"
            : "spokenAudio",
      title: a.name,
      assetUrl: mediaUrl(v.media),
      mime: v.media.mime,
      content: ref.purpose || "",
      status: "completed",
      x: 60,
      y: 80 + i * 280,
      meta: { dramaRef: ref },
    });
    links.push({
      id: "ref-" + i,
      fromNodeId: ref.assetId,
      toNodeId: "prompt",
      relation: "input",
      inputRole:
        ref.role === "audio"
          ? "reference_audio"
          : ref.role === "video"
            ? "reference_video"
            : "ref",
    });
  }
  for (const [i, v] of target.versions.entries()) {
    if (v.deletedAt) continue;
    const source = v.snapshot;
    const sameInputs =
      source &&
      source.prompt === (draft?.prompt ?? plan.prompt) &&
      JSON.stringify(source.refs || []) === JSON.stringify(draft?.refs || plan.refs);
    const sourcePromptId = sameInputs ? "prompt" : "source-prompt-" + v.id;
    const candidateY = source && !sameInputs ? 720 + i * 500 : 80 + i * 280;
    if (source && !sameInputs) {
      nodes.push({
        id: sourcePromptId,
        type: kind === "asset" ? "imagePrompt" : "videoPrompt",
        family: "Comet",
        role: kind === "asset" ? "imagePrompt" : "videoPrompt",
        title: "候选 " + (i + 1) + " 实际使用的提示词",
        content: source.prompt,
        status: "completed",
        x: 480,
        y: candidateY,
      });
      for (const [ri, ref] of (source.refs || []).entries()) {
        const asset = S.project.assets.find((a) => a.id === ref.assetId),
          version = asset?.versions.find((v) => v.id === ref.versionId);
        if (!version) continue;
        const refId = v.id + "-source-" + ri;
        nodes.push({
          id: refId,
          type: ref.role === "audio" ? "spokenAudio" : ref.role,
          family:
            ref.role === "image"
              ? "Sol"
              : ref.role === "video"
                ? "Luna"
                : "Meteor",
          role:
            ref.role === "image"
              ? "refImage"
              : ref.role === "video"
                ? "refVideo"
                : "spokenAudio",
          title: asset.name + " · 生成时版本",
          assetUrl: mediaUrl(version.media),
          mime: version.media.mime,
          content: ref.purpose || "",
          status: "completed",
          x: 60,
          y: candidateY + ri * 280,
          meta: { dramaRef: ref },
        });
        links.push({
          id: refId + "-link",
          fromNodeId: refId,
          toNodeId: sourcePromptId,
          relation: "input",
          inputRole:
            ref.role === "audio"
              ? "reference_audio"
              : ref.role === "video"
                ? "reference_video"
                : "ref",
        });
      }
    }
    const type = v.media.mime.split("/")[0];
    nodes.push({
      id: v.id,
      type: type === "audio" ? "spokenAudio" : type,
      family: type === "image" ? "Sol" : type === "video" ? "Luna" : "Meteor",
      role:
        type === "image"
          ? "genImage"
          : type === "video"
            ? "genVideo"
            : "spokenAudio",
      title:
        "候选 " +
        (i + 1) +
        (target.acceptedVersionId === v.id ? " · 已采用" : ""),
      assetUrl: mediaUrl(v.media),
      mime: v.media.mime,
      status: "completed",
      assetState: target.acceptedVersionId === v.id ? "official" : "candidate",
      x: 940,
      y: candidateY,
      meta: {
        dramaVersionId: v.id,
        ...(kind === "asset"
          ? { dramaRef: { assetId: target.id, versionId: v.id, role: type } }
          : {}),
      },
    });
    if (source)
      links.push({
        id: "out-" + i,
        fromNodeId: sourcePromptId,
        toNodeId: v.id,
        relation: "input",
        inputRole: "prompt",
      });
  }
  openDialog(
    (target.name || target.title) + " · 前置与候选",
    '<p class="muted">调整提示词和参考，查看这份内容的生成候选。</p><iframe title="Auralis 制作子画布" class="canvas-frame" id="canvasFrame" src="/canvas"></iframe><div class="actions">' +
      btn(
        kind === "asset" ? "保存画布" : "保存画布提示词与参考",
        "saveCanvas",
        "",
        "primary",
      ) +
      (kind === "asset"
        ? '<input id="importMedia" type="file" accept="image/png,image/jpeg,image/webp,audio/mpeg,audio/wav,video/mp4,video/quicktime" hidden>' +
          btn("上传参考", "import")
        : "") +
      btn(
        "返回候选比较",
        "detail",
        'data-kind="' + kind + '" data-id="' + targetId + '"',
      ) +
      "</div>",
    true,
  );
  const frame = $("canvasFrame");
  frame.addEventListener("load", async () => {
    await frame.contentWindow.__auralisReady;
    if (frame !== $("canvasFrame") || !$("dialog").open) return;
    const graph = {
      nodes: nodes.map((n) => ({
        ...n,
        ...(target.canvasLayout?.[n.id] || {}),
      })),
      links,
    };
    if (kind === "asset") mountAssetCanvas(frame, target, graph);
    else
      frame.contentWindow.AuralisCanvas.mount({
        ...graph,
        id: targetId,
        title: target.title,
        allowedModels: Object.keys(S.models),
      });
  });
}
async function act(action, d) {
  if (
    [
      "editVoice",
      "refreshVoices",
      "chooseVoice",
      "toggleVoices",
      "focusVoice",
    ].includes(action)
  )
    return voiceAction(action, d);
  if (videoBoardActions.has(action)) return videoBoardAction(action, d);
  if (action === "continueProduction") return startAgent("继续");
  if (action === "deleteVariant") {
    const m = { ...S.modal };
    await apply([
      {
        type: "deleteMediaVersion",
        targetType: m.kind,
        targetId: m.id,
        episodeId: ep()?.id,
        versionId: d.version,
      },
    ]);
    return canvas(m.kind, m.id);
  }
  if (boardActions.has(action)) return assetBoardAction(action, d);
  if (action === "preview") return previewMedia(d.kind, d.id, d.version);
  if (action === "citeAsset") return citeAsset(d.id, d.version);
  if (action === "close") return closeDialog();
  if (action === "refresh") return loadProject(S.project.id);
  if (action === "home") {
    S.projectLoad = (S.projectLoad || 0) + 1;
    S.project = null;
    S.episodeId = null;
    render();
    return;
  }
  if (action === "project") {
    S.episodeId = null;
    S.stage = "setting";
    S.cardVersions.clear();
    return loadProject(d.id);
  }
  if (action === "renameProject" || action === "deleteProject") {
    const project = await api("projects/" + d.id);
    const deleting = action === "deleteProject";
    return openDialog(deleting ? "删除“" + project.title + "”？" : "重命名项目",
      '<form id="projectManageForm" data-id="' + project.id + '" data-operation="' + (deleting ? "remove" : "rename") +
      '" data-revision="' + project.revision + '" data-title="' + esc(project.title) + '">' +
      (deleting ? '<p>将删除这个项目的设定、分集、素材和聊天记录。</p>'
        : field("title", "项目名称", S.drafts["project-title/" + project.id] ?? project.title)) +
      '<div class="actions">' + btn("取消", "close", 'type="button"', "quiet") +
      '<button type="submit" class="' + (deleting ? "danger" : "primary") + '">' + (deleting ? "删除项目" : "保存名称") +
      '</button></div><p class="preference-result" role="status"></p></form>');
  }
  if (action === "duplicateProject") {
    S.copyingProjects ||= new Set();
    if (S.copyingProjects.has(d.id)) return;
    S.copyingProjects.add(d.id);
    toast("正在复制项目…");
    try {
      await api("projects/" + d.id + "/duplicate", {});
      S.projects = await api("projects");
      render();
      toast("项目已复制");
    } finally { S.copyingProjects.delete(d.id); }
    return;
  }
  if (action === "setting") {
    S.episodeId = null;
    S.stage = "setting";
    render();
    return;
  }
  if (action === "library") {
    S.stage = "library";
    render();
    return;
  }
  if (action === "episode") {
    S.episodeId = d.id;
    S.stage = S.project.nextStages?.[d.id] || "synopsis";
    render();
    return;
  }
  if (action === "stage") {
    S.stage = d.stage;
    render();
    return;
  }
  if (action === "newProject")
    return openDialog(
      "开始一个故事",
      '<form id="projectForm">' +
        field("title", "短剧名称") +
        textField("premise", "初始设定 · 一两句话也可以") +
        '<button class="primary">建立项目</button></form>',
    );
  if (action === "newEpisode")
    return openDialog(
      "开始你想制作的那一集",
      '<form id="episodeForm">' +
        field("number", "第几集", S.project.episodes.length + 1, "number") +
        field(
          "title",
          "本集名称",
          "第 " + (S.project.episodes.length + 1) + " 集",
        ) +
        '<p class="muted">使用当前共享设定版本，仅创建这一集。</p><button class="primary">开始本集</button></form>',
    );
  if (action === "editSetting") {
    const s = S.project.settings.find((s) => s.id === d.id);
    S.modal = { id: s?.id, revision: S.project.revision };
    return openDialog(
      s ? "编辑共享设定" : "添加设定",
      '<form id="settingForm">' +
        field("title", "标题", s?.title || "") +
        textField("text", "内容", latest(s)?.text || "", 12) +
        voiceFields(latest(s)?.character || {}, true) +
        '<button class="primary">保存设定</button></form>',
    );
  }
  if (action === "deleteSetting") {
    await apply([{ type: "deleteSetting", id: d.id }]);
    S.selectedSettings.delete(d.id);
    render();
    toast("设定已删除");
    return;
  }
  if (action === "completeSetting") {
    if (S.project.settingComplete) return act("newEpisode", {});
    await apply([{ type: "completeSetting" }]);
    return act("newEpisode", {});
  }
  if (action === "useLatestDocument") {
    const key = ep().id + "-" + S.stage;
    delete S.drafts[key]; delete S.documentBases[key]; delete S.documentConflicts[key];
    render();
    return;
  }
  if (action === "reviewDoc") {
    const targetType = S.stage, pid = S.project.id, eid = ep().id,
      v = latest(ep()[targetType]), draft = captureDocumentDraft();
    if (draft) {
      const versionId = await saveDocumentDraft(draft);
      if (S.project?.id === pid && S.episodeId === eid && S.stage === targetType)
        return advanceAfterReview(targetType, versionId);
      return;
    }
    if (d.decision === "accepted" && ep()[targetType].acceptedVersionId === v.id)
      return advanceAfterReview(targetType, v.id);
    await apply([
      {
        type: "review",
        targetType,
        episodeId: ep().id,
        versionId: v.id,
        decision: d.decision,
      },
    ]);
    if (d.decision === "accepted") return advanceAfterReview(targetType, v.id);
    return toast(d.decision === "accepted" ? "已采用当前版本" : "已退回修改");
  }
  if (action === "editAsset") return editAsset(d.id);
  if (action === "editClip") return editClip(d.id);
  if (action === "detail") return detail(d.kind, d.id);
  if (action === "canvas") return canvas(d.kind, d.id);
  if (action === "resolveMention") {
    S.modal = { name: d.name, revision: S.project.revision };
    return openDialog(
      "明确资产引用：" + d.name,
      '<form id="bindingForm"><label>选择稳定身份<select name="assetId">' +
        S.project.assets
          .map(
            (a) =>
              '<option value="' +
              a.id +
              '">' +
              esc(a.name) +
              " · " +
              esc(kindNames[a.kind]) +
              " · " +
              a.id.slice(-8) +
              "</option>",
          )
          .join("") +
        '</select></label><button class="primary">绑定此资产</button></form>',
    );
  }
  if (action === "generate") {
    await apply([
      {
        type: "generate",
        targetType: "asset",
        targetId: d.id,
        episodeId: ep()?.id,
      },
    ]);
    closeDialog();
    return toast("资产生成任务已创建");
  }
  if (action === "reviewVariant") {
    const m = { ...S.modal },
      versions = [d.version];
    if (!versions.length) return toast("先选择候选");
    await apply(
      versions.map((versionId) => ({
        type: "review",
        targetType: m.kind,
        targetId: m.id,
        episodeId: ep()?.id,
        versionId,
        decision: d.decision || "accepted",
      })),
    );
    if (m.canvasScope) {
      S.assetSelection?.delete(m.id);
      refreshProductionUI();
      return toast("已通过");
    }
    if ((d.decision || "accepted") === "accepted" && ep()) {
      closeDialog();
      await advanceAfterReview(m.kind, versions[versions.length - 1], m.id);
    } else detail(m.kind, m.id);
    return;
  }
  if (action === "promote") {
    const m = { ...S.modal };
    await apply([
      {
        type: "promoteVariant",
        targetType: m.kind,
        episodeId: ep()?.id,
        clipId: m.id,
        assetId: m.id,
        versionId: d.version,
      },
    ]);
    closeDialog();
    return toast("已独立成为正式内容，来源关系已保留");
  }
  if (action === "batch") {
    const selected = ep().clips.filter((c) => S.clipSelection.has(c.id));
    if (!selected.length) return toast("先选中需要生成的片段");
    if (selected.some((c) => c.plan.pendingVoiceAssetIds?.length))
      return toast("先在资产库选定所选片段的角色音色");
    S.modal = {
      kind: "batch",
      revision: S.project.revision,
      items: selected.map((c) => ({
        clipId: c.id,
        planRevision: c.planRevision,
      })),
    };
    return openDialog(
      "确认本批视频输入",
      '<p class="muted">本次将按下面的提示词和素材版本生成 ' +
        selected.length +
        " 段视频。</p>" +
        selected
          .map(
            (c) =>
              '<section class="batch-item"><h3>' +
              esc(c.title) +
              " · " +
              c.plan.duration +
              ' 秒</h3><p class="muted">' +
              generationDescription("video", c.plan) +
              "</p><pre>" +
              esc(c.plan.prompt) +
              '</pre><p class="muted">参考：' +
              c.plan.refs
                .map(
                  (r) =>
                    esc(S.project.assets.find((a) => a.id === r.assetId).name) +
                    " / " +
                    esc(r.purpose || r.role) +
                    " / " +
                    esc(r.versionId.slice(0, 10)),
                )
                .join("、") +
              "</p></section>",
          )
          .join("") +
        '<div class="actions">' +
        btn("同意本批输入并生成", "confirmBatch", "", "primary") +
        "</div>",
    );
  }
  if (action === "confirmBatch") {
    await apply(
      [{ type: "approveBatch", episodeId: ep().id, items: S.modal.items }],
      S.modal.revision,
    );
    S.clipSelection.clear();
    refreshProductionUI();
    closeDialog();
    return toast("本批已确认，按固定输入提交");
  }
  if (action === "retry" || action === "cancelJob") {
    await apply([
      { type: action === "retry" ? "retryJob" : "cancelJob", jobId: d.id },
    ]);
    return;
  }
  if (action === "recoverJob") {
    S.modal = { jobId: d.id, revision: S.project.revision };
    return openDialog(
      "核对供应商任务",
      '<form id="recoverJobForm"><p class="muted">请求曾经开始提交，但响应中断。填写供应商后台对应的任务 ID，可继续查询原任务。</p><label>供应商任务 ID<input name="remoteId"></label><label class="ref-check"><input name="notSubmitted" type="checkbox">我已核对，供应商没有收到这次任务</label><button class="primary">保存恢复结果</button></form>',
    );
  }
  if (action === "job") {
    const j = S.project.jobs.find((j) => j.id === d.id);
    return openDialog(
      "真实生成输入与结果",
      "<pre>" +
        esc(
          JSON.stringify(
            {
              status: j.status,
              remoteId: j.remoteId,
              snapshot: j.snapshot,
              request: j.request,
              error: j.error,
            },
            null,
            2,
          ),
        ) +
        "</pre>",
    );
  }
  if (action === "repin") {
    return openDialog(
      "更新本集固定引用",
      '<p>已制作内容和候选会保留；依赖旧版本的计划需要重新核对。</p><div class="actions">' +
        btn(
          "采用当前共享版本",
          "confirmRepin",
          'data-kind="' +
            d.kind +
            '" data-id="' +
            d.id +
            '" data-version="' +
            d.version +
            '"',
          "primary",
        ) +
        "</div>",
    );
  }
  if (action === "confirmRepin") {
    await apply([
      {
        type: d.kind === "asset" ? "repinAsset" : "repinSetting",
        episodeId: ep().id,
        ...(d.kind === "asset" ? { assetId: d.id } : { settingId: d.id }),
        versionId: d.version,
      },
    ]);
    closeDialog();
    return;
  }
  if (action === "settings")
    return openDialog(
      "设置",
      preferencesNav("generation") + '<form id="providerForm">' +
        (S.project
          ? '<p class="muted">本剧的默认生成参数。已有片段保留原计划，可在各自的前置中修改。</p><div class="two">' +
            generationFields("image", S.project.generation.image) +
            generationFields("video", S.project.generation.video) +
            "</div>"
          : "<p>打开一个短剧后可设置默认模型、比例和清晰度。</p>") +
        '<p class="muted">API 与自由画布共用，可在「共享 API」中修改。</p><div class="actions"><button class="primary">应用生成参数</button></div></form>',
      true,
    );
  if (action === "addReference") return $("referenceFiles").click();
  if (action === "detachReference") {
    if (S.clipSelection.has(d.id)) {
      S.clipSelection.delete(d.id);
      return refreshProductionUI();
    }
    if (S.assetSelection.has(d.id)) {
      S.assetSelection.delete(d.id);
      return render();
    }
    S.selectedReferences.delete(d.id);
    renderAttachments();
    return;
  }
  if (action === "removeReference") {
    await apply([{ type: "removeReference", id: d.id }]);
    return;
  }
  if (action === "editReference") {
    const reference = S.project.references.find((r) => r.id === d.id);
    S.modal = { id: d.id, revision: S.project.revision };
    return openDialog(
      "图片说明",
      '<form id="referenceForm">' +
        field("name", "名称", reference.name) +
        textField("note", "希望借鉴什么", reference.note, 3) +
        '<button class="primary">保存说明</button></form>',
    );
  }
  if (action === "importReferenceAsset") {
    const reference = S.project.references.find((r) => r.id === d.id);
    const draftKey = "reference-asset/" + S.project.id + "/" + reference.id;
    S.modal = { id: reference.id, draftKey, revision: S.project.revision };
    openDialog(
      "导入资产库",
      '<form id="importReferenceForm"><label>资产名称<input name="name" required maxlength="120" data-draft="' +
        draftKey + '" value="' + esc(S.drafts[draftKey] ?? reference.name.replace(/\.(png|jpe?g|webp)$/i, "")) +
        '"></label><button class="primary" type="submit">导入</button></form>',
    );
    const input = $("importReferenceForm").elements.name;
    input.focus();
    input.select();
    return;
  }
  if (action === "import") return $("importMedia").click();
  if (action === "saveCanvas" && S.modal?.canvasScope) {
    await saveCanvasDraft(S.modal.canvasScope);
    return toast("画布已保存");
  }
  if (action === "saveCanvas") {
    const m = { ...S.modal },
      snap = $("canvasFrame").contentWindow.AuralisCanvas.snapshot(),
      promptNode = snap.nodes.find((n) => n.id === "prompt"),
      prompt = promptNode?.content;
    const settings = promptNode?.generation?.mediaSettings || {};
    const videoSettings =
      m.kind === "clip"
        ? {
            model: promptNode.generation.model,
            resolution: settings.videoResolution,
            aspectRatio: settings.videoAspectRatio,
            duration: settings.segmentDurationSeconds,
          }
        : {};
    const refs = snap.links
      .filter((l) => l.toNodeId === "prompt")
      .map((l) => snap.nodes.find((n) => n.id === l.fromNodeId)?.meta?.dramaRef)
      .filter(Boolean);
    const op =
      m.kind === "asset"
        ? {
            type: "setAssetPrompt",
            episodeId: ep().id,
            assetId: m.id,
            prompt,
            refs,
          }
        : {
            type: "planClip",
            episodeId: ep().id,
            id: m.id,
            ...ep().clips.find((c) => c.id === m.id).plan,
            ...videoSettings,
            speakingAssetIds: promptNode.meta?.dramaSpeakingAssetIds || [],
            prompt,
            refs,
          };
    const target =
        m.kind === "asset"
          ? S.project.assets.find((a) => a.id === m.id)
          : ep().clips.find((c) => c.id === m.id),
      previous =
        m.kind === "asset"
          ? { prompt: target.prompt, refs: target.refs || [] }
          : target.plan;
    const ops = [];
    if (
      prompt !== previous.prompt ||
      JSON.stringify(refs) !== JSON.stringify(previous.refs) ||
      (m.kind === "clip" && JSON.stringify(op.speakingAssetIds) !== JSON.stringify(previous.speakingAssetIds || [])) ||
      Object.entries(videoSettings).some(
        ([key, value]) => previous[key] !== value,
      )
    )
      ops.push(op);
    ops.push({
      type: "saveCanvasLayout",
      targetType: m.kind,
      targetId: m.id,
      episodeId: ep().id,
      positions: snap.nodes.map((n) => ({ id: n.id, x: n.x, y: n.y })),
    });
    await apply(ops, m.revision);
    closeDialog();
    return toast("子画布的提示词、参考与布局已保存");
  }
}
document.addEventListener("click", (event) => {
  const b = event.target.closest("[data-action]");
  if (b) {
    if (!b.matches('input[type="checkbox"]')) event.preventDefault();
    act(b.dataset.action, b.dataset).catch((e) => toast(e.message, true));
  }
  $("contextMenu").hidden = true;
});
document.addEventListener("input", (event) => {
  if (event.target.closest('#projectManageForm[data-operation="rename"]'))
    S.drafts["project-title/" + event.target.form.dataset.id] = event.target.value;
  if (event.target.dataset.draft)
    S.drafts[event.target.dataset.draft] = event.target.value;
  if (event.target.id === "documentText") {
    const key = event.target.dataset.draft, form = event.target.form;
    S.documentBases[key] ||= { versionId: form.dataset.version || null, synopsisVersionId: form.dataset.synopsisVersion || null };
    if (!S.documentSaving[key] && event.target.value.trim() === (latest(ep()[S.stage])?.text || "")) {
      delete S.drafts[key]; delete S.documentBases[key]; delete S.documentConflicts[key];
      form.dataset.version = latest(ep()[S.stage])?.id || "";
      form.dataset.synopsisVersion = ep().synopsis.acceptedVersionId || "";
    }
    form.querySelector(".review-bar").innerHTML = documentActions();
  }
});
document.addEventListener("change", async (event) => {
  try {
    const kind = event.target.dataset.generationModel;
    if (kind) {
      const group = event.target.closest("[data-generation]");
      const current = generationFromForm(event.target.form, kind);
      group.querySelector(".generation-options").innerHTML = generationOptions(
        kind,
        current,
      );
    }
    if (event.target.dataset.reference) {
      if (event.target.checked)
        S.selectedReferences.add(event.target.dataset.reference);
      else S.selectedReferences.delete(event.target.dataset.reference);
      renderAttachments();
    }
    if (event.target.id === "referenceFiles")
      await uploadReferences(event.target.files);
    if (event.target.dataset.setting) {
      if (event.target.checked)
        S.selectedSettings.add(event.target.dataset.setting);
      else S.selectedSettings.delete(event.target.dataset.setting);
    }
    if (event.target.id === "importMedia" && event.target.files[0]) {
      const m = S.modal,
        file = event.target.files[0],
        media = await api("projects/" + S.project.id + "/upload", file, true);
      const result = await apply([
        { type: "importAsset", assetId: m.id, episodeId: ep()?.id, media },
      ]);
      if (S.modal === m) await previewMedia(m.kind, m.id, result.results[0].id);
    }
  } catch (e) {
    toast(e.message, true);
  }
});
document.addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.target,
    f = Object.fromEntries(new FormData(form));
  try {
    if (form.id === "projectForm") {
      const p = await api("projects", f);
      S.episodeId = null;
      S.stage = "setting";
      closeDialog();
      await loadProject(p.id);
    }
    if (form.id === "projectManageForm") {
      const projectId = form.dataset.id, deleting = form.dataset.operation === "remove", submit = form.querySelector('button[type="submit"]');
      if (submit.disabled) return;
      submit.disabled = true;
      try {
        await api("projects/" + projectId + "/" + form.dataset.operation, deleting
          ? { confirmed: true, expectedRevision: Number(form.dataset.revision) }
          : { title: f.title, expectedTitle: form.dataset.title });
        delete S.drafts["project-title/" + projectId];
        S.projects = await api("projects");
        if (S.project?.id === projectId) {
          if (deleting) { S.projectLoad = (S.projectLoad || 0) + 1; S.project = null; S.episodeId = null; }
          else S.project.title = f.title.trim();
        }
        if (deleting) for (const key of Object.keys(S.agentDrafts)) if (key.startsWith(projectId + "/")) delete S.agentDrafts[key];
        if (document.getElementById("projectManageForm") === form) closeDialog();
        render();
        toast(deleting ? "项目已删除" : "名称已保存");
      } catch (error) { form.querySelector('.preference-result').textContent = error.message; }
      finally { submit.disabled = false; }
      return;
    }
    if (form.id === "episodeForm") {
      const r = await apply([
        { type: "createEpisode", number: Number(f.number), title: f.title },
      ]);
      S.episodeId = r.results[0].id;
      S.stage = "synopsis";
      closeDialog();
      render();
      await startAgent("开始本集梗概，请先读取本集固定的共享设定。");
    }
    if (form.id === "settingForm") {
      await apply(
        [
          {
            type: "setSetting",
            id: S.modal.id,
            title: f.title,
            text: f.text,
            character:
              f.voiceMode === "none"
                ? null
                : { name: f.characterName, ...voiceFromForm(f) },
          },
        ],
        S.modal.revision,
      );
      closeDialog();
    }
    if (form.id === "documentForm") {
      await saveDocumentDraft(captureDocumentDraft());
      toast("已保存并采用");
    }
    if (form.id === "voiceForm") {
      const assetId = S.modal.id;
      await apply(
        [
          {
            type: "setVoiceProfile",
            assetId,
            episodeId: ep()?.id,
            voice: voiceFromForm(f),
          },
        ],
        S.modal.revision,
      );
      S.voiceDrafts.delete(assetId);
      closeDialog();
    }
    if (form.id === "assetForm") {
      const m = { ...S.modal },
        ops = [];
      if (m.id && S.project.assets.find((a) => a.id === m.id).name !== f.name)
        ops.push({ type: "renameAsset", assetId: m.id, name: f.name });
      ops.push({
        type: "ensureAsset",
        episodeId: ep().id,
        name: f.name,
        kind: f.kind,
        description: f.prompt,
        parentAssetId: f.parent || null,
        purpose: f.purpose,
      });
      let r = await apply(ops, m.revision);
      const aid = r.results.at(-1).id;
      await apply([
        {
          type: "setAssetPrompt",
          episodeId: ep().id,
          assetId: aid,
          prompt: f.prompt,
          generation: generationFromForm(form, "image"),
          refs: refsFromForm(form),
        },
      ]);
      closeDialog();
    }
    if (form.id === "clipForm") {
      await apply(
        [
          {
            type: "planClip",
            episodeId: ep().id,
            id: S.modal.id,
            title: f.title,
            prompt: f.prompt,
            ...generationFromForm(form, "video"),
            refs: refsFromForm(form),
            speakingAssetIds: new FormData(form).getAll("speakingAssetIds"),
          },
        ],
        S.modal.revision,
      );
      closeDialog();
    }
    if (form.id === "recoverJobForm") {
      await apply(
        [
          {
            type: "resolveUnknownJob",
            jobId: S.modal.jobId,
            remoteId: f.remoteId || undefined,
            notSubmitted: !!f.notSubmitted,
          },
        ],
        S.modal.revision,
      );
      closeDialog();
    }
    if (form.id === "bindingForm") {
      await apply(
        [
          {
            type: "bindAsset",
            episodeId: ep().id,
            name: S.modal.name,
            assetId: f.assetId,
          },
        ],
        S.modal.revision,
      );
      closeDialog();
    }
    if (form.id === "providerForm") {
      if (S.project)
        await apply([
          {
            type: "setGeneration",
            image: generationFromForm(form, "image"),
            video: generationFromForm(form, "video"),
          },
        ]);
      if (f.key) {
        await api("provider", { key: f.key });
        S.providerReady = true;
      }
      if (f.elevenLabsKey) {
        await api("voice-provider", { key: f.elevenLabsKey });
        S.elevenLabsReady = true;
      }
      closeDialog();
      toast("生成设置已应用");
    }
    if (form.id === "importReferenceForm") {
      const modal = { ...S.modal }, button = form.querySelector("button[type=submit]");
      if (button.disabled) return;
      button.disabled = true;
      button.textContent = "导入中…";
      try {
        await apply([{ type: "importReferenceAsset", referenceId: modal.id, name: f.name }], modal.revision);
        delete S.drafts[modal.draftKey];
        if (S.modal?.draftKey === modal.draftKey) closeDialog();
        toast("已导入资产库");
      } finally {
        button.disabled = false;
        button.textContent = "导入";
      }
    }
    if (form.id === "referenceForm") {
      await apply(
        [
          {
            type: "updateReference",
            id: S.modal.id,
            name: f.name,
            note: f.note,
          },
        ],
        S.modal.revision,
      );
      closeDialog();
    }
    if (form.id === "agentForm") {
      await startAgent(
        $("agentInput").value.trim() ||
          ((S.selectedReferences.size || S.assetSelection.size || S.clipSelection.size)
            ? "请结合这些引用，帮我推进当前创作。"
            : ""),
      );
    }
  } catch (e) {
    toast(e.message, true);
  }
});
async function startAgent(message, advance = null) {
  if ((S.agentRunning && S.agentStatus !== "running" && !advance) || S.uploadingReferences) return;
  if (!message) return;
  const assetReferences = selectedAssetInputs();
  const clipReferences = selectedClipInputs();
  const referenceIds = [...S.selectedReferences],
    agentKey = S.agentKey, pid = S.project.id, eid = S.episodeId, stage = S.stage,
    settingIds = [...S.selectedSettings], documentDraft = advance ? null : captureDocumentDraft();
  if (S.agentPending[agentKey]) return;
  const appending = S.agentStatus === "running" && !advance;
  S.agentPending[agentKey] = appending ? "appending" : "starting";
  if (!appending) {
    S.agentStatus = "starting";
    S.agentFinishedAt = null;
    S.agentStartedAt = new Date().toISOString();
  }
  S.projectLoad = (S.projectLoad || 0) + 1;
  S.agentError = "";
  S.agentDetail = "";
  renderAgentStatus();
  renderMessages();
  let result;
  try {
    await saveDocumentDraft(documentDraft);
    result = await api("projects/" + pid + "/agent", {
      requestId: crypto.randomUUID(),
      message,
      stage: eid ? stage : "setting",
      episodeId: eid,
      settingIds,
      referenceIds,
      assetReferences: assetReferences.map((r) => r.source),
      clipReferences: clipReferences.map((r) => r.source),
      advance,
    });
  } catch (error) {
    delete S.agentPending[agentKey];
    if (S.agentKey === agentKey) {
      S.agentStatus = appending ? "running" : "failed";
      if (appending) S.agentNeedsSync = true;
      S.agentError = advance
        ? "已采用；下一阶段启动失败，可发送“继续”重试。" + error.message
        : (appending ? "追加消息未送达：" : "") + error.message;
      renderAgentStatus();
    }
    throw error;
  }
  // A late response belongs to the original page, even when the creator has moved on.
  const draft = S.agentDrafts[agentKey];
  if (draft?.text?.trim() === message) S.agentDrafts[agentKey] = { text: "" };
  delete S.agentPending[agentKey];
  if (S.project?.id !== pid) return;
  S.projectRevisionFloor = Math.max(S.projectRevisionFloor || 0, result.revision || 0);
  const resultKey = eid ? eid + "/" + result.stage : "setting";
  S.project.agentRuns ||= {};
  S.project.agentConversations ||= {};
  const currentRun = S.project.agentRuns[resultKey];
  const olderResult = S.project.revision > (result.revision || 0) || (S.project.activityRevision || 0) > (result.activityRevision || 0);
  S.projectActivityFloor = Math.max(S.projectActivityFloor || 0, result.activityRevision || 0);
  if (currentRun && currentRun.turnId !== result.turnId && olderResult) {
    requestAgentSync();
    render();
    return;
  }
  if (!currentRun || !olderResult) {
    if (result.run) S.project.agentRuns[resultKey] = result.run;
    if (result.conversation) S.project.agentConversations[resultKey] = result.conversation;
  }
  if (S.agentKey !== agentKey) { render(); return; }
  S.agentRevision = Math.max(S.project.revision, result.revision || 0);
  S.agentActivityRevision = Math.max(S.project.activityRevision || 0, result.activityRevision || 0);
  const sameTurn = S.agentTurn === result.turnId;
  const run = S.project.agentRuns[resultKey] || result.run || result;
  S.agentStatus = ["started", "steered"].includes(run.status) ? "running" : run.status || "running";
  S.agentStartedAt = run.startedAt || S.agentStartedAt;
  S.agentFinishedAt = run.finishedAt || null;
  S.agentError = run.error || "";
  if (result.stage) S.stage = result.stage;
  S.agentNeedsSync = true;
  if (!sameTurn) S.after = 0;
  S.agentAura = result.auraId;
  S.agentTurn = result.turnId;
  const messages = S.project.agentConversations?.[agentScopeKey()]?.messages || result.conversation?.messages || [];
  if (sameTurn) mergeAgentMessages(messages);
  else S.messages = [...messages];
  if ($("agentInput").value.trim() === message) $("agentInput").value = "";
  S.selectedReferences.clear();
  S.assetSelection.clear();
  S.clipSelection.clear();
  render();
  toast(sameTurn ? "消息已追加" : "创作搭档已开始");
  const project = await api("projects/" + pid).catch(() => null);
  if (project && acceptProjectSnapshot(project)) { requestAgentSync(); render(); }
}
$("agentInput").addEventListener("keydown", (event) => {
  if (event.key !== "Enter" || !(event.ctrlKey || event.metaKey) || event.isComposing || event.keyCode === 229 || event.repeat) return;
  event.preventDefault();
  const form = $("agentForm"), submit = form.querySelector("button[type=submit]");
  if (!form.hidden && !submit.disabled) form.requestSubmit(submit);
});
async function advanceAfterReview(targetType, versionId, targetId) {
  if (["asset", "clip"].includes(targetType)) return;
  if (
    !ep() ||
    S.stage === "library" ||
    (targetType === "asset" &&
      !ep().assetRefs.some((r) => r.assetId === targetId))
  )
    return;
  S.stage = S.project.nextStages?.[S.episodeId] || S.stage;
  render();
  if (targetType === "clip" && ep().clips.every((c) => c.acceptedVersionId))
    return toast("本集片段已全部采用");
  await startAgent("已采用，继续。", { targetType, versionId, targetId });
}
function renderMessages() {
  renderAgentTranscript();
}

document.addEventListener("contextmenu", (e) => {
  const project = e.target.closest('.project-card[data-id]');
  if (project) {
    e.preventDefault();
    showProjectMenu(project, e.clientX, e.clientY);
    return;
  }
  const target = e.target.closest("[data-version-context]");
  if (!target || !["clip", "asset"].includes(S.modal?.kind)) return;
  e.preventDefault();
  const menu = $("contextMenu");
  menu.removeAttribute("role");
  menu.removeAttribute("aria-label");
  projectMenuTrigger = null;
  menu.innerHTML = btn(
    "独立成为上层正式内容",
    "promote",
    'data-version="' + target.dataset.versionContext + '"',
  );
  menu.style.left = Math.min(e.clientX, innerWidth - 240) + "px";
  menu.style.top = Math.min(e.clientY, innerHeight - 60) + "px";
  menu.hidden = false;
});
let projectMenuTrigger = null;
function showProjectMenu(card, x, y) {
  const menu = $("contextMenu");
  projectMenuTrigger = card;
  menu.setAttribute("role", "menu");
  menu.setAttribute("aria-label", "项目操作");
  const attributes = 'role="menuitem" type="button" data-id="' + card.dataset.id + '"';
  menu.innerHTML = btn("重命名", "renameProject", attributes) + btn("复制项目", "duplicateProject", attributes) + btn("删除项目", "deleteProject", attributes, "danger");
  menu.hidden = false;
  menu.style.left = Math.max(8, Math.min(x, innerWidth - menu.offsetWidth - 8)) + "px";
  menu.style.top = Math.max(8, Math.min(y, innerHeight - menu.offsetHeight - 8)) + "px";
  menu.querySelector("button").focus();
}
document.addEventListener("keydown", event => {
  const card = event.target.closest('.project-card[data-id]');
  if (card && (event.key === "ContextMenu" || (event.shiftKey && event.key === "F10"))) {
    event.preventDefault();
    const box = card.getBoundingClientRect(); showProjectMenu(card, box.left + 24, box.top + 24); return;
  }
  const menu = $("contextMenu");
  if (menu.hidden) return;
  if (event.key === "Escape") { event.preventDefault(); menu.hidden = true; projectMenuTrigger?.focus(); }
  if (["ArrowUp", "ArrowDown"].includes(event.key)) {
    event.preventDefault();
    const buttons = [...menu.querySelectorAll('button:not(:disabled)')], position = buttons.indexOf(document.activeElement);
    buttons[(position + (event.key === "ArrowDown" ? 1 : buttons.length - 1)) % buttons.length]?.focus();
  }
});
$("agentToggle").onclick = () => $("assistant").classList.toggle("collapsed");
const resizeHandle = $("agentResize"),
  widthStorageKey = "auralis-drama-agent-width";
let preferredAgentWidth = 0;
try {
  preferredAgentWidth = Number(localStorage.getItem(widthStorageKey)) || 0;
} catch {}
function applyAgentWidth(width = preferredAgentWidth) {
  const max = innerWidth > 1150 ? innerWidth - 690 : innerWidth - 40;
  const value = Math.round(
    Math.max(
      320,
      Math.min(max, width || Math.min(560, Math.max(360, innerWidth * 0.28))),
    ),
  );
  document.documentElement.style.setProperty("--assistant-width", value + "px");
  resizeHandle.setAttribute("aria-valuemin", "320");
  resizeHandle.setAttribute("aria-valuemax", String(Math.max(320, max)));
  resizeHandle.setAttribute("aria-valuenow", String(value));
}
function rememberAgentWidth(width) {
  preferredAgentWidth = width;
  try {
    localStorage.setItem(widthStorageKey, String(width));
  } catch {}
  applyAgentWidth();
}
resizeHandle.addEventListener("pointerdown", (event) => {
  if (event.button !== 0) return;
  event.preventDefault();
  resizeHandle.setPointerCapture(event.pointerId);
  document.body.classList.add("resizing-agent");
});
resizeHandle.addEventListener("pointermove", (event) => {
  if (resizeHandle.hasPointerCapture(event.pointerId))
    applyAgentWidth(innerWidth - event.clientX);
});
function finishAgentResize(event) {
  if (!resizeHandle.hasPointerCapture(event.pointerId)) return;
  rememberAgentWidth(Number(resizeHandle.getAttribute("aria-valuenow")));
  resizeHandle.releasePointerCapture(event.pointerId);
  document.body.classList.remove("resizing-agent");
}
resizeHandle.addEventListener("pointerup", finishAgentResize);
resizeHandle.addEventListener("pointercancel", finishAgentResize);
resizeHandle.addEventListener("dblclick", () => rememberAgentWidth(0));
resizeHandle.addEventListener("keydown", (event) => {
  if (!["ArrowLeft", "ArrowRight", "Home"].includes(event.key)) return;
  event.preventDefault();
  const width = Number(resizeHandle.getAttribute("aria-valuenow"));
  rememberAgentWidth(
    event.key === "Home" ? 0 : width + (event.key === "ArrowLeft" ? 32 : -32),
  );
});
window.addEventListener("resize", () => applyAgentWidth());
applyAgentWidth();
window.addEventListener("message", (event) => {
  if (
    event.origin !== location.origin ||
    event.source !== $("canvasFrame")?.contentWindow ||
    event.data?.type !== "drama-candidate-action"
  )
    return;
  if (
    !["reviewVariant", "promote", "deleteVariant"].includes(
      event.data.action,
    ) ||
    !S.modal
  )
    return;
  const target =
    S.modal.kind === "asset"
      ? S.project.assets.find((a) => a.id === S.modal.id)
      : ep()?.clips.find((c) => c.id === S.modal.id);
  if (!target?.versions.some((v) => v.id === event.data.versionId)) return;
  act(event.data.action, {
    version: event.data.versionId,
    decision: "accepted",
  }).catch((error) => toast(error.message, true));
});
$("agentStop").onclick = async () => {
  const key = S.agentKey, turn = S.agentTurn;
  S.agentStatus = "stopping";
  renderAgentStatus();
  try {
    const stopped = await api("projects/" + S.project.id + "/agent-stop", {
      episodeId: S.episodeId,
      stage: S.stage,
      turnId: S.agentTurn,
    });
    if (S.agentKey !== key || S.agentTurn !== turn) return;
    S.agentRevision = Math.max(S.agentRevision || 0, stopped.revision || 0);
    S.agentActivityRevision = Math.max(S.agentActivityRevision || 0, stopped.activityRevision || 0);
    S.projectActivityFloor = Math.max(S.projectActivityFloor || 0, stopped.activityRevision || 0);
    S.projectRevisionFloor = Math.max(S.projectRevisionFloor || 0, stopped.revision || 0);
    S.agentStatus = "interrupted";
    S.agentFinishedAt = new Date().toISOString();
    S.agentNeedsSync = true;
  } catch (error) {
    if (S.agentKey !== key) return;
    S.agentStatus = "disconnected";
    S.agentError = error.message;
  }
  renderAgentStatus();
};
let polling = false;
setInterval(async () => {
  if (!S.project || polling || S.agentPending[S.agentKey] || S.agentStatus === "starting") return;
  polling = true;
  const pid = S.project.id,
    key = S.agentKey,
    eid = S.episodeId, stage = S.stage, turn = S.agentTurn;
  try {
    if (S.agentRunning || S.agentNeedsSync) {
      const r = await api(
        "projects/" +
          pid +
          "/agent-events?episodeId=" +
          (eid || "") +
          "&stage=" + stage +
          "&after=" +
          S.after,
      );
      if (S.agentKey !== key || S.agentTurn !== turn || S.agentPending[key] || S.agentStatus === "starting") return;
      if (r.revision < (S.agentRevision || 0) || (r.activityRevision || 0) < (S.agentActivityRevision || 0)) return;
      S.agentRevision = r.revision || S.agentRevision;
      S.agentActivityRevision = r.activityRevision || S.agentActivityRevision;
      S.projectActivityFloor = Math.max(S.projectActivityFloor || 0, r.activityRevision || 0);
      S.projectRevisionFloor = Math.max(S.projectRevisionFloor || 0, r.revision || 0);
      S.after = r.nextEventId;
      if (r.run) {
        S.project.agentRuns ||= {};
        S.project.agentRuns[agentScopeKey()] = r.run;
        S.agentTurn = r.run.turnId;
        S.agentStatus = r.run.status;
        S.agentStartedAt = r.run.startedAt;
        S.agentFinishedAt = r.run.finishedAt;
        S.agentError = r.run.error || "";
        S.agentNeedsSync = false;
      }
      mergeAgentMessages(r.messages || []);
      if (S.project.agentConversations) S.project.agentConversations[agentScopeKey()] = { messages: r.messages || [] };
      for (const item of r.events || []) {
        if (item.turnId && item.turnId !== S.agentTurn) continue;
        const value = item.params || {};
        if (item.method === "error") {
          S.agentDetail = value.willRetry ? "连接异常，Agent 正在重试：" + (value.message || "暂时不可用") : "Agent 错误：" + (value.message || "未知错误");
        }
        if (item.method === "item/started") {
          const kind = value.item?.type;
          S.agentDetail =
            {
              reasoning: "正在思考",
              commandExecution: "正在执行操作",
              mcpToolCall: "正在调用工具",
              fileChange: "正在写入内容",
              agentMessage: "正在回复",
            }[kind] || "正在处理";
        }
        if (
          item.method !== "item/agentMessage/delta" &&
          !(
            item.method === "item/completed" &&
            value.item?.type === "agentMessage"
          )
        )
          continue;
        const delta = value.delta || value.item?.text;
        if (!delta) continue;
        const messageId = value.itemId || value.item?.id || item.eventId;
        let message = S.messages.find((m) => m.id === messageId);
        if (!message) {
          message = { id: messageId, turnId: S.agentTurn, role: "agent", text: "" };
          S.messages.push(message);
        }
        message.text = value.delta ? message.text + delta : delta;
      }
      if (r.snapshot?.terminal && r.snapshot.finalText) {
        const messageId = "reply-" + S.agentTurn;
        let message = S.messages.find((m) => m.id === messageId);
        if (!message) {
          message = { id: messageId, turnId: S.agentTurn, role: "agent" };
          S.messages.push(message);
        }
        message.text = r.snapshot.finalText;
        message.final = true;
      }
      renderMessages();
      renderAgentStatus();
    }
    if (
      S.modal?.mediaViewer ||
      $("canvasFrame") ||
      (!$("dialog").open &&
        (["synopsis", "storyboard", "assets", "library", "video"].includes(S.stage) ||
          !["TEXTAREA", "INPUT", "SELECT"].includes(
            document.activeElement.tagName,
          )))
    ) {
      const p = await api("projects/" + pid);
      if (S.agentKey !== key || S.agentTurn !== turn || S.agentPending[key]) return;
      if ((p.revision > S.project.revision || (p.activityRevision || 0) > (S.project.activityRevision || 0)) && acceptProjectSnapshot(p)) {
        requestAgentSync();
        if (["assets", "library", "video"].includes(S.stage))
          refreshProductionUI();
        else render();
      }
    }
  } catch (error) {
    if (S.agentKey === key && S.agentTurn === turn && S.agentRunning && S.agentStatus !== "starting") {
      S.agentStatus = "disconnected";
      S.agentError = error.message;
      renderAgentStatus();
    }
  } finally {
    polling = false;
  }
}, 2500);
setInterval(() => {
  if (S.project && S.agentRunning) renderAgentStatus();
}, 1000);
document.addEventListener("paste", (event) => {
  const files = [...(event.clipboardData?.files || [])];
  if (!files.length || !S.project) return;
  event.preventDefault();
  uploadReferences(files);
});
for (const type of ["dragenter", "dragover", "dragleave", "drop"])
  document.addEventListener(type, (event) => {
    if (!S.project || !event.dataTransfer?.types.includes("Files")) return;
    event.preventDefault();
    const area = event.target.closest("#assistant, [data-image-drop]");
    if (type === "dragenter" || type === "dragover")
      area?.classList.add("dragging");
    if (type === "dragleave" || type === "drop")
      document
        .querySelectorAll(".dragging")
        .forEach((el) => el.classList.remove("dragging"));
    if (type === "drop") uploadReferences(event.dataTransfer.files);
  });

(async () => {
  try {
    const data = await fetch("/api/bootstrap").then((r) => r.json());
    Object.assign(S, {
      token: data.token,
      models: data.models,
      defaults: data.defaults,
      controller: data.controller,
      companyReady: data.companyReady,
      providerReady: data.providerReady,
      elevenLabsReady: data.elevenLabsReady,
      projects: data.projects,
    });
    if (innerWidth < 1150) $("assistant").classList.add("collapsed");
    render();
    startDramaUpdateChecks(data.appVersion);
  } catch (e) {
    toast(e.message, true);
  }
})();

matchMedia("(max-width:1150px)").addEventListener("change", (e) =>
  $("assistant").classList.toggle("collapsed", e.matches),
);
