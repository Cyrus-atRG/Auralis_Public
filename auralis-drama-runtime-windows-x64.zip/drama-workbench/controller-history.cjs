const leanOperations = operations => operations?.map(op => Object.fromEntries(Object.entries(op)
  .filter(([key]) => ["type", "id", "assetId", "clipId", "episodeId", "targetType", "baseVersionId"].includes(key))));
function compactTools(messages, archive) {
  let imageCount = 0;
  for (const message of [...messages].reverse()) {
    if (!message.detailImages) continue;
    message.content = message.content.filter(part => part.type !== "image_url" || ++imageCount <= 4);
    if (!message.content.some(part => part.type === "image_url") && !message.imagesOmitted) {
      message.content.unshift({ type: "text", text: "较早单图已移出本轮输入；需要再次核对时用 view_image，版本 ID 见下。" });
      Object.defineProperty(message, "imagesOmitted", { value: true });
    }
  }
  const calls = new Map(), newest = new Map(), toolMessages = messages.filter(m => m.role === "tool");
  for (const message of messages) for (const call of message.tool_calls || []) {
    let args; try { args = JSON.parse(call.function.arguments); } catch { continue; }
    const key = ["context", "inspect", "job"].includes(call.function.name) ? call.function.name + ":" + JSON.stringify(args) : null;
    calls.set(call.id, { call, message, key });
    if (key) newest.set(key, call.id);
  }
  const recent = new Set(toolMessages.slice(-4).map(m => m.tool_call_id));
  for (const message of toolMessages) {
    const record = calls.get(message.tool_call_id);
    if (!record || archive.has(message.tool_call_id)) continue;
    const { call, key } = record;
    const superseded = key && newest.get(key) !== call.id;
    if (!superseded && (recent.has(message.tool_call_id) || message.content.length + call.function.arguments.length < 2000)) continue;
    archive.set(call.id, JSON.stringify({ tool: call.function.name, arguments: call.function.arguments, result: message.content }));
    // Keep receipts and errors visible. Large raw inputs/results remain retrievable.
    let result; try { result = JSON.parse(message.content); } catch {}
    message.content = JSON.stringify({ archivedToolCall: call.id, ...(result?.error ? { error: result.error } : {}),
      ...(result?.results ? { results: result.results, revision: result.revision } : {}),
      ...(key && newest.get(key) !== call.id ? { superseded: true } : {}), readWith: "tool_result" });
    if (call.function.arguments.length >= 2000) {
      const args = JSON.parse(call.function.arguments);
      call.function.arguments = JSON.stringify({ archivedToolCall: call.id, operations: leanOperations(args.operations) });
      for (const item of record.message.responseOutput || []) if (item.type === "function_call" && item.call_id === call.id) item.arguments = call.function.arguments;
    }
  }
}
function archivedTool(archive, input) {
  const text = archive.get(input.id);
  if (!text) return { error: { code: "not_found", message: "本轮没有此工具记录" } };
  const offset = Math.max(0, Number(input.offset) || 0), part = text.slice(offset, offset + 12000);
  return { text: part, nextOffset: offset + part.length < text.length ? offset + part.length : null };
}
module.exports = { compactTools, archivedTool };
