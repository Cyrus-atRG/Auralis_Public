# 工作流程｜资产准备

根据已采用分镜复用已有资产、待审候选和在途任务，再补缺项。参考图/声音选择读 `guides/reference-assets.md`，命名读 `asset-naming.md`。

人物角色（不包括野兽怪物等非类人角色）先登记完整全身母版与待派生的分区参考图，按“全身母版生成 → 用户采用 → 参考编辑为单张分区图 → 用户采用”执行。派生图用 parentAssetId 关联母版；母版通过后，refs 才绑定其在本集固定的采用版本并提交编辑。已有符合要求的采用版本直接复用。野兽、怪物等非类人角色使用完整外观图，不自动登记或生成分区参考图。

自行上传的素材直接可用，不要求用户再审核。生成候选由用户选择通过；每项仅一个当前通过版本，其余是备选，不再催用户逐个审核。各引用固定到本集采用的版本。不要因保留的备选阻塞下一步。

## 工作规范｜操作

生图 prompt 描述具体画面、参考用途和本次改动，不附通用的提质、锐化或细节增强套话；分辨率等交给生成参数。审核顺序与资产管理说明留在工作台，不发给生图模型。

- `ensureAsset {episodeId,name,kind,description,parentAssetId?,purpose?,settingId?,voice?}`。kind：character/costume/scene/prop/audio/video；先给自动解析出的 unclassified 对象分类。人物名与本集固定人物卡的 character.name 相同时自动继承音色，也可显式传 settingId。
- `bindAsset {episodeId,name,assetId}`：明确名称对应。
- `setAssetPrompt {episodeId,assetId,prompt,refs}`：refs 全量保存，遗漏会清空；每项 `{assetId,versionId,role,purpose?}`，引用本集已采用的实际素材。
- `generate {targetType:'asset',targetId,episodeId,model?}`：首版只生成图像，视频由用户批次触发。

有台词的角色必须准备音色。人物卡缺失音色时，给人物资产填写 `voice: {hasDialogue:true,description:"upbeat sweet",language:"en",gender:"female"}`，或调用 `setVoiceProfile {episodeId,assetId,voice}`；不会说话的角色设 hasDialogue:false。后台自动搜索 ElevenLabs、下载最多 4 个候选到该角色的音色资产。无需 agent 搜索、下载、轮询或逐个挑选；等用户在资产库试听选定。相同特质重复保存不会重复搜索。context 中 voiceSearch 是简要进度。

外部 voice ID 和文字描述不能充当视频音频输入，只有实际下载且已选定的音频版本才可使用。其他音频/视频仍可导入文件；没有独立 TTS。
