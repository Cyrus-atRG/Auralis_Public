# 工作流程｜视频片段

读取已采用分镜、目标片段和所需资产版本；有对白时读取说话角色的人物卡音色信息或资产继承的 voice 特征。写提示词时读 `guides/video-direction.md`；已有结果需要修复时读 `guides/repair.md`。

规划分段、时长和参考，填好完整提示词并接齐素材，让用户直接修改或要求修改，再由用户选片段批量同意生成。结果作为候选供审核；变体可从界面独立提升，素材下载后由用户剪辑。

以已审核文字分镜为基础完成可直接交给视频模型的视听设计：保留剧情、角色状态和关键叙事意图，按片段需要进一步设计动作过程、表演、摄影、光影、声音和转场，不把分镜缩写后贴上秒数。先决定节奏和连续事件，再结合实际模型能力确定生成段及总时长；一个生成段可以包含多个镜头，不机械套用项目默认时长或平均分配镜头时间。

## 工作规范｜操作

`planClip {episodeId,id?,title,prompt,duration,model,refs,aspectRatio?,speakingAssetIds}`。修改已有卡片传实际 id；refs 为完整参考列表，每项 `{assetId,versionId,role,purpose?}`，role 为 image/audio/video，版本须已采用且本集固定。

本阶段可直接整理片段：`deleteClip {id,episodeId?}` 删除多余卡片，`restoreClip {id,episodeId?}` 恢复，`reorderClips {ids,episodeId?}` 按完整列表排序；删除记录见 context.archived.clips。`deleteMediaVersion {targetType:'clip',targetId,versionId,episodeId?}` 删除未采用、未被引用的备选。`promoteVariant {targetType:'clip',clipId,versionId,title?,episodeId?}` 将候选拆成独立待审片段。`saveCanvasLayout {targetType:'clip',targetId,positions:[{id,x,y}],episodeId?}` 保存节点布局。`setGeneration {video:{model,resolution,aspectRatio,duration}}` 修改视频默认参数；已有卡片用 planClip 修改。以上操作均不授权或提交视频生成。

speakingAssetIds 只列本片段实际说话的角色资产 ID（含画外说话者），无对白填 []。服务自动添加这些角色在本集固定的音色音频，在最终请求内按真实 @Audio 顺序绑定角色。不要列只是出镜却不说话的角色，不要自行用最新公共音色替换本集固定版本。音色待选时可以先保存计划，用户在资产库选定后自动补齐音频参考；未选完不能批量生成，补齐参考会更新计划版本，需用户确认完整输入。已绑定的音频不会随公共音色替换而静默改动。人物卡尚未填写时回资产阶段填写特质。

prompt 逐个介绍实际音频参考：角色音频写清对应谁、用于参考声线，并写入人物卡的音色关键词（可读取角色资产继承的 voice.description）；其他音频说明参考的是音效、环境或音乐。按完整 refs 中音频的实际顺序标注 @Audio N，保存后核对服务补齐的 refs/voiceBindings，不按图片序号或角色出场顺序猜编号。音频尚待选择时先写角色声线与用途，不虚构已提供的文件或编号。每句对白写清说话人、台词和本句表演，固定声线与本句情绪、语速分开；样本的台词和背景声不作为本段内容照搬。

批次只授权当时的输入版本；改动后由工作台排除或重新确认。未接通的编辑/延长端点不能靠提示词执行。内部审核说明不写进发给模型的 prompt。
