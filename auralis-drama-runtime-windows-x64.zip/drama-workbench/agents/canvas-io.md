# 工作规范｜读写接口

使用本轮提供的 cli、server、session、capability，以及 scope/allowedOperations。规范文件已全文载入；仅补读未提供的规范时，使用本轮 promptsRoot 下的快照文件。不要改用通用画布 CLI。

```text
node "<cli>" <context|inspect|apply|job|history|view_image> --server "<server>" --session <session> --capability <capability> --json-file "<UTF-8请求文件>"
```

也支持 `--json '<对象>'` 或 `--json -`（stdin）。各命令请求体：

- context：`{}`。本轮已有有效上下文可直接使用。
- history：较早讨论不重复附带。`{"query":"关键词"}` 搜索本环节讨论目录；用返回的 `id` 读正文，长消息按 `nextTextOffset` 续读。无 query 时返回近期目录，可按 nextBefore 翻页。涉及先前要求、选项或决定而上下文缺失时再查，不要猜测。重置前的讨论不可读。
- view_image：`{"assetId":"资产ID","versionId":"版本ID"}`，返回可直接看图的本地 path；公司 API 直接返回图片。超过 1080p 级别的单图会自动等比缩小，无需选择清晰度。
- inspect：`{"ids":["实际ID"]}`，读取至多20个作用域内条目。versions 默认只含当前、采用、本集固定和用户选中版本全文；versionIndex 是按新到旧的历史目录，每页20条。按目录的 nextOffset 传 historyOffset 翻页，historyLimit 可设0至100。确需旧版全文时传 `{"ids":["条目ID"],"versionIds":["版本ID"],"historyLimit":0}`，仅返回点名版本。生产阶段设定始终只提供本集固定版。
- job：`{"id":"任务ID"}`，返回状态、错误和结果；只有追查该任务的生成输入时才加 `"includeInput":true`。不要为查看进度反复读取完整输入。
- apply：`{requestId,expectedRevision,operations:[{type:"操作名",...操作字段}]}`。正文或提示词的修改必须通过工具写入，不能只留在聊天中。

本轮 context.imageSheets 对应已附的资产总览图片：每页至多9张，按从左到右、从上到下排列，图下标资产名称；items 给出准确 assetId/versionId。先看总览，只有需要辨认关键细节时才查看相关原图。总览仅供 agent 规划，不能拿整张拼图当成生成参考；生成 refs 始终使用其中具体资产的原始版本 ID。

需要查看单张资产细节时用 view_image 获取图片；本地模式再用看图工具读取返回的 path。已有准确 assetId/versionId 时直接调用，无需再 inspect。不要仅因目录缺少文件大小、哈希或下载地址就额外 inspect。生成、下载和导出仍使用原始图片。

写入使用最新 revision；409 后重读受影响内容。相同请求重试使用同一 requestId 和请求体；修改请求体后换 ID。引用采用的资产版本，不自动替换为公共库新版。

在 allowedOperations 内可直接编辑、删除、恢复和整理本阶段内容，无需再要求用户替你点编辑按钮。生产阶段可用 `updateEpisode {episodeId?,title?,number?}` 改本集名称或集号。排序操作传当前范围内完整、不重复的 ids；删除保留历史记录，不删除媒体文件。仍被当前内容依赖的条目须先调整关联；有制作任务则先 cancelJob。不能修改其他集或其他阶段；审核采用、固定引用换版和视频生成授权仍由用户执行。跨 agent 交接尚未接通，不得声称已经通知其他 agent。

生成有任务 ID 就查询原任务；submission_unknown 从用户界面的恢复入口处理，不能按失败另起重复生成。晚到结果归原输入的候选；取消本地任务不等于供应商取消。审核和视频批次授权由界面执行。
