# 工作规范｜读写接口

使用本轮提供的 cli、server、session、capability，以及 scope/allowedOperations。提示词中的相对文件路径从 cli 所在目录下的 `agents/` 解析。不要改用通用画布 CLI。

```text
node "<cli>" <context|inspect|apply|job> --server "<server>" --session <session> --capability <capability> --json-file "<UTF-8请求文件>"
```

也支持 `--json '<对象>'` 或 `--json -`（stdin）。各命令请求体：

- context：`{}`。本轮已有有效上下文可直接使用。
- inspect：`{"ids":["实际ID"]}`，读取至多20个作用域内条目。
- job：`{"id":"任务ID"}`。
- apply：`{requestId,expectedRevision,operations:[{type:"操作名",...操作字段}]}`。作品写入操作的 text/prompt，不能只留在聊天中。

查看公共库图片时先 inspect 资产，取得具体版本的 media.path；以本轮提供的 projectDir 为根目录解析成绝对路径，再使用看图工具读取实际图片。资产索引和文件名不能代替看图。

写入使用最新 revision；409 后重读受影响内容。相同请求重试使用同一 requestId 和请求体；修改请求体后换 ID。引用采用的资产版本，不自动替换为公共库新版。

在 allowedOperations 内可直接编辑、删除、恢复和整理本阶段内容，无需再要求用户替你点编辑按钮。生产阶段可用 `updateEpisode {episodeId?,title?,number?}` 改本集名称或集号。排序操作传当前范围内完整、不重复的 ids；删除保留历史记录，不删除媒体文件。仍被当前内容依赖的条目须先调整关联；有制作任务则先 cancelJob。不能修改其他集或其他阶段；审核采用、固定引用换版和视频生成授权仍由用户执行。跨 agent 交接尚未接通，不得声称已经通知其他 agent。

生成有任务 ID 就查询原任务；submission_unknown 从用户界面的恢复入口处理，不能按失败另起重复生成。晚到结果归原输入的候选；取消本地任务不等于供应商取消。审核和视频批次授权由界面执行。
