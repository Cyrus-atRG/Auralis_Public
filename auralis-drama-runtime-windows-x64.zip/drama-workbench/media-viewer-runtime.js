// Small workbench host for the viewer extracted from Auralis.html.
// The parent owns persistence, generation, review and downloads; there is no
// canvas, local project database, controller, or provider transport in this page.
const $ = (id) => document.getElementById(id);
document.documentElement.dataset.visualScheme = "aura";
document.documentElement.style.colorScheme = "dark";
const state = {
  settings: { aspectRatio: "9:16", duration: 5 },
  selectedNodeIds: [], mediaViewerBatchNodeIds: [], mediaViewerNodeId: "",
};
const ASTRA_ROLE_LABELS = {};
let viewerProject = null;
const currentProject = () => viewerProject;
// Native request builders describe inputs; the parent uploads their saved files.
const embeddedCanvasHost = { referenceUrl: node => 'https://canvas-input.invalid/' + encodeURIComponent(node.id) };
const videoRequestUrlForAsset = async node => node ? embeddedCanvasHost.referenceUrl(node) : '';
const videoImageRequestUrlForAsset = videoRequestUrlForAsset;
const waveSpeedVideoRequestUrlForAsset = videoRequestUrlForAsset;
const waveSpeedImageRequestUrlForAsset = videoRequestUrlForAsset;
const waveSpeedUploadMediaAsset = videoRequestUrlForAsset;
const nodeById = (id, project = viewerProject) => project?.nodes.find((node) => node.id === id);
const projectContainingNode = (id) => nodeById(id) ? viewerProject : null;
const selectedNodes = (project = viewerProject) => project.nodes.filter((node) => state.selectedNodeIds.includes(node.id));
const displayNodeTitle = (node) => node.title;
const scheduleSave = () => {}; // Drafts are stashed by the parent before dismissal/remount.
const refreshProjectSurface = () => {};
const markGeneratedMediaViewed = () => {};
const starFlowMediaSettings = () => ({
  plannerNodeId: "", productionMode: "first_frame", segmentCount: 1,
  segmentDurationSeconds: 5, videoResolution: "720p", videoAspectRatio: "1:1",
  imageAspectRatio: state.settings.aspectRatio, imageResolution: "2k",
});
function updateNode(id, patch) {
  const node = nodeById(id);
  if (node) Object.assign(node, patch);
}
function renderContextMenu() {
  const root = $("contextMenuRoot"), menu = state.contextMenu;
  root.innerHTML = menu ? renderGenerationControlContextMenu(menu) : "";
  root.querySelectorAll("[data-menu-action]").forEach((button) => {
    button.onclick = () => {
      updatePromptGenerationControl(menu.id, menu.field, button.dataset.menuAction);
      closeContextMenu();
      renderMediaViewer();
    };
  });
}
const mentionMenuItems = (menu = state.mentionMenu) => filteredPromptReferenceCandidates(menu?.nodeId, menu?.query);
const activeMentionTextarea = () => document.querySelector("[data-media-prompt-editor]");
function insertMentionFromMenu(alias, nodeId) {
  const editor = activeMentionTextarea();
  insertPromptReferenceMention(alias, nodeId, editor);
  editor?.dispatchEvent(new Event("input", { bubbles: true }));
}
function downloadMediaNode(id) {
  const node = nodeById(id);
  if (node) parent.postMessage({ type: "drama-media-action", action: "download", versionId: id,
    targetId: node.meta.dramaTargetId, kind: node.meta.dramaKind }, location.origin);
}
// Native review/generate buttons are replaced/intercepted by media-viewer.js.
// Its authoritative parent actions are the only write path.
window.AuralisCanvas = {
  videoExecution(promptId) {
    const settings = promptGenerationSettings(nodeById(promptId)), links = viewerProject.links.filter(l => l.toNodeId === promptId);
    const first = role => links.find(l => l.inputRole === role)?.fromNodeId || '';
    const execution = { model: settings.model, mediaSettings: settings.mediaSettings, promptNodeId: promptId,
      firstFrameNodeId: first('first_frame'), lastFrameNodeId: first('last_frame'), editVideoNodeId: first('video_edit'), extendVideoNodeId: first('video_extend'),
      referenceNodeIds: links.filter(l => l.inputRole === 'ref').map(l => l.fromNodeId),
      referenceVideoNodeIds: links.filter(l => l.inputRole === 'reference_video').map(l => l.fromNodeId),
      inputNodeIds: links.map(l => l.fromNodeId) };
    execution.mode = execution.editVideoNodeId ? 'video_edit' : execution.extendVideoNodeId ? 'video_extend'
      : execution.firstFrameNodeId ? execution.lastFrameNodeId ? 'image_to_video_first_last_frame' : 'image_to_video' : 'text_to_video';
    return execution;
  },
  async videoRequest(model, prompt, execution, graph) {
    const project = { ...viewerProject, ...graph, runtime: { videoModel: model } };
    if (mediaModelConfig(model, 'video').provider === 'wavespeed') {
      const request = await buildWaveSpeedVideoRequest(model, prompt, execution, project);
      return { endpoint: request.endpointModel, body: request.body };
    }
    const body = await buildVideoGenerationBody(model, prompt, execution, project);
    return { endpoint: mediaModelConfig(model, 'video').bodyKind === 'doubao-seedance' || isRgSeedanceSoraRequestModel(body.model) ? 'videos' : 'video/generations', body };
  },
  mount(data) {
    closeMediaViewer();
    closeContextMenu();
    closePromptMentionMenu();
    viewerProject = structuredClone({ ...data, embeddedMediaModels: data.allowedModels || [], embeddedJobs: data.jobs || [] });
    return viewerProject.id;
  },
  snapshot() {
    const p = viewerProject;
    return { id: p?.id, nodes: p?.nodes || [], links: p?.links || [], jobs: p?.embeddedJobs || [] };
  },
  openMedia(id, batchIds = [id]) {
    state.selectedNodeIds = batchIds;
    openMediaViewer(id);
  },
  closeMedia() { closeMediaViewer(); },
  mediaReview() {
    const node = nodeById(state.mediaViewerNodeId);
    if (!node) return null;
    const prompt = mediaPromptNodeForReview(node);
    return { node, prompt, batchIds: [...state.mediaViewerBatchNodeIds], settings: prompt ? promptGenerationSettings(prompt) : null,
      inputs: prompt ? upstreamInputsFor(prompt.id).map((item) => item.node) : [] };
  },
  syncMedia(data, { syncInputs = false } = {}) {
    const project = viewerProject;
    if (!project || project.id !== data.id) return;
    const incomingIds = new Set(data.nodes.map((node) => node.id));
    project.nodes = project.nodes.filter((node) => incomingIds.has(node.id));
    project.links = project.links.filter((link) => incomingIds.has(link.fromNodeId) && incomingIds.has(link.toNodeId));
    project.embeddedJobs = data.jobs || [];
    const added = new Set();
    const synced = new Set();
    let refreshControls = false;
    for (const incoming of data.nodes) {
      const existing = nodeById(incoming.id);
      if (!existing) { project.nodes.push(structuredClone(incoming)); added.add(incoming.id); }
      else if (incoming.meta?.dramaVersionId) {
        existing.meta = { ...existing.meta, ...incoming.meta };
        existing.assetState = incoming.assetState;
      }
      else if (syncInputs && incoming.meta?.dramaDraftBase) {
        if (existing === this.mediaReview()?.prompt && JSON.stringify(existing.generation) !== JSON.stringify(incoming.generation)) refreshControls = true;
        Object.assign(existing, structuredClone({ content: incoming.content, generation: incoming.generation, meta: incoming.meta }));
        synced.add(incoming.id);
      }
    }
    // Background results must not overwrite edited prompts or chosen references.
    project.links = project.links.filter(link => !synced.has(link.toNodeId));
    project.links.push(...structuredClone(data.links.filter((link) => added.has(link.toNodeId) || synced.has(link.toNodeId))));
    state.mediaViewerBatchNodeIds = data.batchIds;
    if (refreshControls) renderMediaViewer();
    if (syncInputs) {
      const review = this.mediaReview(), editor = document.querySelector('[data-media-prompt-editor]');
      if (editor && review?.prompt && editor.value !== review.prompt.content) editor.value = review.prompt.content;
      const marker = document.querySelector('[data-media-prompt-change]');
      if (marker && review) marker.textContent = mediaReviewPromptChanged(review.node, review.prompt) ? '*存在变更*' : '';
    }
  },
  setMediaReferences(ids) {
    const review = this.mediaReview(), project = viewerProject;
    if (!review?.prompt || !project) return;
    project.links = project.links.filter((link) => link.toNodeId !== review.prompt.id);
    uniqueIds(ids).forEach((id) => {
      const node = nodeById(id);
      if (!node?.meta?.dramaRef && !node?.meta?.dramaCanvasMedia) return;
      project.links.push({ id: `review-${review.prompt.id}-${id}`, fromNodeId: id, toNodeId: review.prompt.id,
        relation: "input", inputRole: node.meta?.dramaCanvasInputRole || (node.mime?.startsWith("audio/") ? "reference_audio" : node.mime?.startsWith("video/") ? "reference_video" : "ref") });
    });
    renderMediaViewer();
  },
};
document.addEventListener("keyup", (event) => {
  if (event.target.matches("[data-media-prompt-editor]"))
    updateMediaPromptFromEditor(event.target.dataset.promptId, event.target.value);
});
document.addEventListener("keydown", (event) => {
  if (handleMediaViewerKeydown(event)) return;
  if (event.key === "Escape") {
    event.preventDefault();
    if (state.contextMenu) closeContextMenu();
    else if (state.mentionMenu) closePromptMentionMenu();
    else closeMediaViewer();
  }
});
document.addEventListener("pointerdown", (event) => {
  if (!event.target.closest(".generation-control-menu,[data-generation-control]")) closeContextMenu();
  if (!event.target.closest(".mention-menu,[data-media-prompt-editor]")) closePromptMentionMenu();
});
window.__auralisReady = Promise.resolve();
