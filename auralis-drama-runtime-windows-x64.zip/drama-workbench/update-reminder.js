function startDramaUpdateChecks(currentVersion) {
  const reminder = document.getElementById("updateReminder");
  const storageKey = "auralis.drama.ignoredUpdateVersion";
  const manifestUrl = "https://raw.githubusercontent.com/Cyrus-atRG/Auralis_Public/main/drama-release-manifest.json";
  const parts = version => typeof version === "string" && /^v?\d+(\.\d+)*$/i.test(version.trim())
    ? version.trim().replace(/^v/i, "").split(".").map(Number) : null;
  const current = parts(currentVersion);
  if (!reminder || !current) return;
  let latestVersion = "", ignoredVersion = "";
  try { ignoredVersion = localStorage.getItem(storageKey) || ""; } catch (_) {}

  document.getElementById("updateReminderDismiss").addEventListener("click", () => {
    ignoredVersion = latestVersion;
    try { localStorage.setItem(storageKey, ignoredVersion); } catch (_) {}
    reminder.hidden = true;
  });
  async function check() {
    try {
      const response = await fetch(manifestUrl, {
        cache: "no-store", credentials: "omit", signal: AbortSignal.timeout(12000),
      });
      if (!response.ok) return;
      const manifest = await response.json(), next = parts(manifest?.releaseVersion);
      if (!next) return;
      const delta = Array.from({ length: Math.max(current.length, next.length) },
        (_, index) => (next[index] || 0) - (current[index] || 0)).find(value => value !== 0) || 0;
      latestVersion = next.join(".");
      reminder.dataset.version = latestVersion;
      reminder.hidden = delta <= 0 || ignoredVersion === latestVersion;
    } catch (_) {
      // Update checks must not interrupt production when the release channel is unreachable.
    }
  }
  setTimeout(() => {
    check();
    setInterval(check, 2 * 60 * 60 * 1000);
  }, 8000);
}
