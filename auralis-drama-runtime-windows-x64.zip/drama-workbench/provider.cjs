const fs = require("node:fs");
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const { id, find, requireValue, hash, now } = require("./store.cjs");

const { models, buildRequest } = require("./generation.cjs");
function probe(file, mime) {
  if (!/^(audio|video)\//.test(mime)) return {};
  const result = spawnSync(
    process.env.FFPROBE_PATH || "ffprobe",
    ["-v", "error", "-show_entries", "format=duration", "-of", "json", file],
    { encoding: "utf8", windowsHide: true },
  );
  if (result.error || result.status !== 0)
    throw new Error("无法探测音视频时长：请安装 ffprobe 或设置 FFPROBE_PATH");
  const duration = Number(JSON.parse(result.stdout).format?.duration);
  requireValue(Number.isFinite(duration) && duration > 0, "素材时长无效");
  return { duration };
}
class Provider {
  constructor(store, options = {}) {
    this.store = store;
    this.fetch = options.fetch || fetch;
    this.base = options.base || "https://api.wavespeed.ai/api/v3";
    this.key = options.key || process.env.WAVESPEED_API_KEY || "";
    this.credentials = options.credentials || (() => ({}));
    this.promptLibrary = options.promptLibrary;
    this.active = new Set();
    this.timer = null;
  }
  async json(route, body) {
    const r = await this.fetch(this.base + route, {
      method: body ? "POST" : "GET",
      headers: {
        Authorization: "Bearer " + this.key,
        "Content-Type": "application/json",
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
      signal: AbortSignal.timeout(60000),
    });
    if (!r.ok)
      throw Object.assign(new Error("供应商返回 HTTP " + r.status), {
        definite: r.status >= 400 && r.status < 500,
      });
    return r.json();
  }
  start() {
    for (const p of this.store.list())
      this.store.internal(p.id, (doc) => {
        for (const j of doc.jobs) {
          if (j.status === "submitting")
            j.status = j.remoteId ? "polling" : "submission_unknown";
          if (j.status === "preparing") j.status = "queued";
        }
      });
    this.timer = setInterval(() => this.tick(), 2500);
    this.timer.unref();
    this.tick();
  }
  stop() {
    clearInterval(this.timer);
  }
  tick() {
    for (const p of this.store.list()) {
      for (const job of this.store.read(p.id).jobs) {
        if (
          !["queued", "polling", "downloading"].includes(job.status) ||
          this.active.has(job.id)
        )
          continue;
        this.active.add(job.id);
        this.run(p.id, job.id)
          .catch(() => {})
          .finally(() => this.active.delete(job.id));
      }
    }
  }
  update(pid, jid, values) {
    this.store.internal(pid, (p) =>
      Object.assign(find(p.jobs, jid), values, { updatedAt: now() }),
    );
  }
  async upload(pid, media) {
    const file = path.join(path.dirname(this.store.file(pid)), media.path),
      bytes = fs.readFileSync(file);
    requireValue(bytes.length <= 200 * 1024 * 1024, "参考文件超过 200 MiB");
    const ticket = await this.json("/media/uploads", {
      filename: path.basename(file),
      size: bytes.length,
      content_type: media.mime,
    });
    const upload = ticket.data?.upload;
    requireValue(upload && /^https:\/\//.test(upload.url), "上传票据无效");
    const headers = Object.fromEntries(
      Object.entries(upload.headers || {}).filter(
        ([key]) => key.toLowerCase() !== "authorization",
      ),
    );
    const r = await this.fetch(upload.url, {
      method: upload.method,
      headers,
      body: bytes,
      signal: AbortSignal.timeout(120000),
    });
    requireValue(r.ok, "参考文件上传失败");
    const url =
      ticket.data?.download_url || ticket.data?.url || ticket.data?.file_url;
    requireValue(/^https:\/\//.test(url || ""), "供应商未返回可用素材地址");
    return url;
  }
  async companyJson(route, body, multipart = false, base = "") {
    const config = this.credentials();
    const endpoint = (base || config.baseUrl || "").replace(/\/+$/, "") + "/" + route;
    let payload = body ? JSON.stringify(body) : undefined;
    const headers = { Authorization: "Bearer " + config.apiKey };
    if (multipart) {
      payload = new FormData();
      for (const [key, value] of Object.entries(body)) if (key !== "images") payload.append(key, String(value));
      for (const [i, url] of body.images.entries()) {
        const image = await this.fetch(url);
        requireValue(image.ok, "无法读取 RG 编辑参考图");
        payload.append("image", await image.blob(), "reference-" + i + ".png");
      }
    } else headers["Content-Type"] = "application/json";
    const r = await this.fetch(endpoint, { method: body ? "POST" : "GET", headers, body: payload, signal: AbortSignal.timeout(body ? 600000 : 60000) });
    if (!r.ok) throw Object.assign(new Error("RG 返回 HTTP " + r.status), { definite: r.status >= 400 && r.status < 500 });
    return r.json();
  }
  async run(pid, jid) {
    let p = this.store.read(pid),
      j = find(p.jobs, jid);
    if (!["queued", "polling", "downloading"].includes(j.status)) return;
    try {
      const config = this.credentials();
      if (Object.hasOwn(config, "wavespeedApiKey")) this.key = config.wavespeedApiKey;
      const company = models[j.snapshot.model]?.provider === "company";
      const { resultMedia, taskStatus, taskId } = require("./rg-provider.cjs");
      if (company ? !(config.apiKey && config.baseUrl) : !this.key) {
        this.update(pid, jid, {
          status: "failed",
          error: "请先在共享 API 设置配置 " + (company ? "RG" : "WaveSpeed") + "，再重试",
        });
        return;
      }
      if (j.status === "queued") {
        this.assertSnapshot(p, j);
        this.update(pid, jid, { status: "preparing", error: null });
        const inputs = [];
        for (const ref of j.snapshot.refs) {
          const a = find(p.assets, ref.assetId),
            v = find(a.versions, ref.versionId);
          requireValue(
            !v.deletedAt &&
              v.media &&
              (j.independent ||
                v.status === "accepted" ||
                v.approvedAt ||
                v.source === "import"),
            "参考素材未审核通过",
          );
          inputs.push({
            ...ref,
            name: a.name,
            duration: v.media.duration,
            url: company && ref.role === "image"
              ? "data:" + v.media.mime + ";base64," + fs.readFileSync(path.join(path.dirname(this.store.file(pid)), v.media.path)).toString("base64")
              : /^https:\/\//.test(v.media.remoteUrl || "") && company
                ? v.media.remoteUrl : await this.upload(pid, v.media),
            mediaPath: v.media.path,
          });
        }
        const snapshot = { ...j.snapshot, voicePrompt: this.promptLibrary?.snapshot().text("voice-binding.md") || j.snapshot.voicePrompt };
        const request = buildRequest(snapshot, inputs);
        p = this.store.read(pid);
        j = find(p.jobs, jid);
        if (j.status === "cancelled") return;
        this.assertSnapshot(p, j);
        // Persist before the network request; a crash here is uncertain, never an automatic resubmit.
        this.update(pid, jid, {
          status: "submitting",
          request: {
            provider: company ? "company" : "wavespeed",
            ...(company ? { baseUrl: config.baseUrl } : {}),
            endpoint: request.endpoint,
            body: request.body,
            inputs: request.inputs,
          },
          submittedAt: now(),
        });
        const response = company
          ? await this.companyJson(request.endpoint, request.body, request.multipart, config.baseUrl)
          : await this.json("/" + request.endpoint, request.body);
        const remote = response.data || response;
        const completedUrl = company && j.snapshot.kind === "image" ? resultMedia(response, "image") : "";
        const remoteId = company ? taskId(response) : remote.id;
        requireValue(remoteId || completedUrl, "供应商未返回任务 ID 或生成素材");
        this.update(pid, jid, {
          remoteId: remoteId || null,
          ...(completedUrl ? { completedUrl } : {}),
          status: !!find(this.store.read(pid).jobs, jid).cancelledAt
            ? "cancelled"
            : "polling",
        });
        j = find(this.store.read(pid).jobs, jid);
      }
      if (!j.remoteId && !j.completedUrl) return;
      const response = j.completedUrl ? { status: "completed" } : company
        ? await this.companyJson((models[j.snapshot.model].bodyKind === "doubao-seedance" ? "video/generations/" : "videos/") + encodeURIComponent(j.remoteId), null, false, j.request?.baseUrl)
        : await this.json("/predictions/" + encodeURIComponent(j.remoteId) + "/result");
      const result = response.data || response;
      const status = company ? taskStatus(response) : result.status;
      if (["failed", "failure", "error", "cancelled", "canceled", "timeout", "deleted"].includes(status))
        throw Object.assign(
          new Error("生成失败：" + (result.error || result.status)),
          { definite: true, remoteTerminal: true },
        );
      if (!["completed", "succeeded", "success", "done"].includes(status)) return;
      const url = j.completedUrl || (company ? resultMedia(response, j.snapshot.kind) :
        typeof result.outputs?.[0] === "string"
          ? result.outputs[0]
          : result.outputs?.[0]?.url);
      requireValue(/^(https:\/\/|data:image\/)/.test(url || ""), "任务完成但没有可下载的素材");
      this.update(pid, jid, { status: "downloading" });
      const r = await this.fetch(url, { signal: AbortSignal.timeout(120000) });
      requireValue(r.ok, "生成素材下载失败");
      const mime = (r.headers.get("content-type") || "").split(";")[0];
      requireValue(
        mime.startsWith(j.snapshot.kind + "/"),
        "供应商返回素材类型不符",
      );
      const ext =
        {
          "image/png": ".png",
          "image/jpeg": ".jpg",
          "image/webp": ".webp",
          "video/mp4": ".mp4",
        }[mime] || (j.snapshot.kind === "video" ? ".mp4" : ".png");
      const relative = "media/" + id("generated") + ext,
        folder = path.dirname(this.store.file(pid));
      fs.mkdirSync(path.join(folder, "media"), { recursive: true });
      const bytes = Buffer.from(await r.arrayBuffer());
      requireValue(bytes.length <= 250 * 1024 * 1024, "生成素材过大");
      fs.writeFileSync(path.join(folder, relative), bytes);
      this.store.addResult(pid, jid, {
        path: relative,
        mime,
        size: bytes.length,
        sha256: hash(bytes.toString("base64")),
        remoteUrl: /^https:/.test(url) ? url : "",
      });
    } catch (error) {
      const current = find(this.store.read(pid).jobs, jid);
      if (current.status === "cancelled") return;
      const status =
        current.submittedAt && !current.remoteId && !current.completedUrl && !error.definite
          ? "submission_unknown"
          : error.code === "superseded"
            ? "superseded"
            : (current.remoteId || current.completedUrl) && !error.definite && error.code !== "invalid"
              ? "polling"
              : "failed";
      this.update(pid, jid, {
        status,
        remoteTerminal: !!error.remoteTerminal || !!current.remoteTerminal,
        error: String(error.message).slice(0, 600),
      });
    }
  }
  assertSnapshot(p, j) {
    const e = find(p.episodes, j.episodeId);
    this.store.storyboardGate(e);
    if (j.targetType === "clip") {
      const c = find(e.clips, j.targetId);
      if (
        (!j.independent && c.planRevision !== j.snapshot.planRevision) ||
        j.snapshot.storyboardVersionId !== e.storyboard.acceptedVersionId
      )
        throw Object.assign(new Error("输入已修改，未提交；请重新确认本片段"), {
          code: "superseded",
        });
      for (const ref of j.snapshot.refs) this.store.validateRef(p, e, ref);
    } else {
      for (const ref of j.snapshot.refs) {
        if (j.independent) this.store.validateCanvasRef(p, ref);
        else this.store.validateRef(p, e, ref);
      }
      const a = find(p.assets, j.targetId);
      if (!j.independent && a.promptRevision !== j.snapshot.promptRevision)
        throw Object.assign(new Error("资产提示词已修改，未提交"), {
          code: "superseded",
        });
    }
  }
}
module.exports = { Provider, models, buildRequest, probe };
