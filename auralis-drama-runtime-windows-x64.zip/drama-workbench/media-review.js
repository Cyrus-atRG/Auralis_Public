// Workbench data adapter for Auralis's existing media viewer. No second lightbox.
S.mediaDrafts = new Map();
function stashMediaDrafts() {
  const api = $("mediaFrame")?.contentWindow?.AuralisCanvas;
  if (!S.modal?.mediaViewer || !api) return;
  const graph = api.snapshot();
  for (const node of graph.nodes.filter((n) =>
    n.id.startsWith("review-prompt-"),
  )) {
    const refs = graph.links
      .filter((l) => l.toNodeId === node.id)
      .map(
        (l) => graph.nodes.find((n) => n.id === l.fromNodeId)?.meta?.dramaRef,
      )
      .filter(Boolean);
    S.mediaDrafts.set(
      node.id.slice("review-prompt-".length),
      structuredClone({
        prompt: node.content,
        generation: node.generation,
        speakingAssetIds: node.meta?.dramaSpeakingAssetIds,
        refs,
      }),
    );
  }
}
function reviewGeneration(kind, saved = {}) {
  const defaults = S.project.generation[kind];
  const model = S.models[saved.model]
    ? saved.model
    : Object.keys(S.models).find(
        (key) =>
          S.models[key].kind === kind &&
          Object.values(S.models[key]).includes(saved.model),
      );
  const value = { ...defaults, ...saved, model: model || defaults.model };
  return {
    model: value.model,
    mediaSettings:
      kind === "image"
        ? {
            imageResolution: value.resolution,
            imageAspectRatio: value.aspectRatio,
          }
        : {
            videoResolution: value.resolution,
            videoAspectRatio: value.aspectRatio,
            segmentDurationSeconds: value.duration,
          },
  };
}
function mediaReviewGraph(kind = S.stage === "video" ? "clip" : "asset") {
  const episode = ep(),
    nodes = [],
    links = [],
    batchIds = [];
  const targets =
    kind === "clip"
      ? episode.clips
          .filter((c) => !S.modal?.mediaViewer || c.id === S.modal.id)
          .map((target) => ({ kind: "clip", target }))
      : S.project.assets
          .filter(
            (a) =>
              !episode ||
              S.stage === "library" ||
              episode.assetRefs.some((r) => r.assetId === a.id),
          )
          .map((target) => ({ kind: "asset", target }));
  // All candidate bytes can be viewed or cited. Generation inputs still use adopted episode pins.
  const addMedia = (asset, version, kind, index, versionIndex) => {
    if (!version.media || version.deletedAt) return;
    const mime = version.media.mime,
      type = mime.split("/")[0];
    const ref =
      kind === "asset"
        ? {
            assetId: asset.id,
            versionId: version.id,
            role: type,
            purpose: asset.purpose || asset.kind,
          }
        : null;
    const eligible =
      !!ref &&
      !!episode?.assetRefs.some(
        (r) => r.assetId === asset.id && r.versionId === version.id,
      ) &&
      !!(
        version.status === "accepted" ||
        version.approvedAt ||
        version.source === "import"
      );
    nodes.push({
      id: version.id,
      family: type === "image" ? "Sol" : type === "video" ? "Luna" : "Meteor",
      type: type === "audio" ? "spokenAudio" : type,
      role:
        type === "image"
          ? "genImage"
          : type === "video"
            ? "genVideo"
            : "spokenAudio",
      title:
        (asset.name || asset.title) +
        (version.source === "plan"
          ? " · 当前计划"
          : version.source === "job"
            ? " · 生成任务"
            : " · 版本 " +
              (asset.versions.findIndex((v) => v.id === version.id) + 1)),
      assetUrl: version.placeholder ? "" : mediaUrl(version.media),
      displayUrl: version.placeholder ? "" : mediaUrl(version.media),
      mime,
      status: "completed",
      assetState:
        asset.acceptedVersionId === version.id ? "official" : "candidate",
      x: index * 600,
      y: versionIndex * 280,
      meta: {
        dramaVersionId: version.id,
        dramaVersionNumber:
          asset.versions.findIndex((v) => v.id === version.id) + 1,
        dramaPlaceholder: version.placeholder || "",
        dramaPlan: version.source === "plan",
        dramaJobId: version.source === "job" ? version.id : null,
        dramaTargetId: asset.id,
        dramaKind: kind,
        dramaVoiceCharacters:
          kind === "clip"
            ? S.project.assets
                .filter(
                  (a) =>
                    a.kind === "character" &&
                    a.voice?.hasDialogue &&
                    episode.assetRefs.some((r) => r.assetId === a.id),
                )
                .map((a) => ({
                  id: a.id,
                  name: a.name,
                  assetId: a.voiceAssetId,
                  versionId: episode.assetRefs.find(
                    (r) => r.assetId === a.voiceAssetId,
                  )?.versionId,
                }))
            : [],
        dramaStatus: version.status,
        dramaSource: version.source,
        dramaRef: ref,
        dramaReferenceEligible: eligible,
        dramaCanEdit: !!episode && S.stage !== "library",
        prompt:
          version.snapshot?.prompt ??
          version.prompt ??
          asset.prompt ??
          asset.plan?.prompt ??
          "",
      },
    });
  };
  targets.forEach(({ kind, target }, i) => {
    const versions =
      kind === "clip"
        ? [
            {
              id: "plan-" + target.id,
              media: { mime: "video/mp4" },
              snapshot: target.plan,
              placeholder: "当前计划 · 点击生成后在这里预览",
              source: "plan",
              status: "draft",
            },
            ...target.versions,
            ...mediaJobs("clip", target.id).map((job) => ({
              id: job.id,
              media: { mime: "video/mp4" },
              snapshot: job.snapshot,
              source: "job",
              status: job.status,
              placeholder:
                (statusNames[job.status] || "生成中") +
                (job.error ? " · " + job.error : ""),
            })),
          ]
        : target.versions;
    versions.forEach((version, vi) => {
      if (version.deletedAt) return;
      addMedia(target, version, kind, i, vi);
      if (!version.media || !/^(image|video)\//.test(version.media.mime))
        return;
      batchIds.push(version.id);
      const saved =
        version.snapshot ||
        (kind === "asset"
          ? {
              ...target.generation,
              prompt: version.prompt ?? target.prompt,
              refs: target.refs || [],
            }
          : target.plan);
      const draft = S.mediaDrafts.get(version.id);
      const mediaKind = kind === "clip" ? "video" : "image",
        promptId = "review-prompt-" + version.id;
      nodes.push({
        id: promptId,
        family: "Comet",
        type: mediaKind + "Prompt",
        role: mediaKind + "Prompt",
        title: "生成提示词",
        content: draft?.prompt ?? saved.prompt ?? "",
        meta: {
          dramaSpeakingAssetIds:
            draft?.speakingAssetIds ?? saved.speakingAssetIds ?? [],
        },
        status: "completed",
        x: i * 600 - 340,
        y: vi * 280,
        generation: draft?.generation || reviewGeneration(mediaKind, saved),
      });
      links.push({
        id: "output-" + version.id,
        fromNodeId: promptId,
        toNodeId: version.id,
        relation: "input",
        inputRole: "prompt",
      });
      for (const [ri, ref] of (draft?.refs || saved.refs || []).entries())
        links.push({
          id: "input-" + version.id + "-" + ri,
          fromNodeId: ref.versionId,
          toNodeId: promptId,
          relation: "input",
          inputRole:
            ref.role === "audio"
              ? "reference_audio"
              : ref.role === "video"
                ? "reference_video"
                : "ref",
        });
    });
  });
  // Include adopted reference media that are not among the viewed targets (e.g. video inputs).
  for (const asset of S.project.assets)
    asset.versions.forEach((version, vi) => {
      if (!nodes.some((n) => n.id === version.id))
        addMedia(asset, version, "asset", targets.length, vi);
    });
  return {
    id: "review-" + (episode?.id || S.project.id),
    title: "素材查看",
    nodes,
    links,
    batchIds,
    allowedModels: Object.keys(S.models),
    jobs: targets
      .flatMap(({ kind, target }) => mediaJobs(kind, target.id))
      .map((j) => ({
        id: j.id,
        targetId: j.targetId,
        status: j.status,
        error: j.error,
      })),
  };
}
function refreshMediaReview() {
  const frame = $("mediaFrame");
  if (
    !$("dialog").open ||
    !S.modal?.mediaViewer ||
    !frame?.contentWindow.AuralisCanvas?.mediaReview()
  )
    return;
  const api = frame.contentWindow.AuralisCanvas;
  const activeJobId = api.mediaReview()?.node.meta?.dramaJobId;
  const resultId = S.project.jobs.find(
    (j) => j.id === activeJobId,
  )?.resultVersionId;
  const finishedJob =
    activeJobId &&
    !mediaJobs("clip", S.modal.id).some((j) => j.id === activeJobId);
  const nextId = resultId || (finishedJob ? "plan-" + S.modal.id : null);
  if (nextId) {
    stashMediaDrafts();
    const draft = S.mediaDrafts.get(activeJobId);
    if (draft) S.mediaDrafts.set(nextId, draft);
    S.mediaDrafts.delete(activeJobId);
  }
  const graph = mediaReviewGraph(S.modal.kind);
  api.syncMedia(graph);
  if (nextId && graph.batchIds.includes(nextId)) {
    const prompt = api
      .snapshot()
      .nodes.find((n) => n.id === "review-prompt-" + nextId);
    const draft = S.mediaDrafts.get(nextId);
    if (prompt && draft) {
      prompt.content = draft.prompt;
      prompt.generation = draft.generation;
      prompt.meta.dramaSpeakingAssetIds = draft.speakingAssetIds;
    }
    api.openMedia(nextId, graph.batchIds);
    if (draft) api.setMediaReferences(draft.refs.map((r) => r.versionId));
  }
  frame.contentWindow.postMessage(
    { type: "drama-media-updated" },
    location.origin,
  );
}
async function previewMedia(kind, targetId, versionId) {
  const target =
    kind === "asset"
      ? S.project.assets.find((a) => a.id === targetId)
      : ep()?.clips.find((c) => c.id === targetId);
  const version =
    target?.versions.find((v) => v.id === versionId) ||
    visibleVersion(
      target,
      ep()?.assetRefs.find((r) => r.assetId === targetId)?.versionId,
    );
  if (
    kind !== "clip" &&
    (!version?.media || !/^(image|video)\//.test(version.media.mime))
  )
    return canvas(kind, targetId);
  S.modal = {
    kind,
    id: targetId,
    revision: S.project.revision,
    mediaViewer: true,
    planRevision: target.planRevision,
  };
  const graph = mediaReviewGraph(kind);
  const chosen = graph.batchIds.includes(versionId)
    ? versionId
    : version?.id || "plan-" + targetId;
  openDialog(
    "查看素材",
    '<iframe id="mediaFrame" title="Auralis 素材查看器" src="/canvas?viewer=1"></iframe>',
    true,
  );
  $("dialog").classList.add("media-dialog");
  const frame = $("mediaFrame");
  frame.addEventListener(
    "load",
    async () => {
      try {
        await frame.contentWindow.__auralisReady;
        if (frame !== $("mediaFrame") || !$("dialog").open) return;
        frame.contentWindow.AuralisCanvas.mount(graph);
        frame.contentWindow.AuralisCanvas.openMedia(chosen, graph.batchIds);
        frame.contentWindow.focus();
      } catch (error) {
        toast(error.message, true);
      }
    },
    { once: true },
  );
}
async function citeAsset(assetId, versionId) {
  S.cardVersions.set(assetId, versionId);
  selectAsset(assetId, versionId);
  $("assistant").classList.remove("collapsed");
  $("agentInput").focus();
  toast("已引用此版本");
}
window.addEventListener("message", async (event) => {
  const frame = $("mediaFrame"),
    data = event.data;
  if (
    event.origin !== location.origin ||
    event.source !== frame?.contentWindow ||
    data?.type !== "drama-media-action" ||
    !S.modal?.mediaViewer
  )
    return;
  if (data.action === "close") return closeDialog();
  const review = frame.contentWindow.AuralisCanvas.mediaReview();
  if (!review || (review.node.id !== data.versionId && !data.input)) return;
  const m = S.modal,
    meta = data.input
      ? { dramaKind: data.kind, dramaTargetId: data.targetId }
      : review.node.meta,
    kind = meta.dramaKind;
  const target =
    kind === "asset"
      ? S.project.assets.find((a) => a.id === meta.dramaTargetId)
      : ep()?.clips.find((c) => c.id === meta.dramaTargetId);
  const version =
    target?.versions.find((v) => v.id === data.versionId) ||
    (kind === "clip" && graphPlaceholder());
  function graphPlaceholder() {
    const node = frame.contentWindow.AuralisCanvas.snapshot().nodes.find(
      (n) => n.id === data.versionId,
    );
    return node?.meta?.dramaPlaceholder
      ? { id: node.id, status: node.meta.dramaStatus }
      : null;
  }
  if (!version) return;
  try {
    if (data.action === "canvas") {
      stashMediaDrafts();
      return canvas(kind, target.id, S.mediaDrafts.get(version.id));
    }
    if (data.action === "cite") {
      await citeAsset(target.id, version.id);
      closeDialog();
      $("agentInput").focus();
      return;
    }
    if (["save", "generate"].includes(data.action)) {
      if (!ep() || !review.prompt)
        throw new Error("进入具体一集后编辑生成前置");
      const { model, mediaSettings: settings } = review.settings;
      const refs = review.inputs.map((n) => n.meta?.dramaRef).filter(Boolean);
      const generation =
        kind === "asset"
          ? {
              model,
              resolution: settings.imageResolution,
              aspectRatio: settings.imageAspectRatio,
            }
          : {
              model,
              resolution: settings.videoResolution,
              aspectRatio: settings.videoAspectRatio,
              duration: settings.segmentDurationSeconds,
            };
      const input = data.input || {
        prompt: review.prompt.content,
        speakingAssetIds: review.prompt.meta?.dramaSpeakingAssetIds,
        refs,
        generation,
      };
      const op =
        kind === "asset"
          ? { type: "generateAssetVariation", assetId: target.id, ...input }
          : {
              type: "generateClipVariation",
              clipId: target.id,
              expectedPlanRevision: m.planRevision,
              ...input,
            };
      await apply([{ ...op, episodeId: ep().id }], m.revision);
    } else if (data.action === "download") {
      downloadClips([{ clipId: target.id, versionId: version.id }]);
    } else if (data.action === "delete") {
      await apply([
        {
          type: "deleteMediaVersion",
          targetType: kind,
          targetId: target.id,
          episodeId: ep()?.id,
          versionId: version.id,
        },
      ]);
      S.mediaDrafts.delete(version.id);
      if (S.assetSelection.get(target.id) === version.id)
        S.assetSelection.delete(target.id);
      const currentTarget =
        kind === "asset"
          ? S.project.assets.find((a) => a.id === target.id)
          : ep().clips.find((c) => c.id === target.id);
      const ordered = target.versions.filter((v) => !v.deletedAt && v.media);
      const deletedIndex = ordered.findIndex((v) => v.id === version.id);
      const remaining = currentTarget.versions.filter(
        (v) => !v.deletedAt && v.media,
      );
      const next = remaining[Math.min(deletedIndex, remaining.length - 1)];
      if (!next) {
        closeDialog();
        render();
        return;
      }
      refreshMediaReview();
      const graph = mediaReviewGraph(kind);
      frame.contentWindow.AuralisCanvas.openMedia(next.id, graph.batchIds);
    } else if (data.action === "accepted") {
      await apply(
        [
          {
            type: "review",
            targetType: kind,
            targetId: target.id,
            episodeId: ep()?.id,
            versionId: version.id,
            decision: data.action,
          },
        ],
        m.revision,
      );
      if (kind === "asset") S.assetSelection.delete(target.id);
      else S.clipSelection.delete(target.id);
      refreshProductionUI();
    } else return;
    m.revision = S.project.revision;
    if (kind === "clip")
      m.planRevision = ep().clips.find((c) => c.id === target.id).planRevision;
    const current =
      kind === "asset"
        ? S.project.assets.find((a) => a.id === target.id)
        : ep().clips.find((c) => c.id === target.id);
    if (frame !== $("mediaFrame") || !$("dialog").open) return;
    refreshMediaReview();
    frame.contentWindow.postMessage(
      {
        type: "drama-media-result",
        action: data.action,
        versionId: version.id,
        status:
          current.versions.find((v) => v.id === version.id)?.status ||
          version.status,
        eligible:
          kind === "asset" &&
          !!ep()?.assetRefs.some(
            (r) => r.assetId === target.id && r.versionId === version.id,
          ),
        message: {
          save: "视频计划已保存",
          generate: "生成任务已加入",
          accepted: "已通过，其余保留为备选",
          delete: "备选已删除",
          download: "已开始下载",
        }[data.action],
        requestId: data.requestId,
      },
      location.origin,
    );
  } catch (error) {
    if (error.code === "revision_conflict") m.revision = S.project.revision;
    if (frame !== $("mediaFrame") || !$("dialog").open) return;
    frame.contentWindow.postMessage(
      {
        type: "drama-media-result",
        error: error.message,
        requestId: data.requestId,
      },
      location.origin,
    );
  }
});
