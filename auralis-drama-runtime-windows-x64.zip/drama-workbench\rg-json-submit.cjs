const http = require("node:http");
const https = require("node:https");
const { Readable } = require("node:stream");

// Native fetch has a separate five-minute response-header deadline. RG video
// submissions must instead use the caller's single deadline, including upload.
// Keep the streaming JSON body and never replay a paid submission on failure.
function submitJson(url, options) {
  return new Promise((resolve, reject) => {
    const transport = new URL(url).protocol === "https:" ? https : http;
    const request = transport.request(url, {
      method: options.method, headers: options.headers,
      signal: options.signal, agent: false,
    }, response => {
      resolve(new Response([204, 205, 304].includes(response.statusCode) ? null : Readable.toWeb(response), {
        status: response.statusCode, statusText: response.statusMessage,
        headers: response.headers,
      }));
    });
    request.once("error", error => { options.body?.destroy?.(); reject(error); });
    if (options.body?.pipe) {
      options.body.once("error", error => request.destroy(error));
      options.body.pipe(request);
    } else request.end(options.body);
  });
}
module.exports = { submitJson };
