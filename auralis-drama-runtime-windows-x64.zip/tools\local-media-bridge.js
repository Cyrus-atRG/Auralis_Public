const http = require("http");
const fs = require("fs");
const os = require("os");
const path = require("path");
const net = require("net");
const { spawn, spawnSync } = require("child_process");

const host = process.env.AURALIS_MEDIA_BRIDGE_HOST || "127.0.0.1";
const port = Number(process.env.AURALIS_MEDIA_BRIDGE_PORT || 17877);
const token = process.env.AURALIS_MEDIA_BRIDGE_TOKEN || "";
const ffmpegPath = process.env.AURALIS_FFMPEG_PATH || process.env.FFMPEG_PATH || findFfmpeg();
const configuredMaxBodyBytes = Number(process.env.AURALIS_MEDIA_BRIDGE_MAX_BODY_BYTES || 1024 * 1024 * 1024);
const maxBodyBytes = Number.isFinite(configuredMaxBodyBytes) && configuredMaxBodyBytes > 0 ? configuredMaxBodyBytes : 1024 * 1024 * 1024;
const frameExtractMaxFrames = Math.round(environmentNumber("AURALIS_FRAME_EXTRACT_MAX_FRAMES", 24, 1, 80));
const frameExtractMaxTimeoutMs = Math.round(environmentNumber("AURALIS_FRAME_EXTRACT_MAX_TIMEOUT_MS", 120_000, 1_000, 10 * 60_000));
const frameExtractMaxOutputBytes = Math.round(environmentNumber(
  "AURALIS_FRAME_EXTRACT_MAX_OUTPUT_BYTES",
  Math.min(128 * 1024 * 1024, maxBodyBytes),
  1,
  maxBodyBytes
));
const activeFrameExtractions = new Map();
const videoFileExtensions = new Set([".avi", ".m4v", ".mkv", ".mov", ".mp4", ".mpeg", ".mpg", ".ts", ".webm"]);
const runtimeRoot = path.resolve(__dirname, "..");
const waveSpeedUploadUrl = process.env.AURALIS_WAVESPEED_UPLOAD_URL || "https://api.wavespeed.ai/api/v3/media/uploads";
const waveSpeedUploadMaxBytes = 200 * 1024 * 1024;
let shuttingDown = false;

function environmentNumber(name, fallback, min, max) {
  const number = Number(process.env[name]);
  return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : fallback;
}

function findFfmpeg() {
  const candidates = [
    path.resolve(__dirname, "bin", "ffmpeg.exe"),
    path.resolve(__dirname, "..", "tools", "bin", "ffmpeg.exe"),
    "C:\\Program Files\\ffmpeg\\bin\\ffmpeg.exe",
    "C:\\Program Files (x86)\\ffmpeg\\bin\\ffmpeg.exe"
  ];

  const localAppData = process.env.LOCALAPPDATA || "";
  const winGetRoot = path.join(localAppData, "Microsoft", "WinGet", "Packages");
  try {
    for (const vendor of fs.readdirSync(winGetRoot)) {
      const vendorRoot = path.join(winGetRoot, vendor);
      for (const child of fs.readdirSync(vendorRoot)) {
        const exe = path.join(vendorRoot, child, "bin", "ffmpeg.exe");
        if (fs.existsSync(exe)) candidates.push(exe);
      }
    }
  } catch (_) {}

  for (const candidate of candidates) {
    if (candidate !== "ffmpeg" && fs.existsSync(candidate)) return candidate;
  }
  return "ffmpeg";
}

function sendJson(res, status, value) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-WaveSpeed-Authorization, X-WaveSpeed-Filename",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  });
  res.end(JSON.stringify(value));
}

function sendBinary(res, status, body, headers = {}) {
  const bytes = Buffer.isBuffer(body) ? body : Buffer.from(body || "");
  res.writeHead(status, {
    "Content-Type": headers.contentType || "application/octet-stream",
    "Content-Length": String(bytes.length),
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization, X-WaveSpeed-Authorization, X-WaveSpeed-Filename",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Expose-Headers": "Content-Type, Content-Length"
  });
  res.end(bytes);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", chunk => {
      size += chunk.length;
      if (size > maxBodyBytes) {
        const error = new Error(`request body too large; received ${size} bytes, limit is ${maxBodyBytes} bytes`);
        error.statusCode = 413;
        error.receivedBytes = size;
        error.limitBytes = maxBodyBytes;
        reject(error);
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function readRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", chunk => {
      size += chunk.length;
      if (size > maxBodyBytes) {
        const error = new Error(`request body too large; received ${size} bytes, limit is ${maxBodyBytes} bytes`);
        error.statusCode = 413;
        error.receivedBytes = size;
        error.limitBytes = maxBodyBytes;
        reject(error);
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function assertToken(req) {
  if (!token) return;
  const header = req.headers.authorization || "";
  if (header === `Bearer ${token}`) return;
  const error = new Error("invalid bridge token");
  error.statusCode = 401;
  throw error;
}

function assertFrameExtractionAccess(req) {
  if (!token) throw httpError(503, "video frame extraction requires AURALIS_MEDIA_BRIDGE_TOKEN");
  assertToken(req);
  assertLocalBrowserOrigin(req);
}

function assertShutdownAccess(req) {
  if (!token) throw httpError(503, "bridge shutdown requires AURALIS_MEDIA_BRIDGE_TOKEN");
  assertToken(req);
  assertLocalBrowserOrigin(req);
}

function assertLocalBrowserOrigin(req) {
  const origin = req.headers.origin || "";
  if (!origin || origin === "null") return;
  let parsed;
  try {
    parsed = new URL(origin);
  } catch (_) {
    const error = new Error("invalid request origin");
    error.statusCode = 403;
    throw error;
  }
  if (["localhost", "127.0.0.1", "::1"].includes(parsed.hostname)) return;
  const error = new Error("local media operations are only available to local Auralis pages");
  error.statusCode = 403;
  throw error;
}

function isBlockedHost(hostname) {
  const host = String(hostname || "").toLowerCase().replace(/^\[|\]$/g, "");
  if (!host || ["localhost", "0.0.0.0", "127.0.0.1", "::1"].includes(host)) return true;
  if (host.endsWith(".local") || host.endsWith(".localhost")) return true;
  if (net.isIP(host) === 4) {
    const [a, b] = host.split(".").map(part => Number(part));
    return a === 10
      || a === 127
      || (a === 169 && b === 254)
      || (a === 172 && b >= 16 && b <= 31)
      || (a === 192 && b === 168);
  }
  return net.isIP(host) === 6;
}

function assertRemoteAssetUrl(value) {
  let parsed;
  try {
    parsed = new URL(String(value || "").trim());
  } catch (_) {
    throw new Error("fetch-asset requires a valid URL");
  }
  if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("fetch-asset only supports http(s) URLs");
  if (isBlockedHost(parsed.hostname)) throw new Error("fetch-asset refuses local or private network URLs");
  return parsed.href;
}

async function responseBufferWithLimit(response) {
  if (!response.body?.getReader) {
    const bytes = Buffer.from(await response.arrayBuffer());
    if (bytes.length > maxBodyBytes) {
      const error = new Error(`remote asset too large; received ${bytes.length} bytes, limit is ${maxBodyBytes} bytes`);
      error.statusCode = 413;
      error.receivedBytes = bytes.length;
      error.limitBytes = maxBodyBytes;
      throw error;
    }
    return bytes;
  }
  const reader = response.body.getReader();
  const chunks = [];
  let size = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = Buffer.from(value);
    size += chunk.length;
    if (size > maxBodyBytes) {
      await reader.cancel().catch(() => {});
      const error = new Error(`remote asset too large; received ${size} bytes, limit is ${maxBodyBytes} bytes`);
      error.statusCode = 413;
      error.receivedBytes = size;
      error.limitBytes = maxBodyBytes;
      throw error;
    }
    chunks.push(chunk);
  }
  return Buffer.concat(chunks, size);
}

function ffmpegVersion() {
  const result = spawnSync(ffmpegPath, ["-version"], { encoding: "utf8", windowsHide: true });
  if (result.error) return { ok: false, error: result.error.message };
  const firstLine = (result.stdout || result.stderr || "").split(/\r?\n/)[0] || "";
  return { ok: result.status === 0, version: firstLine, error: result.status === 0 ? "" : result.stderr };
}

function parseDataUrl(dataUrl) {
  const match = String(dataUrl || "").match(/^data:([^;,]+)?(;base64)?,(.*)$/s);
  if (!match || !match[2]) throw new Error("scene cut requires a base64 data URL video");
  return {
    mime: match[1] || "application/octet-stream",
    bytes: Buffer.from(match[3], "base64")
  };
}

function safeNumber(value, fallback, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.max(min, Math.min(max, number));
}

function extensionFromMime(mime, fileName = "") {
  const lower = String(fileName || "").toLowerCase();
  const known = lower.match(/\.(mp4|webm|mov|m4v|avi|mkv)$/);
  if (known) return known[1];
  if (mime.includes("webm")) return "webm";
  if (mime.includes("quicktime")) return "mov";
  if (mime.includes("x-m4v")) return "m4v";
  return "mp4";
}

function runFfmpeg(args, cwd) {
  return new Promise((resolve, reject) => {
    const child = spawn(ffmpegPath, args, { cwd, windowsHide: true });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", data => { stdout += data.toString(); });
    child.stderr.on("data", data => { stderr += data.toString(); });
    child.on("error", reject);
    child.on("close", code => {
      if (code !== 0) reject(new Error(stderr.trim() || `ffmpeg exited with code ${code}`));
      else resolve({ stdout, stderr });
    });
  });
}

function parseSceneTimes(stderr) {
  return [...String(stderr || "").matchAll(/pts_time:([0-9.]+)/g)].map(match => Number(match[1]));
}

function httpError(statusCode, message, details = {}) {
  const error = new Error(message);
  error.statusCode = statusCode;
  Object.assign(error, details);
  return error;
}

function boundedNumber(value, fallback, min, max, label, integer = false) {
  if (value === undefined || value === null || value === "") return fallback;
  const number = Number(value);
  if (!Number.isFinite(number)) throw httpError(400, `${label} must be a finite number`);
  if (number < min || number > max) throw httpError(400, `${label} must be between ${min} and ${max}`);
  if (integer && !Number.isInteger(number)) throw httpError(400, `${label} must be an integer`);
  return number;
}

function frameExtractionRequestId(value) {
  const generated = value === undefined || value === null || value === "";
  const requestId = String(generated ? `frames-${Date.now()}-${Math.random().toString(36).slice(2, 10)}` : value).trim();
  if (!/^[A-Za-z0-9._:-]{1,128}$/.test(requestId)) {
    throw httpError(400, "requestId must contain only letters, numbers, dot, underscore, colon, or dash");
  }
  return requestId;
}

function frameExtractionMode(value) {
  const mode = String(value || "uniform").trim().toLowerCase();
  if (mode === "timestamps") return "manual";
  if (["uniform", "scene", "manual"].includes(mode)) return mode;
  throw httpError(400, "mode must be uniform, scene, manual, or timestamps");
}

function configuredMediaRoots() {
  const roots = [
    path.resolve(__dirname, ".."),
    process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, "Auralis") : "",
    path.join(os.tmpdir(), "Auralis")
  ];
  const configured = String(process.env.AURALIS_MEDIA_ALLOWED_ROOTS || "")
    .split(path.delimiter)
    .map(value => value.trim())
    .filter(Boolean);
  const canonical = [];
  for (const candidate of [...roots, ...configured]) {
    if (!candidate) continue;
    try {
      const root = fs.realpathSync.native(path.resolve(candidate));
      const key = process.platform === "win32" ? root.toLowerCase() : root;
      if (!canonical.some(entry => entry.key === key)) canonical.push({ key, path: root });
    } catch (_) {}
  }
  return canonical.map(entry => entry.path);
}

function pathIsInsideRoot(filePath, rootPath) {
  const relative = path.relative(rootPath, filePath);
  return relative === "" || (!relative.startsWith(`..${path.sep}`) && relative !== ".." && !path.isAbsolute(relative));
}

function resolveAllowedVideoPath(value) {
  if (!token) throw httpError(503, "local-path frame extraction requires AURALIS_MEDIA_BRIDGE_TOKEN");
  const supplied = String(value || "").trim();
  if (!supplied || !path.isAbsolute(supplied)) throw httpError(400, "source.path must be an absolute local path");
  const windowsPath = supplied.replace(/\//g, "\\");
  if (process.platform === "win32" && (/^\\\\[?.]\\/.test(windowsPath) || /^\\\\/.test(windowsPath))) {
    throw httpError(400, "source.path does not allow device or UNC paths");
  }
  let resolved;
  try {
    resolved = fs.realpathSync.native(supplied);
  } catch (_) {
    throw httpError(404, "source.path does not exist");
  }
  const stat = fs.statSync(resolved);
  if (!stat.isFile()) throw httpError(400, "source.path must reference a regular file");
  if (!videoFileExtensions.has(path.extname(resolved).toLowerCase())) {
    throw httpError(400, "source.path must use a supported video file extension");
  }
  if (stat.size <= 0) throw httpError(400, "source.path video is empty");
  if (stat.size > maxBodyBytes) {
    throw httpError(413, `source.path video exceeds the ${maxBodyBytes}-byte limit`, {
      receivedBytes: stat.size,
      limitBytes: maxBodyBytes
    });
  }
  if (!configuredMediaRoots().some(root => pathIsInsideRoot(resolved, root))) {
    throw httpError(403, "source.path is outside Auralis media roots; add its directory to AURALIS_MEDIA_ALLOWED_ROOTS");
  }
  return resolved;
}

function parseFrameVideoDataUrl(value) {
  const match = String(value || "").match(/^data:([^;,]+);base64,([A-Za-z0-9+/=\r\n]+)$/);
  if (!match) throw httpError(400, "source.dataUrl must be a base64 video data URL");
  const mime = String(match[1] || "").toLowerCase();
  if (!mime.startsWith("video/")) throw httpError(400, `source.dataUrl must be video data, got ${mime || "unknown"}`);
  const bytes = Buffer.from(match[2].replace(/\s+/g, ""), "base64");
  if (!bytes.length) throw httpError(400, "source.dataUrl video is empty");
  if (bytes.length > maxBodyBytes) {
    throw httpError(413, `source.dataUrl video exceeds the ${maxBodyBytes}-byte limit`, {
      receivedBytes: bytes.length,
      limitBytes: maxBodyBytes
    });
  }
  return { mime, bytes };
}

function prepareFrameVideoSource(body, temporaryDirectory) {
  const source = body?.source && typeof body.source === "object" ? body.source : {};
  const pathValue = source.path ?? body?.path;
  const dataUrlValue = source.dataUrl ?? body?.dataUrl;
  if (Boolean(pathValue) === Boolean(dataUrlValue)) {
    throw httpError(400, "provide exactly one video source: source.dataUrl or source.path");
  }
  if (pathValue) {
    const inputPath = resolveAllowedVideoPath(pathValue);
    return {
      inputPath,
      description: { kind: "localPath", fileName: path.basename(inputPath) }
    };
  }
  const { mime, bytes } = parseFrameVideoDataUrl(dataUrlValue);
  const fileName = String(source.fileName ?? body?.fileName ?? "video");
  const extension = extensionFromMime(mime, fileName);
  const inputPath = path.join(temporaryDirectory, `input.${extension}`);
  fs.writeFileSync(inputPath, bytes);
  return {
    inputPath,
    description: { kind: "dataUrl", fileName: path.basename(fileName), mime, size: bytes.length }
  };
}

function frameJobError(job) {
  if (job.timedOut) return httpError(504, "frame extraction timed out", { requestId: job.requestId });
  if (job.cancelled) return httpError(499, "frame extraction cancelled", { requestId: job.requestId });
  return null;
}

function stopFrameJob(job, reason) {
  if (reason === "timeout") job.timedOut = true;
  else job.cancelled = true;
  if (job.child && !job.child.killed) job.child.kill("SIGKILL");
}

function runControlledFfmpeg(args, cwd, job, options = {}) {
  return new Promise((resolve, reject) => {
    const stopped = frameJobError(job);
    if (stopped) return reject(stopped);
    const remainingMs = job.deadline - Date.now();
    if (remainingMs <= 0) {
      stopFrameJob(job, "timeout");
      return reject(frameJobError(job));
    }

    const child = spawn(ffmpegPath, args, { cwd, windowsHide: true });
    job.child = child;
    let stdout = "";
    let stderr = "";
    let settled = false;
    const append = (current, value) => `${current}${value.toString()}`.slice(-4 * 1024 * 1024);
    const timer = setTimeout(() => stopFrameJob(job, "timeout"), remainingMs);
    const finish = (error, result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (job.child === child) job.child = null;
      if (error) reject(error);
      else resolve(result);
    };
    child.stdout.on("data", data => { stdout = append(stdout, data); });
    child.stderr.on("data", data => { stderr = append(stderr, data); });
    child.on("error", error => finish(error));
    child.on("close", code => {
      const stoppedAfterRun = frameJobError(job);
      if (stoppedAfterRun) return finish(stoppedAfterRun);
      if (code !== 0 && !options.allowNonZero) {
        return finish(httpError(422, stderr.trim() || `ffmpeg exited with code ${code}`));
      }
      finish(null, { code, stdout, stderr });
    });
  });
}

function parseVideoDuration(stderr) {
  const match = String(stderr || "").match(/Duration:\s*(\d+):(\d+):([0-9.]+)/);
  if (!match) return null;
  const seconds = Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]);
  return Number.isFinite(seconds) && seconds > 0 ? seconds : null;
}

async function probeFrameVideo(inputPath, temporaryDirectory, job) {
  const result = await runControlledFfmpeg(["-hide_banner", "-i", inputPath], temporaryDirectory, job, { allowNonZero: true });
  if (!/Stream #.*Video:/m.test(result.stderr)) throw httpError(422, "video source has no decodable video stream");
  const duration = parseVideoDuration(result.stderr);
  if (!duration) throw httpError(422, "video source duration could not be determined");
  return duration;
}

function roundedTime(value) {
  return Number(Number(value).toFixed(6));
}

function uniformFrameTimes(duration, count) {
  return Array.from({ length: count }, (_, index) => roundedTime(Math.max(0, Math.min(duration - 0.001, duration * (index + 0.5) / count))));
}

function manualFrameTimes(value, duration, maxFrames) {
  if (!Array.isArray(value) || !value.length) throw httpError(400, "manual mode requires a non-empty timestamps array");
  if (value.length > maxFrames) throw httpError(400, `timestamps cannot contain more than ${maxFrames} entries`);
  return value.map((entry, index) => {
    const time = Number(entry);
    if (!Number.isFinite(time) || time < 0 || time >= duration) {
      throw httpError(400, `timestamps[${index}] must be at least 0 and less than the video duration`);
    }
    return roundedTime(time);
  });
}

function readExtractedFrames(temporaryDirectory, times, width) {
  let totalBytes = 0;
  return times.map((time, index) => {
    const outputPath = path.join(temporaryDirectory, `frame_${String(index + 1).padStart(4, "0")}.jpg`);
    if (!fs.existsSync(outputPath)) throw httpError(422, `ffmpeg did not produce frame ${index + 1}`);
    const bytes = fs.readFileSync(outputPath);
    totalBytes += bytes.length;
    if (totalBytes > frameExtractMaxOutputBytes) {
      throw httpError(413, `extracted frames exceed the ${frameExtractMaxOutputBytes}-byte output limit`, {
        receivedBytes: totalBytes,
        limitBytes: frameExtractMaxOutputBytes
      });
    }
    return {
      index: index + 1,
      timeSeconds: Number.isFinite(time) ? roundedTime(time) : null,
      mime: "image/jpeg",
      width,
      fileName: `frame-${String(index + 1).padStart(3, "0")}.jpg`,
      dataUrl: `data:image/jpeg;base64,${bytes.toString("base64")}`
    };
  });
}

async function extractFramesAtTimes(inputPath, times, options, temporaryDirectory, job) {
  const labels = times.map((_, index) => `[frame_source_${index}]`).join("");
  const filters = times.length === 1 ? [] : [`[0:v:0]split=${times.length}${labels}`];
  times.forEach((time, index) => {
    const input = times.length === 1 ? "[0:v:0]" : `[frame_source_${index}]`;
    filters.push(`${input}trim=start=${time.toFixed(6)},setpts=PTS-STARTPTS,scale=${options.width}:-2[frame_${index}]`);
  });
  const args = ["-hide_banner", "-loglevel", "error", "-y", "-i", inputPath, "-filter_complex", filters.join(";"), "-an"];
  times.forEach((_, index) => {
    args.push(
      "-map", `[frame_${index}]`,
      "-frames:v", "1",
      "-q:v", String(options.quality),
      path.join(temporaryDirectory, `frame_${String(index + 1).padStart(4, "0")}.jpg`)
    );
  });
  await runControlledFfmpeg(args, temporaryDirectory, job);
  return readExtractedFrames(temporaryDirectory, times, options.width);
}

async function extractSceneFrames(inputPath, options, temporaryDirectory, job) {
  const pattern = path.join(temporaryDirectory, "frame_%04d.jpg");
  const filter = `select=eq(n\\,0)+gt(scene\\,${options.threshold}),showinfo,scale=${options.width}:-2`;
  const result = await runControlledFfmpeg([
    "-hide_banner",
    "-loglevel", "info",
    "-y",
    "-i", inputPath,
    "-vf", filter,
    "-fps_mode", "vfr",
    "-frames:v", String(options.maxFrames),
    "-q:v", String(options.quality),
    pattern
  ], temporaryDirectory, job);
  const files = fs.readdirSync(temporaryDirectory).filter(name => /^frame_\d+\.jpg$/i.test(name)).sort();
  const times = parseSceneTimes(result.stderr).slice(0, files.length);
  while (times.length < files.length) times.push(null);
  return readExtractedFrames(temporaryDirectory, times, options.width);
}

async function extractVideoFrames(body, job) {
  const mode = frameExtractionMode(body?.mode);
  const options = {
    maxFrames: boundedNumber(body?.maxFrames, Math.min(12, frameExtractMaxFrames), 1, frameExtractMaxFrames, "maxFrames", true),
    width: boundedNumber(body?.width, 640, 160, 1280, "width", true),
    quality: boundedNumber(body?.quality, 2, 2, 31, "quality", true),
    threshold: boundedNumber(body?.threshold, 0.3, 0.05, 0.95, "threshold")
  };
  const temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), "auralis-video-frames-"));
  try {
    const source = prepareFrameVideoSource(body, temporaryDirectory);
    const durationSeconds = await probeFrameVideo(source.inputPath, temporaryDirectory, job);
    let frames;
    if (mode === "scene") {
      frames = await extractSceneFrames(source.inputPath, options, temporaryDirectory, job);
    } else {
      const times = mode === "manual"
        ? manualFrameTimes(body?.timestamps, durationSeconds, options.maxFrames)
        : uniformFrameTimes(durationSeconds, options.maxFrames);
      frames = await extractFramesAtTimes(source.inputPath, times, options, temporaryDirectory, job);
    }
    return {
      ok: true,
      requestId: job.requestId,
      status: "completed",
      mode,
      source: source.description,
      durationSeconds: roundedTime(durationSeconds),
      options,
      frames
    };
  } finally {
    fs.rmSync(temporaryDirectory, { recursive: true, force: true });
  }
}

async function sceneCuts(body) {
  const threshold = safeNumber(body.threshold, 0.3, 0.05, 0.95);
  const maxFrames = Math.round(safeNumber(body.maxFrames, 24, 1, 80));
  const width = Math.round(safeNumber(body.width, 640, 160, 1280));
  const quality = Math.round(safeNumber(body.quality, 2, 2, 31));
  const { mime, bytes } = parseDataUrl(body.dataUrl);
  if (!mime.startsWith("video/")) throw new Error(`expected video data URL, got ${mime}`);

  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "auralis-scene-cuts-"));
  const input = path.join(tmp, `input.${extensionFromMime(mime, body.fileName)}`);
  const pattern = path.join(tmp, "frame_%04d.jpg");
  fs.writeFileSync(input, bytes);

  try {
    const filter = `select=gt(scene\\,${threshold}),showinfo,scale=${width}:-2`;
    const result = await runFfmpeg([
      "-hide_banner",
      "-y",
      "-i", input,
      "-vf", filter,
      "-vsync", "vfr",
      "-frames:v", String(maxFrames),
      "-q:v", String(quality),
      pattern
    ], tmp);

    const times = parseSceneTimes(result.stderr);
    const files = fs.readdirSync(tmp)
      .filter(name => /^frame_\d+\.jpg$/i.test(name))
      .sort();
    const frames = files.map((name, index) => ({
      index: index + 1,
      time: Number.isFinite(times[index]) ? times[index] : null,
      mime: "image/jpeg",
      fileName: name,
      dataUrl: `data:image/jpeg;base64,${fs.readFileSync(path.join(tmp, name)).toString("base64")}`
    }));

    return { ok: true, threshold, maxFrames, width, ffmpegPath, frames };
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

async function videoClip(body) {
  const { mime, bytes } = parseDataUrl(body.dataUrl);
  if (!mime.startsWith("video/")) throw new Error(`expected video data URL, got ${mime}`);

  const start = safeNumber(body.start, 0, 0, 1_000_000);
  const rawEnd = Number(body.end);
  const hasEnd = Number.isFinite(rawEnd) && rawEnd > start;
  const duration = hasEnd ? Math.max(0.05, rawEnd - start) : null;
  const crf = Math.round(safeNumber(body.crf, 26, 18, 35));

  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "auralis-video-clip-"));
  const input = path.join(tmp, `input.${extensionFromMime(mime, body.fileName)}`);
  const output = path.join(tmp, "output.mp4");
  fs.writeFileSync(input, bytes);

  try {
    const args = ["-hide_banner", "-y"];
    if (start > 0) args.push("-ss", String(start));
    args.push("-i", input);
    if (duration) args.push("-t", String(duration));
    args.push(
      "-map", "0:v:0",
      "-an",
      "-c:v", "libx264",
      "-preset", "veryfast",
      "-crf", String(crf),
      "-pix_fmt", "yuv420p",
      "-movflags", "+faststart",
      output
    );
    await runFfmpeg(args, tmp);
    const outputBytes = fs.readFileSync(output);
    return {
      ok: true,
      mime: "video/mp4",
      size: outputBytes.length,
      start,
      end: hasEnd ? rawEnd : null,
      ffmpegPath,
      dataUrl: `data:video/mp4;base64,${outputBytes.toString("base64")}`
    };
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

async function wavespeedUpload(req) {
  assertLocalBrowserOrigin(req);
  const authorization = req.headers["x-wavespeed-authorization"] || "";
  if (!/^Bearer\s+\S+/i.test(authorization)) throw new Error("WaveSpeed upload requires X-WaveSpeed-Authorization header");
  const encodedFilename = req.headers["x-wavespeed-filename"] || "";
  let filename = "";
  try {
    filename = decodeURIComponent(encodedFilename);
  } catch (_) {
    throw httpError(400, "WaveSpeed upload filename is invalid");
  }
  if (!filename) throw httpError(400, "WaveSpeed upload requires X-WaveSpeed-Filename header");
  const contentType = req.headers["content-type"] || "application/octet-stream";
  const body = await readRawBody(req);
  if (body.length > waveSpeedUploadMaxBytes) throw httpError(413, "WaveSpeed upload exceeds the 200 MiB limit");
  const ticketBody = { filename, size: body.length };
  if (contentType !== "application/octet-stream") ticketBody.content_type = contentType;
  const response = await fetch(waveSpeedUploadUrl, {
    method: "POST",
    headers: {
      Authorization: authorization,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(ticketBody)
  });
  const text = await response.text();
  let json = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch (_) {
    json = { error: { message: text || "non-JSON WaveSpeed response" } };
  }
  if (!response.ok) return { status: response.status, json };
  const upload = json?.data?.upload;
  if (!/^https?:\/\//i.test(String(upload?.url || "")) || !upload?.method) {
    throw new Error("WaveSpeed upload ticket is missing upload URL or method");
  }
  const uploadHeaders = Object.fromEntries(Object.entries(upload.headers || {})
    .filter(([key]) => key.toLowerCase() !== "authorization"));
  const uploadResponse = await fetch(upload.url, {
    method: upload.method,
    headers: uploadHeaders,
    body
  });
  if (!uploadResponse.ok) {
    const detail = await uploadResponse.text();
    return {
      status: uploadResponse.status,
      json: { error: { message: `WaveSpeed storage upload failed: ${detail || `HTTP ${uploadResponse.status}`}` } }
    };
  }
  return { status: response.status, json };
}

async function fetchAsset(req) {
  assertLocalBrowserOrigin(req);
  const body = JSON.parse(await readBody(req) || "{}");
  let url = assertRemoteAssetUrl(body.url);
  for (let redirect = 0; redirect <= 5; redirect += 1) {
    const response = await fetch(url, {
      redirect: "manual",
      headers: {
        Accept: "image/*, video/*, audio/*, application/octet-stream, */*",
        "User-Agent": "AuralisLocalMediaBridge/1.0"
      }
    });
    if ([301, 302, 303, 307, 308].includes(response.status)) {
      const location = response.headers.get("location");
      if (!location) throw new Error(`remote asset redirected without Location: HTTP ${response.status}`);
      url = assertRemoteAssetUrl(new URL(location, url).href);
      continue;
    }
    if (!response.ok) throw new Error(`remote asset download failed: HTTP ${response.status}`);
    return {
      bytes: await responseBufferWithLimit(response),
      contentType: response.headers.get("content-type") || "application/octet-stream"
    };
  }
  throw new Error("remote asset redirected too many times");
}

function closeBridgeAfterShutdown() {
  setImmediate(() => {
    server.close(error => {
      if (error) {
        console.error(`Auralis local media bridge shutdown failed: ${error.message}`);
        process.exitCode = 1;
      }
      setImmediate(() => process.exit(process.exitCode || 0));
    });
    if (typeof server.closeIdleConnections === "function") server.closeIdleConnections();
  });
}

const sharedApi = new (require('./shared-api-settings.cjs').SharedApiSettings)();
const server = http.createServer(async (req, res) => {
  try {
    if (req.method === "OPTIONS") return sendJson(res, 204, {});
    const url = new URL(req.url, `http://${host}:${port}`);
    if (req.method === "POST" && url.pathname === "/v1/shutdown") {
      assertShutdownAccess(req);
      const activeExtractions = activeFrameExtractions.size;
      if (!shuttingDown) {
        shuttingDown = true;
        for (const job of activeFrameExtractions.values()) stopFrameJob(job, "cancel");
        closeBridgeAfterShutdown();
      }
      res.setHeader("Connection", "close");
      return sendJson(res, 202, {
        ok: true,
        bridge: "auralis-local-media",
        status: "shutting_down",
        activeFrameExtractions: activeExtractions,
        runtimeRoot
      });
    }
    if (req.method === "GET" && (url.pathname === "/status" || url.pathname === "/v1/status")) {
      assertToken(req);
      return sendJson(res, 200, {
        ok: true,
        bridge: "auralis-local-media",
        runtimeRoot,
        shuttingDown,
        activeFrameExtractions: activeFrameExtractions.size,
        maxBodyBytes,
        ffmpegPath,
        frameExtraction: {
          available: Boolean(token),
          maxFrames: frameExtractMaxFrames,
          maxTimeoutMs: frameExtractMaxTimeoutMs,
          maxOutputBytes: frameExtractMaxOutputBytes
        },
        ...ffmpegVersion()
      });
    }
    if (shuttingDown) throw httpError(503, "local media bridge is shutting down");
    if (url.pathname === "/v1/shared-api" && ["GET", "POST"].includes(req.method)) {
      if (!token) throw httpError(503, "Shared API settings require an authenticated local bridge");
      assertToken(req);
      if (req.method === "GET") return sendJson(res, 200, sharedApi.snapshot());
      const body = JSON.parse(await readBody(req) || "{}");
      sharedApi.save(body.settings || {}, { missingOnly: !!body.missingOnly, multimediaTokenUpdatedAt: body.multimediaTokenUpdatedAt });
      return sendJson(res, 200, sharedApi.snapshot());
    }
    if (req.method === "POST" && url.pathname === "/v1/wavespeed-upload") {
      if (token) assertToken(req);
      const result = await wavespeedUpload(req);
      return sendJson(res, result.status, result.json);
    }
    if (req.method === "POST" && url.pathname === "/v1/fetch-asset") {
      if (token) assertToken(req);
      const result = await fetchAsset(req);
      return sendBinary(res, 200, result.bytes, { contentType: result.contentType });
    }
    const frameCancelMatch = url.pathname.match(/^\/v1\/video-frames\/([^/]+)\/cancel$/);
    if (req.method === "POST" && frameCancelMatch) {
      assertFrameExtractionAccess(req);
      let decodedRequestId;
      try {
        decodedRequestId = decodeURIComponent(frameCancelMatch[1]);
      } catch (_) {
        throw httpError(400, "cancel requestId must be valid URL text");
      }
      const requestId = frameExtractionRequestId(decodedRequestId);
      const job = activeFrameExtractions.get(requestId);
      if (!job) throw httpError(404, "frame extraction request is not active", { requestId });
      stopFrameJob(job, "cancel");
      return sendJson(res, 202, { ok: true, requestId, status: "cancelling" });
    }
    if (req.method === "POST" && url.pathname === "/v1/video-frames") {
      assertFrameExtractionAccess(req);
      let body;
      try {
        body = JSON.parse(await readBody(req) || "{}");
      } catch (error) {
        if (error.statusCode) throw error;
        throw httpError(400, "request body must be valid JSON");
      }
      if (!body || Array.isArray(body) || typeof body !== "object") {
        throw httpError(400, "request body must be a JSON object");
      }
      const requestId = frameExtractionRequestId(body.requestId);
      if (activeFrameExtractions.has(requestId)) {
        throw httpError(409, "frame extraction requestId is already active", { requestId });
      }
      const timeoutMs = boundedNumber(body.timeoutMs, 60_000, 1, frameExtractMaxTimeoutMs, "timeoutMs", true);
      const job = {
        requestId,
        deadline: Date.now() + timeoutMs,
        child: null,
        cancelled: false,
        timedOut: false
      };
      const abort = () => stopFrameJob(job, "cancel");
      activeFrameExtractions.set(requestId, job);
      req.once("aborted", abort);
      try {
        return sendJson(res, 200, await extractVideoFrames(body, job));
      } finally {
        req.off("aborted", abort);
        activeFrameExtractions.delete(requestId);
      }
    }
    assertToken(req);
    if (req.method === "POST" && url.pathname === "/v1/scene-cuts") {
      const body = JSON.parse(await readBody(req) || "{}");
      return sendJson(res, 200, await sceneCuts(body));
    }
    if (req.method === "POST" && url.pathname === "/v1/video-clip") {
      const body = JSON.parse(await readBody(req) || "{}");
      return sendJson(res, 200, await videoClip(body));
    }
    sendJson(res, 404, { error: { message: "not found" } });
  } catch (error) {
    sendJson(res, error.statusCode || 500, {
      error: {
        message: error.message,
        ...(error.requestId ? { requestId: error.requestId } : {}),
        ...(error.receivedBytes ? { receivedBytes: error.receivedBytes } : {}),
        ...(error.limitBytes ? { limitBytes: error.limitBytes } : {})
      }
    });
  }
});

server.listen(port, host, () => {
  console.log(`Auralis local media bridge: http://${host}:${port}/v1`);
  console.log(`FFmpeg: ${ffmpegPath}`);
});
