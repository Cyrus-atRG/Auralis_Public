const { nodeId } = require('./media-references.js');
function add(target, projectId, ref, source, kind) {
  const graph = target.canvasGraph, id = nodeId(ref), type = ref.role;
  const url = '/media/' + projectId + '/' + source.media.path.split('/').at(-1);
  const prompt = graph.nodes.find(n => n.id === 'prompt');
  if (!prompt) return; // A custom canvas without the plan prompt keeps its own wiring.
  if (!graph.nodes.some(n => n.id === id)) graph.nodes.push({ id, type: type === 'audio' ? 'spokenAudio' : type,
    family: type === 'image' ? 'Sol' : type === 'video' ? 'Luna' : 'Meteor',
    role: type === 'image' ? 'refImage' : type === 'video' ? 'refVideo' : 'spokenAudio',
    title: source.name, mime: source.media.mime, assetUrl: url, displayUrl: url, status: 'completed',
    x: prompt.x - 400, y: prompt.y + graph.links.filter(l => l.toNodeId === 'prompt').length * 180,
    meta: { dramaRef: ref, dramaCanvasMedia: source.media } });
  if (!graph.links.some(l => l.fromNodeId === id && l.toNodeId === 'prompt')) graph.links.push({
    id: 'reference-' + id, fromNodeId: id, toNodeId: 'prompt', relation: 'input',
    inputRole: type === 'video' ? 'reference_video' : type === 'audio' ? 'reference_audio' : 'ref',
    referenceRevision: target.referenceRevision,
  });
  if (kind === 'clip') graph.planRevision = target.planRevision;
  graph.referenceRevision = target.referenceRevision;
}
function preserveAdditions(target, incoming) {
  const graph = structuredClone(incoming), revision = graph.referenceRevision || 0;
  for (const link of target.canvasGraph?.links || []) {
    if (!(link.referenceRevision > revision)) continue;
    for (const id of [link.fromNodeId, link.toNodeId]) {
      const node = target.canvasGraph.nodes.find(n => n.id === id);
      if (node && !graph.nodes.some(n => n.id === id)) graph.nodes.push(structuredClone(node));
    }
    if (!graph.links.some(l => l.fromNodeId === link.fromNodeId && l.toNodeId === link.toNodeId)) graph.links.push(structuredClone(link));
  }
  graph.referenceRevision = target.referenceRevision || 0;
  return graph;
}
module.exports = { add, preserveAdditions };
