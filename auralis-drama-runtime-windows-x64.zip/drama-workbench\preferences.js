const promptDrafts = new Map();
let promptEntries = [], currentPromptId = '';
let controllerDraft = null;
let sharedDraft = null, sharedBaseline = null;
let backupCheckRunning = false;
function renderBackupStatus(status) {
  const notice = document.getElementById('backupNotice');
  notice.hidden = !status.error;
  notice.querySelector('span').textContent = status.error
    ? '备份未完成。' + (status.lastBackupAt ? '上次成功备份：' + new Date(status.lastBackupAt).toLocaleString() : '目前还没有成功备份。') : '';
}
async function checkBackupStatus() {
  if (!S.token || backupCheckRunning) return;
  backupCheckRunning = true;
  try { renderBackupStatus(await api('backup?summary=1')); }
  catch (_) { /* A connection failure does not prove that the backup failed. */ }
  finally { backupCheckRunning = false; }
}
function startBackupChecks() {
  checkBackupStatus();
  setInterval(() => { if (!document.hidden) checkBackupStatus(); }, 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) checkBackupStatus(); });
}
function preferencesNav(active) {
  return '<nav class="preferences-nav" aria-label="设置分类">' + [['controller', '主控模型'], ['generation', '生成参数'], ['shared', '共享 API'], ['prompts', '提示词'], ['backup', '自动备份'], ['trash', '回收站']].map(([id, title]) => '<button type="button" data-preference="' + id + '" aria-current="' + (active === id ? 'page' : 'false') + '">' + title + '</button>').join('') + '</nav>';
}
function renderControllerFields() {
  const form = document.getElementById('controllerPreferences');
  if (!form) return;
  const company = form.elements.mode.value === 'company';
  form.querySelector('[data-controller-company]').hidden = !company;
  form.querySelector('[data-controller-codex]').hidden = company;
}
function retainPromptDraft() {
  const form = document.getElementById('promptPreferences');
  if (!form || !currentPromptId) return;
  const prior = promptDrafts.get(currentPromptId) || {};
  promptDrafts.set(currentPromptId, { custom: form.elements.mode.value === 'custom' ? form.elements.promptText.value : prior.custom, mode: form.elements.mode.value });
}
function showPromptEditor(id) {
  currentPromptId = id;
  const entry = promptEntries.find(p => p.id === id), draft = promptDrafts.get(id) || { custom: entry.custom, mode: entry.mode };
  promptDrafts.set(id, draft);
  const form = document.getElementById('promptPreferences');
  form.elements.promptId.value = id; form.elements.mode.value = draft.mode;
  form.elements.promptText.value = draft.mode === 'official' ? entry.official : draft.custom;
  form.elements.promptText.readOnly = draft.mode === 'official';
  document.getElementById('promptModeHint').textContent = draft.mode === 'official' ? 'official 随工作台更新。切换为自定义后可编辑。' : '自定义内容独立保存，不会被工作台更新覆盖。';
  if (id.startsWith('relay/')) document.getElementById('promptModeHint').textContent += ' 从下一次接力拷打生效。';
  if (id === 'relay/review.md') document.getElementById('promptModeHint').textContent += ' {{stageName}} 自动填入当前环节，{{stageGuidance}} 自动填入该环节的创作规范。';
}
async function openPreferences(section) {
  retainPromptDraft();
  if (section === 'generation') return document.querySelector('[data-action="settings"]').click();
  if (section === 'controller') {
    const c = await api('controller-settings');
    controllerDraft ||= { mode: c.mode, companyModel: c.companyModel, reasoningEffort: c.reasoningEffort };
    openDialog('设置', preferencesNav(section) + '<form id="controllerPreferences"><p class="muted">所有短剧共用，从下一轮任务生效。运行中的任务和追加消息继续使用原来的主控。</p><label>主控模式<select name="mode"><option value="local-codex">本地 Codex</option><option value="company">公司 API</option></select></label><div data-controller-company><label>主控模型<select name="companyModel">' + c.companyModels.map(model => '<option value="' + esc(model) + '">' + esc(model) + '</option>').join('') + '</select></label><p class="muted">' + (c.companyReady ? '使用已配置的公司 API。' : '请先在「共享 API」填写公司 API 地址和 Key。') + ' <button type="button" class="quiet" data-preference="shared">共享 API</button></p></div><div data-controller-codex><label>推理深度<select name="reasoningEffort">' + c.reasoningEfforts.map(effort => '<option value="' + effort + '">' + ({ inherit: '跟随 Codex', low: '低', medium: '中', high: '高', xhigh: '极高' }[effort]) + '</option>').join('') + '</select></label><p class="muted">使用本机 Codex 登录与模型配置。</p></div><div class="actions"><button class="primary">保存主控设置</button></div><p class="preference-result" role="status"></p></form>');
    const form = document.getElementById('controllerPreferences');
    for (const [key, value] of Object.entries(controllerDraft)) form.elements[key].value = value;
    renderControllerFields();
  } else if (section === 'shared') {
    const c = await api('shared-api');
    if (!sharedDraft) sharedBaseline = c;
    openDialog('设置', preferencesNav(section) + '<form id="sharedPreferences"><p class="muted">自由画布与所有短剧共用，素材解析也使用这份配置。密钥留空保留现有值。</p>' + field('baseUrl', '公司 API 地址', sharedDraft?.baseUrl ?? c.baseUrl, 'url', false) + field('apiKey', '公司 API Key · ' + (c.companyKeyReady ? '已配置' : '未配置'), sharedDraft?.apiKey || '', 'password', false) + field('multimediaToken', '多媒体 Token · ' + (c.multimediaReady ? '已配置' : '未配置'), sharedDraft?.multimediaToken || '', 'password', false) + '<p class="muted">RG Seedance / wavesdance 使用。<a href="' + CompanyAigc.LOGIN + '" target="_blank" rel="noopener">打开多媒体平台</a>，登录后点击右上角复制 Token，在这里粘贴并保存。</p><div class="actions"><button type="button" data-check-multimedia>检查已保存 Token</button></div><p id="multimediaTokenStatus" class="muted" role="status"></p>' + field('wavespeedApiKey', 'WaveSpeed API Key · ' + (c.wavespeedReady ? '已配置' : '未配置'), sharedDraft?.wavespeedApiKey || '', 'password', false) + field('elevenLabsApiKey', 'ElevenLabs API Key · ' + (c.elevenLabsReady ? '已配置' : '未配置'), sharedDraft?.elevenLabsApiKey || '', 'password', false) + '<div class="actions"><button class="primary">保存共享配置</button></div><p class="preference-result" role="status"></p></form>', true);
  } else if (section === 'prompts') {
    promptEntries = await api('prompts');
    openDialog('设置', preferencesNav(section) + '<form id="promptPreferences"><p class="muted">所有短剧共用。保存后从下一轮调用生效，已有作品不变。</p><div class="prompt-preferences-controls"><label>位置<select name="promptId">' + promptEntries.map(p => '<option value="' + esc(p.id) + '">' + esc(p.title) + (p.mode === 'custom' ? ' · 自定义' : '') + '</option>').join('') + '</select></label><label>使用版本<select name="mode"><option value="official">official</option><option value="custom">自定义</option></select></label></div><p class="muted" id="promptModeHint"></p><label class="sr-only" for="promptText">提示词正文</label><textarea id="promptText" name="promptText" spellcheck="false"></textarea><div class="actions"><button class="primary">保存更改</button></div><p class="preference-result" role="status"></p></form>', true);
    showPromptEditor(promptEntries.some(p => p.id === currentPromptId) ? currentPromptId : promptEntries[0].id);
  } else if (section === 'trash') {
    const trash = await api('media-trash');
    openDialog('设置', preferencesNav(section) + '<p>保留整个工作台最近删除的 30 条候选，超出后自动清理最早删除的。恢复后回到原来的资产或片段，仍需你选择通过。</p>' +
      (trash.error ? '<p class="error">' + esc(trash.error) + '</p>' : '') +
      '<div class="trash-list">' + (trash.items.length ? trash.items.map((item, index) => {
        const url = '/media/' + item.projectId + '/' + encodeURIComponent(item.media?.path.split(/[\\/]/).at(-1) || '');
        const preview = item.media?.mime.startsWith('image/') ? '<img src="' + url + '" alt="" loading="lazy">'
          : '<span class="muted">' + (item.media?.mime.startsWith('video/') ? '视频' : '音频') + '</span>';
        return '<article class="trash-item">' + preview + '<div><strong>' + esc(item.title) + ' · 版本 ' + item.versionNumber + '</strong><p class="muted">' + esc(item.projectTitle) + (item.episodeTitle ? ' / ' + esc(item.episodeTitle) : '') + '<br>' + esc(new Date(item.deletedAt).toLocaleString()) + ' 删除</p></div><button type="button" data-restore-media="' + index + '" ' + (item.targetDeleted ? 'disabled title="请先恢复所属资产或片段"' : '') + '>恢复</button></article>';
      }).join('') : '<p class="muted">暂无已删除的候选。</p>') + '</div>', true);
    for (const button of document.querySelectorAll('[data-restore-media]')) button.addEventListener('click', async () => {
      button.disabled = true;
      try {
        const item = trash.items[Number(button.dataset.restoreMedia)], project = await api('projects/' + item.projectId);
        await api('projects/' + item.projectId + '/apply', { requestId: crypto.randomUUID(), expectedRevision: project.revision,
          operations: [{ type: 'restoreMediaVersion', targetType: item.targetType, targetId: item.targetId, episodeId: item.episodeId, versionId: item.versionId }] });
        if (S.project?.id === item.projectId) await loadProject(item.projectId);
        await openPreferences('trash');
        toast('已恢复到原来的' + (item.targetType === 'asset' ? '资产' : '片段'));
      } catch (error) { button.disabled = false; toast(error.message); }
    });
  } else if (section === 'backup') {
    const b = await api('backup');
    renderBackupStatus(b);
    openDialog('设置', preferencesNav(section) + '<form id="backupPreferences"><p>项目、图片、视频、声音及自定义提示词一起备份。</p><label class="check"><input type="checkbox" name="enabled" ' + (b.enabled ? 'checked' : '') + '>有改动时每 10 分钟自动备份</label>' + field('directory', '备份文件夹', b.directory) + '<p class="muted">素材增量保存；已有备份保留，可随时恢复。</p><div class="actions"><button class="primary">保存设置</button><button type="button" data-backup-action="write">立即备份</button></div><p class="preference-result" role="status">' + esc(b.error || (b.lastBackupAt ? '最近备份：' + new Date(b.lastBackupAt).toLocaleString() : '尚无备份')) + '</p>' + (b.snapshots.length ? '<label>恢复版本<select name="snapshot">' + b.snapshots.map(s => '<option value="' + esc(s.id) + '">' + esc(new Date(s.createdAt).toLocaleString()) + ' · ' + s.projectCount + ' 部短剧</option>').join('') + '</select></label><button type="button" data-backup-action="restore">恢复此备份</button>' : '') + '</form>', true);
  }
}
document.addEventListener('click', async event => {
  const tab = event.target.closest('[data-preference]'), backup = event.target.closest('[data-backup-action]');
  try {
    if (tab) await openPreferences(tab.dataset.preference);
    if (backup) {
      const form = backup.closest('form'), action = backup.dataset.backupAction;
      if (action === 'restore' && !confirm('恢复会替换当前项目和自定义提示词。恢复前会自动备份当前内容，继续？')) return;
      backup.disabled = true;
      form.querySelector('.preference-result').textContent = action === 'write' ? '正在备份…' : '正在恢复…';
      await api('backup', { action, id: form.elements.snapshot?.value });
      if (action === 'restore') location.reload();
      else await openPreferences('backup');
    }
  } catch (error) {
    toast(error.message, true);
    if (backup) {
      backup.disabled = false;
      backup.closest('form').querySelector('.preference-result').textContent = error.message;
      await checkBackupStatus();
    }
  }
});
document.addEventListener('change', event => {
  const controllerForm = event.target.closest('#controllerPreferences');
  if (controllerForm) {
    controllerDraft = Object.fromEntries(new FormData(controllerForm));
    renderControllerFields();
    return;
  }
  const form = event.target.closest('#promptPreferences'); if (!form) return;
  if (event.target.name === 'promptId') { retainPromptDraft(); showPromptEditor(event.target.value); }
  if (event.target.name === 'mode') {
    const draft = promptDrafts.get(currentPromptId), entry = promptEntries.find(p => p.id === currentPromptId);
    if (event.target.value === 'official') draft.custom = form.elements.promptText.value;
    draft.mode = event.target.value; draft.custom ??= entry.custom;
    showPromptEditor(currentPromptId);
  }
});
document.addEventListener('input', event => {
  if (event.target.id === 'promptText') retainPromptDraft();
  if (event.target.form?.id === 'sharedPreferences') sharedDraft = Object.fromEntries(new FormData(event.target.form));
});
document.addEventListener('submit', async event => {
  const form = event.target;
  if (!['controllerPreferences', 'sharedPreferences', 'promptPreferences', 'backupPreferences'].includes(form.id)) return;
  event.preventDefault();
  const submit = form.querySelector('button[type="submit"], button.primary'), result = form.querySelector('.preference-result');
  submit.disabled = true;
  try {
    if (form.id === 'controllerPreferences') {
      controllerDraft = Object.fromEntries(new FormData(form));
      S.controller = await api('controller-settings', controllerDraft);
      renderControllerChoice();
    } else if (form.id === 'sharedPreferences') {
      const data = Object.fromEntries(new FormData(form));
      if (data.baseUrl === sharedBaseline?.baseUrl) delete data.baseUrl;
      for (const key of ['apiKey', 'wavespeedApiKey', 'elevenLabsApiKey', 'multimediaToken']) if (!data[key]) delete data[key];
      const saved = await api('shared-api', data);
      sharedDraft = null; sharedBaseline = null;
      S.providerReady = saved.wavespeedReady; S.elevenLabsReady = saved.elevenLabsReady; S.companyReady = saved.companyReady;
      await openPreferences('shared');
      document.querySelector('#sharedPreferences .preference-result').textContent = '已保存';
      await multimediaMonitor.check(true);
      return;
    } else if (form.id === 'promptPreferences') {
      retainPromptDraft();
      promptEntries = await api('prompts', { id: currentPromptId, ...promptDrafts.get(currentPromptId) });
    } else await api('backup', { action: 'save', enabled: form.elements.enabled.checked, directory: form.elements.directory.value });
    result.textContent = '已保存';
  } catch (error) { result.textContent = error.message; }
  finally { submit.disabled = false; }
});

const multimediaMonitor = CompanyAigc.watchToken({
  enabled: () => !!S.token,
  canNotify: () => !document.getElementById('dialog').open,
  check: force => api('multimedia-token', { force }),
  openSettings: async () => { await openPreferences('shared'); document.querySelector('[name="multimediaToken"]').focus(); },
  onStatus: (_state, text) => { const status = document.getElementById('multimediaTokenStatus'); if (status) status.textContent = text; }
});
document.addEventListener('click', event => { if (event.target.closest('[data-check-multimedia]')) multimediaMonitor.check(true); });
