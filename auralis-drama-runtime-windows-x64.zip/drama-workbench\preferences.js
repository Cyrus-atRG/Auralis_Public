const promptDrafts = new Map();
let promptEntries = [], currentPromptId = '';
function preferencesNav(active) {
  return '<nav class="preferences-nav" aria-label="设置分类">' + [['generation', '生成参数'], ['shared', '共享 API'], ['prompts', '提示词'], ['backup', '自动备份']].map(([id, title]) => '<button type="button" data-preference="' + id + '" aria-current="' + (active === id ? 'page' : 'false') + '">' + title + '</button>').join('') + '</nav>';
}
function retainPromptDraft() {
  const form = document.getElementById('promptPreferences');
  if (!form || !currentPromptId) return;
  const prior = promptDrafts.get(currentPromptId) || {};
  promptDrafts.set(currentPromptId, { custom: form.elements.mode.value === 'custom' ? form.elements.promptText.value : prior.custom, mode: form.elements.mode.value });
}
function showPromptEditor(id) {
  currentPromptId = id;
  const entry = promptEntries.find(p => p.id === id), draft = promptDrafts.get(id) || { custom: entry.custom, mode: entry.mode };
  promptDrafts.set(id, draft);
  const form = document.getElementById('promptPreferences');
  form.elements.promptId.value = id; form.elements.mode.value = draft.mode;
  form.elements.promptText.value = draft.mode === 'official' ? entry.official : draft.custom;
  form.elements.promptText.readOnly = draft.mode === 'official';
  document.getElementById('promptModeHint').textContent = draft.mode === 'official' ? 'official 随工作台更新。切换为自定义后可编辑。' : '自定义内容独立保存，不会被工作台更新覆盖。';
}
async function openPreferences(section) {
  retainPromptDraft();
  if (section === 'generation') return document.querySelector('[data-action="settings"]').click();
  if (section === 'shared') {
    const c = await api('shared-api');
    openDialog('设置', preferencesNav(section) + '<form id="sharedPreferences"><p class="muted">自由画布与所有短剧共用。密钥留空保留现有值。</p>' + field('baseUrl', 'RG API 地址', c.baseUrl, 'url', false) + field('apiKey', 'RG API Key · ' + (c.companyReady ? '已配置' : '未配置'), '', 'password', false) + field('wavespeedApiKey', 'WaveSpeed API Key · ' + (c.wavespeedReady ? '已配置' : '未配置'), '', 'password', false) + field('elevenLabsApiKey', 'ElevenLabs API Key · ' + (c.elevenLabsReady ? '已配置' : '未配置'), '', 'password', false) + '<div class="actions"><button class="primary">保存共享配置</button></div><p class="preference-result" role="status"></p></form>', true);
  } else if (section === 'prompts') {
    promptEntries = await api('prompts');
    openDialog('设置', preferencesNav(section) + '<form id="promptPreferences"><p class="muted">所有短剧共用。保存后从下一轮调用生效，已有作品不变。</p><div class="prompt-preferences-controls"><label>位置<select name="promptId">' + promptEntries.map(p => '<option value="' + esc(p.id) + '">' + esc(p.title) + (p.mode === 'custom' ? ' · 自定义' : '') + '</option>').join('') + '</select></label><label>使用版本<select name="mode"><option value="official">official</option><option value="custom">自定义</option></select></label></div><p class="muted" id="promptModeHint"></p><label class="sr-only" for="promptText">提示词正文</label><textarea id="promptText" name="promptText" spellcheck="false"></textarea><div class="actions"><button class="primary">保存更改</button></div><p class="preference-result" role="status"></p></form>', true);
    showPromptEditor(promptEntries.some(p => p.id === currentPromptId) ? currentPromptId : promptEntries[0].id);
  } else if (section === 'backup') {
    const b = await api('backup');
    openDialog('设置', preferencesNav(section) + '<form id="backupPreferences"><p>项目、图片、视频、声音及自定义提示词一起备份。</p><label class="check"><input type="checkbox" name="enabled" ' + (b.enabled ? 'checked' : '') + '>有改动时每 10 分钟自动备份</label>' + field('directory', '备份文件夹', b.directory) + '<p class="muted">素材增量保存；已有备份保留，可随时恢复。</p><div class="actions"><button class="primary">保存设置</button><button type="button" data-backup-action="write">立即备份</button></div><p class="preference-result" role="status">' + esc(b.error || (b.lastBackupAt ? '最近备份：' + new Date(b.lastBackupAt).toLocaleString() : '尚无备份')) + '</p>' + (b.snapshots.length ? '<label>恢复版本<select name="snapshot">' + b.snapshots.map(s => '<option value="' + esc(s.id) + '">' + esc(new Date(s.createdAt).toLocaleString()) + ' · ' + s.projectCount + ' 部短剧</option>').join('') + '</select></label><button type="button" data-backup-action="restore">恢复此备份</button>' : '') + '</form>', true);
  }
}
document.addEventListener('click', async event => {
  const tab = event.target.closest('[data-preference]'), backup = event.target.closest('[data-backup-action]');
  try {
    if (tab) await openPreferences(tab.dataset.preference);
    if (backup) {
      const form = backup.closest('form'), action = backup.dataset.backupAction;
      if (action === 'restore' && !confirm('恢复会替换当前项目和自定义提示词。恢复前会自动备份当前内容，继续？')) return;
      backup.disabled = true;
      form.querySelector('.preference-result').textContent = action === 'write' ? '正在备份…' : '正在恢复…';
      await api('backup', { action, id: form.elements.snapshot?.value });
      if (action === 'restore') location.reload();
      else await openPreferences('backup');
    }
  } catch (error) { toast(error.message); if (backup) backup.disabled = false; }
});
document.addEventListener('change', event => {
  const form = event.target.closest('#promptPreferences'); if (!form) return;
  if (event.target.name === 'promptId') { retainPromptDraft(); showPromptEditor(event.target.value); }
  if (event.target.name === 'mode') {
    const draft = promptDrafts.get(currentPromptId), entry = promptEntries.find(p => p.id === currentPromptId);
    if (event.target.value === 'official') draft.custom = form.elements.promptText.value;
    draft.mode = event.target.value; draft.custom ??= entry.custom;
    showPromptEditor(currentPromptId);
  }
});
document.addEventListener('input', event => { if (event.target.id === 'promptText') retainPromptDraft(); });
document.addEventListener('submit', async event => {
  const form = event.target;
  if (!['sharedPreferences', 'promptPreferences', 'backupPreferences'].includes(form.id)) return;
  event.preventDefault();
  const submit = form.querySelector('button[type="submit"], button.primary'), result = form.querySelector('.preference-result');
  submit.disabled = true;
  try {
    if (form.id === 'sharedPreferences') {
      const data = Object.fromEntries(new FormData(form));
      for (const key of ['apiKey', 'wavespeedApiKey', 'elevenLabsApiKey']) if (!data[key]) delete data[key];
      const saved = await api('shared-api', data);
      S.providerReady = saved.wavespeedReady; S.elevenLabsReady = saved.elevenLabsReady; S.companyReady = saved.companyReady;
      await openPreferences('shared');
      document.querySelector('#sharedPreferences .preference-result').textContent = '已保存';
      return;
    } else if (form.id === 'promptPreferences') {
      retainPromptDraft();
      promptEntries = await api('prompts', { id: currentPromptId, ...promptDrafts.get(currentPromptId) });
    } else await api('backup', { action: 'save', enabled: form.elements.enabled.checked, directory: form.elements.directory.value });
    result.textContent = '已保存';
  } catch (error) { result.textContent = error.message; }
  finally { submit.disabled = false; }
});
