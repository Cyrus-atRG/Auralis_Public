const crypto = require("node:crypto");

const stages = ["synopsis", "storyboard", "assets", "video"];
const scopeKey = (episodeId, stage) => episodeId ? episodeId + "/" + stage : "setting";
const digest = (value) => crypto.createHash("sha256").update(JSON.stringify(value)).digest("hex");

function migrateConversations(project) {
  project.agentRuns ||= {};
  project.agentConversations ||= {};
  // Older projects retain only the most recent episode run. Never copy it to other stages.
  for (const episode of project.episodes) {
    const legacy = project.agentRuns[episode.id];
    if (legacy && stages.includes(legacy.stage)) {
      project.agentRuns[scopeKey(episode.id, legacy.stage)] ||= legacy;
      delete project.agentRuns[episode.id];
    }
  }
}

function conversation(project, key) {
  return project.agentConversations[key] ||= { messages: [], seenDocuments: null };
}

function recordReply(project, key, run, snapshot) {
  if (!snapshot?.finalText) return;
  const chat = conversation(project, key);
  const message = { id: "reply-" + run.turnId, turnId: run.turnId, role: "agent", text: snapshot.finalText, final: !!snapshot.terminal, partial: !snapshot.terminal };
  const existing = chat.messages.find(m => m.id === message.id);
  if (existing) Object.assign(existing, message);
  else chat.messages.push(message);
}

// Keep a baseline of relevant persisted inputs, not other agents' conversations.
function documentSnapshot(project, scope) {
  const episode = project.episodes.find(e => e.id === scope.episodeId);
  const result = {};
  const add = (key, title, text, state = "", version = null) => {
    result[key] = { title, text: String(text || ""), state, version };
  };
  add("premise", "故事起点", project.premise);
  for (const setting of project.settings) {
    const pin = episode?.settingPins.find(p => p.settingId === setting.id);
    if (setting.deletedAt && !pin) continue;
    if (episode && !pin) continue;
    const current = setting.versions.at(-1);
    const status = setting.deletedAt ? "已从共享设定移除；本集固定版仍保留" : current?.id === setting.acceptedVersionId ? "已采用" : "待审核";
    add("setting/" + setting.id, setting.title, current?.text, status + (pin && pin.versionId !== current?.id ? "；本集仍固定原版本，尚未替换" : ""), current?.id);
    if (current?.character) add("character/" + setting.id, setting.title + "·人物与音色", JSON.stringify(current.character), status);
    if (pin) {
      const pinned = setting.versions.find(v => v.id === pin.versionId);
      add("pin/" + setting.id, setting.title + "（本集固定版）", pinned?.text, "本集工作依据", pin.versionId);
    }
  }
  if (!episode) return result;
  if (scope.stage === "synopsis") for (const number of [episode.number - 2, episode.number - 1].filter(n => n > 0)) {
    const previous = project.episodes.find(e => e.number === number);
    const adopted = previous?.synopsis.versions.find(v => v.id === previous.synopsis.acceptedVersionId);
    add("previous-synopsis/" + number, "第 " + number + " 集已采用梗概", adopted?.text,
      adopted ? "仅作本集剧情承接" : previous ? "尚无已采用梗概" : "该集尚未创建", adopted?.id);
  }
  const names = scope.stage === "synopsis" ? ["synopsis"] : scope.stage === "storyboard" ? ["synopsis", "storyboard"] : ["storyboard"];
  for (const name of names) {
    const doc = episode[name], own = scope.stage === name;
    const current = doc.versions.at(-1), approved = doc.versions.find(v => v.id === doc.acceptedVersionId);
    const title = "第 " + episode.number + " 集" + (name === "synopsis" ? "梗概" : "文字分镜");
    add(name, title, current?.text, current?.id === doc.acceptedVersionId ? "已采用" : "待审核", current?.id);
    if (!own) add(name + "/accepted", title + "（采用版）", approved?.text, "后续工作依据", approved?.id);
  }
  if (["assets", "video"].includes(scope.stage)) {
    for (const ref of episode.assetRefs) {
      const asset = project.assets.find(a => a.id === ref.assetId);
      if (!asset) continue;
      add("asset/" + asset.id, "资产·" + asset.name, JSON.stringify({ description: asset.description, voice: asset.voice, pinnedVersionId: ref.versionId, approvedVersionId: asset.acceptedVersionId }), "本集资产引用");
      if (scope.stage === "assets") add("asset-plan/" + asset.id, asset.name + "·制作计划", "# 提示词\n" + asset.prompt + "\n# 参考与参数\n" + JSON.stringify({ refs: asset.refs || [], generation: asset.generation }), "已落盘计划", asset.promptRevision);
    }
    const kind = scope.stage === "video" ? "video" : "image";
    add("generation", "生成设置", JSON.stringify(project.generation[kind]), "项目默认值；已有卡片参数保留");
  }
  if (scope.stage === "video") {
    for (const clip of episode.clips) {
      if (clip.deletedAt) continue;
      const { prompt, ...parameters } = clip.plan;
      add("clip/" + clip.id, clip.title + "·视频计划", "# 提示词\n" + prompt + "\n# 参考与参数\n" + JSON.stringify(parameters), "已落盘计划", clip.planRevision);
    }
  }
  return result;
}

function changedLocation(before, after) {
  const a = before.split(/\r?\n/), b = after.split(/\r?\n/);
  let start = 0;
  while (start < a.length && start < b.length && a[start] === b[start]) start++;
  let end = b.length - 1, oldEnd = a.length - 1;
  while (end >= start && oldEnd >= start && b[end] === a[oldEnd]) { end--; oldEnd--; }
  const heading = b.slice(0, start + 1).findLast(line => /^#{1,6}\s/.test(line));
  const location = (heading ? heading.replace(/^#+\s*/, "") + "，" : "") + "第 " + (start + 1) + (end > start ? "–" + (end + 1) : "") + " 行";
  const excerpt = b.slice(start, end + 1).join("\n");
  return location + (excerpt ? "：" + excerpt.slice(0, 240) + (excerpt.length > 240 ? "…" : "") : "：内容已删除");
}

function changeNotice(previous, current) {
  // First contact still needs to identify upstream versions newer than this episode's pins.
  if (!previous) {
    previous = structuredClone(current);
    for (const [key, doc] of Object.entries(current)) {
      if (!key.startsWith("setting/")) continue;
      const pin = current["pin/" + key.slice(8)];
      if (pin && pin.version !== doc.version) previous[key] = { ...doc, text: pin.text, version: pin.version };
    }
  }
  const changes = [];
  for (const key of new Set([...Object.keys(previous), ...Object.keys(current)])) {
    const before = previous[key], after = current[key];
    if (digest(before ?? null) === digest(after ?? null)) continue;
    const title = after?.title || before.title;
    let detail = !before ? "新增" : !after ? "已移除" : before.text !== after.text ? changedLocation(before.text, after.text) : before.title !== after.title ? "名称有修改（原名：" + before.title + "）" : "采用状态或引用版本有修改";
    changes.push("《" + title + "》" + detail + (after?.state ? "（" + after.state + "）" : ""));
  }
  return changes.length ? "文档变更（自动生成）\n" + changes.join("\n") + "\n以当前工作台落盘内容和本集固定版本为准；待审核改动不自动替换已采用依据。" : "";
}

module.exports = { stages, scopeKey, migrateConversations, conversation, recordReply, documentSnapshot, changeNotice };
