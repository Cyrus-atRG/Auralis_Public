const fs = require("node:fs"), path = require("node:path"), crypto = require("node:crypto");
const { execFile } = require("node:child_process"), { promisify } = require("node:util");
const { mediaFile, cachedImage, ffmpeg } = require("./asset-images.cjs");
const exec = promisify(execFile), pending = new Map(), cache = new Map();
let active = 0;
const waiting = [];
async function slot(run) {
  if (active >= 2) await new Promise(resolve => waiting.push(resolve));
  else active++;
  try { return await run(); } finally { const next = waiting.shift(); if (next) next(); else active--; }
}
async function imagePreview(projectDir, media, kind = "agent") {
  if (!/^image\/(png|jpeg|webp)$/.test(media?.mime)) return media;
  const source = mediaFile(projectDir, media), stat = await fs.promises.stat(source, { bigint: true });
  const key = crypto.createHash("sha256").update([source, stat.dev, stat.ino, stat.size, stat.mtimeNs, stat.ctimeNs, kind, "v1"].join(":")).digest("hex");
  if (cache.has(key) && fs.existsSync(mediaFile(projectDir, cache.get(key)))) return cache.get(key);
  if (pending.has(key)) return pending.get(key);
  const promise = slot(async () => {
    const { stdout } = await exec(process.env.AURALIS_FFPROBE_PATH || process.env.FFPROBE_PATH || "ffprobe",
      ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,pix_fmt", "-of", "json", source],
      { encoding: "utf8", windowsHide: true, timeout: 20000, maxBuffer: 65536 });
    const { width, height, pix_fmt: pixelFormat } = JSON.parse(stdout).streams?.[0] || {};
    if (!(width > 0 && height > 0)) throw new Error("无法读取图片分辨率");
    const box = kind === "thumb" ? [640, 640] : width > height ? [1920, 1080] : width < height ? [1080, 1920] : [1080, 1080];
    if (width <= box[0] && height <= box[1]) return { ...media, width, height };
    const scale = Math.min(box[0] / width, box[1] / height), w = Math.max(1, Math.floor(width * scale)), h = Math.max(1, Math.floor(height * scale));
    const alpha = /^(rgba|bgra|argb|abgr|ya\d|gbrap|yuva|pal8)/.test(pixelFormat || "");
    const preview = { path: `media/${kind}-preview-${key}.${alpha ? "png" : "jpg"}`, mime: alpha ? "image/png" : "image/jpeg", width: w, height: h };
    await cachedImage(mediaFile(projectDir, preview), output => ffmpeg(["-threads", "1", "-i", source,
      "-vf", `scale=${w}:${h},setsar=1`, "-frames:v", "1", ...(alpha ? [] : ["-q:v", kind === "thumb" ? "4" : "2"]), "-threads", "1", output]));
    return preview;
  }).catch(() => media).then(value => {
    cache.set(key, value);
    if (cache.size > 512) cache.delete(cache.keys().next().value);
    return value;
  }).finally(() => pending.delete(key));
  pending.set(key, promise);
  return promise;
}
module.exports = { imagePreview };
