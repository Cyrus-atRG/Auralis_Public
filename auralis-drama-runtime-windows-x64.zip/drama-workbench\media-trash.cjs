const fs = require("node:fs");
const path = require("node:path");
const limit = 30;
const indexes = new WeakMap();
const stamp = file => { const s = fs.statSync(file, { bigint: true }); return [s.ino, s.size, s.mtimeNs, s.ctimeNs].join(":"); };
function entries(project) {
  return [
    ...project.assets.map(target => ({ targetType: "asset", target, episodeId: null })),
    ...project.episodes.flatMap(episode => episode.clips.map(target => ({ targetType: "clip", target, episodeId: episode.id, episodeTitle: episode.title || "第 " + episode.number + " 集" }))),
  ].flatMap(({ target, ...scope }) => target.versions.filter(v => v.deletedAt).map(version => ({
    ...scope, projectId: project.id, projectTitle: project.title,
    targetId: target.id, title: target.name || target.title, targetDeleted: !!target.deletedAt,
    versionId: version.id, versionNumber: target.versions.indexOf(version) + 1,
    deletedAt: version.deletedAt, deletedOrder: version.deletedOrder || 0,
    purgedAt: version.purgedAt, media: version.media,
  })));
}
function mediaStillUsed(project, removed) {
  const containsRef = value => {
    if (!value || typeof value !== "object") return false;
    if (value.versionId === removed.versionId || value.path === removed.media.path) return true;
    return Object.values(value).some(containsRef);
  };
  const docs = [...project.assets, ...project.episodes.flatMap(e => e.clips)];
  return docs.some(doc => doc.versions.some(v => v.id !== removed.versionId && !v.purgedAt && v.media?.path === removed.media.path)
    || containsRef(doc.refs) || containsRef(doc.plan?.refs) || containsRef(doc.canvasGraph)
    || doc.versions.some(v => !v.purgedAt && (containsRef(v.snapshot?.refs) || containsRef(v.snapshot?.canvasInputs))))
    || containsRef(project.episodes.map(e => e.assetRefs))
    || containsRef(project.jobs.map(j => [j.snapshot?.refs, j.snapshot?.canvasInputs]))
    || project.references.some(r => r.media?.path === removed.media.path || containsRef(r.source));
}
function pruneMediaTrash(store) {
  let index = indexes.get(store);
  if (!index) { index = new Map(); indexes.set(store, index); }
  const ids = new Set(store.projectIds()), loaded = new Map();
  const read = id => { if (!loaded.has(id)) loaded.set(id, store.read(id)); return loaded.get(id); };
  for (const id of index.keys()) if (!ids.has(id)) index.delete(id);
  for (const id of ids) {
    const current = stamp(store.file(id));
    if (index.get(id)?.stamp !== current) index.set(id, { stamp: current, entries: entries(read(id)) });
  }
  const deleted = [...index.values()].flatMap(item => item.entries).filter(v => !v.purgedAt)
    .sort((a, b) => b.deletedAt.localeCompare(a.deletedAt) || b.deletedOrder - a.deletedOrder || b.versionId.localeCompare(a.versionId));
  const overflow = new Set(deleted.slice(limit).map(v => v.versionId));
  store.trashError = "";
  for (const id of ids) {
    if (index.get(id).entries.some(v => overflow.has(v.versionId))) {
      const project = store.internal(id, value => {
        for (const target of [...value.assets, ...value.episodes.flatMap(e => e.clips)])
          for (const v of target.versions) if (overflow.has(v.id)) v.purgedAt = new Date().toISOString();
      }, { contentChanged: false });
      loaded.set(id, project);
      index.set(id, { stamp: stamp(store.file(id)), entries: entries(project) });
    }
    // Keep bytes still used by another version or by historical generation inputs.
    // The expired trash entry itself can no longer be restored.
    for (const removed of index.get(id).entries.filter(v => v.purgedAt && v.media)) {
      const mediaRoot = path.resolve(path.dirname(store.file(id)), "media");
      const file = path.resolve(path.dirname(store.file(id)), removed.media.path);
      if (path.dirname(file) !== mediaRoot) continue;
      if (!fs.existsSync(file) || mediaStillUsed(read(id), removed)) continue;
      try { fs.rmSync(file, { force: true }); }
      catch { store.trashError = "部分过期文件暂时无法清理；下次删除候选或打开回收站时会重试。"; }
    }
  }
  return { limit, items: deleted.slice(0, limit), error: store.trashError };
}
module.exports = { pruneMediaTrash };
