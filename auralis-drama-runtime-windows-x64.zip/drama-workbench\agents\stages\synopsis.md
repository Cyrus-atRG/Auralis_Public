# 工作流程｜梗概

读取本集要求及相关的固定设定。新写或调整剧情时按已提供的 `guides/episode-writing.md`。

本集固定的通用设定和对应集素材已在 context.settings 全文提供；settingIndex 仅是目录，未提供的额外条目才按 id inspect。context.previousSynopses 是第 x−2、x−1 集已采用梗概，仅用于承接剧情，不修改这些前集正文；缺失时按明确状态处理。“第 X 集素材”等单集准备条目只作对应集的剧情输入，不当作全剧通用规则；“待分集素材”不自动塞入当前集。

写本集梗概供用户判断剧情。首次写作或用户要求整体重写时，使用 `setSynopsis {episodeId,text}` 保存待审版本。没有额外的钩子表、转折表或逐项分析交付要求。审核通过后再做文字分镜。

局部修改优先使用 `patchDocument {targetType:"synopsis",episodeId,baseVersionId,edits:[{oldText,newText}]}`，只提交需要替换的片段，不重新输出全文。baseVersionId 用 context.episode.synopsis.currentVersionId 或上次保存回执的 id。每处 oldText 须与同一当前稿中的原文完全一致且只出现一次；有重复时带上相邻文字定位，各处不能重叠。newText 为空字符串可删除片段；插入内容时用相邻原文作锚点，在 newText 中保留锚点并加入新文。成功后得到新版本 id，仍待用户采用；冲突时按错误核对当前稿或定位，不能回退为整篇覆盖。
