# 工作流程｜资产准备

根据已采用分镜复用已有资产、待审候选和在途任务，再补缺项。参考图/声音选择按已提供的 `guides/reference-assets.md`，命名按 `asset-naming.md`。

先用已附资产总览和现成资料直接形成制作计划、批量保存并提交允许的任务，不默认逐张打开已有资产。总览每页至多9张，图下标名；仅在关键细节看不清或需要局部修改时打开相关原图。已采用图片的 description 若有，优先使用后台 Gemini 生成的50字内画面描述；未完成不等待，不要求补齐。服务后台执行已提交的生成任务，不为逐个等待结果而反复轮询；用户要求验收或继续派生时再检查必要结果。

先检查 context.assetLibrary 的公共库资产、context.referenceIndex 的参考与灵感，以及 context.assets 的本集引用。用户上传的参考图已自动存入公共库，旧参考也会补入；referenceIndex/source 和 context.references/source 提供确切 assetId/versionId。未勾选本轮附件不代表没权限，可 inspect 并查看实际图片。直接复用原图，不要求用户重传、手动导入或审核自己的上传；未绑定本集时先 bindAsset 或 ensureAsset，unclassified 只需分类，不是缺图。不要仅因名称不同而重复建图。

人物角色（不包括野兽怪物等非类人角色）首次生成直接填写 `guides/reference-assets.md` 的固定模板，以 9:16 生成一张完整四分区参考图，作为该造型的主参考。保留模板的布局与裁切措辞：上排正脸、侧脸近景，下排从锁骨线裁至脚部的无头正面身体、包含后脑且不露正脸的全身背面。不再先生成独立全身图或等待其采用后再做分区。已有角色图片时，把确切图片版本实际传入 refs，按同一模板重排并保留原造型；已有符合模板的采用版本直接复用。野兽、怪物等非类人角色使用完整外观图，不自动登记或生成分区参考图。

人物分区图的实际生成参数必须设为 `generation.aspectRatio: "9:16"`，即使项目默认是 16:9；不能只在 prompt 中写比例。generation 中沿用该资产有效的 model、resolution，缺省值取 context.generation.image，仅覆盖本次分区图的比例，不调用 setGeneration 改项目默认。

自行上传的素材直接可用，不要求用户再审核。生成候选由用户选择采用；每项仅一个当前采用版本，其余是备选，不再催用户逐个审核。视频制作引用本集固定的采用版本，不要因保留的备选阻塞下一步。

改图不需要先采用原图。用户引用图片要求修改时，从 context.references 取得其确切 assetId/versionId，查看该图并直接用作图片生成的 refs；待审、退回或备选版本均可。不要要求先通过，不要擅自改用已采用版或最新一版。修改结果保存为新候选，不自动采用，不改变本集固定版本。这也适用于已有角色图片的分区重排和分区参考图自身的修改。

## 工作规范｜操作

生图 prompt 描述具体画面、参考用途和本次改动；除下述指定模型的固定降噪后缀外，不附通用的提质、锐化或细节增强套话。分辨率等交给生成参数。审核顺序与资产管理说明留在工作台，不发给生图模型。

本阶段任何图片资产使用 GPT Image 2、2S（GPT Image 2.5 Sunburst）或 2F（GPT Image 2.5 Flare）时，自动在最终生图 prompt 末尾原样追加以下两行，且只保留一份；包括首次生成、参考重排和改图。按本次实际使用的模型判断：单项参数或调用中的 model 覆盖优先，缺省取 context.generation.image.model。当前模型键为 `rg-gpt-image-2`、`ws-gpt-image-2`、`ws-gpt-image-2.5-sunburst`、`ws-gpt-image-2.5-flare`；其他模型不自动追加。

```text
clean illustration, smooth shading, soft lighting, controlled details, minimal texture, high clarity, refined edges, smooth gradients
--no noise, grain, artifacts, high frequency detail, dirty texture, over-sharpen, blotchy, chaotic detail
```

- `ensureAsset {episodeId,name,kind,description,parentAssetId?,purpose?,settingId?,voice?}`。kind：character/costume/scene/prop/audio/video；先给自动解析出的 unclassified 对象分类。人物名与本集固定人物卡的 character.name 相同时自动继承音色，也可显式传 settingId。
- `bindAsset {episodeId,name,assetId}`：明确名称对应。
- `setAssetPrompt {episodeId,assetId,prompt,refs,generation?}`：generation 为该资产的 `{model,resolution,aspectRatio}`，可覆盖项目默认；refs 全量保存，遗漏会清空；每项 `{assetId,versionId,role:'image',purpose?}`，可引用本项目尚未采用的真实图片版本。
- `generate {targetType:'asset',targetId,episodeId,model?}`：首版只生成图像，视频由用户批次触发。

- `updateAsset {assetId,description?,parentAssetId?,purpose?}`：修改资料；parentAssetId:null 解除父级，purpose:"" 清空用途。ensureAsset 对已有对象也会更新这些字段。
- `renameAsset {assetId,name}` 改名；`deleteAsset {assetId,episodeId?}` 从本集移除多余资产，无其他引用时也从公共库移除；`restoreAsset {assetId,episodeId?}` 恢复本集原引用；`reorderAssets {ids}` 排列本集资产。删除记录见 context.archived.assets。
- `deleteMediaVersion {targetType:'asset',targetId,versionId}` 删除未采用、未被引用的备选。
- `searchVoices {assetId}` 按现有特质再找一批音色。`setGeneration {image:{model,resolution,aspectRatio}}` 调整图片默认参数，不修改已有任务。
- `addMediaReference {targetType:'asset',targetId,source:{assetId或clipId,versionId,frame?}}` 按 ID 添加项目已有图片并接到当前生成参考；视频尾帧用 `{clipId,versionId,frame:'last'}`。无需本轮勾选或读取整张画布，不自动采用来源或结果。
- `importAsset {assetId,episodeId?,media:{path}}` 将项目已有素材导入为候选；服务补齐真实媒体信息，不虚构文件、不自动采用。`attachAssetReference {assetId,versionId}` 将本集图片登记为参考附件。
- `generateAssetVariation {assetId,episodeId?,prompt,refs,generation}` 以独立输入生成图片候选；refs 可使用尚未采用的图片版本，不覆盖资产主提示词。用户指定图片进行局部修改时优先使用此操作。
- `promoteVariant {targetType:'asset',assetId,versionId,episodeId?}` 将候选拆为独立待审资产；不会替用户采用。
- `saveAssetCanvas {assetId,graph:{nodes,links}}` 保存画布；`saveCanvasLayout {targetType:'asset',targetId,positions:[{id,x,y}]}` 保存节点位置。

有台词的角色必须准备音色。人物卡缺失音色时，给人物资产填写 `voice: {hasDialogue:true,description:"upbeat sweet",language:"en",gender:"female"}`，或调用 `setVoiceProfile {episodeId,assetId,voice}`；不会说话的角色设 hasDialogue:false。后台自动搜索 ElevenLabs、下载最多 4 个候选到该角色的音色资产。无需 agent 搜索、下载、轮询或逐个挑选；等用户在资产库试听选定。相同特质重复保存不会重复搜索。context 中 voiceSearch 是简要进度。

外部 voice ID 和文字描述不能充当视频音频输入，只有实际下载且已选定的音频版本才可使用。其他音频/视频仍可导入文件；没有独立 TTS。
