#!/usr/bin/env node
const fs = require("node:fs");
async function main(argv) {
  const verb = argv.shift(),
    args = {};
  while (argv.length) {
    const key = argv.shift();
    if (!key.startsWith("--") || !argv.length)
      throw new Error(
        "参数格式：--session ID --capability TOKEN [--json-file file | --json -]",
      );
    args[key.slice(2)] = argv.shift();
  }
  if (!["context", "inspect", "apply", "job", "history", "view_image"].includes(verb))
    throw new Error("命令：context | inspect | apply | job | history | view_image");
  let input = {};
  if (args["json-file"])
    input = JSON.parse(
      fs.readFileSync(args["json-file"], "utf8").replace(/^\uFEFF/, ""),
    );
  else if (args.json) {
    let source = args.json;
    if (source === "-") {
      const chunks = [];
      for await (const part of process.stdin) chunks.push(part);
      source = Buffer.concat(chunks).toString("utf8");
    }
    input = JSON.parse(source);
  }
  const base =
    args.server || process.env.AURALIS_DRAMA_URL || "http://127.0.0.1:17887";
  if (!/^http:\/\/(127\.0\.0\.1|localhost):\d+$/.test(base))
    throw new Error("仅支持本地工作台 URL");
  const response = await fetch(base + "/api/controller/" + verb, {
    method: "POST",
    headers: {
      Authorization: "Bearer " + args.capability,
      "X-Drama-Session": args.session,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(verb === "view_image" ? { ...input, localPath: true } : input),
  });
  const result = await response.json();
  process.stdout.write(JSON.stringify(result, null, 2) + "\n");
  if (!response.ok) process.exitCode = 1;
}
if (require.main === module)
  main(process.argv.slice(2)).catch((e) => {
    process.stderr.write(e.message + "\n");
    process.exitCode = 1;
  });
module.exports = { main };
