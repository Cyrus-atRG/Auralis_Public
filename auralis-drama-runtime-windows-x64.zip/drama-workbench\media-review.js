// Workbench data adapter for Auralis's existing media viewer. No second lightbox.
S.mediaDrafts = new Map();
let mediaViewerReady;
function stashMediaDrafts() {
  const api = $("mediaFrame")?.contentWindow?.AuralisCanvas;
  if (!S.modal?.mediaViewer || !api) return;
  const graph = api.snapshot();
  for (const node of graph.nodes.filter((n) =>
    n.id.startsWith("review-prompt-"),
  )) {
    const refs = graph.links
      .filter((l) => l.toNodeId === node.id)
      .map(
        (l) => graph.nodes.find((n) => n.id === l.fromNodeId)?.meta?.dramaRef,
      )
      .filter(Boolean);
    S.mediaDrafts.set(
      node.id.slice("review-prompt-".length),
      structuredClone({
        prompt: node.content,
        generation: node.generation,
        speakingAssetIds: node.meta?.dramaSpeakingAssetIds,
        refs,
        base: node.meta?.dramaDraftBase,
        ...(graph.nodes.find(n => n.id === node.id.slice("review-prompt-".length))?.meta?.dramaCanvasVideo ? {
          canvasInputs: graph.links.filter(l => l.toNodeId === node.id).flatMap(l => {
            const input = graph.nodes.find(n => n.id === l.fromNodeId);
            return input?.meta?.dramaCanvasMedia ? [{ nodeId: input.id, name: input.title, media: input.meta.dramaCanvasMedia, inputRole: l.inputRole }] : [];
          }),
        } : {}),
      }),
    );
  }
}
function reviewGeneration(kind, saved = {}) {
  const defaults = S.project.generation[kind];
  const model = S.models[saved.model]
    ? saved.model
    : Object.keys(S.models).find(
        (key) =>
          S.models[key].kind === kind &&
          Object.values(S.models[key]).includes(saved.model),
      );
  const value = { ...defaults, ...saved, model: model || defaults.model };
  return {
    model: value.model,
    mediaSettings:
      kind === "image"
        ? {
            imageResolution: value.resolution,
            imageAspectRatio: value.aspectRatio,
          }
        : {
            videoResolution: value.resolution,
            videoAspectRatio: value.aspectRatio,
            segmentDurationSeconds: value.duration,
          },
  };
}
function rebaseMediaDraft(draft, base) {
  if (!draft) return base;
  // Merge server changes against what the user originally saw, retaining their edits/removals.
  const previous = draft.base || base;
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const key = ref => DramaReferences.nodeId(ref);
  const oldRefs = new Map(previous.refs.map(ref => [key(ref), ref]));
  const currentRefs = new Map(base.refs.map(ref => [key(ref), ref]));
  const localRefs = new Map(draft.refs.map(ref => [key(ref), ref]));
  const refs = draft.refs.flatMap(ref => {
    const id = key(ref);
    if (!oldRefs.has(id) || !same(ref, oldRefs.get(id))) return [ref];
    return currentRefs.has(id) ? [currentRefs.get(id)] : [];
  });
  for (const ref of base.refs)
    if (!oldRefs.has(key(ref)) && !localRefs.has(key(ref))) refs.push(ref);
  const next = { ...draft, refs, base };
  for (const field of ['prompt', 'speakingAssetIds'])
    if (same(draft[field], previous[field])) next[field] = base[field];
  next.generation = {
    model: draft.generation.model === previous.generation.model ? base.generation.model : draft.generation.model,
    mediaSettings: { ...draft.generation.mediaSettings },
  };
  for (const [name, value] of Object.entries(base.generation.mediaSettings))
    if (same(draft.generation.mediaSettings[name], previous.generation.mediaSettings[name])) next.generation.mediaSettings[name] = value;
  return next;
}
function mediaReviewGraph(kind = S.stage === "video" ? "clip" : "asset") {
  const episode = ep(),
    nodes = [],
    links = [],
    batchIds = [];
  const exactRefs = new Map();
  const targets =
    kind === "clip"
      ? episode.clips
          .filter((c) => !S.modal?.mediaViewer || c.id === S.modal.id)
          .map((target) => ({ kind: "clip", target }))
      : S.project.assets
          .filter(
            (a) =>
              (!S.modal?.mediaViewer || a.id === S.modal.id) &&
              (!episode ||
                S.stage === "library" ||
                episode.assetRefs.some((r) => r.assetId === a.id)),
          )
          .map((target) => ({ kind: "asset", target }));
  // All candidate bytes can be viewed or cited. Generation inputs still use adopted episode pins.
  const addMedia = (asset, version, kind, index, versionIndex) => {
    if (!version.media || version.deletedAt) return;
    const mime = version.media.mime,
      type = mime.split("/")[0];
    const ref =
      kind === "asset"
        ? {
            assetId: asset.id,
            versionId: version.id,
            role: type,
            purpose: asset.purpose || asset.kind,
          }
        : null;
    const eligible = !!ref && !version.deletedAt && ((!episode && type === "image") || (
      !!episode?.assetRefs.some(
        (r) => r.assetId === asset.id && r.versionId === version.id,
      ) &&
      !!(
        version.status === "accepted" ||
        version.approvedAt ||
        version.source === "import"
      )));
    nodes.push({
      id: version.id,
      family: type === "image" ? "Sol" : type === "video" ? "Luna" : "Meteor",
      type: type === "audio" ? "spokenAudio" : type,
      role:
        type === "image"
          ? "genImage"
          : type === "video"
            ? "genVideo"
            : "spokenAudio",
      title:
        (asset.name || asset.title) +
        (version.source === "plan"
          ? " · 当前计划"
          : version.source === "job"
            ? " · 生成任务"
            : " · 版本 " +
              (asset.versions.findIndex((v) => v.id === version.id) + 1)),
      assetUrl: version.placeholder ? "" : mediaUrl(version.media),
      displayUrl: version.placeholder ? "" : mediaUrl(version.media),
      mime,
      status: "completed",
      assetState:
        mediaApprovedId(kind, asset) === version.id ? "official" : "candidate",
      x: index * 600,
      y: versionIndex * 280,
      meta: {
        dramaVersionId: version.id,
        dramaVersionNumber:
          asset.versions.findIndex((v) => v.id === version.id) + 1,
        dramaPlaceholder: version.placeholder || "",
        dramaPlan: version.source === "plan",
        dramaPlanChange: version.source === "plan" ? clipPlanPromptChange(asset) : null,
        dramaJobId: version.source === "job" ? version.id : null,
        dramaTargetId: asset.id,
        dramaKind: kind,
        dramaVoiceCharacters:
          kind === "clip"
            ? S.project.assets
                .filter(
                  (a) =>
                    a.kind === "character" &&
                    a.voice?.hasDialogue &&
                    episode.assetRefs.some((r) => r.assetId === a.id),
                )
                .map((a) => ({
                  id: a.id,
                  name: a.name,
                  assetId: a.voiceAssetId,
                  versionId: episode.assetRefs.find(
                    (r) => r.assetId === a.voiceAssetId,
                  )?.versionId,
                }))
            : [],
        dramaStatus: mediaReviewStatus(kind, asset, version),
        dramaSource: version.source,
        dramaRef: ref,
        dramaReferenceEligible: eligible,
        dramaCanEdit: kind === "asset" || !!episode,
        dramaCanvasVideo: !!version.snapshot?.canvasRequest,
        prompt:
          version.snapshot?.prompt ??
          version.prompt ??
          asset.prompt ??
          asset.plan?.prompt ??
          "",
      },
    });
  };
  targets.forEach(({ kind, target }, i) => {
    const versions =
      kind === "clip"
        ? [
            {
              id: "plan-" + target.id,
              media: { mime: "video/mp4" },
              snapshot: target.plan,
              placeholder: "当前计划 · 点击生成后在这里预览",
              source: "plan",
              status: "draft",
            },
            ...target.versions,
            ...mediaJobs("clip", target.id).map((job) => ({
              id: job.id,
              media: { mime: "video/mp4" },
              snapshot: job.snapshot,
              source: "job",
              status: job.status,
              placeholder:
                generationStatus(job) + (downloadDetail(job) ? " · " + downloadDetail(job) : "") +
                (job.error ? " · " + job.error : ""),
            })),
          ]
        : target.versions;
    versions.forEach((version, vi) => {
      if (version.deletedAt) return;
      addMedia(target, version, kind, i, vi);
      if (!version.media || !/^(image|video)\//.test(version.media.mime))
        return;
      batchIds.push(version.id);
      const saved =
        version.snapshot ||
        (kind === "asset"
          ? {
              ...target.generation,
              prompt: version.prompt ?? target.prompt,
              refs: target.refs || [],
            }
          : target.plan);
      const mediaKind = kind === "clip" ? "video" : "image",
        promptId = "review-prompt-" + version.id;
      const base = { prompt: saved.prompt ?? '', generation: reviewGeneration(mediaKind, saved),
        speakingAssetIds: saved.speakingAssetIds || [], refs: saved.refs || [] };
      const draft = rebaseMediaDraft(S.mediaDrafts.get(version.id), base);
      if (S.mediaDrafts.has(version.id)) S.mediaDrafts.set(version.id, structuredClone(draft));
      nodes.push({
        id: promptId,
        family: "Comet",
        type: mediaKind + "Prompt",
        role: mediaKind + "Prompt",
        title: "生成提示词",
        content: draft?.prompt ?? saved.prompt ?? "",
        meta: {
          dramaDraftBase: structuredClone(base),
          dramaSpeakingAssetIds:
            draft?.speakingAssetIds ?? saved.speakingAssetIds ?? [],
        },
        status: "completed",
        x: i * 600 - 340,
        y: vi * 280,
        generation: draft?.generation || reviewGeneration(mediaKind, saved),
      });
      links.push({
        id: "output-" + version.id,
        fromNodeId: promptId,
        toNodeId: version.id,
        relation: "input",
        inputRole: "prompt",
      });
      for (const [ri, ref] of (draft?.refs || saved.refs || []).entries()) {
        exactRefs.set(DramaReferences.nodeId(ref), ref);
        links.push({
          id: "input-" + version.id + "-" + ri,
          fromNodeId: DramaReferences.nodeId(ref),
          toNodeId: promptId,
          relation: "input",
          inputRole:
            ref.role === "audio"
              ? "reference_audio"
              : ref.role === "video"
                ? "reference_video"
                : "ref",
        });
      }
      for (const [ri, input] of (draft?.canvasInputs || saved.canvasInputs || []).entries()) {
        const nodeId = version.id + '-canvas-input-' + ri, type = input.media.mime.split('/')[0];
        nodes.push({ id: nodeId, type: type === 'audio' ? 'spokenAudio' : type,
          family: type === 'image' ? 'Sol' : type === 'video' ? 'Luna' : 'Meteor',
          role: type === 'image' ? 'refImage' : type === 'video' ? 'refVideo' : 'spokenAudio',
          title: input.name, mime: input.media.mime, assetUrl: mediaUrl(input.media), status: 'completed',
          x: i * 600 - 700, y: vi * 280 + ri * 150,
          meta: { dramaCanvasMedia: input.media, dramaCanvasInputRole: input.inputRole, dramaReferenceEligible: true } });
        links.push({ id: 'canvas-ref-' + nodeId, fromNodeId: nodeId, toNodeId: promptId,
          relation: 'input', inputRole: input.inputRole || 'ref' });
      }
    });
  });
  // Keep reference choices as metadata; unrelated candidates and voice auditions are not preview targets.
  const included = new Set(nodes.map((n) => n.id));
  const referenced = new Set(links.map((l) => l.fromNodeId));
  const pins = new Set((episode?.assetRefs || []).map((r) => r.versionId));
  for (const asset of S.project.assets)
    asset.versions.forEach((version, vi) => {
      if (
        !included.has(version.id) &&
        (referenced.has(version.id) ||
          ((pins.has(version.id) || !episode) && (kind === "clip" || version.media?.mime.startsWith("image/"))))
      )
        addMedia(asset, version, "asset", targets.length, vi);
    });
  for (const [id, ref] of exactRefs) {
    const source = DramaReferences.resolve(S.project, ref, true), type = ref.role;
    let node = nodes.find(n => n.id === id);
    if (!node) {
      node = { id, type: type === 'audio' ? 'spokenAudio' : type,
        family: type === 'image' ? 'Sol' : type === 'video' ? 'Luna' : 'Meteor',
        role: type === 'image' ? 'refImage' : type === 'video' ? 'refVideo' : 'spokenAudio',
        title: source.name, mime: source.media.mime, assetUrl: mediaUrl(source.media), displayUrl: mediaUrl(source.media),
        status: 'completed', x: -400, y: exactRefs.size * 180, meta: {} };
      nodes.push(node);
    }
    node.meta = { ...node.meta, dramaRef: ref, dramaCanvasMedia: source.media, dramaReferenceEligible: true };
  }
  return {
    id: "review-" + (episode?.id || S.project.id),
    title: "素材查看",
    nodes,
    links,
    batchIds,
    allowedModels: Object.keys(S.models),
    jobs: targets
      .flatMap(({ kind, target }) => mediaJobs(kind, target.id))
      .map((j) => ({
        id: j.id,
        targetId: j.targetId,
        status: j.status,
        error: j.error,
        label: generationStatus(j),
        detail: downloadDetail(j),
        download: j.download,
      })),
  };
}
// Compare with the newest represented plan, regardless of adoption or completion order.
// Canvas variations at the same plan revision do not imply an agent changed the plan.
function clipPlanPromptChange(clip) {
  const version = clip?.versions.filter(v => !v.deletedAt && v.media?.mime?.startsWith('video/') && typeof v.snapshot?.prompt === 'string')
    .reduce((latest, v) => (latest?.snapshot.planRevision || 0) > (v.snapshot.planRevision || 0) ? latest : v, null);
  if (!version || typeof clip.plan?.prompt !== 'string' || clip.plan.prompt === version.snapshot.prompt) return null;
  if (Number.isFinite(version.snapshot.planRevision) && clip.planRevision <= version.snapshot.planRevision) return null;
  return { versionId: version.id, versionNumber: clip.versions.indexOf(version) + 1, prompt: version.snapshot.prompt };
}
function refreshMediaReview() {
  const frame = $("mediaFrame");
  if (
    !$("dialog").open ||
    !S.modal?.mediaViewer ||
    !frame?.contentWindow.AuralisCanvas?.mediaReview()
  )
    return;
  const api = frame.contentWindow.AuralisCanvas;
  stashMediaDrafts();
  const activeJobId = api.mediaReview()?.node.meta?.dramaJobId;
  const resultId = S.project.jobs.find(
    (j) => j.id === activeJobId,
  )?.resultVersionId;
  const finishedJob =
    activeJobId &&
    !mediaJobs("clip", S.modal.id).some((j) => j.id === activeJobId);
  const nextId = resultId || (finishedJob ? "plan-" + S.modal.id : null);
  if (nextId) {
    const draft = S.mediaDrafts.get(activeJobId);
    if (draft) S.mediaDrafts.set(nextId, draft);
    S.mediaDrafts.delete(activeJobId);
  }
  const graph = mediaReviewGraph(S.modal.kind);
  api.syncMedia(graph, { syncInputs: true });
  S.modal.revision = S.project.revision;
  if (S.modal.kind === 'clip') S.modal.planRevision = ep()?.clips.find(c => c.id === S.modal.id)?.planRevision;
  if (nextId && graph.batchIds.includes(nextId)) {
    const prompt = api
      .snapshot()
      .nodes.find((n) => n.id === "review-prompt-" + nextId);
    const draft = S.mediaDrafts.get(nextId);
    if (prompt && draft) {
      prompt.content = draft.prompt;
      prompt.generation = draft.generation;
      prompt.meta.dramaSpeakingAssetIds = draft.speakingAssetIds;
    }
    api.openMedia(nextId, graph.batchIds);
    if (draft) api.setMediaReferences(draft.refs.map(DramaReferences.nodeId));
  }
  frame.contentWindow.postMessage(
    { type: "drama-media-updated" },
    location.origin,
  );
}
async function previewMedia(kind, targetId, versionId) {
  const target =
    kind === "asset"
      ? S.project.assets.find((a) => a.id === targetId)
      : ep()?.clips.find((c) => c.id === targetId);
  const version =
    target?.versions.find((v) => v.id === versionId) ||
    visibleVersion(
      target,
      ep()?.assetRefs.find((r) => r.assetId === targetId)?.versionId,
    );
  if (
    kind !== "clip" &&
    (!version?.media || !/^(image|video)\//.test(version.media.mime))
  )
    return canvas(kind, targetId);
  S.modal = {
    kind,
    id: targetId,
    revision: S.project.revision,
    mediaViewer: true,
    planRevision: target.planRevision,
  };
  const graph = mediaReviewGraph(kind);
  const chosen = graph.batchIds.includes(versionId)
    ? versionId
    : kind === 'clip' && clipPlanPromptChange(target)
      ? "plan-" + targetId
      : version?.id || "plan-" + targetId;
  const modal = S.modal;
  // Keep the iframe outside dialogBody, which ordinary dialogs replace.
  // It survives other dialogs and canvas visits without navigation/reinitialization.
  let frame = $("mediaFrame");
  if (!frame) {
    frame = document.createElement("iframe");
    frame.id = "mediaFrame";
    frame.title = "Auralis 素材查看器";
    frame.src = "/media-viewer?viewer=1";
    mediaViewerReady = new Promise((resolve, reject) => {
      frame.addEventListener("load", () => {
        if (frame.contentWindow.AuralisCanvas) resolve();
        else reject(new Error("素材查看器加载失败，请重试。"));
      }, { once: true });
    });
    $("dialog").append(frame);
  }
  $("dialogBody").hidden = true;
  frame.hidden = false;
  $("dialog").className = "wide media-dialog";
  if (!$("dialog").open) $("dialog").showModal();
  try {
    await mediaViewerReady;
    if (S.modal !== modal || !$("dialog").open) return;
    frame.contentWindow.AuralisCanvas.mount(graph, { referenceUrl: node => 'https://canvas-input.invalid/' + encodeURIComponent(node.id) });
    frame.contentWindow.AuralisCanvas.openMedia(chosen, graph.batchIds);
    frame.contentWindow.postMessage({ type: "drama-media-open" }, location.origin);
    frame.contentWindow.focus();
  } catch (error) {
    frame.remove();
    if (S.modal === modal) closeDialog();
    toast(error.message, true);
  }
}
async function citeAsset(assetId, versionId) {
  S.cardVersions.set(assetId, versionId);
  selectAsset(assetId, versionId);
  $("assistant").classList.remove("collapsed");
  $("agentInput").focus();
  toast("已引用此版本");
}
window.addEventListener("message", async (event) => {
  const frame = $("mediaFrame"),
    data = event.data;
  if (
    event.origin !== location.origin ||
    event.source !== frame?.contentWindow ||
    data?.type !== "drama-media-action" ||
    !S.modal?.mediaViewer
  )
    return;
  if (data.action === "close") return closeDialog();
  const review = frame.contentWindow.AuralisCanvas.mediaReview();
  if (!review || (review.node.id !== data.versionId && !data.input)) return;
  const m = S.modal,
    meta = data.input
      ? { dramaKind: data.kind, dramaTargetId: data.targetId }
      : review.node.meta,
    kind = meta.dramaKind;
  const target =
    kind === "asset"
      ? S.project.assets.find((a) => a.id === meta.dramaTargetId)
      : ep()?.clips.find((c) => c.id === meta.dramaTargetId);
  const version =
    target?.versions.find((v) => v.id === data.versionId) ||
    (kind === "clip" && graphPlaceholder());
  function graphPlaceholder() {
    const node = frame.contentWindow.AuralisCanvas.snapshot().nodes.find(
      (n) => n.id === data.versionId,
    );
    return node?.meta?.dramaPlaceholder
      ? { id: node.id, status: node.meta.dramaStatus }
      : null;
  }
  if (!version) return;
  try {
    if (data.action === "canvas") {
      stashMediaDrafts();
      const draft = S.mediaDrafts.get(version.id);
      closeDialog();
      return canvas(kind, target.id, draft);
    }
    if (data.action === "cite") {
      await citeAsset(target.id, version.id);
      closeDialog();
      $("agentInput").focus();
      return;
    }
    if (["retry", "recover", "restart"].includes(data.action)) {
      const job = S.project.jobs.find(j => j.id === data.jobId && j.targetType === kind && j.targetId === target.id);
      if (!job) throw new Error("找不到这条生成任务，请刷新后重试");
      if (data.action === "recover" && !(job.remoteId || job.completedUrl)) {
        stashMediaDrafts(); closeDialog();
        return act("recoverJob", { id: job.id });
      }
      await retryGeneration(job.id, data.action === "restart");
    } else if (["save", "generate"].includes(data.action)) {
      if ((kind === "clip" && !ep()) || !review.prompt)
        throw new Error("未找到当前生成输入，请重新打开素材");
      const { model, mediaSettings: settings } = review.settings;
      const refs = review.inputs.map((n) => n.meta?.dramaRef).filter(Boolean);
      const generation =
        kind === "asset"
          ? {
              model,
              resolution: settings.imageResolution,
              aspectRatio: settings.imageAspectRatio,
            }
          : {
              model,
              resolution: settings.videoResolution,
              aspectRatio: settings.videoAspectRatio,
              duration: settings.segmentDurationSeconds,
            };
      const input = data.input || {
        prompt: review.prompt.content,
        speakingAssetIds: review.prompt.meta?.dramaSpeakingAssetIds,
        refs,
        generation,
      };
      const op =
        kind === "asset"
          ? { type: "generateAssetVariation", assetId: target.id, ...input }
          : {
              type: "generateClipVariation",
              clipId: target.id,
              expectedPlanRevision: m.planRevision,
              ...input,
            };
      if (kind === 'clip' && data.input?.canvasExecution) {
        const scope = { api: frame.contentWindow.AuralisCanvas, pid: S.project.id, eid: ep().id,
          clipId: target.id, project: S.project, revision: S.project.revision, imports: new Map() };
        await queueCanvasVideo(scope, { model: input.generation.model, prompt: input.prompt,
          execution: data.input.canvasExecution, graph: data.input.canvasGraph, nodeId: crypto.randomUUID() }, false);
      } else await apply([{ ...op, episodeId: ep()?.id }], m.revision);
    } else if (data.action === "download") {
      if (kind === "clip") downloadClips([{ clipId: target.id, versionId: version.id }]);
      else {
        const link = document.createElement("a");
        link.href = mediaUrl(version.media) + "?download=1";
        link.download = "";
        link.click();
      }
    } else if (data.action === "delete") {
      await apply([
        {
          type: "deleteMediaVersion",
          targetType: kind,
          targetId: target.id,
          episodeId: ep()?.id,
          versionId: version.id,
        },
      ]);
      S.mediaDrafts.delete(version.id);
      if (S.assetSelection.get(target.id) === version.id)
        S.assetSelection.delete(target.id);
      const currentTarget =
        kind === "asset"
          ? S.project.assets.find((a) => a.id === target.id)
          : ep().clips.find((c) => c.id === target.id);
      const ordered = target.versions.filter((v) => !v.deletedAt && v.media);
      const deletedIndex = ordered.findIndex((v) => v.id === version.id);
      const remaining = currentTarget.versions.filter(
        (v) => !v.deletedAt && v.media,
      );
      const next = remaining[Math.min(deletedIndex, remaining.length - 1)];
      if (!next) {
        closeDialog();
        render();
        return;
      }
      refreshMediaReview();
      const graph = mediaReviewGraph(kind);
      frame.contentWindow.AuralisCanvas.openMedia(next.id, graph.batchIds);
    } else if (["accepted", "unaccepted"].includes(data.action)) {
      await apply(
        [
          {
            type: "review",
            targetType: kind,
            targetId: target.id,
            episodeId: ep()?.id,
            versionId: version.id,
            decision: data.action,
          },
        ],
        m.revision,
      );
      if (kind === "asset") S.assetSelection.delete(target.id);
      else S.clipSelection.delete(target.id);
      refreshProductionUI();
    } else return;
    m.revision = S.project.revision;
    if (kind === "clip")
      m.planRevision = ep().clips.find((c) => c.id === target.id).planRevision;
    const current =
      kind === "asset"
        ? S.project.assets.find((a) => a.id === target.id)
        : ep().clips.find((c) => c.id === target.id);
    if (frame !== $("mediaFrame") || !$("dialog").open) return;
    refreshMediaReview();
    frame.contentWindow.postMessage(
      {
        type: "drama-media-result",
        action: data.action,
        versionId: version.id,
        status:
          mediaReviewStatus(kind, current, current.versions.find(v => v.id === version.id) || version),
        eligible:
          kind === "asset" &&
          (!ep() ? version.media?.mime.startsWith("image/") : !!ep().assetRefs.some(
            (r) => r.assetId === target.id && r.versionId === version.id,
          )),
        message: {
          save: "视频计划已保存",
          generate: "生成任务已加入",
          retry: "已恢复任务",
          recover: "正在查询原任务",
          restart: "已新建生成任务",
          unaccepted: "已取消通过，候选和历史记录已保留",
          accepted: "已通过，其余保留为备选",
          delete: "备选已删除",
          download: "已开始下载",
        }[data.action],
        requestId: data.requestId,
      },
      location.origin,
    );
  } catch (error) {
    if (error.code === "revision_conflict") m.revision = S.project.revision;
    if (frame !== $("mediaFrame") || !$("dialog").open) return;
    frame.contentWindow.postMessage(
      {
        type: "drama-media-result",
        error: error.message,
        requestId: data.requestId,
      },
      location.origin,
    );
  }
});
