const crypto = require("node:crypto");
const path = require("node:path");
const { isFileInput } = require("./media-transfer.cjs");

// Request bodies are audit records, never replay inputs. Keep media identity,
// while the actual provider request and the pinned local files retain the bytes.
function compactRequestBody(value, changed = () => {}) {
  if (isFileInput(value)) return { localMedia: value.mime, mediaPath: "media/" + path.basename(value.file), size: value.size };
  if (typeof value === "string" && /^data:[^;,]+;base64,/.test(value)) {
    changed();
    return {
      inlineMedia: value.slice(5, value.indexOf(";")),
      characters: value.length,
      dataUrlSha256: crypto.createHash("sha256").update(value).digest("hex"),
    };
  }
  if (Array.isArray(value)) return value.map(item => compactRequestBody(item, changed));
  if (value && typeof value === "object")
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, compactRequestBody(item, changed)]));
  return value;
}

function compactJobRecords(project) {
  let changed = false;
  for (const job of project.jobs || []) {
    if (job.request?.body) job.request.body = compactRequestBody(job.request.body, () => { changed = true; });
    // An unfinished synchronous result still needs its URL for download recovery.
    if (job.status === "completed" && job.resultVersionId && job.completedUrl?.startsWith("data:")) {
      delete job.completedUrl;
      changed = true;
    }
  }
  return changed;
}

module.exports = { compactRequestBody, compactJobRecords };
