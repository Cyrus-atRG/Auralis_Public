const fs = require("node:fs"), crypto = require("node:crypto");
const { readProject, sameStored, fieldStamp } = require("./project-storage.cjs");

function changes(before, after, path = [], result = []) {
  if (before === after || sameStored(before, after)) return result;
  if (!before || !after || typeof before !== "object" || typeof after !== "object" || Array.isArray(before) !== Array.isArray(after)) {
    result.push({ path, value: after }); return result;
  }
  for (const key of Object.keys(before)) if (!Object.hasOwn(after, key)) result.push({ path: [...path, key], remove: true });
  for (const key of Object.keys(after)) {
    const stamp = fieldStamp(before, key);
    if (stamp !== null && stamp === fieldStamp(after, key)) continue;
    if (!Object.hasOwn(before, key)) result.push({ path: [...path, key], value: after[key] });
    else changes(before[key], after[key], [...path, key], result);
  }
  if (Array.isArray(after) && before.length !== after.length) result.push({ path: [...path, "length"], value: after.length });
  return result;
}

class ProjectSync {
  constructor(store) { this.store = store; this.snapshots = new Map(); this.salt = crypto.randomBytes(8).toString("hex"); }
  tag(id) {
    const stat = fs.statSync(this.store.file(id), { bigint: true });
    return 'W/"' + this.salt + '-' + id + '-' + [stat.dev, stat.ino, stat.size, stat.mtimeNs, stat.ctimeNs].map(v => v.toString(16)).join('-') + '"';
  }
  remember(id, tag) {
    const source = fs.readFileSync(this.store.file(id), "utf8");
    // Old inline files can be large; they still work through full responses.
    if (source.length > 256000) return;
    this.snapshots.delete(tag); this.snapshots.set(tag, { id, source });
    while (this.snapshots.size > 32) this.snapshots.delete(this.snapshots.keys().next().value);
  }
  previous(id, tag) {
    const saved = this.snapshots.get(tag);
    return saved?.id === id ? readProject(this.store.file(id), { lazy: true, source: saved.source }) : null;
  }
  projectView(p) {
    return { ...p,
      jobs: p.jobs.map(({ request, ...job }) => job),
      settings: p.settings.filter(d => !d.deletedAt), assets: p.assets.filter(d => !d.deletedAt),
      episodes: p.episodes.map(e => ({ ...e, clips: e.clips.filter(d => !d.deletedAt) })),
      agentConversations: Object.fromEntries(Object.entries(p.agentConversations).map(([key, chat]) => [key, { messages: chat.messages }])),
      nextStages: Object.fromEntries(p.episodes.map(e => [e.id, this.store.nextStage(p, e)])),
      impacts: Object.fromEntries(p.episodes.map(e => [e.id, this.store.impacts(p, e)])),
      unresolved: Object.fromEntries(p.episodes.map(e => [e.id, this.store.unresolved(p, e)])),
    };
  }
  project(p, previousTag, tag) {
    const view = this.projectView(p);
    let response = view;
    if (previousTag) {
      try {
        const before = this.previous(p.id, previousTag);
        if (before) response = { delta: true, id: p.id, base: previousTag, patches: changes(this.projectView(before), view) };
      } catch { /* An evicted/deleted historical part falls back to the complete snapshot. */ }
    }
    this.remember(p.id, tag);
    return response;
  }
  messages(p, key, previousTag, tag) {
    const messages = p.agentConversations[key]?.messages || [];
    let response = { messages };
    if (previousTag) {
      try {
        const before = this.previous(p.id, previousTag);
        if (before) response = { messagesDelta: changes(before.agentConversations[key]?.messages || [], messages), messagesBase: previousTag };
      } catch { /* A cursor is an optimization, never a requirement for reading the transcript. */ }
    }
    this.remember(p.id, tag);
    return { ...response, messagesCursor: tag };
  }
}
module.exports = { ProjectSync, changes };
