const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { Store, id, find, fail, requireValue, latest } = require("./store.cjs");
const { Provider, models, probe } = require("./provider.cjs");
const { VoiceProvider } = require("./voices.cjs");
const { saveKey } = require("./voice-credentials.cjs");
const { defaults } = require("./generation.cjs");
const { clipDownloads, sendClipZip, disposition, filename } = require("./clip-download.cjs");
const runtimeRoot = path.resolve(__dirname, "..");
const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".jpg": "image/jpeg",
  ".webp": "image/webp",
  ".mp4": "video/mp4",
  ".mp3": "audio/mpeg",
  ".wav": "audio/wav",
};
async function body(req, max = 1048576) {
  const parts = [];
  let size = 0;
  for await (const part of req) {
    size += part.length;
    if (size > max) fail("请求过大", "too_large", 413);
    parts.push(part);
  }
  return Buffer.concat(parts);
}
async function jsonBody(req) {
  try {
    return JSON.parse((await body(req)).toString("utf8"));
  } catch (e) {
    if (e.code) throw e;
    fail("JSON 格式无效");
  }
}
function createWorkbench(options = {}) {
  const port = options.port ?? Number(process.env.AURALIS_DRAMA_PORT || 17887),
    root =
      options.root || process.env.AURALIS_DRAMA_DATA_DIR || path.join(runtimeRoot, ".auralis", "drama-workbench"),
    store = new Store(path.join(root, "projects"));
  const prompts = new (require("./prompts.cjs").PromptLibrary)(root);
  const backups = new (require("./backup.cjs").DramaBackup)(root, prompts, options.backupOptions);
  const sharedApi = new (require("../tools/shared-api-settings.cjs").SharedApiSettings)(options.sharedApiFile || (options.root ? path.join(root, "shared-api.local.json") : undefined));
  const userToken = crypto.randomBytes(32).toString("hex"),
    sessionsFile = path.join(root, "controller-sessions.json"),
    sessions = new Map(
      fs.existsSync(sessionsFile)
        ? JSON.parse(fs.readFileSync(sessionsFile, "utf8"))
        : [],
    ),
    provider = options.provider || new Provider(store, { credentials: () => sharedApi.read(), promptLibrary: prompts }),
    voices = options.voices || new VoiceProvider(store, { credentials: () => sharedApi.read(), ...options.voiceOptions }),
    bridgePort = options.bridgePort || 17888;
  if (!options.root && !options.provider && !options.voiceOptions?.key && !fs.existsSync(sharedApi.file)) {
    const legacy = { wavespeedApiKey: provider.key || "", elevenLabsApiKey: voices.key || "" };
    if (Object.values(legacy).some(Boolean)) sharedApi.save(legacy, { missingOnly: true });
  }
  const saveSessions = () => {
    const temporary = sessionsFile + ".tmp";
    fs.writeFileSync(temporary, JSON.stringify([...sessions]), "utf8");
    fs.renameSync(temporary, sessionsFile);
  };
  let bridge = null,
    base = "";
  const startingTurns = new Set();
  const json = (res, status, value) => {
    res.writeHead(status, {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    });
    res.end(JSON.stringify(value));
  };
  const sendFile = (res, file, mime, download = false, name = path.basename(file)) => {
    requireValue(fs.existsSync(file), "文件不存在");
    res.writeHead(200, {
      "Content-Type":
        mime || mimeTypes[path.extname(file)] || "application/octet-stream",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      ...(download
        ? {
            "Content-Disposition": disposition(name),
          }
        : {}),
    });
    fs.createReadStream(file).pipe(res);
  };
  const user = (req) => {
    if (req.headers.authorization !== "Bearer " + userToken)
      fail("需要工作台会话", "unauthorized", 401);
  };
  const controller = (req) => {
    const s = sessions.get(req.headers["x-drama-session"]);
    if (!s || req.headers.authorization !== "Bearer " + s.capability)
      fail("工作台作用域失效，请重新发起本阶段", "scope_expired", 401);
    return s;
  };
  async function ensureBridge() {
    if (bridge) return bridge;
    const { createBridge } = require("../tools/local-codex-bridge.js");
    bridge = createBridge({
      port: bridgePort,
      runtimeRoot,
      workspace: runtimeRoot,
      dataDir: path.join(root, "bridge"),
      dramaRoot: root,
      appServerEnv: { AURALIS_DRAMA_URL: base },
    });
    await bridge.listen();
    return bridge;
  }
  async function bridgeCall(route, payload) {
    if (options.bridgeCall) return options.bridgeCall(route, payload);
    const b = await ensureBridge();
    const token = fs.readFileSync(b.tokenFile, "utf8").trim();
    const r = await fetch("http://127.0.0.1:" + bridgePort + "/v1/" + route, {
      method: payload ? "POST" : "GET",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
      ...(payload ? { body: JSON.stringify(payload) } : {}),
      signal: AbortSignal.timeout(30000),
    });
    const value = await r.json();
    if (!r.ok)
      fail(
        value.error?.message || "侧载 agent 连接失败",
        value.error?.code || "bridge",
        r.status,
      );
    return value;
  }
  async function agentState(pid, eid) {
    const key = eid || "setting";
    const run = store.read(pid).agentRuns?.[key];
    if (!run?.turnId) return { run: run || null };
    const snapshot = await bridgeCall(
      "auras/" + run.auraId + "/turns/" + run.turnId,
    );
    const status = snapshot.status === "active" ? "running" : snapshot.status;
    const next = {
      ...run,
      status: status || "unknown",
      error: snapshot.error?.message || null,
    };
    if (snapshot.terminal && !next.finishedAt)
      next.finishedAt = new Date().toISOString();
    if (JSON.stringify(next) !== JSON.stringify(run))
      store.internal(pid, (p) => {
        if (p.agentRuns?.[key]?.turnId === run.turnId) p.agentRuns[key] = next;
      });
    return { run: next, snapshot };
  }
  const activeWork = () => startingTurns.size > 0 || provider.active?.size > 0 || voices.active?.size > 0 || store.list().some(item => {
    const p = store.read(item.id);
    return p.jobs.some(j => ["queued", "preparing", "submitting", "polling", "downloading"].includes(j.status)) || p.assets.some(a => ["queued", "searching", "running"].includes(a.voiceSearch?.status)) || Object.values(p.agentRuns || {}).some(r => ["running", "starting"].includes(r.status));
  });
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, base || "http://127.0.0.1:" + port),
        route = url.pathname;
      if (req.headers.origin && req.headers.origin !== base)
        fail("来源不匹配", "origin", 403);
      if (req.headers.host !== new URL(base || "http://127.0.0.1:" + port).host)
        fail("Host 不匹配", "host", 403);
      if (route === "/launcher/status" && req.method === "GET") return json(res, 200, { app: "auralis-drama", runtimeRoot, dataRoot: root, active: activeWork(), pid: process.pid });
      if (route === "/api/bootstrap" && req.method === "GET")
        return json(res, 200, {
          token: userToken,
          models,
          defaults,
          providerReady: !!(sharedApi.read().wavespeedApiKey || provider.key),
          companyReady: sharedApi.status().companyReady,
          elevenLabsReady: !!(sharedApi.read().elevenLabsApiKey || voices.key),
          projects: store.list(),
        });
      if (backups.restoring && route.startsWith("/api/controller/") && req.method !== "GET") fail("正在恢复备份，请稍后重试", "backup_busy", 409);
      if (route.startsWith("/api/controller/")) {
        const s = controller(req),
          p = store.read(s.projectId),
          verb = route.split("/").at(-1),
          input = req.method === "POST" ? await jsonBody(req) : {};
        if (verb === "context") return json(res, 200, store.context(p, s));
        if (verb === "inspect")
          return json(res, 200, {
            revision: p.revision,
            items: store.inspect(p, s, input.ids),
          });
        if (verb === "job") {
          const job = find(p.jobs, input.id);
          if (job.episodeId !== s.episodeId)
            fail("任务不在本集", "scope_denied", 403);
          return json(res, 200, job);
        }
        if (verb === "apply") {
          const result = store.mutate(p.id, input, s);
          if (s.role === "setting")
            for (const r of result.results)
              if (r.id?.startsWith("setting-") && !s.settingIds.includes(r.id))
                s.settingIds.push(r.id);
          if (options.runJobs !== false) provider.tick();
          if (options.runJobs !== false) voices.tick();
          return json(res, 200, result);
        }
        fail("未知 controller 操作");
      }
      if (route.startsWith("/api/")) {
        user(req);
        if (route === "/api/shutdown" && req.method === "POST") {
          requireValue(!activeWork() && !backups.busy, "正在制作，请等待完成后更新服务");
          json(res, 200, { ok: true });
          setImmediate(async () => {
            backups.stop(); provider.stop(); await voices.stop(); if (bridge) await bridge.close();
            server.close(() => { if (require.main === module) process.exit(0); });
          });
          return;
        }
        if (backups.restoring && req.method !== "GET" && !route.startsWith("/api/backup")) fail("正在备份或恢复，请稍后重试", "backup_busy", 409);
        if (route === "/api/backup" && req.method === "GET") return json(res, 200, backups.status());
        if (route === "/api/backup" && req.method === "POST") {
          const b = await jsonBody(req);
          if (b.action === "save") return json(res, 200, backups.configure(b));
          if (b.action === "write") { await backups.write(); return json(res, 200, backups.status()); }
          if (b.action === "restore") {
            requireValue(!activeWork(), "请先等待当前制作任务完成，再恢复备份");
            return json(res, 200, await backups.restore(b.id));
          }
          fail("未知备份操作");
        }
        if (route === "/api/prompts" && req.method === "GET") return json(res, 200, prompts.list());
        if (route === "/api/prompts" && req.method === "POST") {
          const b = await jsonBody(req);
          return json(res, 200, prompts.save(b.id, b.custom, b.mode));
        }
        if (route === "/api/shared-api" && req.method === "GET") return json(res, 200, sharedApi.status());
        if (route === "/api/shared-api" && req.method === "POST") {
          const b = await jsonBody(req);
          sharedApi.save(b);
          const values = sharedApi.read();
          provider.key = values.wavespeedApiKey || provider.key;
          voices.key = values.elevenLabsApiKey || voices.key;
          return json(res, 200, sharedApi.status());
        }
        if (route === "/api/projects" && req.method === "GET")
          return json(res, 200, store.list());
        if (route === "/api/projects" && req.method === "POST") {
          const b = await jsonBody(req);
          return json(res, 201, store.create(b.title, b.premise));
        }
        if (route === "/api/provider" && req.method === "POST") {
          const b = await jsonBody(req);
          sharedApi.save({ wavespeedApiKey: String(b.key || "").trim() });
          provider.key = String(b.key || "").trim();
          return json(res, 200, { ready: !!provider.key });
        }
        if (route === "/api/voice-provider" && req.method === "POST") {
          const b = await jsonBody(req);
          saveKey(b.key, options.voiceCredentialFile);
          sharedApi.save({ elevenLabsApiKey: b.key.trim() });
          voices.key = b.key.trim();
          return json(res, 200, { ready: true });
        }
        const match = route.match(
          /^\/api\/projects\/(project-[a-f0-9-]+)(?:\/(.+))?$/,
        );
        if (!match) fail("未知路径", "not_found", 404);
        const pid = match[1],
          action = match[2] || "";
        let p = store.read(pid);
        if (!action && req.method === "GET")
          return json(res, 200, {
            ...p,
            nextStages: Object.fromEntries(
              p.episodes.map((e) => [e.id, store.nextStage(p, e)]),
            ),
            impacts: Object.fromEntries(
              p.episodes.map((e) => [e.id, store.impacts(p, e)]),
            ),
            unresolved: Object.fromEntries(
              p.episodes.map((e) => [e.id, store.unresolved(p, e)]),
            ),
          });
        if (action === "apply" && req.method === "POST") {
          const result = store.mutate(pid, await jsonBody(req));
          if (options.runJobs !== false) provider.tick();
          if (options.runJobs !== false) voices.tick();
          return json(res, 200, result);
        }
        if (action === "upload" && req.method === "POST") {
          const mime = String(req.headers["content-type"] || "").split(";")[0];
          const ext = {
            "image/png": ".png",
            "image/jpeg": ".jpg",
            "image/webp": ".webp",
            "audio/mpeg": ".mp3",
            "audio/wav": ".wav",
            "audio/x-wav": ".wav",
            "video/mp4": ".mp4",
            "video/quicktime": ".mov",
          }[mime];
          requireValue(ext, "仅支持 PNG/JPG/WebP、MP3/WAV、MP4/MOV");
          const bytes = await body(req, 200 * 1024 * 1024);
          requireValue(bytes.length > 0, "文件为空");
          const relative = "media/" + id("import") + ext,
            file = path.join(path.dirname(store.file(pid)), relative);
          fs.mkdirSync(path.dirname(file), { recursive: true });
          fs.writeFileSync(file, bytes);
          try {
            return json(res, 200, {
              path: relative,
              mime,
              size: bytes.length,
              ...probe(file, mime),
            });
          } catch (e) {
            fs.unlinkSync(file);
            throw e;
          }
        }
        if (action === "agent" && req.method === "POST") {
          const b = await jsonBody(req),
            role = b.episodeId ? "production" : "setting";
          requireValue(
            ["setting", "synopsis", "storyboard", "assets", "video"].includes(
              b.stage,
            ),
            "阶段无效",
          );
          let e = role === "production" ? find(p.episodes, b.episodeId) : null;
          const runKey = e?.id || "setting",
            lockKey = pid + "/" + runKey;
          requireValue(!startingTurns.has(lockKey), "Agent 正在启动，请稍候");
          startingTurns.add(lockKey);
          try {
            let advanceKey = null;
            if (b.advance) {
              requireValue(e, "请选择要继续的一集");
              const { targetType, targetId, versionId } = b.advance;
              const doc = ["synopsis", "storyboard"].includes(targetType)
                ? e[targetType]
                : targetType === "asset" &&
                    e.assetRefs.some((r) => r.assetId === targetId)
                  ? find(p.assets, targetId)
                  : targetType === "clip"
                    ? find(e.clips, targetId)
                    : null;
              requireValue(
                doc && versionId && doc.acceptedVersionId === versionId,
                "采用版本已变化，请刷新后继续",
              );
              advanceKey =
                targetType + "/" + (targetId || e.id) + "/" + versionId;
              const previous = p.agentRuns?.[runKey];
              if (previous?.advanceKey === advanceKey) {
                const { run } = await agentState(pid, e.id);
                if (["running", "completed"].includes(run.status))
                  return json(res, 200, { ...run, reused: true });
              }
            }
            if (p.agentRuns?.[runKey]?.turnId) {
              const { run } = await agentState(pid, e?.id);
              if (run.status === "running" && b.advance) {
                // Adoption supersedes the old stage; revoke its write scope before interrupting.
                for (const [key, old] of sessions)
                  if (old.projectId === pid && old.episodeId === e.id)
                    sessions.delete(key);
                saveSessions();
                await bridgeCall("auras/" + run.auraId + "/interrupt", {
                  requestId: id("stop"),
                });
              }
              requireValue(
                run.status !== "running" || b.advance,
                "Agent 正在运行，请先停止本轮",
              );
            }
            p = store.read(pid);
            e = e ? find(p.episodes, e.id) : null;
            if (
              b.advance &&
              ["synopsis", "storyboard"].includes(b.advance.targetType)
            ) {
              const adopted = e[b.advance.targetType];
              requireValue(
                adopted.acceptedVersionId === b.advance.versionId &&
                  latest(adopted)?.id === b.advance.versionId,
                "创作者又修改了正文，请先审核最新版本再继续",
              );
            }
            if (
              e &&
              (b.advance ||
                b.intent === "continue" ||
                /^(?:ok[了的]?[,，。！!\s]*)?(?:好[的了]?[,，。！!\s]*)?(?:继续|下一步|下一阶段|往下|接着来)[。！!\s]*$/i.test(
                  String(b.message || "").trim(),
                ))
            )
              b.stage = store.nextStage(p, e);
            if (!e) b.stage = "setting";
            const settingIds = b.settingIds || [];
            settingIds.forEach((key) => {
              find(p.settings, key);
              if (e && !e.settingPins.some((x) => x.settingId === key))
                fail("本集未固定该设定");
            });
            const referenceIds = [...new Set(b.referenceIds || [])];
            requireValue(
              referenceIds.length + (b.assetReferences?.length || 0) + (b.clipReferences?.length || 0) <= 100,
              "本轮选择的素材过多，请分批发送",
            );
            const references = referenceIds.map((key) =>
              find(p.references, key),
            );
            const assetReferences = (b.assetReferences || []).map((ref) => {
              const asset = find(p.assets, ref.assetId),
                version = find(asset.versions, ref.versionId);
              requireValue(
                !version.deletedAt && version.media?.mime.startsWith("image/"),
                "所选图片已删除或不可用",
              );
              return {
                id: "asset-" + version.id,
                name: asset.name,
                note: "",
                source: { assetId: asset.id, versionId: version.id },
                media: version.media,
              };
            });
            references.push(...assetReferences);
            const clipReferences = (b.clipReferences || []).map(ref => {
              requireValue(e && b.stage === "video", "视频引用须在本集视频阶段使用");
              const clip = find(e.clips, ref.clipId);
              const version = ref.versionId ? find(clip.versions, ref.versionId) : null;
              requireValue(!version || (!version.deletedAt && version.media?.mime.startsWith("video/")), "所选视频已删除或不可用");
              return { clipId: clip.id, versionId: version?.id || null };
            });
            const session = {
              id: id("session"),
              sessionId: id("scope"),
              capability: crypto.randomBytes(32).toString("hex"),
              projectId: pid,
              role,
              episodeId: e?.id || null,
              stage: b.stage,
              settingIds,
              referenceIds,
              assetReferences: assetReferences.map((r) => r.source),
              clipReferences,
              targetIds: b.targetIds || [],
              inputVersions: e
                ? Object.fromEntries(
                    ["synopsis", "storyboard"].map((name) => [
                      name,
                      {
                        currentVersionId: latest(e[name])?.id,
                        acceptedVersionId: e[name].acceptedVersionId,
                      },
                    ]),
                  )
                : null,
            };
            sessions.set(session.id, session);
            saveSessions();
            const promptSnapshot = prompts.snapshot();
            const previousRun = p.agentRuns?.[runKey];
            const auraId =
              !b.freshSession &&
              previousRun?.contextVersion === 2 &&
              previousRun.promptRevision === promptSnapshot.revision &&
              previousRun.stage === b.stage
                ? previousRun.auraId
                : id("drama-" + b.stage);
            const context = store.context(p, session),
              stagePath =
                role === "production"
                  ? path.join(promptSnapshot.root, "stages", b.stage + ".md")
                  : null;
            const input = [
              {
                type: "text",
                text:
                  String(
                    b.message || "请推进当前阶段，准备好后等待用户审核。",
                  ) +
                  (b.advance
                    ? "\n创作者刚刚采用了版本 " +
                      b.advance.versionId +
                      "。已切换到当前可继续的阶段，请直接推进下一项工作；先核对 context.reviewHandoff 和最新采用正文。"
                    : "") +
                  "\n\n[Trusted workbench scope]\n" +
                  JSON.stringify({
                    auraId,
                    cli: path.join(__dirname, "cli.cjs"),
                    server: base,
                    session: session.id,
                    capability: session.capability,
                    stageFile: stagePath,
                    promptsRoot: promptSnapshot.root,
                    assetNamingFile: path.join(
                      promptSnapshot.root,
                      "asset-naming.md",
                    ),
                    context,
                  }),
              },
              ...references.map((r) => ({
                type: "localImage",
                path: path.join(path.dirname(store.file(pid)), r.media.path),
              })),
            ];
            if (references.length)
              input[0].text +=
                "\n\n本轮图片按下列顺序附上：\n" +
                references
                  .map(
                    (r, i) =>
                      i + 1 + ". " + r.name + (r.note ? " — " + r.note : ""),
                  )
                  .join("\n");
            if (clipReferences.length)
              input[0].text += "\n\n创作者已引用 " + clipReferences.length + " 个视频片段。context.references 给出所选片段及具体版本；未生成项引用当前计划。修改前按这些 ID inspect，不要默认成其他备选或已通过版本。视频文件未作为图片附上，需要查看成片时读取对应 mediaPath。";
            const started = await bridgeCall("auras/" + auraId + "/turn", {
              requestId: b.requestId || id("turn"),
              profile: "drama-" + role,
              input,
              mode: "auto",
              developerInstructions:
                promptSnapshot.text("turn.md"),
            });
            for (const [key, old] of sessions)
              if (
                key !== session.id &&
                old.projectId === pid &&
                old.episodeId === session.episodeId
              )
                sessions.delete(key);
            saveSessions();
            store.internal(pid, (doc) => {
              doc.agentRuns = doc.agentRuns || {};
              doc.agentRuns[e?.id || "setting"] = {
                auraId,
                contextVersion: 2,
                promptRevision: promptSnapshot.revision,
                turnId: started.turnId,
                threadId: started.threadId,
                stage: b.stage,
                status: "running",
                error: null,
                startedAt: new Date().toISOString(),
                referenceIds,
                advanceKey,
              };
            });
            return json(res, 200, {
              ...started,
              auraId,
              sessionId: session.id,
              stage: b.stage,
            });
          } finally {
            startingTurns.delete(lockKey);
          }
        }
        if (action === "agent-events" && req.method === "GET") {
          const eid = url.searchParams.get("episodeId");
          if (eid) find(p.episodes, eid);
          const state = await agentState(pid, eid);
          if (!state.run?.turnId)
            return json(res, 200, { ...state, events: [], nextEventId: 0 });
          const auraId = state.run.auraId;
          const response = await bridgeCall(
            "events?auraId=" +
              auraId +
              "&after=" +
              (Number(url.searchParams.get("after")) || 0),
          );
          return json(res, 200, { ...response, ...state });
        }
        if (action === "agent-stop" && req.method === "POST") {
          const b = await jsonBody(req);
          if (b.episodeId) find(p.episodes, b.episodeId);
          const activeRun =
            store.read(pid).agentRuns?.[b.episodeId || "setting"];
          requireValue(activeRun?.auraId, "没有正在运行的 Agent");
          const stopped = await bridgeCall(
            "auras/" + activeRun.auraId + "/interrupt",
            { requestId: id("stop") },
          );
          store.internal(pid, (doc) => {
            const run = doc.agentRuns?.[b.episodeId || "setting"];
            if (run)
              Object.assign(run, {
                status: "interrupted",
                finishedAt: new Date().toISOString(),
              });
          });
          return json(res, 200, stopped);
        }
        fail("未知项目操作", "not_found", 404);
      }
      const downloads = route.match(/^\/downloads\/(project-[a-f0-9-]+)\/(episode-[a-f0-9-]+)$/);
      if (downloads && req.method === "GET") {
        const project = store.read(downloads[1]);
        const selections = (url.searchParams.get("items") || "").split(",").filter(Boolean).map(value => {
          const [clipId, versionId] = value.split(":");
          return { clipId, versionId };
        });
        const files = clipDownloads(store, project, downloads[2], selections);
        if (files.length === 1) return sendFile(res, files[0].file, files[0].mime, true, files[0].name);
        return await sendClipZip(res, files, filename(project.title) + "_第" + find(project.episodes, downloads[2]).number + "集_视频片段.zip");
      }
      // Media is local, opaque project/id URLs; no arbitrary filesystem path routes.
      const media = route.match(
        /^\/media\/(project-[a-f0-9-]+)\/([a-zA-Z0-9._-]+)$/,
      );
      if (media)
        return sendFile(
          res,
          path.join(path.dirname(store.file(media[1])), "media", media[2]),
          null,
          url.searchParams.has("download"),
        );
      if (route === "/canvas") {
        const html = fs
          .readFileSync(path.join(runtimeRoot, "Auralis.html"), "utf8")
          .replace(
            "</body>",
            '<script src="/canvas.js"></script><script src="/media-viewer.js"></script></body>',
          );
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        return res.end(html);
      }
      const files = {
        "/": "index.html",
        "/index.html": "index.html",
        "/app.js": "app.js",
        "/asset-board.js": "asset-board.js",
        "/video-board.js": "video-board.js",
        "/voice-board.js": "voice-board.js",
        "/canvas-bridge.js": "canvas-bridge.js",
        "/production-updates.js": "production-updates.js",
        "/production-status.js": "production-status.js",
        "/style.css": "style.css",
        "/preferences.js": "preferences.js",
        "/canvas.js": "canvas.js",
        "/media-viewer.js": "media-viewer.js",
        "/media-review.js": "media-review.js",
      };
      if (files[route])
        return sendFile(res, files[route] === "index.html" && process.env.AURALIS_DRAMA_HTML ? process.env.AURALIS_DRAMA_HTML : path.join(__dirname, files[route]));
      if (
        /^\/(assets|src)\/[a-zA-Z0-9_/. -]+$/.test(route) &&
        !route.includes("..")
      )
        return sendFile(res, path.join(runtimeRoot, route.slice(1)));
      fail("未找到", "not_found", 404);
    } catch (e) {
      if (res.headersSent) { res.destroy(e); return; }
      json(res, e.status || 500, {
        error: { code: e.code || "error", message: e.message },
      });
    }
  });
  return {
    server,
    store,
    provider,
    voices,
    async listen() {
      await new Promise((resolve) => server.listen(port, "127.0.0.1", resolve));
      base = "http://127.0.0.1:" + server.address().port;
      if (options.runBackups !== false) backups.start();
      if (options.runJobs !== false) provider.start();
      if (options.runJobs !== false) voices.start();
      return base;
    },
    async close() {
      backups.stop();
      provider.stop();
      await voices.stop();
      if (bridge) await bridge.close();
      await new Promise((resolve) => server.close(resolve));
    },
  };
}
if (require.main === module) {
  const app = createWorkbench();
  app.listen().then((url) => console.log("Auralis 短剧工作台 " + url));
  for (const signal of ["SIGINT", "SIGTERM"])
    process.once(signal, () => app.close().finally(() => process.exit()));
}
module.exports = { createWorkbench };
