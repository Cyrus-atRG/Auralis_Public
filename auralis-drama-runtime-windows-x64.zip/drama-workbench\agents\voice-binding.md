Character voice references:
{{bindings}}
Use these samples only for the named characters' vocal identity. Speak the dialogue specified above; do not repeat the sample words or copy its background audio.
