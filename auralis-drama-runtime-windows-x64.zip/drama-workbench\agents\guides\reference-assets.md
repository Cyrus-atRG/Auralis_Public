# 创作指引｜设定图与声音参考

人物分区参考图按下述固定模板填写；其余创作经验按当前题材和任务择用，不要求额外交付分析表。

## 人物造型主参考

人物角色（不包括野兽怪物等非类人角色）首次生成直接使用以下模板，以 9:16 产出一张完整四分区参考图，作为该造型的主参考。填写槽位，保留固定布局与裁切措辞；只填写当前角色实际需要的特征，没有额外排除项时删去最后一个槽位，不保留占位符。正面身体区必须从锁骨线裁至脚部；背面区保留后脑，但不露正脸。生成参数也设为 9:16。

已有角色图片则将其确切版本实际传入参考，使用同一模板重排。根据图片填写外观槽位，并在 Subject 中说明沿用所传图片的身份、五官、发型、体型和服装，只调整布局与取景。已有符合模板的采用版本直接复用；其他视角和换装从已定主参考派生。

```text
A character design reference sheet.
Vertical 9:16 aspect ratio.
Pure solid neutral light-warm-grey studio backdrop.

【Layout】
2x2 grid with unequal panel heights:
- Top row: two smaller panels, each approximately 1/3 of total
  canvas height — head/face close-ups.
- Bottom row: two larger panels, each approximately 2/3 of total
  canvas height — body front and full body back.
- Thin neutral light-grey dividing lines between all four panels.
- All four panels share the same solid backdrop and lighting setup.

【Subject — same character across all 4 panels】
{{角色身份、年龄感、体型与关键外观特征}}

【4 Panels】

Top-left panel — FRONT FACE CLOSE-UP:
Tight close-up of the character's face, framed from approximately
collarbone-line up to top of head. Subject facing camera directly.
Both eyes intact and visible. Face fully visible.
{{正面五官、发型、表情及必要头饰}}

Top-right panel — SIDE FACE CLOSE-UP (PROFILE):
Tight close-up of the character's face in pure side profile,
framed from collarbone-line up to top of head.
Subject facing camera-right. Face fully visible.
{{侧面轮廓、发型及必要头饰}}

Bottom-left panel — FULL BODY FROM NECK DOWN, FRONT VIEW (NO FACE):
Full body shot from collarbone-line down to feet, facing camera directly.
The face/head is intentionally cropped out of frame at the top of
this panel—only the neck, shoulders, torso, arms, hips, legs,
and feet are visible.
This panel is dedicated to body proportions, costume and equipment.
Zero face involvement.
{{身材比例、服装、鞋履与必要的身体特征}}

Bottom-right panel — FULL BODY BACK VIEW (INCLUDING BACK OF HEAD):
Full body shot from head to feet, facing directly away from camera
(back of subject toward camera).
Includes back of head.
{{后脑发型、服装背面结构及需要展示的背部设计}}

【Critical consistency】
SAME individual character in all 4 panels:
identical face structure, identical hair,
identical clothing items in identical positions.
{{必须保持一致的具体特征及其位置}}
Same studio backdrop and same lighting setup across all 4 panels.

【Style】
{{本项目的画面风格、材质表现与色彩要求}}
Lighting keeps facial features, costume construction and body
details clearly visible.

【Constraints】
NOT equal-sized 4 panels (top row smaller, bottom row larger).
NOT face visible in bottom-left "BODY FRONT (NO FACE)" panel
(face strictly cropped out at top of panel).
NOT face covered by headwear in face close-up panels
(face fully visible).
NOT colorful background (solid neutral light-warm-grey only).
{{当前角色确实需要的少量排除项}}
```

## 其他参考与声音

野兽、怪物等非类人角色通常以完整外观图呈现轮廓、比例、肢体和显著特征，不套用上述头部/身体分区流程；具体镜头确需某个局部时再按需取景。

通用人物参考默认空手，关键道具独立准备；具体镜头需要持物时再组合。

风格样张也会带入人物、衣服、姿态、光线与构图。近景被大全景参考拉远时，可减少冲突输入或换成局部参考。多视角可以保留，按当前镜头需要选用，不强制每次全传或一律禁用拼图。

关键道具保留影响剧情的结构、尺度与状态；场景参考保留会用到的空间关系与固定物。更换服装与只改一张局部取景，影响范围不同，不必都重建整个人物。

场景的视觉意图用空间、形体、光色和必要的材质来表达。表面纹理与颗粒只在具体风格需要时指定，不默认向所有区域补充细碎纹理。

固定角色声线需要可复用的实际音频；视频提示词同时介绍音频对应角色，并用人物卡中的音色关键词描述其声线。声线身份与本句情绪、语速分开，强情绪参考可能把表演方式一起带入。

声线参考不等于原音轨原样播放。若字词和时序必须锁定，需要实际支持的固定音轨或口型路线，不能仅凭一段参考音承诺实现。
