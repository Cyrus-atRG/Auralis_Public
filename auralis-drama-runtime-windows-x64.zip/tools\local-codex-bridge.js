const http = require("http");
const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const readline = require("readline");
const { EventEmitter } = require("events");
const { spawn } = require("child_process");

const BRIDGE_VERSION = "2.3.0";
const BROKER_PROTOCOL_VERSION = 2;
const CONTROLLER_CUSTOMIZATION_VERSION = 2;
const DEFAULT_HOST = "127.0.0.1";
const DEFAULT_PORT = 17876;
const DEFAULT_RPC_TIMEOUT_MS = 30_000;
const MAX_BODY_BYTES = 32 * 1024 * 1024;
const MAX_WS_BYTES = 2_000_000;
const STALE_READ_OPERATION_MS = 5 * 60 * 1000;
const reasoningEfforts = new Set(["low", "medium", "high", "xhigh"]);
const APPLY_OPERATION_TYPES = new Set([
  "executePlan",
  "updateAstraFields",
  "setAstraContent",
  "labelAstra",
  "layoutAstra",
  "createAstra",
  "createCreativeBrief",
  "duplicateAstra",
  "deleteAstra",
  "connectAstra",
  "disconnectLinks",
  "deriveMediaPrompts",
  "generateMedia",
  "generateMediaVariants",
  "promoteMediaCandidate",
  "markStale",
  "extractVideoFrames",
  "analyzeReferenceVideo"
]);
const INSPECT_OPERATION_TYPES = new Set([
  "inspectAura",
  "inspectAstra",
  "inspectActionRun",
  "inspectLinks"
]);
const SAFE_CODEX_NOTIFICATIONS = new Set([
  "error",
  "warning",
  "thread/status/changed",
  "turn/started",
  "turn/completed",
  "item/started",
  "item/completed",
  "item/agentMessage/delta"
]);
const CONTROLLER_PROFILE_DIRS = Object.freeze({
  standard: "auralis-core",
  "auralis-core": "auralis-core",
  "the-mobs": "the-mobs",
  "drama-setting": "drama-setting",
  "drama-production": "drama-production"
});

class BridgeError extends Error {
  constructor(message, status = 500, code = "bridge_error") {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function findCodexCli() {
  const localBin = path.join(os.homedir(), "AppData", "Local", "OpenAI", "Codex", "bin");
  const candidates = [];
  try {
    for (const dir of fs.readdirSync(localBin)) {
      const exe = path.join(localBin, dir, "codex.exe");
      if (fs.existsSync(exe)) candidates.push({ exe, mtime: fs.statSync(exe).mtimeMs });
    }
    const direct = path.join(localBin, "codex.exe");
    if (fs.existsSync(direct)) candidates.push({ exe: direct, mtime: fs.statSync(direct).mtimeMs });
  } catch (_) {}
  candidates.sort((a, b) => b.mtime - a.mtime);
  return candidates[0]?.exe || "codex";
}

function defaultDataDir(fromDir = __dirname) {
  let cursor = path.resolve(fromDir);
  while (path.dirname(cursor) !== cursor) {
    if (path.basename(cursor).toLowerCase() === "runtime") {
      return path.join(path.dirname(cursor), "data");
    }
    cursor = path.dirname(cursor);
  }
  return path.resolve(fromDir, "..", ".auralis", "data");
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (_) {
    return fallback;
  }
}

function writeJsonAtomic(file, value) {
  ensureDir(path.dirname(file));
  const temp = `${file}.${process.pid}.${crypto.randomBytes(4).toString("hex")}.tmp`;
  try {
    fs.writeFileSync(temp, `${JSON.stringify(value, null, 2)}\n`, { encoding: "utf8", mode: 0o600 });
    for (let attempt = 0; ; attempt++) {
      try {
        fs.renameSync(temp, file);
        break;
      } catch (error) {
        if (process.platform !== "win32" || !["EPERM", "EACCES", "EBUSY"].includes(error.code) || attempt >= 5) throw error;
        // Windows readers may briefly omit FILE_SHARE_DELETE. Never delete the old file.
        Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 20 * (attempt + 1));
      }
    }
  } finally {
    try { fs.unlinkSync(temp); } catch (_) {}
  }
}

function loadOrCreateToken(tokenFile, configuredToken = "") {
  const supplied = String(configuredToken || "").trim();
  if (supplied) return supplied;
  try {
    const saved = fs.readFileSync(tokenFile, "utf8").trim();
    if (saved) return saved;
  } catch (_) {}
  ensureDir(path.dirname(tokenFile));
  const generated = crypto.randomBytes(32).toString("base64url");
  try {
    fs.writeFileSync(tokenFile, `${generated}\n`, { encoding: "utf8", mode: 0o600, flag: "wx" });
    return generated;
  } catch (error) {
    if (error.code === "EEXIST") {
      const saved = fs.readFileSync(tokenFile, "utf8").trim();
      if (saved) return saved;
    }
    throw error;
  }
}

function safeIdentifier(value, name) {
  const text = String(value || "").trim();
  if (!/^[A-Za-z0-9._:-]{1,160}$/.test(text)) {
    throw new BridgeError(`${name} is invalid`, 400, `invalid_${name}`);
  }
  return text;
}

function timingSafeEqualText(left, right) {
  const a = Buffer.from(String(left || ""));
  const b = Buffer.from(String(right || ""));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function normalizeReasoningEffort(value) {
  const effort = String(value || "").trim();
  return reasoningEfforts.has(effort) ? effort : "";
}

function resolveControllerProfile(runtimeRoot, requestedProfile = "auralis-core", dramaRoot = "") {
  const requested = String(requestedProfile || "auralis-core").trim();
  const id = CONTROLLER_PROFILE_DIRS[requested];
  if (!id) throw new BridgeError(`unknown controller profile: ${requested}`, 400, "invalid_controller_profile");
  const packsRoot = path.resolve(runtimeRoot, "controller-packs");
  const cwd = path.resolve(packsRoot, id);
  const prefix = `${packsRoot}${path.sep}`;
  if (!cwd.startsWith(prefix)) throw new BridgeError("controller profile path escapes runtime", 500, "invalid_controller_profile_path");
  const agentsPath = path.join(cwd, "AGENTS.md");
  if (!fs.existsSync(agentsPath)) {
    throw new BridgeError(`controller profile is not installed: ${id}`, 503, "controller_profile_missing");
  }
  const canvasCli = path.resolve(runtimeRoot, "tools", "auralis-canvas-cli.js");
  if (!fs.existsSync(canvasCli)) {
    throw new BridgeError("Auralis Canvas CLI is not installed", 503, "canvas_cli_missing");
  }
  if (id.startsWith("drama-")) {
    const role = id.slice(6);
    const dataRoot = dramaRoot || process.env.AURALIS_DRAMA_DATA_DIR || path.join(runtimeRoot, ".auralis", "drama-workbench");
    const { PromptLibrary } = require(path.join(runtimeRoot, "drama-workbench", "prompts.cjs"));
    const promptsRoot = new PromptLibrary(dataRoot, path.join(runtimeRoot, "drama-workbench", "agents")).snapshot().root;
    const promptFiles = [path.join(promptsRoot, role + ".md"), path.join(promptsRoot, "canvas-io.md")];
    const instructions = promptFiles.map(file => fs.readFileSync(file, "utf8")).join("\n\n");
    // Local permission choice survives service restarts; an explicit environment value takes precedence.
    const runtimeConfigFile = path.join(dataRoot, "runtime.json");
    const runtimeConfig = fs.existsSync(runtimeConfigFile) ? JSON.parse(fs.readFileSync(runtimeConfigFile, "utf8")) : {};
    const sandbox = process.env.AURALIS_DRAMA_SANDBOX || runtimeConfig.sandbox || "read-only";
    if (!["read-only", "workspace-write", "danger-full-access"].includes(sandbox)) {
      throw new BridgeError("Invalid drama execution permission in runtime.json", 500, "invalid_drama_sandbox");
    }
    return { id, cwd, agentsPath, canvasCli, sandbox,
      developerInstructions: "Trusted short-drama controller profile: " + id + ".\n" + instructions + "\nUse the dedicated drama CLI from turn context; do not use auralis-canvas or load the general controller instructions." };
  }
  return {
    id,
    cwd,
    agentsPath,
    canvasCli,
    developerInstructions: [
      `Trusted Auralis controller profile: ${id}.`,
      `Before acting, read and follow the complete AGENTS.md in the current working directory: ${agentsPath}.`,
      `The canvas transport is available as auralis-canvas. Its exact script is ${canvasCli}.`,
      "All durable Auralis canvas reads and writes must go through that CLI and must include the Aura id from the turn context.",
      "Do not switch to another controller-pack directory or create a parallel file-based project workflow."
    ].join("\n")
  };
}

function directorySnapshot(root, options = {}) {
  const entries = {};
  const visit = (dir, relativeDir = "") => {
    const names = fs.readdirSync(dir).sort((left, right) => left.localeCompare(right));
    for (const name of names) {
      if (options.ignoreHidden && name.startsWith(".")) continue;
      const fullPath = path.join(dir, name);
      const relativePath = path.join(relativeDir, name).split(path.sep).join("/");
      const stat = fs.lstatSync(fullPath);
      if (stat.isSymbolicLink()) {
        entries[relativePath] = `link:${fs.readlinkSync(fullPath)}`;
      } else if (stat.isDirectory()) {
        entries[`${relativePath}/`] = "directory";
        visit(fullPath, relativePath);
      } else if (stat.isFile()) {
        const contentHash = crypto.createHash("sha256").update(fs.readFileSync(fullPath)).digest("hex");
        entries[relativePath] = `file:${stat.size}:${contentHash}`;
      } else {
        entries[relativePath] = `other:${stat.mode}`;
      }
    }
  };
  visit(root);
  return {
    entries,
    digest: crypto.createHash("sha256").update(JSON.stringify(entries)).digest("hex")
  };
}

function compareDirectorySnapshots(baseline, working) {
  const changedFiles = [];
  const paths = new Set([...Object.keys(baseline.entries), ...Object.keys(working.entries)]);
  for (const relativePath of [...paths].sort((left, right) => left.localeCompare(right))) {
    const before = baseline.entries[relativePath];
    const after = working.entries[relativePath];
    if (before === after) continue;
    changedFiles.push({
      path: relativePath,
      change: before === undefined ? "added" : after === undefined ? "deleted" : "modified"
    });
  }
  return changedFiles;
}

function removeDirectorySync(target) {
  if (process.platform !== "win32") return fs.rmSync(target, { recursive: true, force: true });
  // Node 24.13.0's native recursive rm misdecodes Windows Unicode paths.
  // Walk with libuv-backed primitives, and never follow directory junctions.
  try {
    const stat = fs.lstatSync(target);
    if (!stat.isDirectory() || stat.isSymbolicLink()) {
      fs.unlinkSync(target);
      return;
    }
    for (const name of fs.readdirSync(target)) removeDirectorySync(path.join(target, name));
    fs.rmdirSync(target);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
}

function copyDirectoryAtomic(source, target) {
  ensureDir(path.dirname(target));
  const staging = path.join(path.dirname(target), `.${path.basename(target)}.${process.pid}.${crypto.randomBytes(4).toString("hex")}.tmp`);
  try {
    // A filter bypasses Node 24.13.0's native copy path, which mangles Chinese paths on Windows.
    fs.cpSync(source, staging, { recursive: true, errorOnExist: true, force: false, filter: process.platform === "win32" ? () => true : undefined });
    fs.renameSync(staging, target);
  } catch (error) {
    try { removeDirectorySync(staging); } catch (_) {}
    throw error;
  }
}

function replaceDirectoryAtomic(source, target) {
  ensureDir(path.dirname(target));
  const suffix = `${process.pid}.${crypto.randomBytes(4).toString("hex")}`;
  const staging = path.join(path.dirname(target), `.${path.basename(target)}.${suffix}.tmp`);
  try {
    // Keep the same Unicode-safe copy path used by copyDirectoryAtomic.
    fs.cpSync(source, staging, { recursive: true, errorOnExist: true, force: false, filter: process.platform === "win32" ? () => true : undefined });
    commitPreparedDirectoryAtomic(staging, target);
  } catch (error) {
    try { removeDirectorySync(staging); } catch (_) {}
    throw error;
  }
}

function commitPreparedDirectoryAtomic(staging, target) {
  ensureDir(path.dirname(target));
  const suffix = `${process.pid}.${crypto.randomBytes(4).toString("hex")}`;
  const previous = path.join(path.dirname(target), `.${path.basename(target)}.${suffix}.previous`);
  let movedPrevious = false;
  try {
    if (fs.existsSync(target)) {
      fs.renameSync(target, previous);
      movedPrevious = true;
    }
    fs.renameSync(staging, target);
  } catch (error) {
    if (movedPrevious && !fs.existsSync(target) && fs.existsSync(previous)) {
      try { fs.renameSync(previous, target); } catch (_) {}
    }
    throw error;
  }
  if (movedPrevious) {
    try { removeDirectorySync(previous); } catch (_) {}
  }
}

class ControllerProfileStore {
  constructor({ dataDir, runtimeRoot }) {
    this.runtimeRoot = path.resolve(runtimeRoot);
    this.root = path.resolve(dataDir, "controller-profiles");
    this.sharedRoot = path.join(this.root, "the-mobs-global");
  }

  paths(auraId) {
    if (auraId) safeIdentifier(auraId, "auraId");
    const root = this.sharedRoot;
    return {
      root,
      state: path.join(root, "state.json"),
      baselineRoot: path.join(root, "default"),
      baselineProfile: path.join(root, "default", "the-mobs"),
      baselineCore: path.join(root, "default", "auralis-core"),
      workingRoot: path.join(root, "working"),
      workingProfile: path.join(root, "working", "the-mobs"),
      workingCore: path.join(root, "working", "auralis-core")
    };
  }

  replaceWithInstalled(paths, previousState, installedPacksRoot, installedProfileSnapshot, installedCoreSnapshot) {
    ensureDir(this.root);
    const seedRoot = path.join(this.root, `.seed.${process.pid}.${crypto.randomBytes(4).toString("hex")}`);
    const now = new Date().toISOString();
    try {
      ensureDir(seedRoot);
      copyDirectoryAtomic(installedPacksRoot, path.join(seedRoot, "default"));
      copyDirectoryAtomic(installedPacksRoot, path.join(seedRoot, "working"));
      const profilePack = readJson(path.join(seedRoot, "default", "the-mobs", "pack.json"), {});
      const corePack = readJson(path.join(seedRoot, "default", "auralis-core", "pack.json"), {});
      const state = {
        schemaVersion: CONTROLLER_CUSTOMIZATION_VERSION,
        scope: "global",
        profile: "the-mobs",
        defaultVersion: String(profilePack.version || ""),
        coreDefaultVersion: String(corePack.version || ""),
        baselineHash: installedProfileSnapshot.digest,
        coreBaselineHash: installedCoreSnapshot.digest,
        baselineCreatedAt: previousState.baselineCreatedAt || now,
        baselineUpdatedAt: now
      };
      writeJsonAtomic(path.join(seedRoot, "state.json"), state);
      replaceDirectoryAtomic(seedRoot, paths.root);
      return state;
    } finally {
      try { removeDirectorySync(seedRoot); } catch (_) {}
    }
  }

  ensure(auraId, options = {}) {
    const installedProfile = resolveControllerProfile(this.runtimeRoot, "the-mobs");
    const installedCore = resolveControllerProfile(this.runtimeRoot, "auralis-core");
    const installedPacksRoot = path.dirname(installedProfile.cwd);
    if (installedPacksRoot !== path.dirname(installedCore.cwd)) {
      throw new BridgeError("controller profiles do not share a trusted pack root", 500, "invalid_controller_profile_path");
    }
    const installedProfileSnapshot = directorySnapshot(installedProfile.cwd);
    const installedCoreSnapshot = directorySnapshot(installedCore.cwd);
    const installedVersion = String(readJson(path.join(installedProfile.cwd, "pack.json"), {}).version || "");
    const paths = this.paths(auraId);
    ensureDir(paths.root);
    let state = readJson(paths.state, null);
    if (state && (state.schemaVersion !== CONTROLLER_CUSTOMIZATION_VERSION || state.scope !== "global" || state.profile !== "the-mobs")) {
      throw new BridgeError("shared controller profile state is invalid", 500, "controller_profile_state_mismatch");
    }
    if (!fs.existsSync(paths.baselineProfile) || !fs.existsSync(paths.baselineCore)) {
      if (fs.existsSync(paths.baselineRoot)) {
        throw new BridgeError("controller default snapshot is incomplete", 500, "controller_profile_default_incomplete");
      }
      copyDirectoryAtomic(installedPacksRoot, paths.baselineRoot);
    }
    let baselineProfile = directorySnapshot(paths.baselineProfile);
    let baselineCore = directorySnapshot(paths.baselineCore);
    if (state?.baselineHash && state.baselineHash !== baselineProfile.digest) {
      throw new BridgeError("controller default snapshot was modified", 500, "controller_profile_default_modified");
    }
    if (state?.coreBaselineHash && state.coreBaselineHash !== baselineCore.digest) {
      throw new BridgeError("controller core snapshot was modified", 500, "controller_profile_default_modified");
    }
    if (!state) {
      const profilePack = readJson(path.join(paths.baselineProfile, "pack.json"), {});
      const corePack = readJson(path.join(paths.baselineCore, "pack.json"), {});
      state = {
        schemaVersion: CONTROLLER_CUSTOMIZATION_VERSION,
        scope: "global",
        profile: "the-mobs",
        defaultVersion: String(profilePack.version || ""),
        coreDefaultVersion: String(corePack.version || ""),
        baselineHash: baselineProfile.digest,
        coreBaselineHash: baselineCore.digest,
        baselineCreatedAt: new Date().toISOString()
      };
      writeJsonAtomic(paths.state, state);
    }
    if (!fs.existsSync(paths.workingProfile) || !fs.existsSync(paths.workingCore)) {
      if (fs.existsSync(paths.workingRoot)) {
        throw new BridgeError("controller working copy is incomplete", 500, "controller_profile_working_incomplete");
      }
      copyDirectoryAtomic(paths.baselineRoot, paths.workingRoot);
    }
    const baselineRules = directorySnapshot(paths.baselineProfile, { ignoreHidden: true });
    const workingRules = directorySnapshot(paths.workingProfile, { ignoreHidden: true });
    const customized = compareDirectorySnapshots(baselineRules, workingRules).length > 0;
    const updateAvailable = state.baselineHash !== installedProfileSnapshot.digest
      || state.coreBaselineHash !== installedCoreSnapshot.digest;
    let remainingUpdateAvailable = updateAvailable;
    if (updateAvailable && !customized && options.upgradeUncustomized === true) {
      state = this.replaceWithInstalled(paths, state, installedPacksRoot, installedProfileSnapshot, installedCoreSnapshot);
      baselineProfile = installedProfileSnapshot;
      baselineCore = installedCoreSnapshot;
      remainingUpdateAvailable = false;
    }
    return {
      paths,
      state,
      installedProfile,
      installedPacksRoot,
      installedProfileSnapshot,
      installedCoreSnapshot,
      installedVersion,
      baselineProfile,
      baselineCore,
      updateAvailable: remainingUpdateAvailable,
      customized
    };
  }

  status(auraId = "") {
    const context = this.ensure(auraId);
    const baselineRules = directorySnapshot(context.paths.baselineProfile, { ignoreHidden: true });
    const working = directorySnapshot(context.paths.workingProfile, { ignoreHidden: true });
    const changedFiles = compareDirectorySnapshots(baselineRules, working);
    return {
      schemaVersion: "auralis.controller-customization.v2",
      scope: "global",
      ...(auraId ? { auraId } : {}),
      profile: "the-mobs",
      editable: true,
      customized: changedFiles.length > 0,
      changedFileCount: changedFiles.length,
      changedFiles: changedFiles.slice(0, 100),
      revision: working.digest,
      defaultVersion: context.state.defaultVersion,
      coreDefaultVersion: context.state.coreDefaultVersion,
      installedVersion: context.installedVersion,
      updateAvailable: context.updateAvailable,
      baselineCreatedAt: context.state.baselineCreatedAt,
      baselineUpdatedAt: context.state.baselineUpdatedAt || context.state.baselineCreatedAt
    };
  }

  resolve(auraId, requestedProfile = "auralis-core", options = {}) {
    const installed = resolveControllerProfile(this.runtimeRoot, requestedProfile);
    if (installed.id !== "the-mobs") return { ...installed, sandbox: installed.sandbox || "read-only", profileRevision: "" };
    this.ensure(auraId, { upgradeUncustomized: options.upgradeUncustomized === true });
    const status = this.status(auraId);
    const paths = this.paths(auraId);
    const agentsPath = path.join(paths.workingProfile, "AGENTS.md");
    return {
      ...installed,
      cwd: paths.workingProfile,
      agentsPath,
      sandbox: "workspace-write",
      profileRevision: status.revision,
      developerInstructions: [
        `Trusted Auralis controller profile: ${installed.id}.`,
        "This writable controller profile is shared by every The Mobs Aura in this Auralis installation.",
        `Before acting, read and follow the complete AGENTS.md in the current working directory: ${agentsPath}.`,
        `The canvas transport is available as auralis-canvas. Its exact script is ${installed.canvasCli}.`,
        "All durable Auralis canvas reads and writes must go through that CLI and must include the Aura id from the turn context.",
        "When the user asks to customize your own behavior, edit only AGENTS.md or files under skills/ in this workspace. Those edits become the default behavior for every current and future The Mobs Aura.",
        "A protected default snapshot exists outside this workspace and can be restored from Auralis settings. Do not try to locate or modify it.",
        "After changing controller rules, briefly tell the user what changed. Do not create a parallel file-based project workflow."
      ].join("\n")
    };
  }

  reset(auraId = "", expectedRevision = "") {
    const prepared = this.prepareReset(auraId, expectedRevision);
    try {
      return prepared.commit();
    } finally {
      prepared.discard();
    }
  }

  prepareReset(auraId = "", expectedRevision = "") {
    const context = this.ensure(auraId);
    const currentRevision = directorySnapshot(context.paths.workingProfile, { ignoreHidden: true }).digest;
    if (expectedRevision && currentRevision !== expectedRevision) {
      throw new BridgeError("shared controller profile changed since it was last read", 409, "controller_profile_revision_conflict");
    }
    const stagingRoot = path.join(this.root, `.reset.the-mobs-global.${process.pid}.${crypto.randomBytes(4).toString("hex")}.tmp`);
    let finished = false;
    try {
      ensureDir(stagingRoot);
      const sourceRoot = context.updateAvailable ? context.installedPacksRoot : context.paths.baselineRoot;
      copyDirectoryAtomic(sourceRoot, path.join(stagingRoot, "default"));
      copyDirectoryAtomic(sourceRoot, path.join(stagingRoot, "working"));
      let nextState = context.state;
      if (context.updateAvailable) {
        const profilePack = readJson(path.join(stagingRoot, "default", "the-mobs", "pack.json"), {});
        const corePack = readJson(path.join(stagingRoot, "default", "auralis-core", "pack.json"), {});
        const now = new Date().toISOString();
        nextState = {
          schemaVersion: CONTROLLER_CUSTOMIZATION_VERSION,
          scope: "global",
          profile: "the-mobs",
          defaultVersion: String(profilePack.version || ""),
          coreDefaultVersion: String(corePack.version || ""),
          baselineHash: context.installedProfileSnapshot.digest,
          coreBaselineHash: context.installedCoreSnapshot.digest,
          baselineCreatedAt: context.state.baselineCreatedAt || now,
          baselineUpdatedAt: now
        };
      }
      writeJsonAtomic(path.join(stagingRoot, "state.json"), nextState);
    } catch (error) {
      try { removeDirectorySync(stagingRoot); } catch (_) {}
      throw error;
    }
    return {
      commit: () => {
        if (finished) throw new BridgeError("controller profile reset is no longer pending", 409, "controller_profile_reset_not_pending");
        commitPreparedDirectoryAtomic(stagingRoot, context.paths.root);
        finished = true;
        return this.status(auraId);
      },
      discard: () => {
        if (finished) return;
        finished = true;
        try { removeDirectorySync(stagingRoot); } catch (_) {}
      }
    };
  }

}

function estimateTextTokens(value) {
  const text = String(value || "").trim();
  if (!text) return 0;
  const compact = text.replace(/\s+/g, "");
  const cjkMatches = compact.match(/[\u3400-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]/g) || [];
  const asciiWords = compact.match(/[A-Za-z0-9_]+(?:[-'][A-Za-z0-9_]+)*/g) || [];
  const asciiChars = asciiWords.reduce((sum, word) => sum + word.length, 0);
  const otherChars = Math.max(0, compact.length - cjkMatches.length - asciiChars);
  const asciiTokens = asciiWords.reduce((sum, word) => sum + Math.max(1, Math.ceil(word.length / 4)), 0);
  return Math.max(1, Math.ceil(cjkMatches.length * 1.1) + asciiTokens + Math.ceil(otherChars / 2));
}

function estimateLocalCodexUsage(prompt, content) {
  const promptTokens = estimateTextTokens(prompt);
  const completionTokens = estimateTextTokens(content);
  return {
    prompt_tokens: promptTokens,
    completion_tokens: completionTokens,
    total_tokens: promptTokens + completionTokens,
    estimated: true
  };
}

function localCodexChatCompletionResponse(content, prompt) {
  return {
    id: `cc-codex-${Date.now()}`,
    object: "chat.completion",
    model: "local-codex/app-server",
    choices: [{ index: 0, message: { role: "assistant", content }, finish_reason: "stop" }],
    usage: estimateLocalCodexUsage(prompt, content),
    auralis_usage_estimated: true
  };
}

function contentToText(content) {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content.map(part => {
      if (typeof part === "string") return part;
      if (part?.type === "text") return part.text || "";
      if (part?.type === "image_url") return `[image attached in browser: ${part.image_url?.url || ""}]`;
      if (part?.type === "video_url") return `[video attached in browser: ${part.video_url?.url || ""}]`;
      return JSON.stringify(part);
    }).filter(Boolean).join("\n");
  }
  return content ? JSON.stringify(content) : "";
}

function messagesToPrompt(messages) {
  return (messages || []).map(message => {
    const role = message.role || "user";
    return `# ${role}\n${contentToText(message.content)}`;
  }).join("\n\n");
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let bytes = 0;
    const chunks = [];
    req.on("data", chunk => {
      bytes += chunk.length;
      if (bytes > MAX_BODY_BYTES) {
        reject(new BridgeError("request body too large", 413, "body_too_large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function normalizeUserInput(input) {
  if (!Array.isArray(input) || !input.length) {
    throw new BridgeError("input must be a non-empty array", 400, "invalid_input");
  }
  return input.map(item => {
    if (!item || typeof item !== "object") throw new BridgeError("input item is invalid", 400, "invalid_input");
    if (item.type === "text") return { type: "text", text: String(item.text || ""), text_elements: Array.isArray(item.text_elements) ? item.text_elements : [] };
    if (item.type === "image" && item.url) return { type: "image", url: String(item.url), ...(item.detail ? { detail: item.detail } : {}) };
    if (item.type === "localImage" && item.path) return { type: "localImage", path: String(item.path), ...(item.detail ? { detail: item.detail } : {}) };
    if ((item.type === "skill" || item.type === "mention") && item.name && item.path) {
      return { type: item.type, name: String(item.name), path: String(item.path) };
    }
    throw new BridgeError(`unsupported input type: ${item.type || "unknown"}`, 400, "invalid_input");
  });
}

class AppServerSupervisor extends EventEmitter {
  constructor(options = {}) {
    super();
    this.command = options.command || findCodexCli();
    this.args = options.args || ["app-server", "--stdio"];
    this.cwd = options.cwd || process.cwd();
    this.env = { ...process.env, ...(options.env || {}) };
    this.timeoutMs = options.timeoutMs || DEFAULT_RPC_TIMEOUT_MS;
    this.spawnFn = options.spawnFn || spawn;
    this.child = null;
    this.pending = new Map();
    this.nextId = 1;
    this.starting = null;
    this.stopping = false;
    this.generation = 0;
    this.initialized = false;
    this.initializeResult = null;
    this.lastError = "";
    this.stderrTail = "";
  }

  async ensureStarted() {
    if (this.child && this.initialized) return this.initializeResult;
    if (this.starting) return this.starting;
    this.starting = this.#start();
    try {
      return await this.starting;
    } finally {
      this.starting = null;
    }
  }

  async #start() {
    this.stopping = false;
    const child = this.spawnFn(this.command, this.args, {
      cwd: this.cwd,
      env: this.env,
      stdio: ["pipe", "pipe", "pipe"],
      windowsHide: true
    });
    this.child = child;
    this.initialized = false;
    this.initializeResult = null;
    this.stderrTail = "";
    this.generation += 1;
    const generation = this.generation;
    const lines = readline.createInterface({ input: child.stdout, crlfDelay: Infinity });
    lines.on("line", line => this.#handleLine(line));
    child.stderr.on("data", data => {
      this.stderrTail = `${this.stderrTail}${data.toString("utf8")}`.slice(-8000);
    });
    child.once("error", error => this.#handleExit(error));
    child.once("exit", (code, signal) => {
      const detail = this.stderrTail.trim() || `codex app-server exited (${code ?? signal ?? "unknown"})`;
      this.#handleExit(new Error(detail));
    });
    await new Promise((resolve, reject) => {
      child.once("spawn", resolve);
      child.once("error", reject);
    });
    let result;
    try {
      result = await this.#requestRaw("initialize", {
        clientInfo: { name: "auralis-local-bridge", title: "Auralis Local Bridge", version: BRIDGE_VERSION },
        capabilities: { experimentalApi: false, requestAttestation: false }
      });
      this.#notifyRaw("initialized");
    } catch (error) {
      this.lastError = error.message;
      try { child.kill(); } catch (_) {}
      throw error;
    }
    if (this.child !== child) throw new BridgeError("app-server restarted during initialize", 503, "app_server_restarted");
    this.initialized = true;
    this.initializeResult = result;
    this.lastError = "";
    this.emit("started", { generation, result, pid: child.pid });
    return result;
  }

  request(method, params, timeoutMs) {
    return this.ensureStarted().then(() => this.#requestRaw(method, params, timeoutMs));
  }

  notify(method, params) {
    if (!this.child || !this.initialized) throw new BridgeError("app-server is not ready", 503, "app_server_unavailable");
    this.#notifyRaw(method, params);
  }

  #requestRaw(method, params, timeoutMs = this.timeoutMs) {
    if (!this.child?.stdin?.writable) return Promise.reject(new BridgeError("app-server is unavailable", 503, "app_server_unavailable"));
    const id = `auralis-${this.nextId++}`;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new BridgeError(`app-server request timed out: ${method}`, 504, "app_server_timeout"));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer, method });
      this.#write({ method, id, params });
    });
  }

  #notifyRaw(method, params) {
    this.#write(params === undefined ? { method } : { method, params });
  }

  #write(value) {
    if (!this.child?.stdin?.writable) throw new BridgeError("app-server is unavailable", 503, "app_server_unavailable");
    this.child.stdin.write(`${JSON.stringify(value)}\n`);
  }

  #handleLine(line) {
    const trimmed = String(line || "").trim();
    if (!trimmed) return;
    let message;
    try {
      message = JSON.parse(trimmed);
    } catch (_) {
      this.emit("protocolError", new Error(`invalid app-server JSON: ${trimmed.slice(0, 200)}`));
      return;
    }
    if (message.id !== undefined && !message.method) {
      const pending = this.pending.get(String(message.id));
      if (!pending) return;
      clearTimeout(pending.timer);
      this.pending.delete(String(message.id));
      if (message.error) {
        const error = new BridgeError(message.error.message || `${pending.method} failed`, 502, "app_server_error");
        error.details = message.error;
        pending.reject(error);
      } else {
        pending.resolve(message.result);
      }
      return;
    }
    if (message.id !== undefined && message.method) {
      this.#write({ id: message.id, error: { code: -32601, message: `unsupported server request: ${message.method}` } });
      this.emit("serverRequest", message);
      return;
    }
    if (message.method) this.emit("notification", message);
  }

  #handleExit(error) {
    if (!this.child) return;
    this.lastError = error.message;
    this.child = null;
    this.initialized = false;
    this.initializeResult = null;
    for (const pending of this.pending.values()) {
      clearTimeout(pending.timer);
      pending.reject(new BridgeError(error.message, 503, "app_server_exited"));
    }
    this.pending.clear();
    if (!this.stopping) this.emit("exit", error);
  }

  async stop() {
    this.stopping = true;
    const child = this.child;
    if (!child) return;
    await new Promise(resolve => {
      const timer = setTimeout(resolve, 1000);
      child.once("exit", () => {
        clearTimeout(timer);
        resolve();
      });
      try { child.kill(); } catch (_) { resolve(); }
    });
    this.child = null;
    this.initialized = false;
  }

  status() {
    return {
      state: this.child && this.initialized ? "ready" : this.child ? "starting" : "stopped",
      generation: this.generation,
      pid: this.child?.pid || null,
      userAgent: this.initializeResult?.userAgent || null,
      codexHome: this.initializeResult?.codexHome || null,
      lastError: this.lastError || null
    };
  }
}

class ThreadStore {
  constructor(file) {
    this.file = file;
    this.retryTimer = null;
    this.lastSaveError = null;
    this.receiptDir = `${file}.pending`;
    this.data = readJson(file, { version: 1, auras: {}, turnRequests: {}, resetRequests: {} });
    if (!this.data.auras || typeof this.data.auras !== "object") this.data.auras = {};
    if (!this.data.turnRequests || typeof this.data.turnRequests !== "object") this.data.turnRequests = {};
    if (!this.data.resetRequests || typeof this.data.resetRequests !== "object") this.data.resetRequests = {};
    if (fs.existsSync(this.receiptDir)) {
      for (const name of fs.readdirSync(this.receiptDir).filter(name => /^[a-f0-9]{64}\.json$/.test(name))) {
        const receipt = readJson(path.join(this.receiptDir, name), null);
        if (!receipt?.requestId || !receipt?.value?.auraId || !receipt?.value?.result) continue;
        const { requestId, value, aura } = receipt;
        this.data.turnRequests[requestId] = value;
        const current = this.data.auras[value.auraId];
        if (aura && (!current || String(current.updatedAt) <= String(aura.updatedAt))) this.data.auras[value.auraId] = aura;
      }
      this.save({ deferOnFailure: true });
    }
  }

  save({ deferOnFailure = false } = {}) {
    try {
      writeJsonAtomic(this.file, this.data);
      this.lastSaveError = null;
      clearTimeout(this.retryTimer);
      this.retryTimer = null;
    } catch (error) {
      if (!deferOnFailure) throw error;
      this.lastSaveError = error;
      if (!this.retryTimer) {
        this.retryTimer = setTimeout(() => {
          this.retryTimer = null;
          this.save({ deferOnFailure: true });
        }, 1000);
        this.retryTimer.unref?.();
      }
      return false;
    }
    // A receipt is retired only after the complete state has been committed.
    try {
      for (const name of fs.readdirSync(this.receiptDir).filter(name => /^[a-f0-9]{64}\.json$/.test(name))) fs.unlinkSync(path.join(this.receiptDir, name));
    } catch (_) {}
    return true;
  }

  getAura(auraId) {
    return this.data.auras[auraId] || null;
  }

  setAura(auraId, patch, saveOptions) {
    this.data.auras[auraId] = { ...(this.data.auras[auraId] || {}), ...patch, updatedAt: new Date().toISOString() };
    this.save(saveOptions);
    return this.data.auras[auraId];
  }

  removeAura(auraId) {
    const previous = this.data.auras[auraId] || null;
    delete this.data.auras[auraId];
    this.save();
    return previous;
  }

  findAuraByThread(threadId) {
    return Object.entries(this.data.auras).find(([, entry]) => entry.threadId === threadId)?.[0] || null;
  }

  entries() {
    return Object.entries(this.data.auras);
  }

  getTurnRequest(requestId) {
    return this.data.turnRequests[requestId] || null;
  }

  acceptTurn(auraId, requestId, result, active) {
    const updatedAt = new Date().toISOString();
    if (active) this.data.auras[auraId] = { ...this.data.auras[auraId], activeTurnId: result.turnId, activeRequestId: requestId, updatedAt };
    const value = { auraId, result, updatedAt };
    this.data.turnRequests[requestId] = value;
    this.trimTurnRequests();
    if (this.save({ deferOnFailure: true })) return;
    // Codex has already accepted the input. Keep an independent recovery receipt
    // rather than returning a send failure that would invite duplicate input.
    const name = crypto.createHash("sha256").update(requestId).digest("hex") + ".json";
    try {
      writeJsonAtomic(path.join(this.receiptDir, name), { requestId, value, aura: this.data.auras[auraId] });
    } catch (error) {
      this.lastSaveError = error;
    }
  }

  setTurnRequest(requestId, value) {
    this.data.turnRequests[requestId] = { ...value, updatedAt: new Date().toISOString() };
    this.trimTurnRequests();
    this.save();
  }

  trimTurnRequests() {
    const entries = Object.entries(this.data.turnRequests);
    if (entries.length > 500) {
      entries.sort((a, b) => String(a[1].updatedAt).localeCompare(String(b[1].updatedAt)));
      for (const [id] of entries.slice(0, entries.length - 500)) delete this.data.turnRequests[id];
    }
  }

  close() {
    if (this.lastSaveError) this.save({ deferOnFailure: true });
    clearTimeout(this.retryTimer);
    this.retryTimer = null;
  }

  getResetRequest(requestId) {
    return this.data.resetRequests[requestId] || null;
  }

  setResetRequest(requestId, value) {
    this.data.resetRequests[requestId] = { ...value, updatedAt: new Date().toISOString() };
    const entries = Object.entries(this.data.resetRequests);
    if (entries.length > 500) {
      entries.sort((a, b) => String(a[1].updatedAt).localeCompare(String(b[1].updatedAt)));
      for (const [id] of entries.slice(0, entries.length - 500)) delete this.data.resetRequests[id];
    }
    this.save();
  }

  count() {
    return Object.keys(this.data.auras).length;
  }
}

class EventJournal {
  constructor(file) {
    this.file = file;
    this.metaFile = `${file}.meta.json`;
    this.turnsDir = `${file}.turns`;
    ensureDir(this.turnsDir);
    this.events = [];
    this.historicalTurns = new Map();
    this.nextId = 1;
    ensureDir(path.dirname(file));
    const journalExists = fs.existsSync(file);
    const metadata = readJson(this.metaFile, null);
    if (!journalExists) fs.writeFileSync(file, "", { encoding: "utf8", mode: 0o600, flag: "a" });
    try {
      for (const event of require("./event-journal-files.cjs").readEvents(file)) {
        this.events.push(event);
        this.nextId = Math.max(this.nextId, Number(event.eventId || 0) + 1);
      }
    } catch (_) {}
    if (this.events.length > 10_000) this.events = this.events.slice(-10_000);
    this.fileBytes = fs.statSync(file).size;
    const persistedJournalId = typeof metadata?.journalId === "string" ? metadata.journalId.trim() : "";
    const reuseMetadata = Boolean(journalExists && persistedJournalId);
    this.journalId = reuseMetadata ? persistedJournalId : crypto.randomUUID();
    this.legacyCursorCompatible = reuseMetadata && typeof metadata?.legacyCursorCompatible === "boolean"
      ? metadata.legacyCursorCompatible
      : Boolean(journalExists && this.events.length);
    if (!reuseMetadata || metadata?.schemaVersion !== 2 || typeof metadata?.legacyCursorCompatible !== "boolean") {
      writeJsonAtomic(this.metaFile, {
        schemaVersion: 2,
        journalId: this.journalId,
        legacyCursorCompatible: this.legacyCursorCompatible
      });
    }
  }

  append(value) {
    const event = { ...value, eventId: this.nextId++, createdAt: value.createdAt || new Date().toISOString() };
    if (this.fileBytes >= 8 * 1024 * 1024) {
      require("./event-journal-files.cjs").rotateEvents(this.file, event.eventId - 1);
      this.fileBytes = 0;
    }
    const line = `${JSON.stringify(event)}\n`;
    fs.appendFileSync(this.file, line, "utf8");
    this.fileBytes += Buffer.byteLength(line);
    this.events.push(event);
    if (this.events.length > 10_000) this.events.shift();
    // A terminal receipt survives replay eviction and journal rotation.
    if (event.type === "codex.event" && event.method === "turn/completed")
      this.snapshotTurn({ auraId: event.auraId, turnId: event.turnId });
    return event;
  }

  replay({ auraId, after = 0, limit = 500 }) {
    return this.events.filter(event => (!auraId || event.auraId === auraId) && Number(event.eventId) > Number(after || 0)).slice(0, Math.min(1000, Math.max(1, Number(limit) || 500)));
  }

  latestId() {
    return this.nextId - 1;
  }

  snapshotTurn({ auraId, turnId, activeTurnId = null, activeRequestId = null, activeThreadId = null }) {
    const isActive = activeTurnId === turnId;
    const historyKey = JSON.stringify([auraId, turnId]);
    if (!isActive && this.historicalTurns.has(historyKey)) return this.historicalTurns.get(historyKey);
    const receiptFile = path.join(this.turnsDir, crypto.createHash("sha256").update(historyKey).digest("hex") + ".json");
    if (!isActive) {
      const saved = readJson(receiptFile, null);
      if (saved?.journalId === this.journalId && saved.auraId === auraId && saved.turnId === turnId && saved.terminal) {
        this.cacheTurn(historyKey, saved);
        return saved;
      }
    }
    let events = this.events;
    const needsHistory = !isActive && !events.some(event =>
      event.type === "codex.event" && event.auraId === auraId && event.turnId === turnId && event.method === "turn/completed");
    // A long or resumed turn may have lost its opening text from the replay tail.
    const incompleteTail = !isActive && !events.some(event => event.auraId === auraId && event.turnId === turnId && event.method === "turn/started");
    if (needsHistory || incompleteTail) events = require("./event-journal-files.cjs").readTurnEvents(this.file, auraId, turnId);
    let requestId = isActive ? activeRequestId || null : null;
    let threadId = isActive ? activeThreadId || null : null;
    let itemId = null;
    let completedText = null;
    let deltaText = "";
    let terminalEvent = null;
    for (const event of events) {
      if (event.type !== "codex.event" || event.auraId !== auraId || event.turnId !== turnId) continue;
      if (event.requestId) requestId = event.requestId;
      if (event.threadId || event.params?.threadId) threadId = event.threadId || event.params.threadId;
      if (event.method === "item/agentMessage/delta") {
        deltaText += String(event.params?.delta || "");
        itemId = event.itemId || event.params?.itemId || itemId;
      }
      if (event.method === "item/completed" && event.params?.item?.type === "agentMessage" && typeof event.params.item.text === "string") {
        completedText = event.params.item.text;
        itemId = event.params.item.id || event.itemId || itemId;
      }
      if (event.method === "turn/completed") terminalEvent = event;
    }
    const rawTerminalStatus = terminalEvent?.params?.turn?.status;
    const normalizedTerminalStatus = String(
      rawTerminalStatus && typeof rawTerminalStatus === "object" ? rawTerminalStatus.type : rawTerminalStatus || ""
    ).toLowerCase();
    let status = "unknown";
    if (terminalEvent) {
      if (["completed", "succeeded", "success"].includes(normalizedTerminalStatus)) status = "completed";
      else if (["failed", "error"].includes(normalizedTerminalStatus)) status = "failed";
      else if (["interrupted", "cancelled", "canceled"].includes(normalizedTerminalStatus)) status = "interrupted";
    } else if (isActive) {
      status = "active";
    }
    const rawError = terminalEvent?.params?.turn?.error || null;
    const error = rawError && typeof rawError === "object" ? rawError : rawError ? { message: String(rawError) } : null;
    const snapshot = {
      auraId,
      turnId,
      journalId: this.journalId,
      status,
      terminal: Boolean(terminalEvent),
      requestId,
      threadId,
      itemId,
      finalText: completedText === null ? deltaText : completedText,
      error
    };
    if (snapshot.terminal && snapshot.status !== "unknown") {
      writeJsonAtomic(receiptFile, snapshot);
      this.cacheTurn(historyKey, snapshot);
    }
    return snapshot;
  }

  cacheTurn(key, snapshot) {
    this.historicalTurns.set(key, snapshot);
    if (this.historicalTurns.size > 100) this.historicalTurns.delete(this.historicalTurns.keys().next().value);
  }
}

function operationFingerprint(value) {
  return crypto.createHash("sha256").update(JSON.stringify(value)).digest("hex");
}

function validateBrokerOperation(verb, operation) {
  if (!operation || typeof operation !== "object" || Array.isArray(operation)) {
    throw new BridgeError("operation must be an object", 400, "invalid_operation");
  }
  const type = String(operation.type || "");
  if (verb === "context" && type !== "getAuraContext") throw new BridgeError("context only accepts getAuraContext", 400, "operation_not_allowed");
  if (verb === "inspect" && !INSPECT_OPERATION_TYPES.has(type)) throw new BridgeError(`inspect operation is not allowed: ${type}`, 400, "operation_not_allowed");
  if (verb === "apply" && !APPLY_OPERATION_TYPES.has(type)) throw new BridgeError(`apply operation is not allowed: ${type}`, 400, "operation_not_allowed");
  if (verb === "apply" && type === "executePlan") {
    const ops = operation.plan?.ops;
    if (!Array.isArray(ops) || !ops.length || ops.length > 50) {
      throw new BridgeError("executePlan requires 1 to 50 operations", 400, "invalid_operation_plan");
    }
    const ids = new Set();
    for (const item of ops) {
      if (!item || typeof item !== "object" || Array.isArray(item)) throw new BridgeError("plan operation must be an object", 400, "invalid_operation_plan");
      const op = String(item.op || "");
      if (!APPLY_OPERATION_TYPES.has(op) || op === "executePlan") throw new BridgeError(`plan operation is not allowed: ${op}`, 400, "operation_not_allowed");
      const id = safeIdentifier(item.id, "operation_id");
      if (ids.has(id)) throw new BridgeError(`duplicate plan operation id: ${id}`, 400, "duplicate_operation_id");
      ids.add(id);
      if (!item.payload || typeof item.payload !== "object" || Array.isArray(item.payload)) {
        throw new BridgeError(`plan operation ${id} requires an object payload`, 400, "invalid_operation_plan");
      }
    }
  }
  if (!["context", "inspect", "apply"].includes(verb)) throw new BridgeError(`unsupported verb: ${verb}`, 400, "invalid_verb");
}

class OperationBroker extends EventEmitter {
  constructor(file, publish) {
    super();
    this.file = file;
    this.data = readJson(file, { version: 1, operations: {} });
    if (!this.data.operations || typeof this.data.operations !== "object") this.data.operations = {};
    this.publish = publish;
  }

  save() {
    writeJsonAtomic(this.file, this.data);
  }

  create({ auraId, requestId, verb, operation }, metadata = {}) {
    safeIdentifier(auraId, "auraId");
    safeIdentifier(requestId, "requestId");
    validateBrokerOperation(verb, operation);
    const input = { auraId, requestId, verb, operation };
    const fingerprint = operationFingerprint(input);
    const existing = this.data.operations[requestId];
    if (existing) {
      if (existing.fingerprint !== fingerprint) throw new BridgeError("requestId was already used for another operation", 409, "request_id_conflict");
      return { record: existing, created: false };
    }
    const now = new Date().toISOString();
    const record = {
      ...input,
      fingerprint,
      controllerProfile: CONTROLLER_PROFILE_DIRS[metadata.controllerProfile] || metadata.controllerProfile || "",
      status: "pending",
      result: null,
      error: null,
      cancelRequested: false,
      createdAt: now,
      updatedAt: now
    };
    this.data.operations[requestId] = record;
    this.#prune();
    this.save();
    const event = this.publish({ type: "operation.request", auraId, requestId, operation: { verb, ...operation } });
    record.eventId = event.eventId;
    this.save();
    this.emit(`change:${requestId}`, record);
    return { record, created: true };
  }

  get(requestId, auraId = "") {
    this.#expireStaleReads();
    const record = this.data.operations[requestId] || null;
    if (record && auraId && record.auraId !== auraId) throw new BridgeError("operation does not belong to aura", 404, "operation_not_found");
    return record;
  }

  respond({ auraId, requestId, status, result, error }) {
    const record = this.get(requestId, auraId);
    if (!record) throw new BridgeError("operation not found", 404, "operation_not_found");
    if (!["pending", "completed", "error"].includes(status)) throw new BridgeError("invalid operation status", 400, "invalid_operation_status");
    if (["completed", "error"].includes(record.status)) return record;
    record.status = status;
    if (result !== undefined) record.result = result;
    if (error !== undefined) record.error = typeof error === "string" ? { message: error } : error;
    record.updatedAt = new Date().toISOString();
    this.save();
    const event = { type: "operation.status", auraId, requestId, status, error: record.error, cancelRequested: record.cancelRequested };
    if (status === "pending") event.result = record.result;
    this.publish(event);
    this.emit(`change:${requestId}`, record);
    return record;
  }

  requestCancel(auraId, requestId) {
    const record = this.get(requestId, auraId);
    if (!record) throw new BridgeError("operation not found", 404, "operation_not_found");
    if (["completed", "error"].includes(record.status)) return record;
    record.cancelRequested = true;
    record.updatedAt = new Date().toISOString();
    this.save();
    this.publish({ type: "operation.cancel", auraId, requestId });
    this.emit(`change:${requestId}`, record);
    return record;
  }

  wait(requestId, auraId, waitMs = 0) {
    this.#expireStaleReads();
    const record = this.get(requestId, auraId);
    if (!record) throw new BridgeError("operation not found", 404, "operation_not_found");
    if (!waitMs || record.status !== "pending") return Promise.resolve(record);
    return new Promise(resolve => {
      const eventName = `change:${requestId}`;
      const done = value => {
        clearTimeout(timer);
        this.off(eventName, done);
        resolve(value);
      };
      const timer = setTimeout(() => done(this.get(requestId, auraId)), Math.min(30_000, Math.max(1, waitMs)));
      this.on(eventName, done);
    });
  }

  pendingFor(auraIds) {
    this.#expireStaleReads();
    return Object.values(this.data.operations).filter(record => record.status === "pending" && (auraIds.has("*") || auraIds.has(record.auraId)));
  }

  pendingForProfile(profile, resolveProfile = () => "") {
    this.#expireStaleReads();
    const expected = CONTROLLER_PROFILE_DIRS[profile] || profile;
    return Object.values(this.data.operations).filter(record => {
      if (record.status !== "pending") return false;
      const stored = record.controllerProfile || resolveProfile(record.auraId);
      const resolved = CONTROLLER_PROFILE_DIRS[stored] || stored;
      return resolved ? resolved === expected : true;
    });
  }

  countPending() {
    this.#expireStaleReads();
    return Object.values(this.data.operations).filter(record => record.status === "pending").length;
  }

  #expireStaleReads(now = Date.now()) {
    const expired = [];
    for (const record of Object.values(this.data.operations)) {
      if (record.status !== "pending" || !["context", "inspect"].includes(record.verb)) continue;
      const updatedAt = Date.parse(record.updatedAt || record.createdAt || "");
      if (!Number.isFinite(updatedAt) || now - updatedAt < STALE_READ_OPERATION_MS) continue;
      record.status = "error";
      record.result = null;
      record.error = {
        code: "operation_expired",
        message: "The pending read operation expired after 5 minutes."
      };
      record.updatedAt = new Date(now).toISOString();
      expired.push(record);
    }
    if (!expired.length) return;
    this.save();
    for (const record of expired) {
      this.publish({
        type: "operation.status",
        auraId: record.auraId,
        requestId: record.requestId,
        status: record.status,
        error: record.error,
        cancelRequested: record.cancelRequested
      });
      this.emit(`change:${record.requestId}`, record);
    }
  }

  #prune() {
    const terminal = Object.entries(this.data.operations).filter(([, record]) => record.status !== "pending");
    if (terminal.length <= 500) return;
    terminal.sort((a, b) => String(a[1].updatedAt).localeCompare(String(b[1].updatedAt)));
    for (const [requestId] of terminal.slice(0, terminal.length - 500)) delete this.data.operations[requestId];
  }
}

function commandActivity(command) {
  const value = String(command || "").trim();
  const canvasMatch = value.match(/auralis-canvas(?:-cli)?(?:\.cmd|\.js)?["']?\s+(context|inspect|apply|wait|cancel)\b/i);
  if (canvasMatch) {
    const labels = {
      context: "读取 Auralis 画布",
      inspect: "检查 Auralis 画布",
      apply: "提交 Auralis 画布操作",
      wait: "等待 Auralis 画布操作",
      cancel: "取消 Auralis 画布操作"
    };
    return { stage: "canvas", text: labels[canvasMatch[1].toLowerCase()] || "调用 Auralis CLI", category: "auralis-cli" };
  }
  if (/\b(?:rg|findstr)\b|Get-Content|Select-String|read_mcp_resource/i.test(value)) {
    return { stage: "codex", text: "读取工作规则与项目资料", category: "local-read" };
  }
  return { stage: "codex", text: "执行本地步骤", category: "local-command" };
}

function sanitizeItem(item) {
  if (!item || typeof item !== "object") return null;
  const safe = { id: item.id || null, type: item.type || "unknown" };
  if (item.status !== undefined) safe.status = item.status;
  if (item.type === "agentMessage" && typeof item.text === "string") safe.text = item.text;
  if (item.type === "reasoning") {
    safe.activity = { stage: "codex", text: "分析当前任务", category: "reasoning" };
  }
  if (item.type === "commandExecution") {
    safe.activity = commandActivity(item.command);
    if (item.durationMs !== null && item.durationMs !== undefined && Number.isFinite(Number(item.durationMs))) safe.durationMs = Number(item.durationMs);
    if (item.exitCode !== null && item.exitCode !== undefined && Number.isFinite(Number(item.exitCode))) safe.exitCode = Number(item.exitCode);
  }
  if (item.type === "mcpToolCall") {
    safe.activity = { stage: "tool", text: "调用本地工具", category: "mcp-tool" };
    if (item.durationMs !== null && item.durationMs !== undefined && Number.isFinite(Number(item.durationMs))) safe.durationMs = Number(item.durationMs);
    if (item.error) safe.failed = true;
  }
  if (item.type === "fileChange") safe.activity = { stage: "codex", text: "更新工作文件", category: "file-change" };
  return safe;
}

function sanitizeCodexNotification(message) {
  const method = message.method;
  if (!SAFE_CODEX_NOTIFICATIONS.has(method)) return null;
  const params = message.params || {};
  if (method === "error") {
    return { method, threadId: params.threadId || null, turnId: params.turnId || null,
      params: { message: String(params.error?.message || params.message || "Agent error"), willRetry: params.willRetry === true } };
  }
  if (method === "item/agentMessage/delta") {
    return { method, threadId: params.threadId, turnId: params.turnId, itemId: params.itemId, params: { threadId: params.threadId, turnId: params.turnId, itemId: params.itemId, delta: String(params.delta || "") } };
  }
  if (method === "item/started" || method === "item/completed") {
    const item = sanitizeItem(params.item);
    if (!item) return null;
    return { method, threadId: params.threadId, turnId: params.turnId, itemId: item.id, params: { threadId: params.threadId, turnId: params.turnId, item, ...(params.startedAtMs ? { startedAtMs: params.startedAtMs } : {}), ...(params.completedAtMs ? { completedAtMs: params.completedAtMs } : {}) } };
  }
  if (method === "turn/started" || method === "turn/completed") {
    const turn = params.turn || {};
    return { method, threadId: params.threadId, turnId: turn.id, params: { threadId: params.threadId, turn: { id: turn.id || null, status: turn.status || null, error: turn.error?.message ? { message: turn.error.message } : null, startedAt: turn.startedAt ?? null, completedAt: turn.completedAt ?? null } } };
  }
  if (method === "thread/status/changed") {
    return { method, threadId: params.threadId, params: { threadId: params.threadId, status: params.status || null } };
  }
  return { method, threadId: params.threadId || null, turnId: params.turnId || null, params: { message: String(params.message || params.error?.message || method) } };
}

class BridgeCore extends EventEmitter {
  constructor({ supervisor, threads, journal, profileResolver = null }) {
    super();
    this.supervisor = supervisor;
    this.threads = threads;
    this.journal = journal;
    this.loadedGeneration = new Map();
    this.completedTurns = new Set();
    this.turnOutputs = new Map();
    this.pendingDelta = null;
    this.deltaTimer = null;
    this.auraQueues = new Map();
    this.mobsProfileQueue = null;
    this.profileResolver = profileResolver || ((profile, auraId) => ({ id: profile || "auralis-core", cwd: null, sandbox: "read-only", profileRevision: "", developerInstructions: "" }));
    supervisor.on("started", () => this.loadedGeneration.clear());
    supervisor.on("exit", error => this.#handleSupervisorExit(error));
    supervisor.on("notification", message => this.#handleNotification(message));
  }

  publish(value) {
    if (value.type === "codex.event" && value.method === "item/agentMessage/delta") {
      const pending = this.pendingDelta;
      if (pending && ["auraId", "threadId", "turnId", "itemId", "requestId"].some(key => pending[key] !== value[key]))
        this.flushDelta();
      if (this.pendingDelta) this.pendingDelta.params.delta += value.params.delta;
      else {
        this.pendingDelta = { ...value, params: { ...value.params } };
        this.deltaTimer = setTimeout(() => this.flushDelta(), 200);
        this.deltaTimer.unref?.();
      }
      if (this.pendingDelta.params.delta.length >= 2048) this.flushDelta();
      return null;
    }
    this.flushDelta();
    return this.emitEvent(value);
  }

  emitEvent(value) {
    const event = this.journal.append(value);
    this.emit("event", event);
    return event;
  }

  flushDelta() {
    clearTimeout(this.deltaTimer);
    this.deltaTimer = null;
    const pending = this.pendingDelta;
    this.pendingDelta = null;
    if (pending) this.emitEvent(pending);
  }

  async ensureThread(auraId, options = {}) {
    safeIdentifier(auraId, "auraId");
    await this.supervisor.ensureStarted();
    let entry = this.threads.getAura(auraId);
    const storedProfile = CONTROLLER_PROFILE_DIRS[entry?.profile] || entry?.profile;
    if (storedProfile && options.profile && storedProfile !== options.profile) {
      throw new BridgeError("aura controller profile cannot change", 409, "aura_profile_conflict");
    }
    // Native compaction retains this thread and its summary; no conversation reset.
    // Apply only to drama controllers, including threads resumed after an upgrade.
    const contextConfig = (options.profile || storedProfile || "").startsWith("drama-")
      ? { config: { model_auto_compact_token_limit: 128000 } } : {};
    const requestedCwd = options.cwd || entry?.cwd || null;
    const requestedSandbox = options.sandbox || entry?.sandbox || "read-only";
    const environmentChanged = !!entry?.threadId && (
      (entry.cwd || null) !== requestedCwd
      || (entry.sandbox || "read-only") !== requestedSandbox
    );
    if (environmentChanged && entry.activeTurnId) {
      const replacedThreadId = entry.threadId;
      try {
        if (entry.activeTurnId) {
          await this.supervisor.request("turn/interrupt", { threadId: entry.threadId, turnId: entry.activeTurnId });
        }
        await this.supervisor.request("thread/archive", { threadId: entry.threadId });
      } catch (error) {
        this.publish({ type: "bridge.warning", auraId, requestId: null, message: `Could not archive Codex thread after its controller workspace changed: ${error.message}` });
        throw new BridgeError("could not safely switch the controller workspace while the previous thread is still available", 503, "controller_workspace_switch_failed");
      }
      this.loadedGeneration.delete(entry.threadId);
      this.threads.removeAura(auraId);
      entry = { ...entry, threadId: null, previousThreadId: replacedThreadId, activeTurnId: null, activeRequestId: null };
    }
    const profileRevisionChanged = !!entry?.threadId
      && !!options.profileRevision
      && entry.profileRevision !== options.profileRevision;
    if (entry?.threadId && (profileRevisionChanged || environmentChanged) && !entry.activeTurnId) {
      const previousThreadId = entry.threadId;
      let forked;
      try {
        forked = await this.supervisor.request("thread/fork", {
          ...contextConfig,
          threadId: previousThreadId,
          cwd: requestedCwd || undefined,
          approvalPolicy: "never",
          sandbox: requestedSandbox,
          ephemeral: false,
          ...(options.model ? { model: options.model } : {}),
          ...(options.baseInstructions ? { baseInstructions: options.baseInstructions } : {}),
          ...(options.developerInstructions ? { developerInstructions: options.developerInstructions } : {})
        });
      } catch (error) {
        throw new BridgeError(
          `could not reload controller workspace or rules: ${error.message}`,
          503,
          environmentChanged ? "controller_workspace_switch_failed" : "controller_profile_reload_failed"
        );
      }
      const threadId = forked?.thread?.id;
      if (!threadId) throw new BridgeError("thread/fork returned no thread id", 502, "invalid_app_server_response");
      try {
        await this.supervisor.request("thread/archive", { threadId: previousThreadId });
      } catch (error) {
        try {
          await this.supervisor.request("thread/archive", { threadId });
        } catch (cleanupError) {
          this.publish({ type: "bridge.warning", auraId, requestId: null, message: `Could not clean up a forked Codex thread after reload failed: ${cleanupError.message}` });
        }
        throw new BridgeError(
          `could not retire the previous Codex thread after reload: ${error.message}`,
          503,
          environmentChanged ? "controller_workspace_switch_failed" : "controller_profile_reload_failed"
        );
      }
      entry = this.threads.setAura(auraId, {
        threadId,
        previousThreadId,
        profile: options.profile || entry.profile || "standard",
        cwd: requestedCwd,
        sandbox: requestedSandbox,
        profileRevision: options.profileRevision,
        activeTurnId: null,
        activeRequestId: null,
        createdAt: entry.createdAt || new Date().toISOString()
      });
      this.loadedGeneration.delete(previousThreadId);
      this.loadedGeneration.set(threadId, this.supervisor.generation);
      return entry;
    }
    if (entry?.threadId
      && this.loadedGeneration.get(entry.threadId) === this.supervisor.generation
      && (!profileRevisionChanged || entry.activeTurnId)) return entry;
    if (entry?.threadId) {
      try {
        const resumed = await this.supervisor.request("thread/resume", {
          ...contextConfig,
          threadId: entry.threadId,
          cwd: requestedCwd || undefined,
          approvalPolicy: "never",
          sandbox: requestedSandbox,
          ...(options.developerInstructions ? { developerInstructions: options.developerInstructions } : {})
        });
        const resumedIdle = resumed?.thread?.status?.type === "idle";
        const patch = {
          profile: options.profile || entry.profile || "standard",
          cwd: requestedCwd,
          sandbox: requestedSandbox,
          profileRevision: profileRevisionChanged ? entry.profileRevision || "" : options.profileRevision || entry.profileRevision || ""
        };
        if (resumedIdle) Object.assign(patch, { activeTurnId: null, activeRequestId: null });
        entry = this.threads.setAura(auraId, patch);
        this.loadedGeneration.set(entry.threadId, this.supervisor.generation);
        if (resumedIdle && profileRevisionChanged) return this.ensureThread(auraId, options);
        return entry;
      } catch (error) {
        this.publish({ type: "bridge.warning", auraId, requestId: null, message: `Could not resume Codex thread; starting a new one: ${error.message}` });
      }
    }
    const started = await this.supervisor.request("thread/start", {
      ...contextConfig,
      cwd: requestedCwd || undefined,
      approvalPolicy: "never",
      sandbox: requestedSandbox,
      ephemeral: false,
      ...(options.model ? { model: options.model } : {}),
      ...(options.baseInstructions ? { baseInstructions: options.baseInstructions } : {}),
      ...(options.developerInstructions ? { developerInstructions: options.developerInstructions } : {})
    });
    const threadId = started?.thread?.id;
    if (!threadId) throw new BridgeError("thread/start returned no thread id", 502, "invalid_app_server_response");
    entry = this.threads.setAura(auraId, {
      threadId,
      previousThreadId: entry?.threadId || entry?.previousThreadId || null,
      profile: options.profile || entry?.profile || "standard",
      cwd: requestedCwd,
      sandbox: requestedSandbox,
      profileRevision: options.profileRevision || "",
      activeTurnId: null,
      activeRequestId: null,
      createdAt: entry?.createdAt || new Date().toISOString()
    });
    this.loadedGeneration.set(threadId, this.supervisor.generation);
    return entry;
  }

  startTurn(auraId, body) {
    const task = () => this.#forAura(auraId, () => this.#startTurn(auraId, body));
    const requestedProfile = CONTROLLER_PROFILE_DIRS[String(body?.profile || "auralis-core").trim()];
    return requestedProfile === "the-mobs" ? this.#forMobsProfile(task) : task();
  }

  async #startTurn(auraId, body) {
    const requestId = safeIdentifier(body.requestId, "requestId");
    const existing = this.threads.getTurnRequest(requestId);
    if (existing) {
      if (existing.auraId !== auraId) throw new BridgeError("requestId belongs to another aura", 409, "request_id_conflict");
      return existing.result;
    }
    const input = normalizeUserInput(body.input);
    const mode = body.mode || "auto";
    if (!["auto", "start", "steer"].includes(mode)) throw new BridgeError("invalid turn mode", 400, "invalid_turn_mode");
    const requestedProfile = CONTROLLER_PROFILE_DIRS[String(body.profile || "auralis-core").trim()];
    if (!requestedProfile) throw new BridgeError(`unknown controller profile: ${String(body.profile || "auralis-core").trim()}`, 400, "invalid_controller_profile");
    const currentEntry = this.threads.getAura(auraId);
    const storedProfile = CONTROLLER_PROFILE_DIRS[currentEntry?.profile] || currentEntry?.profile;
    if (storedProfile && storedProfile !== requestedProfile) {
      throw new BridgeError("aura controller profile cannot change", 409, "aura_profile_conflict");
    }
    if (body.expectedTurnId && currentEntry?.activeTurnId !== body.expectedTurnId) {
      throw new BridgeError("active turn does not match expectedTurnId", 409, "turn_precondition_failed");
    }
    if (mode === "steer" && !currentEntry?.activeTurnId) {
      throw new BridgeError("there is no active turn to steer", 409, "no_active_turn");
    }
    const profile = this.profileResolver(requestedProfile, auraId);
    const threadOptions = {
      ...body,
      profile: profile.id,
      cwd: profile.cwd,
      sandbox: profile.sandbox,
      profileRevision: profile.profileRevision,
      developerInstructions: [profile.id.startsWith("drama-") && body.completeDramaInstructions && String(body.developerInstructions || "").trim()
        ? "Use the dedicated drama CLI from turn context; do not load the general canvas controller instructions."
        : profile.developerInstructions, String(body.developerInstructions || "").trim()].filter(Boolean).join("\n\n")
    };
    const entry = await this.ensureThread(auraId, threadOptions);
    if (body.expectedTurnId && entry.activeTurnId !== body.expectedTurnId) throw new BridgeError("active turn does not match expectedTurnId", 409, "turn_precondition_failed");
    let turnId;
    let status;
    if ((mode === "auto" && entry.activeTurnId) || mode === "steer") {
      if (!entry.activeTurnId) throw new BridgeError("there is no active turn to steer", 409, "no_active_turn");
      this.threads.setAura(auraId, { activeRequestId: requestId });
      let steered;
      try {
        steered = await this.supervisor.request("turn/steer", {
          threadId: entry.threadId,
          input,
          expectedTurnId: body.expectedTurnId || entry.activeTurnId,
          clientUserMessageId: requestId
        });
      } catch (error) {
        this.threads.setAura(auraId, { activeRequestId: entry.activeRequestId || null });
        throw error;
      }
      turnId = steered?.turnId || entry.activeTurnId;
      status = "steered";
    } else {
      this.threads.setAura(auraId, { activeRequestId: requestId });
      let started;
      try {
        started = await this.supervisor.request("turn/start", {
          threadId: entry.threadId,
          input,
          clientUserMessageId: requestId,
          ...(entry.cwd ? { cwd: entry.cwd } : {}),
          ...(body.model ? { model: body.model } : {}),
          ...(normalizeReasoningEffort(body.reasoningEffort) ? { effort: normalizeReasoningEffort(body.reasoningEffort) } : {})
        });
      } catch (error) {
        this.threads.setAura(auraId, { activeRequestId: entry.activeRequestId || null });
        throw error;
      }
      turnId = started?.turn?.id;
      if (!turnId) throw new BridgeError("turn/start returned no turn id", 502, "invalid_app_server_response");
      status = "started";
    }
    const result = { auraId, requestId, threadId: entry.threadId, turnId, status };
    this.threads.acceptTurn(auraId, requestId, result, !this.completedTurns.has(turnId));
    if (this.threads.lastSaveError) {
      this.publish({ type: "bridge.warning", auraId, requestId, message: "消息已发送，会话状态正在重试保存，请勿重复发送。", error: { code: this.threads.lastSaveError.code, message: this.threads.lastSaveError.message } });
    }
    return result;
  }

  interrupt(auraId, body) {
    return this.#forAura(auraId, () => this.#interrupt(auraId, body));
  }

  async #interrupt(auraId, body) {
    const requestId = safeIdentifier(body.requestId, "requestId");
    const entry = this.threads.getAura(auraId);
    if (!entry?.threadId) throw new BridgeError("aura has no Codex thread", 404, "thread_not_found");
    const turnId = body.turnId || entry.activeTurnId;
    if (!turnId) return { auraId, requestId, threadId: entry.threadId, turnId: null, status: "idle" };
    if (entry.activeTurnId && turnId !== entry.activeTurnId) throw new BridgeError("turn is not active for aura", 409, "turn_precondition_failed");
    try {
      await this.supervisor.request("turn/interrupt", { threadId: entry.threadId, turnId });
    } catch (error) {
      // A restarted app-server may no longer own the persisted thread.
      if (!/^thread not found:/i.test(error.message)) throw error;
    }
    if (!this.completedTurns.has(turnId)) {
      this.publish({ type: "codex.event", auraId, requestId: entry.activeRequestId, threadId: entry.threadId, turnId,
        method: "turn/completed", params: { threadId: entry.threadId, turn: { id: turnId, status: "interrupted" } } });
      this.completedTurns.add(turnId);
    }
    this.threads.setAura(auraId, { activeTurnId: null, activeRequestId: null });
    return { auraId, requestId, threadId: entry.threadId, turnId, status: "interrupted" };
  }

  archive(auraId, body) {
    return this.#forAura(auraId, () => this.#archive(auraId, body));
  }

  resetControllerProfile(body, prepareReset, hasPendingOperations = () => false) {
    return this.#forMobsProfile(async () => {
      const requestId = safeIdentifier(body.requestId, "requestId");
      const existing = this.threads.getResetRequest(requestId);
      if (existing) {
        if (existing.profile !== "the-mobs") throw new BridgeError("requestId belongs to another controller profile", 409, "request_id_conflict");
        return existing.result;
      }
      const mobsEntries = this.threads.entries().filter(([, entry]) => (CONTROLLER_PROFILE_DIRS[entry?.profile] || entry?.profile) === "the-mobs");
      if (mobsEntries.some(([, entry]) => entry.activeTurnId)) {
        throw new BridgeError("cannot reset shared controller profile while a The Mobs turn is active", 409, "controller_profile_reset_busy");
      }
      if (hasPendingOperations()) {
        throw new BridgeError("cannot reset shared controller profile while canvas operations are pending", 409, "controller_profile_reset_blocked");
      }
      const prepared = prepareReset();
      try {
        const profile = prepared.commit();
        const result = {
          ...profile,
          affectedThreadCount: mobsEntries.length,
          archivedThreadId: null,
          archivedThreadIds: []
        };
        this.threads.setResetRequest(requestId, { profile: "the-mobs", result });
        return result;
      } finally {
        prepared.discard();
      }
    });
  }

  async #archive(auraId, body) {
    const requestId = safeIdentifier(body.requestId, "requestId");
    const entry = this.threads.getAura(auraId);
    if (!entry?.threadId) return { auraId, requestId, threadId: null, status: "not_found" };
    if (entry.activeTurnId) await this.supervisor.request("turn/interrupt", { threadId: entry.threadId, turnId: entry.activeTurnId });
    await this.supervisor.request("thread/archive", { threadId: entry.threadId });
    this.threads.removeAura(auraId);
    this.loadedGeneration.delete(entry.threadId);
    return { auraId, requestId, threadId: entry.threadId, status: "archived" };
  }

  waitForTurn(turnId, timeoutMs = 180_000) {
    const state = this.turnOutputs.get(turnId);
    if (state?.done) return state.error ? Promise.reject(new Error(state.error)) : Promise.resolve(state.text);
    return new Promise((resolve, reject) => {
      const event = `turnDone:${turnId}`;
      const timer = setTimeout(() => {
        this.off(event, finish);
        reject(new BridgeError("turn completion timed out", 504, "turn_timeout"));
      }, timeoutMs);
      const finish = value => {
        clearTimeout(timer);
        if (value.error) reject(new Error(value.error)); else resolve(value.text);
      };
      this.once(event, finish);
    });
  }

  #forAura(auraId, task) {
    const previous = this.auraQueues.get(auraId) || Promise.resolve();
    const current = previous.catch(() => {}).then(task);
    this.auraQueues.set(auraId, current);
    return current.finally(() => {
      if (this.auraQueues.get(auraId) === current) this.auraQueues.delete(auraId);
    });
  }

  #forMobsProfile(task) {
    const previous = this.mobsProfileQueue || Promise.resolve();
    const current = previous.catch(() => {}).then(task);
    this.mobsProfileQueue = current;
    return current.finally(() => {
      if (this.mobsProfileQueue === current) this.mobsProfileQueue = null;
    });
  }

  #handleSupervisorExit(error) {
    this.loadedGeneration.clear();
    for (const [auraId, entry] of this.threads.entries()) {
      if (!entry.activeTurnId) continue;
      const state = this.turnOutputs.get(entry.activeTurnId) || { text: "", done: false, error: null };
      state.done = true;
      state.error = error.message || "Codex app-server stopped";
      this.turnOutputs.set(entry.activeTurnId, state);
      this.emit(`turnDone:${entry.activeTurnId}`, state);
      this.publish({
        type: "codex.event",
        auraId,
        requestId: entry.activeRequestId || null,
        threadId: entry.threadId,
        turnId: entry.activeTurnId,
        itemId: null,
        method: "turn/completed",
        params: {
          threadId: entry.threadId,
          turn: { id: entry.activeTurnId, status: "failed", error: { code: "app_server_exited", message: state.error }, startedAt: null, completedAt: Math.floor(Date.now() / 1000) }
        }
      });
      this.threads.setAura(auraId, { activeTurnId: null, activeRequestId: null }, { deferOnFailure: true });
    }
  }

  #handleNotification(message) {
    const safe = sanitizeCodexNotification(message);
    const raw = message.params || {};
    const threadId = safe?.threadId || raw.threadId;
    const auraId = threadId ? this.threads.findAuraByThread(threadId) : null;
    if (!auraId) return;
    const turnId = safe?.turnId || raw.turnId || raw.turn?.id || null;
    const entry = this.threads.getAura(auraId);
    if (message.method === "turn/started" && turnId) this.threads.setAura(auraId, { activeTurnId: turnId }, { deferOnFailure: true });
    if (message.method === "item/agentMessage/delta" && turnId) {
      const state = this.turnOutputs.get(turnId) || { text: "", done: false, error: null };
      state.text += String(raw.delta || "");
      this.turnOutputs.set(turnId, state);
    }
    if (message.method === "item/completed" && raw.item?.type === "agentMessage" && turnId && typeof raw.item.text === "string") {
      const state = this.turnOutputs.get(turnId) || { text: "", done: false, error: null };
      if (!state.text) state.text = raw.item.text;
      this.turnOutputs.set(turnId, state);
    }
    if (message.method === "turn/completed" && turnId) {
      this.completedTurns.add(turnId);
      if (this.completedTurns.size > 500) this.completedTurns.delete(this.completedTurns.values().next().value);
      const state = this.turnOutputs.get(turnId) || { text: "", done: false, error: null };
      state.done = true;
      state.error = raw.turn?.status === "failed" ? raw.turn?.error?.message || "Codex turn failed" : null;
      this.turnOutputs.set(turnId, state);
      if (entry?.activeTurnId === turnId) this.threads.setAura(auraId, { activeTurnId: null, activeRequestId: null }, { deferOnFailure: true });
      this.emit(`turnDone:${turnId}`, state);
      setTimeout(() => this.turnOutputs.delete(turnId), 300_000).unref?.();
    }
    if (!safe) return;
    this.publish({
      type: "codex.event",
      auraId,
      requestId: entry?.activeRequestId || null,
      threadId: safe.threadId || threadId,
      turnId,
      itemId: safe.itemId || null,
      method: safe.method,
      params: safe.params
    });
  }
}

function encodeWebSocketFrame(value, opcode = 0x1) {
  const payload = Buffer.isBuffer(value) ? value : Buffer.from(String(value), "utf8");
  let header;
  if (payload.length < 126) {
    header = Buffer.from([0x80 | opcode, payload.length]);
  } else if (payload.length <= 0xffff) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 126;
    header.writeUInt16BE(payload.length, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(payload.length), 2);
  }
  return Buffer.concat([header, payload]);
}

function createWebSocketParser(socket, onMessage) {
  let buffer = Buffer.alloc(0);
  let fragmentedOpcode = null;
  let fragments = [];
  let fragmentedBytes = 0;
  let closed = false;
  const closeWithCode = code => {
    if (closed) return;
    closed = true;
    const payload = Buffer.alloc(2);
    payload.writeUInt16BE(code);
    socket.end(encodeWebSocketFrame(payload, 0x8));
  };
  return chunk => {
    if (closed) return;
    buffer = Buffer.concat([buffer, chunk]);
    while (buffer.length >= 2) {
      const first = buffer[0];
      const second = buffer[1];
      const fin = Boolean(first & 0x80);
      const reserved = first & 0x70;
      const opcode = first & 0x0f;
      const masked = Boolean(second & 0x80);
      let length = second & 0x7f;
      const lengthCode = length;
      let offset = 2;
      if (reserved || !masked) return closeWithCode(1002);
      if (length === 126) {
        if (buffer.length < 4) return;
        length = buffer.readUInt16BE(2);
        offset = 4;
      } else if (length === 127) {
        if (buffer.length < 10) return;
        const wide = buffer.readBigUInt64BE(2);
        if (wide > BigInt(MAX_WS_BYTES)) return closeWithCode(1009);
        length = Number(wide);
        offset = 10;
      }
      const control = opcode >= 0x8;
      if ((control && (!fin || lengthCode >= 126 || length > 125)) || ![0x0, 0x1, 0x8, 0x9, 0xA].includes(opcode)) return closeWithCode(1002);
      if (length > MAX_WS_BYTES) return closeWithCode(1009);
      if (buffer.length < offset + 4 + length) return;
      const mask = buffer.subarray(offset, offset + 4);
      offset += 4;
      const payload = Buffer.from(buffer.subarray(offset, offset + length));
      buffer = buffer.subarray(offset + length);
      for (let index = 0; index < payload.length; index += 1) payload[index] ^= mask[index % 4];
      if (opcode === 0x8) {
        if (payload.length === 1) return closeWithCode(1002);
        closed = true;
        socket.end(encodeWebSocketFrame(payload, 0x8));
        return;
      }
      if (opcode === 0x9) {
        socket.write(encodeWebSocketFrame(payload, 0xA));
        continue;
      }
      if (opcode === 0xA) continue;
      if (opcode === 0x1) {
        if (fragmentedOpcode !== null) return closeWithCode(1002);
        if (fin) {
          onMessage(payload.toString("utf8"));
          continue;
        }
        fragmentedOpcode = opcode;
        fragments = [payload];
        fragmentedBytes = payload.length;
        continue;
      }
      if (fragmentedOpcode === null) return closeWithCode(1002);
      fragmentedBytes += payload.length;
      if (fragmentedBytes > MAX_WS_BYTES) return closeWithCode(1009);
      fragments.push(payload);
      if (!fin) continue;
      const message = Buffer.concat(fragments, fragmentedBytes);
      fragmentedOpcode = null;
      fragments = [];
      fragmentedBytes = 0;
      onMessage(message.toString("utf8"));
    }
  };
}

function createBridge(options = {}) {
  const host = options.host || process.env.CREATION_CRAZE_BRIDGE_HOST || DEFAULT_HOST;
  if (!["127.0.0.1", "::1", "localhost"].includes(host)) throw new BridgeError("bridge must bind to loopback", 500, "non_loopback_host");
  const port = Number(options.port ?? process.env.CREATION_CRAZE_BRIDGE_PORT ?? DEFAULT_PORT);
  const workspace = options.workspace || process.env.CREATION_CRAZE_WORKSPACE || path.resolve(__dirname, "..");
  const runtimeRoot = options.runtimeRoot || process.env.AURALIS_RUNTIME_ROOT || path.resolve(__dirname, "..");
  const dataDir = options.dataDir || process.env.AURALIS_DATA_DIR || defaultDataDir();
  const tokenFile = options.tokenFile || process.env.AURALIS_BRIDGE_TOKEN_FILE || path.join(dataDir, "bridge-token");
  const token = loadOrCreateToken(tokenFile, options.token || process.env.AURALIS_BRIDGE_TOKEN || process.env.CREATION_CRAZE_BRIDGE_TOKEN);
  const codexPath = options.codexPath || process.env.CODEX_CLI_PATH || findCodexCli();
  const appServerArgs = ["app-server"];
  const pathKey = Object.keys(process.env).find(key => key.toLowerCase() === "path") || "PATH";
  const runtimePath = [path.join(runtimeRoot, "tools"), path.join(runtimeRoot, "node"), process.env[pathKey] || ""].filter(Boolean).join(path.delimiter);
  const supervisor = options.supervisor || new AppServerSupervisor({
    command: options.appServerCommand || codexPath,
    args: options.appServerArgs || appServerArgs,
    cwd: workspace,
    env: {
      AURALIS_BRIDGE_URL: `http://${host}:${port || DEFAULT_PORT}`,
      AURALIS_BRIDGE_TOKEN: token,
      AURALIS_BRIDGE_TOKEN_FILE: tokenFile,
      AURALIS_DATA_DIR: dataDir,
      AURALIS_RUNTIME_ROOT: runtimeRoot,
      AURALIS_CONTROLLER_PACK_ROOT: path.join(runtimeRoot, "controller-packs"),
      CODEX_CLI_PATH: codexPath,
      AURALIS_CANVAS_CLI: path.join(runtimeRoot, "tools", "auralis-canvas-cli.js"),
      [pathKey]: runtimePath,
      ...(options.appServerEnv || {})
    },
    timeoutMs: options.rpcTimeoutMs || DEFAULT_RPC_TIMEOUT_MS,
    spawnFn: options.spawnFn
  });
  const threads = new ThreadStore(path.join(dataDir, "codex-threads.json"));
  const journal = new EventJournal(path.join(dataDir, "events", "bridge-events.jsonl"));
  const controllerProfiles = new ControllerProfileStore({ dataDir, runtimeRoot });
  const core = new BridgeCore({
    supervisor,
    threads,
    journal,
    profileResolver: (profile, auraId) => profile.startsWith("drama-") ? resolveControllerProfile(runtimeRoot, profile, options.dramaRoot) : controllerProfiles.resolve(auraId, profile, {
      upgradeUncustomized: !threads.entries().some(([, entry]) => (
        (CONTROLLER_PROFILE_DIRS[entry?.profile] || entry?.profile) === "the-mobs" && entry.activeTurnId
      ))
    })
  });
  let closing = false;
  let bridgeApi = null;
  let restartTimer = null;
  let restartAttempt = 0;
  const exitFn = options.exitFn || (require.main === module ? code => process.exit(code) : () => {});
  supervisor.on("started", () => {
    restartAttempt = 0;
    if (restartTimer) clearTimeout(restartTimer);
    restartTimer = null;
  });
  supervisor.on("exit", () => {
    if (closing || restartTimer) return;
    restartAttempt += 1;
    const delay = Math.min(10_000, 500 * (2 ** Math.min(restartAttempt - 1, 5)));
    restartTimer = setTimeout(() => {
      restartTimer = null;
      supervisor.ensureStarted().catch(() => {});
    }, delay);
    restartTimer.unref?.();
  });
  const sockets = new Set();
  const auraExecutors = new Map();
  let broker = null;
  const clientAcceptsAura = (client, auraId) => !!(client?.registered && (client.auraIds.has(auraId) || client.auraIds.has("*")));
  const executorForAura = auraId => {
    const current = auraExecutors.get(auraId);
    if (current && sockets.has(current) && clientAcceptsAura(current, auraId)) return current;
    auraExecutors.delete(auraId);
    const next = [...sockets].find(client => clientAcceptsAura(client, auraId)) || null;
    if (next) auraExecutors.set(auraId, next);
    return next;
  };
  const sendSocketEvent = (client, event) => {
    try {
      client.socket.write(encodeWebSocketFrame(JSON.stringify(event)));
      return true;
    } catch (_) {
      return false;
    }
  };
  const broadcast = event => {
    if (["operation.request", "operation.cancel"].includes(event.type)) {
      const executor = executorForAura(event.auraId);
      if (executor) sendSocketEvent(executor, event);
      return;
    }
    for (const client of sockets) {
      if (!client.registered || (!client.auraIds.has(event.auraId) && !client.auraIds.has("*"))) continue;
      sendSocketEvent(client, event);
    }
  };
  core.on("event", broadcast);
  broker = new OperationBroker(path.join(dataDir, "operations.json"), value => core.publish(value));

  const sendPendingOperations = (client, auraId) => {
    if (!client || executorForAura(auraId) !== client) return;
    for (const record of broker.pendingFor(new Set([auraId]))) {
      sendSocketEvent(client, {
        type: "operation.request",
        auraId: record.auraId,
        requestId: record.requestId,
        operation: { verb: record.verb, ...record.operation },
        createdAt: record.createdAt,
        replayed: true
      });
    }
  };

  const reconcileExecutorLeases = client => {
    const released = [];
    for (const [auraId, owner] of auraExecutors) {
      if (owner === client && !clientAcceptsAura(client, auraId)) {
        auraExecutors.delete(auraId);
        released.push(auraId);
      }
    }
    for (const auraId of client.auraIds || []) {
      if (auraId !== "*") executorForAura(auraId);
    }
    for (const auraId of released) {
      const next = executorForAura(auraId);
      if (next) sendPendingOperations(next, auraId);
    }
  };

  function authorize(req, url) {
    const header = String(req.headers.authorization || "");
    const bearer = header.startsWith("Bearer ") ? header.slice(7) : "";
    const candidate = bearer || url.searchParams.get("token") || "";
    if (!timingSafeEqualText(candidate, token)) throw new BridgeError("invalid bridge token", 401, "invalid_token");
  }

  function sendJson(res, status, value) {
    res.writeHead(status, {
      "Content-Type": "application/json; charset=utf-8",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Auralis-Aura-Id",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Cache-Control": "no-store"
    });
    res.end(status === 204 ? "" : JSON.stringify(value));
  }

  function sendError(res, error) {
    const status = Number(error.status) || 500;
    sendJson(res, status, { error: { code: error.code || "bridge_error", message: error.message || "bridge error" } });
  }

  async function parseJsonBody(req) {
    const raw = await readBody(req);
    try {
      return raw ? JSON.parse(raw) : {};
    } catch (_) {
      throw new BridgeError("invalid JSON body", 400, "invalid_json");
    }
  }

  const server = http.createServer(async (req, res) => {
    try {
      if (req.method === "OPTIONS") return sendJson(res, 204, {});
      const url = new URL(req.url, `http://${host}:${port || DEFAULT_PORT}`);
      authorize(req, url);
      if (closing) throw new BridgeError("bridge is shutting down", 503, "bridge_shutting_down");
      if (req.method === "GET" && (url.pathname === "/status" || url.pathname === "/v1/status")) {
        return sendJson(res, 200, {
          ok: supervisor.status().state === "ready",
          bridgeVersion: BRIDGE_VERSION,
          brokerProtocolVersion: BROKER_PROTOCOL_VERSION,
          journalId: journal.journalId,
          legacyCursorCompatible: journal.legacyCursorCompatible,
          controllerCustomizationVersion: CONTROLLER_CUSTOMIZATION_VERSION,
          tokenRequired: true,
          tokenFile,
          host,
          port: server.address()?.port || port,
          workspace,
          runtimeRoot,
          dataDir,
          codexPath,
          appServer: supervisor.status(),
          auraThreadCount: threads.count(),
          browserCount: sockets.size,
          executorLeaseCount: auraExecutors.size,
          pendingOperationCount: broker.countPending(),
          applyOperationTypes: [...APPLY_OPERATION_TYPES],
          reasoningEfforts: [...reasoningEfforts]
        });
      }
      if (req.method === "POST" && url.pathname === "/v1/shutdown") {
        closing = true;
        sendJson(res, 202, { ok: true, status: "shutting_down", bridgeVersion: BRIDGE_VERSION, runtimeRoot });
        setImmediate(() => {
          bridgeApi.close().then(() => exitFn(0), () => exitFn(1));
        });
        return;
      }
      if (req.method === "GET" && url.pathname === "/v1/models") {
        return sendJson(res, 200, { data: [{ id: "local-codex/app-server", object: "model" }] });
      }
      if (req.method === "GET" && url.pathname === "/v1/controller-profiles/the-mobs") {
        return sendJson(res, 200, controllerProfiles.status());
      }
      if (req.method === "POST" && url.pathname === "/v1/controller-profiles/the-mobs/reset") {
        const body = await parseJsonBody(req);
        const requestId = safeIdentifier(body.requestId, "requestId");
        const expectedRevision = String(body.expectedRevision || "").trim();
        if (!/^[a-f0-9]{64}$/i.test(expectedRevision)) {
          throw new BridgeError("expectedRevision must be the current controller profile revision", 400, "invalid_controller_profile_revision");
        }
        return sendJson(res, 200, await core.resetControllerProfile(
          { requestId },
          () => controllerProfiles.prepareReset("", expectedRevision),
          () => broker.pendingForProfile("the-mobs", auraId => threads.getAura(auraId)?.profile || "").length > 0
        ));
      }
      const controllerProfileMatch = url.pathname.match(/^\/v1\/auras\/([^/]+)\/controller-profile$/);
      if (req.method === "GET" && controllerProfileMatch) {
        const auraId = safeIdentifier(decodeURIComponent(controllerProfileMatch[1]), "auraId");
        const profile = String(url.searchParams.get("profile") || "the-mobs");
        if (profile !== "the-mobs") throw new BridgeError("only the-mobs profile is customizable", 400, "controller_profile_not_editable");
        return sendJson(res, 200, controllerProfiles.status(auraId));
      }
      const controllerProfileResetMatch = url.pathname.match(/^\/v1\/auras\/([^/]+)\/controller-profile\/reset$/);
      if (req.method === "POST" && controllerProfileResetMatch) {
        const auraId = safeIdentifier(decodeURIComponent(controllerProfileResetMatch[1]), "auraId");
        const body = await parseJsonBody(req);
        if (body.profile && body.profile !== "the-mobs") throw new BridgeError("only the-mobs profile is customizable", 400, "controller_profile_not_editable");
        const requestId = safeIdentifier(body.requestId, "requestId");
        const expectedRevision = String(body.expectedRevision || "").trim();
        if (!/^[a-f0-9]{64}$/i.test(expectedRevision)) {
          throw new BridgeError("expectedRevision must be the current controller profile revision", 400, "invalid_controller_profile_revision");
        }
        return sendJson(res, 200, await core.resetControllerProfile(
          { requestId },
          () => controllerProfiles.prepareReset(auraId, expectedRevision),
          () => broker.pendingForProfile("the-mobs", entryAuraId => threads.getAura(entryAuraId)?.profile || "").length > 0
        ));
      }
      const turnMatch = url.pathname.match(/^\/v1\/auras\/([^/]+)\/turn$/);
      if (req.method === "POST" && turnMatch) {
        const auraId = safeIdentifier(decodeURIComponent(turnMatch[1]), "auraId");
        return sendJson(res, 200, await core.startTurn(auraId, await parseJsonBody(req)));
      }
      const turnSnapshotMatch = url.pathname.match(/^\/v1\/auras\/([^/]+)\/turns\/([^/]+)$/);
      if (req.method === "GET" && turnSnapshotMatch) {
        const auraId = safeIdentifier(decodeURIComponent(turnSnapshotMatch[1]), "auraId");
        const turnId = safeIdentifier(decodeURIComponent(turnSnapshotMatch[2]), "turnId");
        const entry = threads.getAura(auraId);
        return sendJson(res, 200, journal.snapshotTurn({
          auraId,
          turnId,
          activeTurnId: entry?.activeTurnId || null,
          activeRequestId: entry?.activeRequestId || null,
          activeThreadId: entry?.threadId || null
        }));
      }
      const interruptMatch = url.pathname.match(/^\/v1\/auras\/([^/]+)\/interrupt$/);
      if (req.method === "POST" && interruptMatch) {
        const auraId = safeIdentifier(decodeURIComponent(interruptMatch[1]), "auraId");
        return sendJson(res, 200, await core.interrupt(auraId, await parseJsonBody(req)));
      }
      const archiveMatch = url.pathname.match(/^\/v1\/auras\/([^/]+)\/archive$/);
      if (req.method === "POST" && archiveMatch) {
        const auraId = safeIdentifier(decodeURIComponent(archiveMatch[1]), "auraId");
        return sendJson(res, 200, await core.archive(auraId, await parseJsonBody(req)));
      }
      if (req.method === "GET" && url.pathname === "/v1/events") {
        const auraId = url.searchParams.get("auraId") || "";
        if (auraId) safeIdentifier(auraId, "auraId");
        const events = journal.replay({ auraId, after: url.searchParams.get("after") || 0, limit: url.searchParams.get("limit") || 500 });
        return sendJson(res, 200, { events, nextEventId: events.at(-1)?.eventId || journal.latestId() });
      }
      if (req.method === "POST" && url.pathname === "/v1/operations") {
        const body = await parseJsonBody(req);
        const controllerProfile = threads.getAura(body.auraId)?.profile || "";
        const created = broker.create(body, { controllerProfile });
        return sendJson(res, created.created ? 202 : 200, created.record);
      }
      const operationMatch = url.pathname.match(/^\/v1\/operations\/([^/]+)$/);
      if (req.method === "GET" && operationMatch) {
        const requestId = safeIdentifier(decodeURIComponent(operationMatch[1]), "requestId");
        const auraId = safeIdentifier(url.searchParams.get("auraId"), "auraId");
        const record = await broker.wait(requestId, auraId, Number(url.searchParams.get("waitMs") || 0));
        return sendJson(res, 200, record);
      }
      const operationResultMatch = url.pathname.match(/^\/v1\/operations\/([^/]+)\/result$/);
      if (req.method === "POST" && operationResultMatch) {
        const requestId = safeIdentifier(decodeURIComponent(operationResultMatch[1]), "requestId");
        const body = await parseJsonBody(req);
        const record = broker.respond({ ...body, requestId });
        return sendJson(res, 200, {
          ok: true,
          requestId: record.requestId,
          status: record.status,
          updatedAt: record.updatedAt,
          ...(record.status === "error" && record.error ? { error: record.error } : {})
        });
      }
      const operationCancelMatch = url.pathname.match(/^\/v1\/operations\/([^/]+)\/cancel$/);
      if (req.method === "POST" && operationCancelMatch) {
        const requestId = safeIdentifier(decodeURIComponent(operationCancelMatch[1]), "requestId");
        const body = await parseJsonBody(req);
        return sendJson(res, 202, broker.requestCancel(safeIdentifier(body.auraId, "auraId"), requestId));
      }
      if (req.method === "POST" && url.pathname === "/v1/chat/completions") {
        const body = await parseJsonBody(req);
        const prompt = messagesToPrompt(body.messages);
        const requestId = safeIdentifier(body.request_id || body.metadata?.requestId || `legacy-${crypto.randomUUID()}`, "requestId");
        const auraId = safeIdentifier(req.headers["x-auralis-aura-id"] || body.aura_id || body.metadata?.auraId || "legacy-default", "auraId");
        const turn = await core.startTurn(auraId, { requestId, input: [{ type: "text", text: prompt, text_elements: [] }], mode: "start", reasoningEffort: body.reasoning_effort });
        const content = await core.waitForTurn(turn.turnId, Number(body.timeout_ms || 180_000));
        return sendJson(res, 200, localCodexChatCompletionResponse(content, prompt));
      }
      return sendJson(res, 404, { error: { code: "not_found", message: "not found" } });
    } catch (error) {
      return sendError(res, error);
    }
  });

  server.on("upgrade", (req, socket) => {
    try {
      const url = new URL(req.url, `http://${host}:${port || DEFAULT_PORT}`);
      if (url.pathname !== "/v1/events") throw new BridgeError("not found", 404, "not_found");
      authorize(req, url);
      if (closing) throw new BridgeError("bridge is shutting down", 503, "bridge_shutting_down");
      const key = req.headers["sec-websocket-key"];
      if (!key || String(req.headers.upgrade || "").toLowerCase() !== "websocket") throw new BridgeError("invalid WebSocket upgrade", 400, "invalid_websocket");
      const accept = crypto.createHash("sha1").update(`${key}258EAFA5-E914-47DA-95CA-C5AB0DC85B11`).digest("base64");
      socket.write([
        "HTTP/1.1 101 Switching Protocols",
        "Upgrade: websocket",
        "Connection: Upgrade",
        `Sec-WebSocket-Accept: ${accept}`,
        "\r\n"
      ].join("\r\n"));
      const client = { socket, registered: false, auraIds: new Set() };
      sockets.add(client);
      socket.setNoDelay(true);
      socket.write(encodeWebSocketFrame(JSON.stringify({ type: "bridge.hello", bridgeVersion: BRIDGE_VERSION, brokerProtocolVersion: BROKER_PROTOCOL_VERSION, journalId: journal.journalId, legacyCursorCompatible: journal.legacyCursorCompatible, latestEventId: journal.latestId() })));
      const onMessage = async raw => {
        try {
          const message = JSON.parse(raw);
          if (message.type === "broker.register") {
            safeIdentifier(message.requestId, "requestId");
            if (!Array.isArray(message.auraIds) || !message.auraIds.length) throw new BridgeError("auraIds must be a non-empty array", 400, "invalid_aura_ids");
            client.auraIds = new Set(message.auraIds.map(auraId => auraId === "*" ? "*" : safeIdentifier(auraId, "auraId")));
            client.registered = true;
            reconcileExecutorLeases(client);
            const executorAuraIds = [...client.auraIds].filter(auraId => auraId !== "*" && executorForAura(auraId) === client);
            socket.write(encodeWebSocketFrame(JSON.stringify({ type: "broker.registered", requestId: message.requestId, auraIds: [...client.auraIds], executorAuraIds, journalId: journal.journalId, legacyCursorCompatible: journal.legacyCursorCompatible, latestEventId: journal.latestId() })));
            const registeredJournalId = typeof message.journalId === "string" ? message.journalId.trim() : "";
            const afterByAura = !registeredJournalId || registeredJournalId === journal.journalId ? (message.afterEventIdByAura || {}) : {};
            const replayedOperationIds = new Set();
            const replayEvents = [];
            for (const auraId of client.auraIds) {
              if (auraId === "*") continue;
              for (const event of journal.replay({ auraId, after: Number(afterByAura[auraId] || 0), limit: 1000 })) {
                if (["operation.request", "operation.cancel"].includes(event.type)) {
                  const operationRecord = broker.get(event.requestId, auraId);
                  if (!operationRecord || operationRecord.status !== "pending" || operationRecord.auraId !== auraId) continue;
                  if (executorForAura(auraId) !== client) continue;
                }
                if (event.type === "operation.request") replayedOperationIds.add(event.requestId);
                replayEvents.push(event);
              }
            }
            replayEvents.sort((a, b) => Number(a.eventId || 0) - Number(b.eventId || 0));
            for (const event of replayEvents) socket.write(encodeWebSocketFrame(JSON.stringify(event)));
            for (const record of broker.pendingFor(client.auraIds)) {
              if (executorForAura(record.auraId) !== client) continue;
              if (replayedOperationIds.has(record.requestId)) continue;
              socket.write(encodeWebSocketFrame(JSON.stringify({ type: "operation.request", auraId: record.auraId, requestId: record.requestId, operation: { verb: record.verb, ...record.operation }, createdAt: record.createdAt, replayed: true })));
            }
            return;
          }
          if (message.type === "operation.response") {
            if (!client.registered || (!client.auraIds.has(message.auraId) && !client.auraIds.has("*"))) throw new BridgeError("browser is not registered for aura", 403, "aura_not_registered");
            if (executorForAura(message.auraId) !== client) throw new BridgeError("browser does not hold the Aura executor lease", 409, "not_aura_executor");
            const record = broker.respond(message);
            socket.write(encodeWebSocketFrame(JSON.stringify({ type: "operation.ack", auraId: record.auraId, requestId: record.requestId, status: record.status })));
            return;
          }
          throw new BridgeError(`unsupported WebSocket message: ${message.type || "unknown"}`, 400, "unsupported_message");
        } catch (error) {
          socket.write(encodeWebSocketFrame(JSON.stringify({ type: "bridge.error", error: { code: error.code || "invalid_message", message: error.message } })));
        }
      };
      socket.on("data", createWebSocketParser(socket, onMessage));
      const cleanup = () => {
        if (!sockets.delete(client)) return;
        const released = [];
        for (const [auraId, owner] of auraExecutors) {
          if (owner !== client) continue;
          auraExecutors.delete(auraId);
          released.push(auraId);
        }
        for (const auraId of released) {
          const next = executorForAura(auraId);
          if (next) sendPendingOperations(next, auraId);
        }
      };
      socket.on("close", cleanup);
      socket.on("error", cleanup);
    } catch (error) {
      const status = Number(error.status) || 500;
      socket.end(`HTTP/1.1 ${status} ${status === 401 ? "Unauthorized" : "Bad Request"}\r\nConnection: close\r\n\r\n`);
    }
  });

  bridgeApi = {
    server,
    core,
    broker,
    auraExecutors,
    supervisor,
    threads,
    journal,
    controllerProfiles,
    token,
    tokenFile,
    dataDir,
    async listen() {
      await new Promise((resolve, reject) => {
        server.once("error", reject);
        server.listen(port, host, resolve);
      });
      supervisor.ensureStarted().catch(() => {});
      return server.address();
    },
    async close() {
      closing = true;
      if (restartTimer) clearTimeout(restartTimer);
      restartTimer = null;
      for (const client of sockets) client.socket.destroy();
      await new Promise(resolve => server.listening ? server.close(resolve) : resolve());
      await supervisor.stop();
      core.flushDelta();
      threads.close();
    }
  };
  return bridgeApi;
}

if (require.main === module) {
  const bridge = createBridge();
  bridge.listen().then(address => {
    console.log(`Auralis local Codex bridge ${BRIDGE_VERSION}: http://${address.address}:${address.port}/v1`);
    console.log(`Bridge token file: ${bridge.tokenFile}`);
    console.log(`Codex app-server: ${bridge.supervisor.command}`);
  }).catch(error => {
    console.error(error.stack || error.message);
    process.exitCode = 1;
  });
  const stop = () => bridge.close().finally(() => process.exit(0));
  process.once("SIGINT", stop);
  process.once("SIGTERM", stop);
}

module.exports = {
  APPLY_OPERATION_TYPES,
  AppServerSupervisor,
  BridgeError,
  ControllerProfileStore,
  EventJournal,
  OperationBroker,
  ThreadStore,
  contentToText,
  createBridge,
  createWebSocketParser,
  defaultDataDir,
  estimateLocalCodexUsage,
  estimateTextTokens,
  localCodexChatCompletionResponse,
  messagesToPrompt,
  normalizeUserInput,
  resolveControllerProfile,
  MAX_WS_BYTES,
  STALE_READ_OPERATION_MS,
  validateBrokerOperation
};
