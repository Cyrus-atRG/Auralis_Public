function imageSize(ratio, resolution) {
  const sizes = { '1080': { '1:1': '1080x1080', '16:9': '1920x1080', '9:16': '1080x1920' }, '2k': { '1:1': '2048x2048', '16:9': '2560x1440', '9:16': '1440x2560' }, '4k': { '1:1': '4096x4096', '16:9': '3840x2160', '9:16': '2160x3840' } };
  return sizes[resolution]?.[ratio] || sizes['1080'][ratio];
}
function buildCompanyRequest(model, settings, prompt, groups) {
  const images = groups.image.map(r => r.url), videos = groups.video.map(r => r.url), audios = groups.audio.map(r => r.url);
  const inputs = Object.values(groups).flat().map(({ url, ...rest }) => rest);
  const { aspectRatio, resolution, duration } = settings;
  let endpoint, body, multipart = false;
  if (model.transport === 'aigc') {
    const spec = require('../src/company-aigc.js').specification(settings.model, { prompt, aspectRatio, resolution, duration, images, videos, audios });
    return { provider: 'company-aigc', endpoint: 'generate', body: spec, inputs, multipart: false };
  }
  if (model.kind === 'image') {
    endpoint = model.endpoint === 'chat' ? 'chat/completions' : 'images/generations';
    if (model.endpoint === 'chat') {
      body = { model: model.requestModel, messages: [{ role: 'user', content: [{ type: 'text', text: prompt }, ...images.map(url => ({ type: 'image_url', image_url: { url } }))] }], google: { image_config: { aspect_ratio: aspectRatio, image_size: resolution === '1080' ? '1K' : resolution.toUpperCase() } } };
    } else {
      body = { model: model.requestModel, prompt, n: 1, size: imageSize(aspectRatio, resolution) };
      if (model.bodyKind === 'seedream') {
        Object.assign(body, { response_format: 'url', output_format: 'png', watermark: false });
        if (images.length) body.image = images.length === 1 ? images[0] : images;
      } else if (images.length) {
        endpoint = 'images/edits'; multipart = true;
        Object.assign(body, { images, output_format: 'png' });
      }
    }
  } else {
    endpoint = 'videos';
    if (model.bodyKind === 'doubao-seedance') {
      const content = [{ type: 'text', text: prompt }];
      for (const [kind, list] of [['image', images], ['video', videos], ['audio', audios]]) {
        for (const url of list) content.push({ type: kind + '_url', [kind + '_url']: { url }, role: 'reference_' + kind });
      }
      body = { model: model.requestModel, prompt, metadata: { content, resolution, ratio: aspectRatio, duration, generate_audio: true, watermark: false, ...((images.length || videos.length || audios.length) ? { omni_reference_task_type: 'reference' } : {}) } };
    } else {
      body = { model: images.length || videos.length ? model.requestModel : model.textRequestModel, prompt, seconds: String(duration), metadata: { resolution, ratio: aspectRatio } };
      if (images.length) body.reference_images = images;
      if (videos.length) body.reference_videos = videos;
      if (audios.length) body.reference_audios = audios;
    }
  }
  return { provider: 'company', endpoint, body, inputs, multipart };
}
function resultMedia(result, kind) {
  if (!result || typeof result !== 'object') return '';
  for (const key of [kind + '_url', 'url', 'output_url', 'result_url']) {
    const value = result[key];
    if (typeof value === 'string' && /^https:\/\//.test(value)) return value;
    if (value?.url && /^https:\/\//.test(value.url)) return value.url;
  }
  if (kind === 'image' && result.b64_json) return 'data:image/' + (result.output_format || 'png') + ';base64,' + result.b64_json;
  for (const key of ['data', 'outputs', 'output', 'result', 'response', 'content', 'choices', 'message', 'images']) {
    const value = result[key];
    if (typeof value === 'string') {
      const match = value.match(/data:image\/[\w+.-]+;base64,[a-zA-Z0-9+/=]+/) || value.match(/https:\/\/[^\s<>"')\]]+/);
      if (match) return match[0];
    }
    for (const item of Array.isArray(value) ? value : [value]) {
      if (typeof item === 'string' && /^(https:\/\/|data:image\/)/.test(item)) return item;
      const found = resultMedia(item, kind); if (found) return found;
    }
  }
  return '';
}
function taskStatus(result) {
  return String(result?.data?.data?.status || result?.data?.data?.state || result?.data?.status || result?.data?.state || result?.status || result?.state || '').toLowerCase();
}
function taskId(result) { return result?.data?.task_id || result?.data?.id || result?.task_id || result?.id; }
module.exports = { buildCompanyRequest, resultMedia, taskStatus, taskId };
