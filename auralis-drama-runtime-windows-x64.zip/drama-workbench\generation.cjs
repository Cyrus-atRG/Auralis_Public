const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const { isFileInput } = require("./media-transfer.cjs");

// Auralis.html remains the model catalogue source of truth. Evaluate only its
// named constant declarations, never the browser application or user content.
const html = fs.readFileSync(path.join(__dirname, "../Auralis.html"), "utf8");
const names = [
  "IMAGE_MODELS",
  "VIDEO_MODELS",
  "SEEDANCE2_DURATION_MIN",
  "SEEDANCE2_DURATION_MAX",
  "SEEDANCE25_DURATION_MAX",
  "PLANNER_VIDEO_RESOLUTIONS",
  "SEEDANCE25_VIDEO_RESOLUTIONS",
  "PLANNER_IMAGE_ASPECT_RATIOS",
  "PLANNER_VIDEO_ASPECT_RATIOS",
  "SEEDANCE25_VIDEO_ASPECT_RATIOS",
  "PLANNER_IMAGE_RESOLUTIONS",
  "IMAGE_MODEL_REGISTRY",
  "GEMINI_OMNI_1_1_FLASH_VIDEO_CONFIG",
  "KLING_4_VIDEO_CONFIG",
  "VIDEO_MODEL_REGISTRY",
  "MODEL_LABELS",
  "VIDEO_REFERENCE_IMAGE_MAX_DIMENSION",
];
const declarations = names.map((name) => {
  const start = html.indexOf("    const " + name + " = ");
  if (start < 0) throw new Error("Auralis model catalogue is missing " + name);
  const end = html.indexOf(";", start);
  return html.slice(start, end + 1);
});
const source = vm.runInNewContext(
  declarations.join("\n") + "\nJSON.stringify({" + names.join(",") + "})",
  {},
  { timeout: 1000 },
);
const catalogue = JSON.parse(source);
const models = {};
const aliases = {};
for (const kind of ["image", "video"]) {
  const registry = catalogue[kind.toUpperCase() + "_MODEL_REGISTRY"];
  for (const key of catalogue[kind.toUpperCase() + "_MODELS"]) {
    const config = registry[key];
    if (!["wavespeed", "company"].includes(config.provider)) continue;
    const isImage = kind === "image";
    models[key] = {
      ...config,
      kind,
      label: catalogue.MODEL_LABELS[key],
      resolutions:
        config[isImage ? "imageResolutions" : "videoResolutions"] ||
        catalogue[
          isImage ? "PLANNER_IMAGE_RESOLUTIONS" : "PLANNER_VIDEO_RESOLUTIONS"
        ],
      aspectRatios:
        config.videoAspectRatios || catalogue.PLANNER_IMAGE_ASPECT_RATIOS,
      images: isImage
        ? config.maxImageInputs ||
          config.maxReferenceImages ||
          (config.provider === "company" ? 14 : 0) ||
          (config.bodyKind === "midjourney"
            ? 1
            : config.editEndpointModel
              ? 14
              : 0)
        : config.maxReferenceImages ||
          (config.family === "seedance2.5" ? 30 : 9),
      audios: config.maxReferenceAudios ||
        (config.family === "seedance2.5"
          ? 10
          : config.family?.startsWith("seedance2")
            ? 3
            : 0),
      videos: isImage
        ? 0
        : config.maxReferenceVideos ||
          (config.family === "seedance2.5" ? 10 : 3),
      ...(isImage
        ? {}
        : {
            durationMin: config.durationMin || catalogue.SEEDANCE2_DURATION_MIN,
            durationMax: config.durationMax || catalogue.SEEDANCE2_DURATION_MAX,
          }),
    };
    for (const [alias, item] of Object.entries(registry)) {
      if (
        alias === key ||
        item.canonical === key ||
        (config.endpointModel && item.endpointModel === config.endpointModel)
      )
        aliases[alias] = key;
    }
  }
}
const defaults = {
  image: { model: "rg-gpt-image-2", aspectRatio: "1:1", resolution: "2k" },
  video: {
    model: "rg-seedance-2.5",
    aspectRatio: "9:16",
    resolution: "720p",
    duration: 8,
  },
};
function check(value, message) {
  if (!value)
    throw Object.assign(new Error(message), { code: "invalid", status: 400 });
}
function normalize(kind, value = {}, fallback = defaults[kind]) {
  const supplied = Object.fromEntries(
    Object.entries(value).filter(([, v]) => v != null),
  );
  const result = { ...fallback, ...supplied };
  result.model = aliases[result.model] || result.model;
  const model = models[result.model];
  check(model?.kind === kind, "请在生成设置选择已接通的" + (kind === "image" ? "图片" : "视频") + "模型");
  check(
    model.resolutions.includes(result.resolution),
    model.label + " 不支持 " + result.resolution + " 清晰度，请选择：" + model.resolutions.join("、"),
  );
  check(
    model.aspectRatios.includes(result.aspectRatio),
    model.label + " 不支持 " + result.aspectRatio + " 比例，请选择：" + model.aspectRatios.join("、"),
  );
  if (kind === "video")
    check(
      Number.isInteger(result.duration) &&
        result.duration >= model.durationMin &&
        result.duration <= model.durationMax,
      model.label +
        " 时长须为 " +
        model.durationMin +
        "–" +
        model.durationMax +
        " 整数秒，当前为 " + result.duration + " 秒",
    );
  return {
    model: result.model,
    aspectRatio: result.aspectRatio,
    resolution: result.resolution,
    ...(kind === "video" ? { duration: result.duration } : {}),
  };
}
function buildRequest(snapshot, inputs) {
  if (snapshot.canvasRequest) return require('./canvas-video.cjs').buildRequest(snapshot, inputs);
  const settings = normalize(snapshot.kind, snapshot);
  const model = models[settings.model];
  const groups = Object.fromEntries(
    ["image", "audio", "video"].map((role) => [
      role,
      inputs.filter((r) => r.role === role),
    ]),
  );
  for (const role of ["image", "audio", "video"]) {
    check(
      groups[role].length <= model[role + "s"],
      model.label + " 最多接收 " + model[role + "s"] + " 个" +
        ({ image: "图片", audio: "音频", video: "视频" })[role] +
        "参考，当前有 " + groups[role].length + " 个，请减少参考或更换模型",
    );
    for (const item of groups[role])
      check(
        /^https:\/\//.test(item.url) || (model.provider === "company" &&
          (role === "image" || (role === "audio" && model.bodyKind === "doubao-seedance")) &&
          (isFileInput(item.url) || new RegExp("^data:" + role + "/").test(item.url))),
        "参考尚未上传为供应商可访问的 HTTPS URL",
      );
  }
  for (const role of ["audio", "video"]) {
    const list = groups[role];
    if (!list.length) continue;
    check(
      list.every((r) => Number.isFinite(r.duration) && r.duration > 0),
      "音视频参考缺少实际时长，先重新导入并探测",
    );
    if (model.bodyKind === "kling4") continue; // Its per-file audio and total video limits are checked by the shared adapter.
    if (model.maxReferenceVideoDuration && role === "video")
      check(
        list.every((r) => r.duration <= model.maxReferenceVideoDuration),
        model.label + " 的单个参考视频不得超过 " + model.maxReferenceVideoDuration + " 秒，请裁短后重新上传",
      );
    const max = model.family === "seedance2.5" ? 30 : 15;
    const total = list.reduce((sum, r) => sum + (role === "video" ? Math.max(2, r.duration) : r.duration), 0);
    check(total <= max,
      (role === "video" ? "视频" : "音频") + "参考总时长不得超过 " + max +
        " 秒，当前按 " + Number(total.toFixed(2)) + " 秒计算" +
        (role === "video" ? "（每个视频至少按 2 秒计算）" : "") + "，请减少参考或裁短文件");
  }
  const images = groups.image.map((r) => r.url),
    audios = groups.audio.map((r) => r.url),
    videos = groups.video.map((r) => r.url);
  const { aspectRatio, resolution, duration } = settings;
  const body = { prompt: snapshot.prompt };
  if (snapshot.voiceBindings?.length) {
    const bindings = snapshot.voiceBindings.map((binding) => {
      const index = groups.audio.findIndex(
        (r) =>
          r.assetId === binding.assetId && r.versionId === binding.versionId,
      );
      check(index >= 0, "缺少已固定的角色音色参考：" + binding.characterName);
      return (
        binding.characterName +
        " uses @Audio " +
        (index + 1) +
        " as voice identity reference."
      );
    });
    const voicePrompt = snapshot.voicePrompt || fs.readFileSync(path.join(__dirname, "agents", "voice-binding.md"), "utf8");
    body.prompt += "\n\n" + voicePrompt.replace("{{bindings}}", bindings.join("\n"));
  }
  if (model.provider === "company") return require("./rg-provider.cjs").buildCompanyRequest(model, settings, body.prompt, groups);
  if (model.bodyKind === "kling4") return {
    ...require("../src/kling-video.js").request(model, {
      prompt: body.prompt, aspectRatio, resolution, duration, images, videos: groups.video, audios: groups.audio,
    }),
    inputs: inputs.map(({ url, ...rest }) => rest),
  };
  let endpoint;
  if (snapshot.kind === "image") {
    if (snapshot.model.endsWith("/edit"))
      check(images.length, "参考生图至少需要一张图片，请添加参考图片");
    endpoint = images.length
      ? model.referenceEndpointModel ||
        model.editEndpointModel ||
        model.endpointModel
      : model.endpointModel;
    if (model.bodyKind === "flux-2-max") {
      body.size = {
        "1:1": "1024*1024",
        "16:9": "1536*864",
        "9:16": "864*1536",
      }[aspectRatio];
      if (images.length) body.images = images;
    } else if (model.bodyKind === "krea-v2-large") {
      Object.assign(body, { aspect_ratio: aspectRatio, creativity: "medium" });
      if (images.length)
        body.reference = images.map((image_url) => ({
          image_url,
          strength: 1,
        }));
    } else if (model.bodyKind === "midjourney") {
      Object.assign(body, {
        aspect_ratio: aspectRatio,
        quality: 1,
        stylize: 0,
        chaos: 0,
        weird: 0,
        version: "8.1",
        hd: resolution !== "1080",
        niji: "close",
        seed: -1,
        enable_base64_output: false,
      });
      if (images.length) body.sref = images[0];
    } else {
      Object.assign(body, {
        aspect_ratio: aspectRatio,
        resolution: resolution === "1080" ? "1k" : resolution,
        output_format: "png",
        enable_sync_mode: false,
        enable_base64_output: false,
      });
      if (model.bodyKind.startsWith("gpt-image")) body.quality = "medium";
      if (images.length) body.images = images;
    }
  } else {
    const hasReferences = images.length || videos.length;
    endpoint =
      hasReferences && model.referenceEndpointModel
        ? model.referenceEndpointModel
        : model.textEndpointModel;
    Object.assign(body, { duration, aspect_ratio: aspectRatio, resolution });
    if (model.family === "minimax-h3") {
      check(
        !videos.length || resolution === "480p",
        "MiniMax H3 的参考视频输入只支持 480p 输出",
      );
      body.seed = -1;
    } else if (model.family === "gemini-omni-1.1-flash") {
      check(body.prompt.length <= model.promptMaxLength,
        "视频提示词最多 " + model.promptMaxLength + " 个字符，当前 " + body.prompt.length + " 个，请缩短后重试");
    } else body.generate_audio = true;
    if (images.length)
      body[
        model.family === "gemini-omni-1.1-flash" ? "images" : "reference_images"
      ] = images;
    if (videos.length) body.reference_videos = videos;
    if (audios.length) body.reference_audios = audios;
  }
  return { endpoint, body, inputs: inputs.map(({ url, ...rest }) => rest) };
}
module.exports = {
  models, defaults, normalize, buildRequest,
  videoReferenceImageMaxDimension: catalogue.VIDEO_REFERENCE_IMAGE_MAX_DIMENSION,
};
