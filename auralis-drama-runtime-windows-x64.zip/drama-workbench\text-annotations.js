// Quotes stay in the current stage's chat draft until the creator sends them.
function validTextAnnotation(value) {
  return value && ["id", "label", "quote", "note"].every(key => typeof value[key] === "string") &&
    Number.isInteger(value.start) && value.start >= 0 && Number.isInteger(value.end) && value.end > value.start;
}
function annotationMessage({ text, annotations }) {
  return [text.trim(), ...annotations.map((item, i) =>
    "批注 " + (i + 1) + " · " + item.label +
    "\n选中原文（第 " + (item.start + 1) + "–" + item.end + " 个字符）：\n" +
    item.quote.split("\n").map(line => "> " + line).join("\n") +
    "\n修改意见：\n" + item.note)].filter(Boolean).join("\n\n");
}
function clearSentAnnotationDraft(key, submission) {
  const draft = S.agentDrafts[key];
  if (!draft) return;
  const sent = new Map(submission.annotations.map(item => [item.id, JSON.stringify(item)]));
  const remaining = { ...draft,
    text: draft.text.trim() === submission.text.trim() ? "" : draft.text,
    annotations: (draft.annotations || []).filter(item => sent.get(item.id) !== JSON.stringify(item)),
  };
  const empty = !remaining.text && !remaining.annotations.length && !remaining.annotationDrafts?.length;
  S.agentDrafts[key] = empty ? { text: "" } : remaining;
  writeLocalDraft("agent/" + key, empty ? null : remaining);
  if (empty) recoveredAgentDrafts.delete(key);
  if (S.agentKey === key) {
    $("agentInput").value = remaining.text;
    S.annotations = remaining.annotations;
  }
}
const annotationPopover = $("textAnnotationPopover");
let annotationSelection = null, annotationEditingId = null, annotationScope = null, annotationFrame = 0;
function closeTextAnnotation() {
  if (annotationPopover.matches(":popover-open")) annotationPopover.hidePopover();
  annotationSelection = null;
}
function renderTextAnnotations() {
  if (annotationScope !== S.agentKey) {
    closeTextAnnotation();
    annotationScope = S.agentKey;
  }
  const markup = S.annotations.map((item, i) =>
    '<article class="text-annotation" data-annotation-id="' + esc(item.id) + '">' +
    '<div class="annotation-heading"><strong>' + esc(item.label) + '</strong><div>' +
    '<button type="button" data-annotation-edit="' + esc(item.id) + '" aria-label="编辑批注 ' + (i + 1) + '">编辑</button>' +
    '<button type="button" data-annotation-remove="' + esc(item.id) + '" aria-label="删除批注 ' + (i + 1) + '">删除</button></div></div>' +
    '<blockquote>' + esc(item.quote) + '</blockquote><p>' + esc(item.note) + '</p></article>').join("") +
    S.annotationDrafts.map(item => '<div class="annotation-resume"><button type="button" data-annotation-resume="' + esc(item.id) +
      '" title="' + esc(item.label + " · " + item.quote) + '">继续未完成的批注<span>' + esc(item.quote) + '</span></button>' +
      '<button type="button" data-annotation-discard="' + esc(item.id) + '" aria-label="丢弃未完成的批注">丢弃</button></div>').join("");
  patchProductionHTML($("agentAnnotations"), markup);
  $("agentAnnotations").hidden = !markup;
}
function rememberTextAnnotations() {
  persistAgentDraft();
  renderTextAnnotations();
}
function positionTextAnnotation(anchor) {
  const gap = 8, box = annotationPopover.getBoundingClientRect();
  const left = Math.max(gap, Math.min(anchor.left, innerWidth - box.width - gap));
  const above = anchor.top - box.height - gap;
  const top = Math.max(gap, Math.min(above >= gap ? above : anchor.bottom + gap, innerHeight - box.height - gap));
  annotationPopover.style.left = left + "px";
  annotationPopover.style.top = top + "px";
}
function openTextAnnotation(item, anchor) {
  item = S.annotationDrafts.find(draft => draft.id === item.id) || { ...item };
  annotationEditingId = item.id;
  if (!S.annotationDrafts.some(draft => draft.id === item.id)) S.annotationDrafts = [...S.annotationDrafts, item];
  annotationSelection = null;
  annotationPopover.className = "annotation-composer";
  annotationPopover.setAttribute("role", "dialog");
  annotationPopover.setAttribute("aria-label", "添加或编辑批注");
  annotationPopover.innerHTML = '<form id="textAnnotationForm"><div class="annotation-heading"><strong>' +
    esc(item.label) + '</strong><button type="button" data-annotation-close aria-label="暂存并关闭批注">×</button></div>' +
    '<blockquote>' + esc(item.quote) + '</blockquote><label for="textAnnotationNote">修改意见</label>' +
    '<textarea id="textAnnotationNote" placeholder="这段希望怎么改？" rows="3" required></textarea>' +
    '<div class="annotation-footer"><span>确认后附到聊天框，尚未发送</span><button type="submit" class="primary">确认批注</button></div></form>';
  $("textAnnotationNote").value = item.note;
  $("textAnnotationForm").querySelector('button[type="submit"]').disabled = !item.note.trim();
  if (!annotationPopover.matches(":popover-open")) annotationPopover.showPopover();
  positionTextAnnotation(anchor);
  $("textAnnotationNote").focus({ preventScroll: true });
  rememberTextAnnotations();
}
// A textarea does not expose selection rectangles. Mirror only while locating its selection.
function textareaSelectionRect(editor, start, end) {
  const bounds = editor.getBoundingClientRect(), styles = getComputedStyle(editor);
  const mirror = document.createElement("div");
  for (const key of ["boxSizing", "width", "height", "fontFamily", "fontSize", "fontWeight", "fontStyle",
    "lineHeight", "letterSpacing", "wordSpacing", "textIndent", "textAlign", "tabSize",
    "paddingTop", "paddingRight", "paddingBottom", "paddingLeft",
    "borderTopWidth", "borderRightWidth", "borderBottomWidth", "borderLeftWidth"]) mirror.style[key] = styles[key];
  Object.assign(mirror.style, { position: "fixed", left: bounds.left + "px", top: bounds.top + "px",
    visibility: "hidden", pointerEvents: "none", overflow: "hidden", whiteSpace: "pre-wrap",
    overflowWrap: "break-word", borderStyle: "solid" });
  mirror.setAttribute("aria-hidden", "true");
  const selected = document.createElement("span");
  selected.textContent = editor.value.slice(start, end);
  mirror.append(document.createTextNode(editor.value.slice(0, start)), selected,
    document.createTextNode(editor.value.slice(end) + "\u200b"));
  document.body.append(mirror);
  mirror.scrollTop = editor.scrollTop;
  mirror.scrollLeft = editor.scrollLeft;
  const rect = [...selected.getClientRects()].find(r => r.bottom > Math.max(bounds.top, 0) &&
    r.top < Math.min(bounds.bottom, innerHeight));
  const anchor = rect ? { left: Math.max(bounds.left, rect.left), top: Math.max(bounds.top, rect.top),
    bottom: Math.min(bounds.bottom, rect.bottom) } : null;
  mirror.remove();
  return anchor;
}
function readTextAnnotationSelection() {
  if (!S.project || $("dialog").open || !["setting", "synopsis", "storyboard"].includes(S.stage)) return null;
  const editor = $("documentText");
  if (editor && document.activeElement === editor) {
    const start = editor.selectionStart, end = editor.selectionEnd, quote = editor.value.slice(start, end);
    if (!quote.trim()) return null;
    const anchor = textareaSelectionRect(editor, start, end);
    return anchor && { label: "第 " + ep().number + " 集 · " + stageNames[S.stage], quote, start, end, anchor };
  }
  const selection = window.getSelection();
  if (S.stage !== "setting" || !selection.rangeCount || selection.isCollapsed) return null;
  const range = selection.getRangeAt(0), node = range.startContainer;
  const source = (node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement)?.closest("[data-annotation-source]");
  if (!source || !source.contains(range.endContainer)) return null;
  const quote = range.toString();
  if (!quote.trim()) return null;
  const prefix = range.cloneRange(); prefix.selectNodeContents(source); prefix.setEnd(range.startContainer, range.startOffset);
  const start = prefix.toString().length, setting = S.project.settings.find(item => item.id === source.dataset.settingId);
  const anchor = [...range.getClientRects()].find(r => r.bottom > 0 && r.top < innerHeight);
  return anchor && { label: setting ? "设定 · " + setting.title : "最初的设定", quote, start, end: start + quote.length, anchor };
}
function updateTextAnnotationSelection() {
  annotationFrame = 0;
  if (annotationPopover.matches(":popover-open") && annotationPopover.classList.contains("annotation-composer")) return;
  if (annotationPopover.matches(":popover-open") && annotationPopover.contains(document.activeElement)) return;
  const selection = readTextAnnotationSelection();
  if (!selection) { closeTextAnnotation(); return; }
  annotationSelection = selection;
  annotationPopover.className = "annotation-trigger";
  annotationPopover.removeAttribute("role");
  annotationPopover.removeAttribute("aria-label");
  annotationPopover.innerHTML = '<button type="button" id="addTextAnnotation">批注</button>';
  if (!annotationPopover.matches(":popover-open")) annotationPopover.showPopover();
  positionTextAnnotation(selection.anchor);
}
function scheduleTextAnnotationSelection() {
  if (!annotationFrame) annotationFrame = requestAnimationFrame(updateTextAnnotationSelection);
}
for (const type of ["selectionchange", "select", "pointerup", "keyup"])
  document.addEventListener(type, event => {
    if (!annotationPopover.contains(event.target)) scheduleTextAnnotationSelection();
  });
document.addEventListener("scroll", event => {
  if (event.target !== document && event.target !== $("documentText") && event.target !== $("agentAnnotations")) return;
  if (annotationPopover.contains(event.target) || !annotationPopover.matches(":popover-open")) return;
  if (annotationPopover.classList.contains("annotation-composer")) closeTextAnnotation();
  else scheduleTextAnnotationSelection();
}, true);
window.addEventListener("resize", closeTextAnnotation);
annotationPopover.addEventListener("pointerdown", event => {
  if (event.target.closest("#addTextAnnotation")) event.preventDefault();
});
document.addEventListener("click", event => {
  const add = event.target.closest("#addTextAnnotation");
  if (add && annotationSelection) {
    const { anchor, ...selection } = annotationSelection;
    openTextAnnotation({ ...selection, id: crypto.randomUUID(), note: "" }, anchor);
  }
  const edit = event.target.closest("[data-annotation-edit]");
  if (edit) {
    const item = S.annotations.find(item => item.id === edit.dataset.annotationEdit);
    if (item) openTextAnnotation(item, edit.getBoundingClientRect());
  }
  const remove = event.target.closest("[data-annotation-remove]");
  if (remove) {
    const id = remove.dataset.annotationRemove;
    S.annotations = S.annotations.filter(item => item.id !== id);
    S.annotationDrafts = S.annotationDrafts.filter(item => item.id !== id);
    if (annotationEditingId === id) closeTextAnnotation();
    rememberTextAnnotations();
  }
  const resume = event.target.closest("[data-annotation-resume]");
  if (resume) {
    const item = S.annotationDrafts.find(item => item.id === resume.dataset.annotationResume);
    if (item) openTextAnnotation(item, resume.getBoundingClientRect());
  }
  const discard = event.target.closest("[data-annotation-discard]");
  if (discard) {
    S.annotationDrafts = S.annotationDrafts.filter(item => item.id !== discard.dataset.annotationDiscard);
    if (annotationEditingId === discard.dataset.annotationDiscard) closeTextAnnotation();
    rememberTextAnnotations();
  }
  if (event.target.closest("[data-annotation-close]")) closeTextAnnotation();
});
annotationPopover.addEventListener("input", event => {
  if (event.target.id !== "textAnnotationNote") return;
  S.annotationDrafts = S.annotationDrafts.map(item => item.id === annotationEditingId ? { ...item, note: event.target.value } : item);
  $("textAnnotationForm").querySelector('button[type="submit"]').disabled = !event.target.value.trim();
  persistAgentDraft();
});
annotationPopover.addEventListener("submit", event => {
  event.preventDefault();
  const draft = S.annotationDrafts.find(item => item.id === annotationEditingId);
  if (!draft || !draft.note.trim()) return;
  const item = { ...draft, note: draft.note.trim() };
  const found = S.annotations.some(existing => existing.id === item.id);
  S.annotations = found ? S.annotations.map(existing => existing.id === item.id ? item : existing) : [...S.annotations, item];
  S.annotationDrafts = S.annotationDrafts.filter(draft => draft.id !== item.id);
  closeTextAnnotation();
  $("assistant").classList.remove("collapsed");
  rememberTextAnnotations();
});
annotationPopover.addEventListener("keydown", event => {
  if (event.key === "Enter" && (event.ctrlKey || event.metaKey) && !event.isComposing && !event.repeat) {
    event.preventDefault();
    $("textAnnotationForm")?.requestSubmit();
  }
});
