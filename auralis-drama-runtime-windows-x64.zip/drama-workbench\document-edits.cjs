// Literal replacements against one immutable base, never regexes or sequential edits.
function applyTextEdits(body, edits) {
  const fail = (message, code = "invalid", status = 400) => { throw Object.assign(new Error(message), { code, status }); };
  if (typeof body !== "string" || !Array.isArray(edits) || !edits.length || edits.length > 100)
    fail("每次正文修改须包含 1 至 100 处替换");
  const spans = edits.map(edit => {
    if (!edit || typeof edit.oldText !== "string" || !edit.oldText.length || edit.oldText.length > 80000 ||
        typeof edit.newText !== "string" || edit.newText.length > 80000)
      fail("替换须提供非空 oldText 和字符串 newText，每段最多 80000 字符");
    const start = body.indexOf(edit.oldText);
    if (start < 0) fail("找不到要替换的原文，请核对当前稿后重试", "document_conflict", 409);
    if (body.indexOf(edit.oldText, start + 1) !== -1)
      fail("原文出现多次，请包含相邻文字以唯一定位", "document_conflict", 409);
    return { start, end: start + edit.oldText.length, text: edit.newText };
  }).sort((a, b) => a.start - b.start);
  let cursor = 0;
  const parts = [];
  for (const span of spans) {
    if (span.start < cursor) fail("替换范围重叠，请合并为一处修改", "document_conflict", 409);
    parts.push(body.slice(cursor, span.start), span.text);
    cursor = span.end;
  }
  parts.push(body.slice(cursor));
  const result = parts.join("");
  if (result === body) fail("修改内容没有变化");
  return result;
}

module.exports = { applyTextEdits };
