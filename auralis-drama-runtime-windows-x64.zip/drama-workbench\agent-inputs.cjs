const crypto = require("node:crypto");
const { applyTextEdits } = require("./document-edits.cjs");
const { recentDiscussion } = require("./agent-history.cjs");

// Retain recent exact messages; older proposals and decisions stay queryable via history.
// Never replace a creator's "use option two" with an inferred decision summary.
function discussionHistory(messages) {
  return recentDiscussion(messages.filter(m => ["user", "agent"].includes(m.role)));
}

function inputManifest(prompts, context, history, rotated, current = context) {
  const materials = [];
  const add = (kind, title, versionId, mode = "全文") => materials.push({ kind, title, versionId, mode });
  if (context.project) add("project", "剧名与故事起点", null);
  const title = (section, item) => item.title || item.name || current[section]?.find(value => value.id === item.id)?.title || current[section]?.find(value => value.id === item.id)?.name || item.id;
  for (const item of context.settings || []) add("setting", title("settings", item), item.versionId, context.delivery === "delta" ? "变更字段" : "全文");
  for (const item of context.previousSynopses || []) add("previousSynopsis", item.title || `第 ${item.number} 集梗概`, item.versionId,
    item.status === "adopted" ? "全文 · 剧情承接" : item.status === "episode_missing" ? "该集尚未创建" : "尚无已采用梗概");
  for (const name of ["synopsis", "storyboard"]) {
    const doc = context.episode?.[name];
    for (const [key, label] of [["current", "当前稿"], ["accepted", "已采用稿"]]) {
      if (doc?.[key]) add(name, `第 ${current.episode.number} 集${name === "synopsis" ? "梗概" : "分镜"} · ${doc.acceptedIsCurrent ? "当前已采用稿" : label}`, doc[key].id, context.delivery === "delta" ? "变更字段" : "全文");
    }
  }
  for (const item of context.assets || []) add("asset", title("assets", item), item.pinnedVersionId, context.delivery === "delta" ? "变更字段" : "资料摘要 · 固定版本" + (context.scope.stage === "assets" ? " · 制作计划" : ""));
  for (const [index, sheet] of (context.imageSheets || []).entries()) add("reference", "资产总览 " + (index + 1), null, sheet.items.length + " 张 · 图片附件");
  for (const item of context.clips || []) add("clip", title("clips", item), item.planRevision, context.delivery === "delta" ? "变更字段" : item.plan ? "计划全文" : "索引");
  for (const item of context.references || []) add("reference", item.name, item.source?.versionId, item.kind === "clip" ? "视频引用路径" : "图片引用");
  return { prompts, materials, delivery: context.delivery || "full", assetIndexCount: context.assetLibrary?.length || 0, contextCharacters: JSON.stringify(context).length,
    history: { userMessages: history.filter(m => m.role === "user").length, agentMessages: history.filter(m => m.role === "agent").length,
      characters: JSON.stringify(history).length, rotated },
  };
}

const digest = value => crypto.createHash("sha256").update(JSON.stringify(value)).digest("hex");
const indexed = new Map(["settings", "settingIndex", "assetLibrary", "assets", "clips", "jobs", "referenceIndex"].map(key => [key, "id"]));
indexed.set("previousSynopses", "number");

// Fingerprints contain no document bodies. List members use stable IDs, so changing
// one clip or its job status never requires replaying the other clips' plans.
function contextParts(context, selection = null) {
  const parts = new Map();
  const visit = (value, path) => {
    if (value === undefined) return;
    if (value && !Array.isArray(value) && typeof value === "object" && Object.keys(value).length) {
      for (const [key, child] of Object.entries(value)) visit(child, [...path, key]);
    } else parts.set(JSON.stringify(path), { path, value, hash: digest(value) });
  };
  for (const [key, value] of Object.entries(context)) {
    if (["schemaVersion", "revision", "scope", "references", "imageSheets", "selected"].includes(key)) continue;
    const identity = indexed.get(key);
    if (identity) {
      // A selected row list is not the section's complete order.
      if (!Array.isArray(selection?.[key])) visit(value.map(item => item[identity]), [key, "$order"]);
      for (const item of value) visit(item, [key, String(item[identity])]);
    } else visit(value, [key]);
  }
  return parts;
}

function rememberContext(state, context) {
  state.known = Object.fromEntries([...contextParts(context)].map(([key, part]) => [key, part.hash]));
}

// Optimize common, narrowly scoped writes. Cross-object operations keep the full
// context path; adding an operation here requires checking all of its side effects.
function writeContextSelection(operations, results = []) {
  if (!Array.isArray(operations)) return null;
  const selection = {};
  const rows = (section, id) => { (selection[section] ||= []); if (id) selection[section].push(id); };
  for (const [i, op] of operations.entries()) {
    switch (op?.type) {
      case "setSetting":
        for (const section of ["settings", "settingIndex"]) rows(section, op.id || results[i]?.id);
        break;
      case "updateEpisode":
        if (op.number !== undefined) return null; // Renumbering also changes preceding episodes and setting selection.
        selection.episode = true;
        break;
      case "setSynopsis": case "setStoryboard": case "patchDocument":
        selection.episode = true;
        break;
      case "setAssetPrompt": rows("assets", op.assetId); break;
      case "planClip": rows("clips", op.id || results[i]?.id); break;
      case "addMediaReference": rows(op.targetType === "clip" ? "clips" : "assets", op.targetId); break;
      case "updateProject": selection.project = true; break;
      default: return null;
    }
  }
  return selection;
}

function acknowledgeWrites(state, before, after, supplied, operations = [], selection = null) {
  if (!state) return;
  const provided = new Set();
  const collect = value => {
    if (value === undefined) return;
    provided.add(digest(value));
    if (value && typeof value === "object") Object.values(value).forEach(collect);
  };
  collect(supplied);
  for (const op of operations) {
    if (op.type !== "patchDocument" || !["synopsis", "storyboard"].includes(op.targetType)) continue;
    const base = before.episode?.[op.targetType]?.current;
    const key = JSON.stringify(["episode", op.targetType, "current", "text"]);
    // The agent can reconstruct the new text only when it knew the exact base.
    if (!base || base.id !== op.baseVersionId || state.known[key] !== digest(base.text)) continue;
    try {
      provided.add(digest(applyTextEdits(base.text, op.edits)));
      provided.add(digest(base.text)); // The old current draft may now appear as "accepted".
    } catch { /* A replayed receipt may no longer match this before snapshot. */ }
  }
  const oldParts = contextParts(before, selection), newParts = contextParts(after, selection);
  for (const [key, part] of newParts) {
    // Acknowledge supplied/returned values, or exact text reconstructed from a known base.
    // Server-normalized/default fields remain changes to deliver next time.
    if (oldParts.get(key)?.hash !== part.hash && provided.has(part.hash)) state.known[key] = part.hash;
  }
  for (const key of oldParts.keys()) if (!newParts.has(key)) delete state.known[key];
}

function incrementalContext(context, state) {
  if (!state) return context;
  const next = contextParts(context);
  const delta = { schemaVersion: context.schemaVersion, delivery: "delta", revision: context.revision, scope: context.scope };
  const rows = new Map();
  for (const [key, { path, value, hash }] of next) {
    if (state.known[key] === hash) continue;
    const [section, member, ...fields] = path, identity = indexed.get(section);
    if (identity && member === "$order") {
      (delta.order ||= {})[section] = value;
      continue;
    }
    let target = delta, keys = path;
    if (identity) {
      const rowKey = section + "/" + member;
      if (!rows.has(rowKey)) {
        const row = { [identity]: identity === "number" ? Number(member) : member };
        (delta[section] ||= []).push(row); rows.set(rowKey, row);
      }
      target = rows.get(rowKey); keys = fields;
    }
    for (const field of keys.slice(0, -1)) target = target[field] ||= {};
    target[keys.at(-1)] = value;
  }
  const parents = new Set();
  for (const { path } of next.values()) for (let i = 1; i < path.length; i++) parents.add(JSON.stringify(path.slice(0, i)));
  const removed = Object.keys(state.known).filter(key => !next.has(key) && !parents.has(key)).map(key => JSON.parse(key))
    .filter(path => !path.some((_, i) => i > 0 && next.has(JSON.stringify(path.slice(0, i)))));
  // Losing selection omits a plan from this envelope; it does not delete the saved plan.
  const scopedRemoved = removed.filter(path => !(path[0] === "clips" && ["plan", "accepted"].includes(path[2]) &&
    context.clips?.some(clip => clip.id === path[1] && !clip.plan)));
  if (scopedRemoved.length) delta.removed = [...new Map(scopedRemoved.map(path => {
    const row = path.slice(0, 2);
    if (indexed.has(path[0]) && path[1] !== "$order" && !parents.has(JSON.stringify(row))) path = row;
    return [JSON.stringify(path), path];
  })).values()];
  if (delta.episode && context.episode) Object.assign(delta.episode, { id: context.episode.id, number: context.episode.number });
  // References describe this message's selection even when its contents are known.
  delta.references = context.references;
  delta.imageSheets = context.imageSheets;
  return delta;
}

const incrementalPolicy = "context.delivery=delta 表示同一会话的增量：未列出的资料沿用先前内容，不代表删除；列表按 id（前集梗概按 number）合并字段，嵌套对象合并，数组/null/空对象整体替换。order 给出顺序，removed 是删除字段路径。selected 是用户本条消息选中的对象，imageSheets 仅列本轮新附图。自己已写入且未变的正文不重复提供；context 默认也只返回变更；若历史压缩后缺少资料，用 context {full:true} 恢复当前作用域资料包（CLI 用 --json-file 或 --json - 传入），或 inspect {ids:[确切ID]} 读取具体条目，不要凭空补写。assetLibrary 仅为目录；clips 只为选中片段附计划全文，其余提供摘要和计划修订号，未附 plan/accepted 不代表删除；planRevision 变化但未附 plan 时，旧计划已过期，修改前先 inspect 当前计划。";

module.exports = { discussionHistory, inputManifest, rememberContext, writeContextSelection, acknowledgeWrites, incrementalContext, incrementalPolicy };
