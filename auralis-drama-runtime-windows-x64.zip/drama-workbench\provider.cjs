const fs = require("node:fs");
const Aigc = require("../src/company-aigc.js");
const path = require("node:path");
const { execFile } = require("node:child_process");
const { promisify } = require("node:util");
const { find, requireValue, now } = require("./store.cjs");
const { responseError, transportError } = require("./provider-errors.cjs");
const { downloadResult } = require("./result-download.cjs");
const { compactRequestBody } = require("./job-records.cjs");
const { FileInput, isFileInput, jsonPayload, saveInlineImage, UploadCache } = require("./media-transfer.cjs");

const { models, buildRequest } = require("./generation.cjs");
const execFileAsync = promisify(execFile);
async function probe(file, mime) {
  if (!/^(audio|video)\//.test(mime)) return {};
  let stdout;
  try {
    ({ stdout } = await execFileAsync(
      process.env.FFPROBE_PATH || "ffprobe",
      ["-v", "error", "-show_entries", "format=duration", "-of", "json", file],
      { encoding: "utf8", windowsHide: true, timeout: 30000 },
    ));
  } catch (error) {
    throw new Error(error.code === "ENOENT"
      ? "工作台缺少音视频解析组件，请联系维护者修复后重试"
      : typeof error.code === "number" ? "无法读取这个音视频文件。文件可能损坏或格式不受支持，请换一个文件后重试"
      : "工作台无法启动音视频解析组件，请联系维护者检查后重试");
  }
  let info;
  try { info = JSON.parse(stdout); }
  catch { throw new Error("音视频解析组件返回了无效结果，请联系维护者检查后重试"); }
  const duration = Number(info?.format?.duration);
  requireValue(Number.isFinite(duration) && duration > 0,
    "这个音视频文件没有可识别的时长，请重新导出后再上传");
  return { duration };
}
class Provider {
  constructor(store, options = {}) {
    this.store = store;
    this.fetch = options.fetch || fetch;
    this.submitRgJson = options.fetch || require("./rg-json-submit.cjs").submitJson;
    this.base = options.base || "https://api.wavespeed.ai/api/v3";
    this.key = options.key || process.env.WAVESPEED_API_KEY || "";
    this.credentials = options.credentials || (() => ({}));
    this.aigc = new Aigc.Client({ fetch: this.fetch, token: () => this.credentials().multimediaToken });
    this.promptLibrary = options.promptLibrary;
    this.active = new Set();
    this.downloads = new Map();
    this.downloadIdleTimeoutMs = options.downloadIdleTimeoutMs || 120000;
    this.submitting = new Set();
    this.maxSubmissions = options.maxSubmissions || 2;
    this.uploadCache = new UploadCache();
    this.timer = null;
  }
  async json(route, body, key = this.key) {
    const r = await this.fetch(this.base + route, {
      method: body ? "POST" : "GET",
      headers: {
        Authorization: "Bearer " + key,
        "Content-Type": "application/json",
      },
      ...(body ? { body: JSON.stringify(body) } : {}),
      signal: AbortSignal.timeout(60000),
    });
    if (!r.ok) throw await responseError(r, "供应商", [this.key]);
    return r.json();
  }
  start() {
    for (const projectId of this.store.projectIds())
      this.store.internal(projectId, (doc) => {
        for (const j of doc.jobs) {
          if (j.status === "submitting")
            j.status = j.remoteId ? "polling" : "submission_unknown";
          if (j.status === "preparing") j.status = "queued";
        }
      }, { contentChanged: false });
    this.timer = setInterval(() => this.tick(), 2500);
    this.timer.unref();
    this.tick();
  }
  stop() {
    clearInterval(this.timer);
    for (const { controller } of this.downloads.values()) controller.abort(new Error("下载已暂停，进度已保留"));
  }
  tick() {
    for (const [jobId, { projectId, controller }] of this.downloads) {
      if (find(this.store.read(projectId).jobs, jobId).status === "cancelled")
        controller.abort(new Error("下载已停止，进度已保留"));
    }
    for (const projectId of this.store.pendingProjectIds("jobs")) {
      for (const job of this.store.read(projectId).jobs) {
        if (
          !["queued", "polling", "downloading"].includes(job.status) ||
          this.active.has(job.id) || job.pollRetryAt > Date.now() || job.download?.retryAt > Date.now()
        )
          continue;
        const submitting = job.status === "queued";
        if (submitting && this.submitting.size >= this.maxSubmissions) continue;
        if (submitting) this.submitting.add(job.id);
        this.active.add(job.id);
        this.run(projectId, job.id)
          .catch(() => {})
          .finally(() => { this.active.delete(job.id); this.submitting.delete(job.id); });
      }
    }
  }
  update(pid, jid, values) {
    this.store.internal(pid, (p) =>
      Object.assign(find(p.jobs, jid), values, { updatedAt: now() }),
      { contentChanged: false },
    );
  }
  async upload(pid, media, options = {}) {
    const folder = path.dirname(this.store.file(pid)), file = path.join(folder, media.path);
    // Both overlapping tasks and later submissions reuse the same uploaded file.
    const key = this.key;
    return this.uploadCache.get(folder, file, [this.base, key, media.mime], async size => {
      const ticket = await this.json("/media/uploads", {
        filename: path.basename(file), size, content_type: media.mime,
      }, key);
      const upload = ticket.data?.upload;
      requireValue(upload && /^https:\/\//.test(upload.url), "上传票据无效");
      const headers = Object.fromEntries(
        Object.entries(upload.headers || {}).filter(([key]) => key.toLowerCase() !== "authorization"),
      );
      const r = await this.fetch(upload.url, {
        method: upload.method, headers,
        body: await fs.openAsBlob(file, { type: media.mime }),
        signal: AbortSignal.timeout(120000),
      });
      requireValue(r.ok, "参考文件上传失败");
      const url = ticket.data?.download_url || ticket.data?.url || ticket.data?.file_url;
      requireValue(/^https:\/\//.test(url || ""), "供应商未返回可用素材地址");
      return url;
    }, options);
  }
  async referenceInput(pid, media, role, snapshot, fallback = false) {
    if (models[snapshot.model]?.transport === 'aigc') {
      const folder = path.dirname(this.store.file(pid));
      let file = path.join(folder, media.path);
      let mime = media.mime;
      if (role === 'image') {
        const prepared = await require('./video-reference-images.cjs').videoImageInput(folder, media);
        file = prepared.file; mime = prepared.mime;
      }
      await this.aigc.ready();
      return this.uploadCache.get(folder, file, [Aigc.BASE, this.credentials().multimediaToken, mime], async () =>
        this.aigc.upload(await fs.openAsBlob(file, { type: mime }), path.basename(file)), { refresh: fallback });
    }
    const company = models[snapshot.model]?.provider === "company";
    const inlineAudio = role === "audio" && models[snapshot.model]?.bodyKind === "doubao-seedance";
    const local = () => company && snapshot.kind === "video" && role === "image"
      ? require("./video-reference-images.cjs").videoImageInput(path.dirname(this.store.file(pid)), media)
      : new FileInput(path.join(path.dirname(this.store.file(pid)), media.path), media.mime);
    if (company) {
      if (role === "image" && (snapshot.kind === "image" || fallback)) return local();
      if (inlineAudio && !this.key) return local();
      if (!fallback && /^https:\/\//.test(media.remoteUrl || "")) return media.remoteUrl;
      if (!this.key) {
        if (role === "image") return local();
        if (role === "audio") throw new Error("这个 RG 模型不支持本地音频直传，请选择 RG/S2.5，或使用有效的音频公网链接");
        throw new Error("RG 参考视频需要有效的公网链接；这个本地视频尚无可用链接。请使用可访问的视频 URL，或配置 WaveSpeed 用于上传");
      }
    }
    return this.upload(pid, media, { refresh: fallback });
  }
  async companyJson(route, body, multipart = false, base = "") {
    const config = this.credentials();
    const endpoint = (base || config.baseUrl || "").replace(/\/+$/, "") + "/" + route;
    let payload;
    let transfer = {};
    const headers = { Authorization: "Bearer " + config.apiKey };
    if (multipart) {
      payload = new FormData();
      for (const [key, value] of Object.entries(body)) if (key !== "images") payload.append(key, String(value));
      for (const [i, url] of body.images.entries()) {
        let blob;
        if (isFileInput(url)) blob = await fs.openAsBlob(url.file, { type: url.mime });
        else {
          const image = await this.fetch(url);
          requireValue(image.ok, "无法读取 RG 编辑参考图");
          blob = await image.blob();
        }
        payload.append("image", blob, "reference-" + i + ".png");
      }
    } else {
      headers["Content-Type"] = "application/json";
      if (body) {
        const encoded = jsonPayload(body);
        if (/^doubao-seedance-/.test(body.model || "") &&
          Number(encoded.contentLength || Buffer.byteLength(encoded.body)) > 64 * 1024 * 1024) {
          encoded.body?.destroy?.();
          throw Object.assign(new Error("RG 视频请求超过 64 MiB，请减少参考素材或缩小文件后重试"), { code: "invalid", definite: true });
        }
        payload = encoded.body;
        if (encoded.duplex) transfer.duplex = encoded.duplex;
        if (encoded.contentLength) headers["Content-Length"] = encoded.contentLength;
      }
    }
    let r;
    try {
      const send = !multipart && /^doubao-seedance-/.test(body?.model || "") ? this.submitRgJson : this.fetch;
      r = await send(endpoint, { method: body ? "POST" : "GET", headers, body: payload, ...transfer, signal: AbortSignal.timeout(body ? 600000 : 60000) });
    } catch (error) {
      throw transportError(error, "RG", [config.apiKey]);
    } finally { payload?.destroy?.(); }
    if (!r.ok) throw await responseError(r, "RG", [config.apiKey]);
    return r.json();
  }
  async run(pid, jid) {
    let p = this.store.read(pid),
      j = find(p.jobs, jid);
    if (!["queued", "polling", "downloading"].includes(j.status)) return;
    try {
      if (j.completedMedia) {
        requireValue(fs.existsSync(path.join(path.dirname(this.store.file(pid)), j.completedMedia.path)), "已生成的本地素材丢失");
        this.store.addResult(pid, jid, j.completedMedia);
        return;
      }
      const config = this.credentials();
      if (Object.hasOwn(config, "wavespeedApiKey")) this.key = config.wavespeedApiKey;
      const company = models[j.snapshot.model]?.provider === "company";
      // Previously submitted jobs retain their recorded transport, including pre-migration jobs.
      const aigc = j.request?.provider === 'company-aigc' || (!j.submittedAt && !j.remoteId && models[j.snapshot.model]?.transport === 'aigc');
      const { resultMedia, taskStatus, taskId } = require("./rg-provider.cjs");
      if (!j.completedUrl && (aigc ? !config.multimediaToken : company ? !(config.apiKey && config.baseUrl) : !this.key)) {
        this.update(pid, jid, {
          status: j.remoteId ? "polling" : "failed",
          ...(j.remoteId ? { pollRetryAt: Date.now() + 30000 } : {}),
          error: "请先在共享 API 设置配置 " + (aigc ? "多媒体 Token" : company ? "RG" : "WaveSpeed") + "，再重试",
        });
        return;
      }
      if (aigc && !j.completedUrl && !j.completedMedia) await this.aigc.ready();
      if (j.status === "queued") {
        this.assertSnapshot(p, j);
        this.update(pid, jid, { status: "preparing", error: null });
        const inputs = [];
        for (const ref of j.snapshot.canvasInputs || j.snapshot.refs) {
          const resolved = ref.media ? null : require('./media-references.js').resolve(p, ref);
          const a = ref.media ? { name: ref.name } : { name: resolved.name },
            v = ref.media ? { media: ref.media } : { ...resolved.version, media: resolved.media };
          requireValue(
            !v.deletedAt &&
              v.media &&
              (j.independent || ref.clipId || ref.referenceOnly ||
                v.status === "accepted" ||
                v.approvedAt ||
                v.source === "import"),
            "参考素材未审核通过",
          );
          const url = await this.referenceInput(pid, v.media, ref.role, j.snapshot);
          inputs.push({
            ...ref,
            name: a.name,
            duration: v.media.duration,
            url,
            mediaPath: v.media.path,
          });
        }
        const snapshot = { ...j.snapshot, voicePrompt: this.promptLibrary?.snapshot().text("voice-binding.md") || j.snapshot.voicePrompt };
        let request = buildRequest(snapshot, inputs);
        if (aigc) request = { ...request, body: await this.aigc.prepare(request.body) };
        p = this.store.read(pid);
        j = find(p.jobs, jid);
        if (j.status === "cancelled") return;
        this.assertSnapshot(p, j);
        // Persist before the network request; a crash here is uncertain, never an automatic resubmit.
        this.update(pid, jid, {
          status: "submitting",
          request: {
            provider: aigc ? "company-aigc" : company ? "company" : "wavespeed",
            ...(company ? { baseUrl: aigc ? Aigc.BASE : config.baseUrl } : {}),
            endpoint: request.endpoint,
            body: compactRequestBody(request.body),
            inputs: request.inputs,
          },
          submittedAt: now(),
        });
        let response;
        try {
          response = aigc ? await this.aigc.submit(request.body) : company
            ? await this.companyJson(request.endpoint, request.body, request.multipart, config.baseUrl)
            : await this.json("/" + request.endpoint, request.body);
        } catch (error) {
          // Only a definite rejected submission may be rebuilt. Never replay an
          // accepted task, a network failure, or an unknown submission.
          if (aigc || !company || error.httpStatus !== 400 || !error.definite ||
            !/resource (?:inaccessible|expired)|url[^\n]*(?:inaccessible|expired)|failed to (?:fetch|download)[^\n]*(?:image|audio|video|url)/i.test(error.message)) throw error;
          const role = /audio_url/.test(error.message) ? "audio" : /video_url/.test(error.message) ? "video" : "image";
          const stale = inputs.filter(input => input.role === role && /^https:\/\//.test(input.url));
          if (!stale.length) throw error;
          p = this.store.read(pid);
          if (find(p.jobs, jid).status === "cancelled") return;
          this.update(pid, jid, { status: "preparing", submittedAt: null });
          for (const input of stale) {
            const media = input.media || require('./media-references.js').resolve(p, input).media;
            input.url = await this.referenceInput(pid, media, role, snapshot, true);
          }
          request = buildRequest(snapshot, inputs);
          p = this.store.read(pid);
          j = find(p.jobs, jid);
          if (j.status === "cancelled") return;
          this.assertSnapshot(p, j);
          this.update(pid, jid, { status: "submitting", request: { provider: "company", baseUrl: config.baseUrl, endpoint: request.endpoint,
            body: compactRequestBody(request.body), inputs: request.inputs, referenceFallback: true }, submittedAt: now() });
          response = await this.companyJson(request.endpoint, request.body, request.multipart, config.baseUrl);
        }
        const remote = response.data || response;
        let completedUrl = company && j.snapshot.kind === "image" ? resultMedia(response, "image") : "";
        const remoteId = aigc ? Aigc.taskId(response) : company ? taskId(response) : remote.id;
        requireValue(remoteId || completedUrl, "供应商未返回任务 ID 或生成素材");
        let completedMedia;
        if (completedUrl.startsWith("data:")) {
          completedMedia = await saveInlineImage(path.dirname(this.store.file(pid)), completedUrl);
          completedUrl = "";
        }
        this.update(pid, jid, {
          remoteId: remoteId || null,
          ...(completedUrl ? { completedUrl } : {}),
          ...(completedMedia ? { completedMedia } : {}),
          status: !!find(this.store.read(pid).jobs, jid).cancelledAt
            ? "cancelled"
            : "polling",
        });
        j = find(this.store.read(pid).jobs, jid);
      }
      if (j.completedMedia) {
        this.store.addResult(pid, jid, j.completedMedia);
        return;
      }
      if (!j.remoteId && !j.completedUrl) return;
      const response = j.completedUrl ? { status: "completed" } : aigc ? await this.aigc.query(j.remoteId) : company
        ? await this.companyJson((models[j.snapshot.model].bodyKind === "doubao-seedance" ? "video/generations/" : "videos/") + encodeURIComponent(j.remoteId), null, false, j.request?.baseUrl)
        : await this.json("/predictions/" + encodeURIComponent(j.remoteId) + "/result");
      const result = aigc ? Aigc.task(response) : response.data || response;
      const status = aigc ? Aigc.status(response) : company ? taskStatus(response) : result.status;
      if (["failed", "failure", "error", "cancelled", "canceled", "timeout", "deleted"].includes(status))
        throw Object.assign(
          new Error("生成失败：" + (result.error_message || result.error?.message || result.error || result.status)),
          { definite: true, remoteTerminal: true },
        );
      if (!["completed", "succeeded", "success", "done"].includes(status)) return;
      const url = j.completedUrl || (aigc ? Aigc.media(response) : company ? resultMedia(response, j.snapshot.kind) :
        typeof result.outputs?.[0] === "string"
          ? result.outputs[0]
          : result.outputs?.[0]?.url);
      requireValue(/^(https:\/\/|data:image\/)/.test(url || ""), "任务完成但没有可下载的素材");
      await this.download(pid, jid, url, j.snapshot.kind);
    } catch (error) {
      const current = find(this.store.read(pid).jobs, jid);
      if (current.status === "cancelled") return;
      const authPaused = current.request?.provider === "company-aigc" && !!current.remoteId && !error.remoteTerminal && (String(error.code || "").startsWith("aigc_auth_") || this.aigc.auth.state === "invalid");
      const status = authPaused ? "polling" :
        current.submittedAt && !current.remoteId && !current.completedUrl && !current.completedMedia && !error.definite
          ? "submission_unknown"
          : error.code === "superseded"
            ? "superseded"
            : (current.remoteId || current.completedUrl || current.completedMedia) && !error.definite && error.code !== "invalid"
              ? current.download ? "downloading" : "polling"
              : "failed";
      this.update(pid, jid, {
        status,
        ...(authPaused ? { pollRetryAt: Date.now() + 30000 } : {}),
        remoteTerminal: !!error.remoteTerminal || !!current.remoteTerminal,
        error: String(error.message).slice(0, 600),
        ...(status === "downloading" ? { download: { ...current.download, state: "retrying", bytesPerSecond: 0, retryAt: Date.now() + 10000 } } : {}),
      });
    }
  }
  async download(pid, jid, url, kind) {
    const controller = new AbortController();
    this.downloads.set(jid, { projectId: pid, controller });
    const old = find(this.store.read(pid).jobs, jid).download || {};
    this.update(pid, jid, { status: "downloading", error: null, download: { ...old, state: "downloading", retryAt: null } });
    try {
      const media = await downloadResult({ folder: path.dirname(this.store.file(pid)), jobId: jid, url, kind,
        fetch: this.fetch, signal: controller.signal, idleTimeoutMs: this.downloadIdleTimeoutMs,
        onProgress: progress => {
          if (find(this.store.read(pid).jobs, jid).status === "cancelled") {
            controller.abort(new Error("下载已停止，进度已保留"));
            return;
          }
          this.update(pid, jid, { download: { ...progress, state: "downloading", attempts: old.attempts || 0 } });
        },
      });
      this.store.addResult(pid, jid, media);
    } catch (error) {
      const current = find(this.store.read(pid).jobs, jid);
      if (current.status === "cancelled") return;
      if (error.code === "invalid") throw error;
      const attempts = (old.attempts || 0) + 1;
      this.update(pid, jid, { status: "downloading", error: String(error.message).slice(0, 600),
        download: { ...current.download, state: "retrying", bytesPerSecond: 0, attempts,
          retryAt: Date.now() + Math.min(30000, 2500 * 2 ** Math.min(attempts - 1, 4)) } });
    } finally { this.downloads.delete(jid); }
  }
  assertSnapshot(p, j) {
    const e = j.episodeId ? find(p.episodes, j.episodeId) : null;
    requireValue(e || j.targetType === "asset", "视频任务缺少所属分集");
    const target = j.targetType === "clip" ? find(e.clips, j.targetId) : find(p.assets, j.targetId);
    if (target.deletedAt) throw Object.assign(new Error("条目已删除，未提交"), { code: "superseded" });
    if (e) this.store.storyboardGate(e);
    if (j.targetType === "clip") {
      const c = find(e.clips, j.targetId);
      if (
        (!j.independent && c.planRevision !== j.snapshot.planRevision) ||
        j.snapshot.storyboardVersionId !== e.storyboard.acceptedVersionId
      )
        throw Object.assign(new Error("输入已修改，未提交；请重新确认本片段"), {
          code: "superseded",
        });
      for (const ref of j.snapshot.refs) this.store.validateRef(p, e, ref);
      if (j.snapshot.canvasInputs) require("./canvas-video.cjs").validateInputs(this.store, p, j.snapshot.canvasInputs);
    } else {
      for (const ref of j.snapshot.refs) this.store.validateImageRef(p, ref);
      const a = find(p.assets, j.targetId);
      if (!j.independent && a.promptRevision !== j.snapshot.promptRevision)
        throw Object.assign(new Error("资产提示词已修改，未提交"), {
          code: "superseded",
        });
    }
  }
}
module.exports = { Provider, models, buildRequest, probe };
