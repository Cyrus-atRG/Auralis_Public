const fs = require('node:fs'), path = require('node:path');
const { models } = require('./generation.cjs');

function validateInputs(store, project, inputs) {
  if (!Array.isArray(inputs) || inputs.length > 50) throw new Error('画布参考素材无效');
  return inputs.map(input => {
    const media = input.media;
    if (!/^media\/[a-zA-Z0-9._-]+$/.test(media?.path || '') || !/^(image|audio|video)\//.test(media.mime || ''))
      throw new Error('画布参考素材尚未保存');
    const file = path.join(path.dirname(store.file(project.id)), media.path);
    if (!fs.existsSync(file)) throw new Error('画布参考素材文件已不存在，请重新添加');
    return { ...input, media: { ...media }, role: media.mime.split('/')[0] };
  });
}
async function probeInputs(store, project, inputs) {
  const result = validateInputs(store, project, inputs);
  for (const input of result) {
    const file = path.join(path.dirname(store.file(project.id)), input.media.path);
    Object.assign(input.media, await require('./provider.cjs').probe(file, input.media.mime));
  }
  return result;
}
function buildRequest(snapshot, inputs) {
  const config = models[snapshot.model];
  let request = snapshot.canvasRequest;
  // Old saved canvas plans have not been submitted yet. Translate their inputs,
  // while Provider keeps the old query route for jobs that already have an ID.
  if (config?.transport === 'aigc' && ['videos', 'video/generations'].includes(request?.endpoint)) {
    const old = request.body, meta = old.metadata || {}, content = meta.content || [];
    const urls = (type, role) => content.filter(x => x.type === type + '_url' && x.role === role).map(x => x[type + '_url'].url);
    const mode = meta.omni_reference_task_type === 'edit' || snapshot.canvasExecution?.mode === 'video_edit' ? 'edit'
      : meta.omni_reference_task_type === 'extend' || snapshot.canvasExecution?.mode === 'video_extend' ? 'extend' : 'text';
    const video = urls('video', 'reference_video');
    request = { endpoint: 'generate', body: require('../src/company-aigc.js').specification(snapshot.model, {
      prompt: old.prompt || snapshot.prompt, resolution: meta.resolution || snapshot.resolution,
      duration: snapshot.duration, aspectRatio: snapshot.aspectRatio, mode,
      first: urls('image', 'first_frame')[0] || old.image, last: urls('image', 'last_frame')[0] || old.last_image,
      source: mode !== 'text' ? video[0] || old.video : undefined,
      images: content.length ? urls('image', 'reference_image') : old.reference_images || [],
      videos: mode === 'text' ? content.length ? video : old.reference_videos || [] : [],
      audios: content.length ? urls('audio', 'reference_audio') : old.reference_audios || [],
    }) };
  }
  const allowed = config?.transport === 'aigc' ? ['generate'] : config?.provider === 'company' ? ['videos', 'video/generations']
    : Object.entries(config || {}).filter(([key]) => /endpointModel$/i.test(key)).map(([, value]) => value);
  if (!config || config.kind !== 'video' || !allowed.includes(request?.endpoint)) throw new Error('画布视频模型或接口无效');
  const urls = new Map(inputs.map(input => [input.nodeId, input.url]));
  const replace = value => {
    if (typeof value === 'string' && value.startsWith('https://canvas-input.invalid/')) {
      const url = urls.get(decodeURIComponent(value.slice('https://canvas-input.invalid/'.length)));
      if (!url) throw new Error('画布参考素材不完整，请重新连接后生成');
      return url;
    }
    if (Array.isArray(value)) return value.map(replace);
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, replace(item)]));
    return value;
  };
  const body = replace(request.body);
  let endpoint = request.endpoint;
  if (inputs.some(input => input.role === 'audio')) {
    // Native video execution tracks visuals; retain the workbench's audio and voice contract.
    const standard = require('./generation.cjs').buildRequest({ ...snapshot, canvasRequest: undefined }, inputs);
    if (config.transport === 'aigc') {
      body.params.prompt = standard.body.params.prompt;
      const key = body.category === 'video-edit' && snapshot.model === 'rg-seedance-2.5' ? 'reference_audio' : 'reference_audios';
      if (!['text-to-video', 'video-edit'].includes(body.category)) throw new Error('此视频模式不支持额外音频参考，请切换参考生成或视频编辑');
      body.params[key] = standard.body.params.reference_audios;
    } else {
      body.prompt = standard.body.prompt;
      if (config.bodyKind === 'doubao-seedance') {
        body.metadata.content = body.metadata.content.filter(item => item.type !== 'audio_url');
        for (const item of body.metadata.content) if (item.type === 'text') item.text = standard.body.prompt;
        body.metadata.content.push(...standard.body.metadata.content.filter(item => item.type === 'audio_url'));
        body.metadata.omni_reference_task_type ||= 'reference';
      } else {
        body.reference_audios = standard.body.reference_audios;
        if (config.provider !== 'company') endpoint = config.referenceEndpointModel || endpoint;
      }
    }
  }
  if (config.transport === 'aigc' && body.model !== snapshot.model) throw new Error('画布视频模型与请求不一致');
  return { endpoint, body, inputs: inputs.map(({ url, ...input }) => input) };
}
module.exports = { validateInputs, probeInputs, buildRequest };
