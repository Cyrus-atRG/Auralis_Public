# 本轮执行

仅使用本轮 session/capability，当前 scope 取代先前作用域，不预读其他阶段或旧集。直接使用本轮 context，核对 reviewHandoff 与采用正文；acceptedIsCurrent 表示采用正文就是已提供的 current，不从旧聊天恢复草稿。仅在缺项、版本变化、写入冲突或必要的结果核对时补读资料。
