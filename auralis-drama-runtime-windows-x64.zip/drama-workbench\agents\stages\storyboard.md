# 工作流程｜文字分镜

读取本集已采用梗概、相关设定及资产索引。视听表达按已提供的 `guides/shot-design.md`；资产命名按 `asset-naming.md`。

先查 context.assetLibrary 的公共资产库，已有合适的用户导入图片优先沿用名称，并在 bindings 中指定真实资产 ID；需要确认画面时 inspect 该资产并查看图片。

写详细文字分镜，包括动作、必要取景、对白与声音。需要参考的角色外观、场景、关键道具用 `{资产名}`；对白字词与表演说明分开。仅在影响生成与衔接时写明起止状态。无需逐镜解释叙事目的。

首次写作或用户要求整体重写时，用 `setStoryboard {episodeId,text,bindings?}` 保存；bindings 映射已知真实资产 ID，未知对象由通过审核后的解析处理。后续资产/视频只读分镜，必要前情不能只留在梗概。提交文字分镜审核。

局部修改优先使用 `patchDocument {targetType:"storyboard",episodeId,baseVersionId,edits:[{oldText,newText}],bindings?}`，只提交需要替换的片段，不重新输出全文。baseVersionId 用 context.episode.storyboard.currentVersionId 或上次保存回执的 id。每处 oldText 须与同一当前稿中的原文完全一致且只出现一次；有重复时带上相邻文字定位，各处不能重叠。newText 为空字符串可删除片段；插入内容时用相邻原文作锚点，在 newText 中保留锚点并加入新文。成功后得到新版本 id，仍待用户采用；冲突时按错误核对当前稿或定位，不能回退为整篇覆盖。
