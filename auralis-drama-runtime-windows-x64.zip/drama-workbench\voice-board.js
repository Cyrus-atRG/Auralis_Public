// Voice casting stays in the asset library; no agent turn is needed to audition.
S.voiceDrafts = new Map();
function voiceFields(profile = {}, setting = false) {
  const mode =
    setting && !profile.name
      ? "none"
      : profile.hasDialogue === false
        ? "silent"
        : "speaking";
  return (
    '<fieldset class="voice-fields"><legend>角色音色</legend>' +
    selectField(
      "voiceMode",
      setting ? "设定类型" : "是否有台词",
      [
        ...(setting ? [["none", "普通设定"]] : []),
        ["speaking", "人物 · 有台词"],
        ["silent", "人物 · 无台词"],
      ],
      mode,
      "data-voice-mode",
    ) +
    "<div data-character-fields" +
    (mode === "none" ? " hidden" : "") +
    ">" +
    (setting
      ? field("characterName", "角色名称", profile.name || "", "text", false)
      : "") +
    "<div data-voice-fields" +
    (mode !== "speaking" ? " hidden" : "") +
    ">" +
    field(
      "voiceDescription",
      "音色关键词",
      profile.description || "",
      "text",
      false,
    ) +
    '<p class="editor-note">如 upbeat, sweet, warm。资产准备时自动找 4 个试听。</p>' +
    '<div class="two">' +
    field(
      "voiceLanguage",
      "语言代码",
      profile.language || "en",
      "text",
      false,
    ) +
    selectField(
      "voiceGender",
      "声线",
      [
        ["", "不限"],
        ["female", "女声"],
        ["male", "男声"],
        ["neutral", "中性"],
      ],
      profile.gender || "",
    ) +
    "</div>" +
    selectField(
      "voiceAge",
      "声音年龄",
      [
        ["", "不限"],
        ["young", "年轻"],
        ["middle_aged", "成熟"],
        ["old", "年长"],
      ],
      profile.age || "",
    ) +
    "</div></div></fieldset>"
  );
}
function voiceFromForm(f) {
  return {
    hasDialogue: f.voiceMode === "speaking",
    description: f.voiceDescription,
    language: f.voiceLanguage || "en",
    gender: f.voiceGender || "",
    age: f.voiceAge || "",
  };
}
function settingVoiceSummary(s) {
  const c = latest(s)?.character;
  if (!c) return "";
  return (
    '<p class="setting-voice-summary">' +
    esc(c.name) +
    " · " +
    (c.hasDialogue ? "音色：" + esc(c.description) : "无台词") +
    "</p>"
  );
}
function voiceRow(character, audio, version) {
  const pin = ep()?.assetRefs.find((r) => r.assetId === audio.id)?.versionId;
  const chosen = version.id === mediaApprovedId("asset", audio);
  return (
    '<div class="voice-option' +
    (chosen ? " chosen" : "") +
    '" data-version="' +
    version.id +
    '">' +
    '<div class="voice-option-text"><strong>' +
    esc(version.voice?.name || "导入音频") +
    "</strong>" +
    "<p>" +
    esc(version.voice?.description || "角色音色参考") +
    "</p></div>" +
    '<audio controls preload="metadata" aria-label="试听 ' +
    esc(version.voice?.name || character.name) +
    '" src="' +
    esc(mediaUrl(version.media)) +
    '"></audio>' +
    '<div class="voice-option-actions">' +
    btn(
      chosen ? "已选定" : "选定",
      "chooseVoice",
      'data-id="' +
        audio.id +
        '" data-version="' +
        version.id +
        '"' +
        ' title="点击切换选定状态"',
      chosen ? "" : "primary",
    ) +
    '<a href="' +
    esc(mediaUrl(version.media)) +
    '?download=1" download aria-label="下载 ' +
    esc(version.voice?.name || character.name) +
    '">下载</a></div></div>'
  );
}
function voiceBoard() {
  const characters = boardAssets().filter(
    (a) => a.kind === "character" && a.voice?.hasDialogue,
  );
  if (!characters.length) return "";
  return (
    '<section class="voice-board" aria-label="角色音色"><h2>角色音色</h2>' +
    characters
      .map((character) => {
        const audio = S.project.assets.find(
          (a) => a.id === character.voiceAssetId,
        );
        if (!audio) return "";
        const search = audio.voiceSearch;
        const busy = ["queued", "searching"].includes(search?.status);
        const pin = ep()?.assetRefs.find(
          (r) => r.assetId === audio.id,
        )?.versionId;
        const activeId = mediaApprovedId("asset", audio);
        const versions = audio.versions.filter((v) => !v.deletedAt && v.media);
        const current = versions.filter(
          (v) => search?.resultVersionIds.includes(v.id) || v.id === activeId,
        );
        const old = versions.filter((v) => !current.includes(v));
        return (
          '<section class="voice-character" id="voice-' +
          character.id +
          '"><div class="row spread"><div><h3>' +
          esc(character.name) +
          '</h3><p class="muted">' +
          esc(character.voice.description) +
          " · " +
          esc(character.voice.language) +
          '</p></div><div class="actions">' +
          btn("改关键词", "editVoice", 'data-id="' + character.id + '"') +
          btn(
            busy
              ? "正在找音色…"
              : search?.status === "failed"
                ? "重试"
                : "换一批",
            "refreshVoices",
            'data-id="' + character.id + '"' + (busy ? " disabled" : ""),
          ) +
          "</div></div>" +
          (!S.elevenLabsReady
            ? '<p class="voice-notice">先在' +
              btn("生成设置", "settings", "", "quiet") +
              "连接 ElevenLabs。</p>"
            : "") +
          (busy
            ? '<p class="voice-notice" role="status">正在搜索和准备试听，完成后会自动出现。</p>'
            : "") +
          (search?.error
            ? '<p class="voice-notice" role="status">' +
              esc(search.error) +
              "</p>"
            : "") +
          (search?.status === "empty"
            ? '<p class="voice-notice">这些关键词暂时没有更多试听，试试改关键词。</p>'
            : "") +
          (search?.status === "completed" && search.resultVersionIds.length < 4
            ? '<p class="muted">本批找到 ' +
              search.resultVersionIds.length +
              " 个新试听。</p>"
            : "") +
          current.map((v) => voiceRow(character, audio, v)).join("") +
          (old.length
            ? '<details class="voice-history"><summary>之前的试听 · ' +
              old.length +
              "</summary>" +
              old.map((v) => voiceRow(character, audio, v)).join("") +
              "</details>"
            : "") +
          (pin && audio.acceptedVersionId !== pin
            ? '<p class="voice-notice">本集保留原音色。选定其他试听只更新本集；已固定的其他集不变。</p>'
            : "") +
          "</section>"
        );
      })
      .join("") +
    "</section>"
  );
}
function speakingFields(clip) {
  const characters = S.project.assets.filter(
    (a) =>
      a.kind === "character" &&
      a.voice?.hasDialogue &&
      ep().assetRefs.some((r) => r.assetId === a.id),
  );
  if (!characters.length) return "";
  return (
    '<fieldset class="voice-fields"><legend>本片段说话的角色</legend><p class="editor-note">选定音色后自动带入；无对白则不勾选。</p>' +
    characters
      .map(
        (a) =>
          '<label class="speaker-choice"><input type="checkbox" name="speakingAssetIds" value="' +
          a.id +
          '"' +
          (clip?.plan.speakingAssetIds?.includes(a.id) ? " checked" : "") +
          ">" +
          esc(a.name) +
          "</label>",
      )
      .join("") +
    "</fieldset>"
  );
}
async function voiceAction(action, d) {
  if (action === "toggleVoices") {
    S.assetView = S.assetView === "voices" ? "all" : "voices";
    return render();
  }
  if (action === "focusVoice") {
    S.assetView = "voices";
    render();
    document
      .getElementById("voice-" + d.id)
      ?.scrollIntoView({ block: "start" });
    return;
  }
  if (action === "editVoice") {
    const a = S.project.assets.find((a) => a.id === d.id),
      profile = S.voiceDrafts.get(a.id) || a.voice || {};
    S.modal = { id: a.id, voiceEditor: true, revision: S.project.revision };
    openDialog(
      a.name + " · 音色",
      '<form id="voiceForm">' +
        voiceFields(profile) +
        '<button class="primary">保存音色特质</button></form>',
    );
  }
  if (action === "refreshVoices")
    await apply([{ type: "searchVoices", assetId: d.id }]);
  if (action === "chooseVoice") {
    const audio = S.project.assets.find(a => a.id === d.id);
    const decision = mediaApprovedId("asset", audio) === d.version ? "unaccepted" : "accepted";
    await apply([
      {
        type: "review",
        targetType: "asset",
        targetId: d.id,
        versionId: d.version,
        episodeId: ep()?.id,
        decision,
      },
    ]);
    toast(decision === "unaccepted" ? "已取消选定音色" : "音色已选定");
  }
}
document.addEventListener("change", (event) => {
  if (!event.target.matches("[data-voice-mode]")) return;
  const fieldset = event.target.closest("fieldset"),
    mode = event.target.value;
  fieldset.querySelector("[data-character-fields]").hidden = mode === "none";
  fieldset.querySelector("[data-voice-fields]").hidden = mode !== "speaking";
});
document.addEventListener("input", (event) => {
  if (event.target.form?.id === "voiceForm" && S.modal?.voiceEditor)
    S.voiceDrafts.set(
      S.modal.id,
      voiceFromForm(Object.fromEntries(new FormData(event.target.form))),
    );
});
document.addEventListener(
  "play",
  (event) => {
    if (event.target.tagName === "AUDIO")
      document.querySelectorAll("audio").forEach((a) => {
        if (a !== event.target) a.pause();
      });
  },
  true,
);
