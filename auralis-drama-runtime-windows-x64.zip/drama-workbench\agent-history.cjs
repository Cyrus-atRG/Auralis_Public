// Visible transcripts survive reset; an execution may only read its own generation.
function discussionMessages(chat, start = chat?.historyStartIndex || 0) {
  return (chat?.messages || []).slice(Math.max(start, chat?.historyStartIndex || 0))
    .filter(m => ["user", "agent"].includes(m.role) && m.text);
}
function recentDiscussion(messages, budget = 12000) {
  const recent = [];
  let size = 0;
  for (const message of [...messages].reverse()) {
    const cost = message.text.length;
    if (size + cost > budget) break;
    recent.unshift({ role: message.role, text: message.text }); size += cost;
  }
  // Never invent a summary or silently treat an old suggestion as a decision.
  if (recent.length < messages.length) recent.unshift({ role: "user", text:
    `[较早讨论共 ${messages.length - recent.length} 条未重复附带。需要查找先前要求、选项或决定时调用 history；不要猜测。作品正文以当前工作台为准。]` });
  return recent;
}
function readDiscussion(messages, input = {}) {
  const limit = Math.max(1, Math.min(20, Number(input.limit) || 10));
  const before = Math.max(0, Math.min(messages.length, input.before === undefined ? messages.length : Math.trunc(Number(input.before)) || 0));
  if (input.id) {
    const message = messages.find(m => m.id === input.id);
    if (!message) return { messages: [], total: messages.length };
    const offset = Math.max(0, Number(input.textOffset) || 0), text = message.text.slice(offset, offset + 12000);
    return { messages: [{ id: message.id, role: message.role, text }],
      nextTextOffset: offset + text.length < message.text.length ? offset + text.length : null };
  }
  const query = String(input.query || "").toLowerCase(), result = [];
  let cursor = before;
  while (cursor > 0 && result.length < limit) {
    const message = messages[--cursor], at = query ? message.text.toLowerCase().indexOf(query) : 0;
    if (at < 0) continue;
    result.unshift({ id: message.id, role: message.role, characters: message.text.length,
      excerpt: message.text.slice(Math.max(0, at - 100), Math.max(0, at - 100) + 500) });
  }
  return { messages: result, total: messages.length, nextBefore: cursor || null };
}
module.exports = { discussionMessages, recentDiscussion, readDiscussion };
