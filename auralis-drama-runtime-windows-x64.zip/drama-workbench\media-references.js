// Shared ID resolution; no images, history or canvas graphs are sent to the agent.
(function (root) {
  const need = (value, message) => { if (!value) throw new Error(message); return value; };
  function resolve(project, ref, historical = false) {
    need(!!ref.assetId !== !!ref.clipId, '参考须指定一个资产或视频片段');
    const target = need(ref.clipId
      ? project.episodes.flatMap(e => e.clips).find(c => c.id === ref.clipId)
      : project.assets.find(a => a.id === ref.assetId), '找不到参考素材');
    const version = need(target.versions.find(v => v.id === ref.versionId), '请指定已生成的确切参考版本');
    need(version.media && (historical || (!target.deletedAt && !version.deletedAt)), '参考素材不存在或已删除');
    need(!ref.frame || (ref.frame === 'last' && ref.clipId && version.media.mime.startsWith('video/')), '尾帧来源必须是视频片段');
    need(!ref.frame || /^[a-zA-Z0-9_-]+$/.test(version.id), '视频版本 ID 无效');
    const media = ref.frame ? { path: 'media/frame-' + version.id + '-last.png', mime: 'image/png' } : version.media;
    return { target, version, media, name: (target.name || target.title) + (ref.frame ? ' · 尾帧' : '') };
  }
  const nodeId = ref => ref.versionId + (ref.frame ? '-' + ref.frame : '');
  const dependencies = clip => [...new Set([...(clip.plan.dependsOn || []),
    ...clip.plan.refs.filter(r => r.clipId && r.clipId !== clip.id).map(r => r.clipId)])];
  function round(episode, clip, visiting = new Set()) {
    need(!visiting.has(clip.id), '视频参考不能循环依赖');
    visiting.add(clip.id);
    // Completed references depend on an immutable output, not its source card's
    // future plan. This permits later rework without creating a false cycle.
    const completed = clip.plan.refs.filter(r => r.clipId).map(ref => {
      const source = episode.clips.find(c => c.id === ref.clipId);
      const version = source?.versions.find(v => v.id === ref.versionId);
      return (version?.snapshot?.round || 1) + 1;
    });
    const value = Math.max(clip.plan.round || 1, ...completed, ...pending(clip).map(id => {
      const source = episode.clips.find(c => c.id === id && !c.deletedAt);
      return source ? round(episode, source, visiting) + 1 : 1;
    }));
    visiting.delete(clip.id);
    return value;
  }
  const pending = clip => (clip.plan.dependsOn || []).filter(id => !clip.plan.refs.some(r => r.clipId === id && r.versionId));
  const roundLabel = n => n === 1 ? '首轮' : n === 2 ? '次轮' : '第 ' + n + ' 轮';
  const api = { resolve, nodeId, dependencies, round, pending, roundLabel };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.DramaReferences = api;
})(typeof window === 'undefined' ? globalThis : window);
