const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const LIMIT = 250 * 1024 * 1024;
const extension = mime => ({ "image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "video/mp4": ".mp4" }[mime] || (mime.startsWith("video/") ? ".mp4" : ".png"));
function downloadPaths(folder, jobId) {
  const key = crypto.createHash("sha256").update(jobId).digest("hex").slice(0, 32);
  return { partial: path.join(folder, "media", "download-" + key + ".part"),
    manifest: path.join(folder, "cache", "downloads", key + ".json"), relative: "media/generated-" + key };
}
const invalid = message => Object.assign(new Error(message), { code: "invalid" });
const length = value => value != null && /^\d+$/.test(value) && Number.isSafeInteger(Number(value)) ? Number(value) : null;
const validator = headers => {
  const tag = headers.get("etag");
  return tag && !tag.startsWith("W/") ? tag : headers.get("last-modified") || "";
};

// Each job keeps one partial file and its HTTP validator across retries/restarts.
async function downloadResult({ folder, jobId, url, kind, fetch: request = fetch,
  onProgress = () => {}, signal, idleTimeoutMs = 120000 }) {
  const paths = downloadPaths(folder, jobId);
  fs.mkdirSync(path.dirname(paths.partial), { recursive: true });
  fs.mkdirSync(path.dirname(paths.manifest), { recursive: true });
  let info = {};
  try { info = JSON.parse(fs.readFileSync(paths.manifest, "utf8")); } catch {}
  const save = () => {
    fs.writeFileSync(paths.manifest + ".tmp", JSON.stringify(info), "utf8");
    fs.renameSync(paths.manifest + ".tmp", paths.manifest);
  };
  // A crash after the rename but before addResult must not redownload the result.
  if (info.media) {
    const final = path.join(folder, paths.relative + extension(info.media.mime));
    if (fs.existsSync(final) && fs.statSync(final).size === info.media.size) return info.media;
    if (fs.existsSync(paths.partial) && fs.statSync(paths.partial).size === info.media.size) {
      fs.renameSync(paths.partial, final);
      return info.media;
    }
    info = {};
  }
  let received = fs.existsSync(paths.partial) ? fs.statSync(paths.partial).size : 0;
  // Without a validator we cannot safely append bytes from a later response.
  const offset = info.validator && !info.restart ? received : 0;
  let total = info.totalBytes || null, lastReported = 0, rateAt = Date.now(), rateBytes = offset;
  const progress = (force = false) => {
    const at = Date.now();
    if (!force && at - lastReported < 1000) return;
    const bytesPerSecond = at > rateAt ? Math.max(0, Math.round((received - rateBytes) * 1000 / (at - rateAt))) : 0;
    onProgress({ receivedBytes: received, totalBytes: total, bytesPerSecond, updatedAt: new Date(at).toISOString() });
    lastReported = at; rateAt = at; rateBytes = received;
  };
  const finish = async mime => {
    const digest = crypto.createHash("sha256");
    for await (const chunk of fs.createReadStream(paths.partial)) digest.update(chunk);
    const relative = paths.relative + extension(mime);
    const media = { path: relative, mime, size: received, sha256: digest.digest("hex"), remoteUrl: /^https:/.test(url) ? url : "" };
    info.media = media; save();
    fs.renameSync(paths.partial, path.join(folder, relative));
    progress(true);
    return media;
  };
  const controller = new AbortController();
  const combined = signal ? AbortSignal.any([signal, controller.signal]) : controller.signal;
  let timer, response, file;
  const touch = () => {
    clearTimeout(timer);
    timer = setTimeout(() => controller.abort(Object.assign(new Error("下载连续 " + Math.round(idleTimeoutMs / 1000) + " 秒没有收到数据，已保留进度"), { code: "download_idle" })), idleTimeoutMs);
    timer.unref?.();
  };
  try {
    progress(true); touch();
    response = await request(url, { headers: { "Accept-Encoding": "identity",
      ...(offset ? { Range: "bytes=" + offset + "-", "If-Range": info.validator } : {}) }, signal: combined });
    touch();
    if (response.status === 416 && offset) {
      const complete = /^bytes \*\/(\d+)$/.exec(response.headers.get("content-range") || "");
      if (complete && Number(complete[1]) === offset && total === offset && validator(response.headers) === info.validator && info.mime?.startsWith(kind + "/")) {
        clearTimeout(timer);
        return await finish(info.mime);
      }
      info.restart = true; save();
      throw new Error("下载文件已变化，将重新获取完整文件");
    }
    if (!response.ok) throw new Error("下载返回 HTTP " + response.status + "，已保留进度");
    const mime = (response.headers.get("content-type") || "").split(";")[0];
    if (!mime.startsWith(kind + "/")) throw invalid("供应商返回素材类型不符");
    const encoding = response.headers.get("content-encoding");
    if (encoding && encoding !== "identity") throw invalid("下载响应使用了不支持断点校验的压缩编码");
    const contentLength = length(response.headers.get("content-length"));
    if (response.status === 206) {
      const range = /^bytes (\d+)-(\d+)\/(\d+)$/.exec(response.headers.get("content-range") || "");
      if (!range || Number(range[1]) !== offset || Number(range[2]) < offset || Number(range[2]) >= Number(range[3]) ||
          (contentLength != null && contentLength !== Number(range[2]) - offset + 1)) throw new Error("断点响应范围不符，已保留进度");
      if ((offset && total && total !== Number(range[3])) || (offset && validator(response.headers) && validator(response.headers) !== info.validator)) {
        info.restart = true; save();
        throw new Error("下载文件已变化，将重新获取完整文件");
      }
      total = Number(range[3]); received = offset;
    } else if (response.status === 200) {
      // The server may ignore Range or replace the resource: never append a full body.
      received = 0; total = contentLength;
    } else throw new Error("下载响应状态不符：HTTP " + response.status);
    if (total != null && (!Number.isSafeInteger(total) || total <= 0 || total > LIMIT)) throw invalid("生成素材为空或超过 250 MiB");
    if (!response.body) throw new Error("生成素材没有内容");
    info = { mime, totalBytes: total, validator: validator(response.headers) };
    // Truncate first when Range was ignored, then record the new representation.
    file = await fs.promises.open(paths.partial, received ? "a" : "w");
    save(); rateAt = Date.now(); rateBytes = received; progress(true);
    for await (const chunk of response.body) {
      combined.throwIfAborted();
      const bytes = Buffer.from(chunk);
      if (!bytes.length) continue;
      touch();
      if (received + bytes.length > LIMIT || (total != null && received + bytes.length > total)) throw invalid("下载大小超过声明范围");
      let written = 0;
      while (written < bytes.length) {
        const count = (await file.write(bytes, written, bytes.length - written)).bytesWritten;
        if (!count) throw new Error("无法写入下载文件，已保留进度");
        written += count;
      }
      received += bytes.length;
      progress();
    }
    clearTimeout(timer);
    await file.close(); file = null;
    if (!received || (total != null && received !== total)) throw new Error("下载未完成，已保留进度");
    total ||= received;
    return await finish(mime);
  } catch (error) {
    // Keep both manifest and bytes. A later run resumes this same generation.
    progress(true);
    throw controller.signal.aborted ? controller.signal.reason : error;
  } finally {
    clearTimeout(timer);
    await file?.close();
    if (response?.body && !response.body.locked) await response.body.cancel().catch(() => {});
  }
}
module.exports = { downloadResult, downloadPaths };
