(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CompanyAigc = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const BASE = 'https://rgxz-agent-center.rivergame.net';
  const LOGIN = 'http://43.110.148.231:8025/playground/';
  const CHECK_INTERVAL = 30 * 60 * 1000;
  const MODELS = {
    'rg-seedance-2': 'yk/seedance-2.0', 'rg-seedance-2.5': 'yk/seedance-2.5',
    'rg-wavesdance-2': 'ws/seedance-2.0', 'rg-wavesdance-2.5': 'ws/seedance-2.5'
  };
  function fail(message, extra = {}) { throw Object.assign(new Error(message), { definite: true, ...extra }); }
  function tokenIssuedAt(token) {
    try {
      const parts = String(token || '').split('.');
      if (parts.length !== 3) return 0;
      const issuedAt = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/'))).iat;
      return Number.isFinite(issuedAt) && issuedAt > 0 ? issuedAt : 0;
    } catch (_) { return 0; }
  }
  function compareTokenVersions(next, current) {
    const nextIssued = tokenIssuedAt(next.token), currentIssued = tokenIssuedAt(current.token);
    // Issuance time orders tokens; it does not authenticate them.
    if (nextIssued && currentIssued && nextIssued !== currentIssued) return Math.sign(nextIssued - currentIssued);
    if (next.updatedAt > 0 && current.updatedAt > 0) return Math.sign(next.updatedAt - current.updatedAt);
    return null;
  }
  function task(value) { return value?.task || value?.data?.task || value?.data || value || {}; }
  function taskId(value) { const t = task(value); return t.task_id || t.id || ''; }
  function status(value) { return String(task(value).status || '').toLowerCase(); }
  function media(value) {
    const r = task(value).result;
    function find(v) {
      if (typeof v === 'string') return /^https:\/\//.test(v) ? v : '';
      if (!v || typeof v !== 'object') return '';
      for (const key of ['video_url', 'url', 'output_url', 'outputs', 'output', 'videos', 'content']) { const url = find(v[key]); if (url) return url; }
      if (Array.isArray(v)) for (const item of v) { const url = find(item); if (url) return url; }
      return '';
    }
    return find(r) || find(task(value));
  }
  // The two surfaces supply the same semantic inputs; only this adapter owns API field names.
  function specification(model, input) {
    if (!MODELS[model]) fail('请选择已接通的 RG 多媒体视频模型');
    const v25 = MODELS[model].endsWith('2.5'), wavesdance = MODELS[model].startsWith('ws/');
    const images = input.images || [], videos = input.videos || [], audios = input.audios || [];
    const mode = input.mode || 'text', first = input.first, last = input.last, source = input.source;
    if (!wavesdance && !v25 && ['edit', 'extend'].includes(mode)) fail('RG / Seedance 2 的 YK 接口暂不支持视频编辑或延长，请选择 RG / Seedance 2.5');
    const extendLast = wavesdance && !v25 && mode === 'extend';
    if (last && !first && !extendLast) fail('使用尾帧时也需要首帧');
    if (first && (images.length || videos.length || audios.length || source)) fail('首尾帧模式不能混用其他图片、视频或音频参考');
    if (images.length > (v25 ? 30 : wavesdance ? 9 : 15) || videos.length > (v25 ? 10 : wavesdance ? 3 : 15) || audios.length > (v25 ? 10 : wavesdance ? 3 : 15)) fail('参考素材数量超过模型上限');
    const category = mode === 'edit' ? 'video-edit' : mode === 'extend' ? 'video-extend' : first ? 'image-to-video' : 'text-to-video';
    const params = { prompt: input.prompt, resolution: wavesdance ? input.resolution : input.resolution?.toUpperCase(), duration: input.duration, generate_audio: true };
    if (category === 'text-to-video') Object.assign(params, { aspect_ratio: input.aspectRatio, reference_images: images, reference_videos: videos, reference_audios: audios });
    if (category === 'image-to-video') Object.assign(params, { image: first, ...(last ? { last_image: last } : {}), ...(!v25 || !wavesdance ? { aspect_ratio: input.aspectRatio } : {}) });
    if (category === 'video-edit' || category === 'video-extend') {
      if (!source) fail('请连接需要编辑或延长的视频');
      if (first || (last && !extendLast) || videos.length) fail('编辑或延长模式只接受一段源视频');
      if (wavesdance) {
        params.video = source;
        if (category === 'video-edit') {
          Object.assign(params, { reference_images: images, reference_audios: audios });
          if (v25) delete params.duration;
          else params.aspect_ratio = input.aspectRatio;
        } else if (last) params.last_image = last;
      } else {
        Object.assign(params, { reference_video: source, reference_image: images, reference_audio: audios });
        if (category === 'video-edit') delete params.duration;
      }
      if (wavesdance && category === 'video-extend' && (images.length || audios.length)) fail('视频延长接口不接受额外图片或音频参考');
    }
    return { model, category, params };
  }
  function validateParams(fields, params) {
    const known = new Map(fields.map(f => [f.field_key, f]));
    for (const field of fields) if (field.required && (params[field.field_key] == null || params[field.field_key] === '' || (Array.isArray(params[field.field_key]) && !params[field.field_key].length))) fail('缺少参数：' + field.field_key);
    for (const [key, value] of Object.entries(params)) {
      const f = known.get(key), c = f?.constraints || {};
      if (!f) fail('当前接口不支持参数：' + key);
      if (c.options && !c.options.some(o => o.value === value)) fail('当前接口不支持 ' + key + ' = ' + value);
      if (f.value_type === 'number' && (!Number.isFinite(value) || (c.min != null && value < c.min) || (c.max != null && value > c.max))) fail('参数超出范围：' + key);
      if (f.value_type === 'url') {
        if (!!f.multiple !== Array.isArray(value)) fail('素材参数格式不正确：' + key);
        const values = Array.isArray(value) ? value : [value];
        if (values.some(v => typeof v !== 'string' || !/^https:\/\//.test(v))) fail('参考素材需要先上传：' + key);
        if ((c.max_count != null && values.length > c.max_count) || (c.min_count != null && values.length < c.min_count)) fail('参考素材数量超出范围：' + key);
      }
    }
  }
  class Client {
    constructor(options = {}) {
      this.fetch = options.fetch || globalThis.fetch.bind(globalThis);
      this.token = options.token || (() => '');
      this.onAuth = options.onAuth || (() => {});
      this.auth = { state: 'missing', checkedAt: 0, revision: '' };
      this.credential = ''; this.pending = null; this.catalog = null; this.forms = new Map();
    }
    current() {
      const token = String(this.token() || '').trim();
      if (this.credential !== token) {
        this.credential = token; this.pending = null; this.catalog = null; this.forms.clear();
        this.auth = { state: token ? 'unchecked' : 'missing', checkedAt: 0, revision: '' };
      }
      return token;
    }
    setAuth(state, token, revision = this.auth.revision) {
      if (this.current() !== token) return;
      this.auth = { state, checkedAt: Date.now(), revision }; this.onAuth({ ...this.auth });
    }
    async request(route, body, timeoutMs = 60000, token = this.current()) {
      if (!token) fail('请在设置中填写多媒体 Token', { code: 'aigc_auth_missing' });
      const headers = { 'X-Casdoor-Token': token };
      const form = typeof FormData !== 'undefined' && body instanceof FormData;
      if (body !== undefined && !form) headers['Content-Type'] = 'application/json';
      let response, json;
      try {
        response = await this.fetch(BASE + route, { method: body === undefined ? 'GET' : 'POST', headers,
          ...(body !== undefined ? { body: form ? body : JSON.stringify(body) } : {}), signal: AbortSignal.timeout(timeoutMs) });
        json = await response.json();
      } catch (error) {
        throw Object.assign(new Error('多媒体接口暂时无法连接或响应无效，请稍后重试'), { definite: false, cause: error });
      }
      if (!response.ok || (json.code != null && json.code !== 200000 && json.code !== 200 && json.code !== 0)) {
        const detail = String(json.error?.message || json.error || json.message || ('HTTP ' + response.status)).split(token).join('[Token]').slice(0, 500);
        if (response.status === 401 || json.code === 401000) this.setAuth('invalid', token);
        throw Object.assign(new Error('多媒体接口：' + detail), { httpStatus: response.status, definite: response.status >= 400 && response.status < 500 || /^4\d{5}$/.test(String(json.code)) });
      }
      return json;
    }
    async check(force = false) {
      const token = this.current();
      if (!token) return { ...this.auth };
      if (!force && this.auth.checkedAt && Date.now() - this.auth.checkedAt < (this.auth.state === 'unavailable' ? 60000 : CHECK_INTERVAL)) return { ...this.auth };
      if (this.pending) return this.pending;
      const run = (async () => {
        let revision = this.auth.revision;
        try {
          // Validation must also work on HTTP-hosted canvases without SubtleCrypto.
          revision = globalThis.crypto?.subtle
            ? Array.from(new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(token)))).map(x => x.toString(16).padStart(2, '0')).join('').slice(0, 20)
            : revision || 'session-' + Date.now() + '-' + Math.random().toString(36).slice(2);
          const response = await this.request('/api/v1/casdoor/token/validate', { token }, 15000, token);
          const data = response.data, user = data?.user_info;
          if (!data || !Object.hasOwn(data, 'user_info')) throw new Error('Invalid validation response');
          this.setAuth(data.valid === true && user && (user.name || user.email || user.id) ? 'valid' : 'invalid', token, revision);
        } catch (error) { this.setAuth(error.httpStatus === 401 || error.httpStatus === 403 ? 'invalid' : 'unavailable', token, revision); }
        return { ...this.auth };
      })();
      this.pending = run;
      try { return await run; } finally { if (this.pending === run) this.pending = null; }
    }
    async ready() {
      const auth = await this.check();
      if (auth.state !== 'valid') fail(auth.state === 'unavailable' ? '暂时无法验证多媒体 Token，请检查网络后重试' : '多媒体 Token 未填写或已失效，请在设置中更新', { code: 'aigc_auth_' + auth.state });
    }
    async prepare(spec) {
      await this.ready();
      if (!MODELS[spec.model]) fail('不支持的多媒体模型');
      if (!this.catalog || Date.now() - this.catalog.at > CHECK_INTERVAL) this.catalog = { at: Date.now(), value: await this.request('/api/v1/aigc/catalog') };
      const models = this.catalog.value.models || this.catalog.value.data?.models || [];
      const modelPath = MODELS[spec.model];
      if (modelPath === 'yk/seedance-2.0' && ['video-edit', 'video-extend'].includes(spec.category)) fail('RG / Seedance 2 的 YK 接口暂不支持视频编辑或延长，请选择 RG / Seedance 2.5');
      const candidates = models.flatMap(m => m.scenes || []).filter(s => s.category === spec.category && s.name === modelPath + '/' + spec.category);
      if (candidates.length !== 1) fail('当前多媒体目录没有唯一可用的 ' + MODELS[spec.model] + ' / ' + spec.category);
      const scene = candidates[0];
      let form = this.forms.get(scene.id);
      if (!form || Date.now() - form.at > CHECK_INTERVAL) { form = { at: Date.now(), value: await this.request('/api/v1/aigc/scenes/' + encodeURIComponent(scene.id) + '/form') }; this.forms.set(scene.id, form); }
      const fields = form.value.fields || form.value.data?.fields;
      if (!Array.isArray(fields)) fail('多媒体接口返回的场景参数无效');
      const params = { ...spec.params };
      // Saved, unsubmitted canvas plans may still contain the previous bytedance schema.
      if (modelPath.startsWith('yk/')) {
        if (params.resolution) params.resolution = params.resolution.toUpperCase();
        if (spec.category === 'video-edit') { delete params.ratio; delete params.duration; }
      }
      validateParams(fields, params);
      return { scene_id: scene.id, params };
    }
    async upload(blob, name) {
      await this.ready();
      const form = new FormData(); form.append('file', blob, name); form.append('path', 'auralis');
      const json = await this.request('/api/v1/xiaozhi/common/upload-object', form, 600000);
      const url = json.data?.url;
      if (!/^https:\/\//.test(url || '')) fail('多媒体上传未返回有效素材地址');
      return url;
    }
    async submit(body) { return this.request('/api/v1/aigc/generate', body); }
    async query(id) { return this.request('/api/v1/aigc/tasks/' + encodeURIComponent(id), {}); }
  }
  function watchToken(options) {
    let busy = false, stopped = false, dialog = null;
    const seen = new Set();
    const labels = { valid: 'Token 有效', invalid: 'Token 已失效，请重新登录并更新', missing: '尚未填写多媒体 Token', unchecked: '尚未验证', unavailable: '暂时无法检查，请检查网络后重试' };
    async function check(force = false) {
      if (busy || stopped || options.enabled?.() === false) return;
      busy = true;
      try {
        const state = await options.check(force);
        options.onStatus?.(state, labels[state.state] || '正在检查…');
        if (state.state !== 'invalid' || !state.revision || options.canNotify?.() === false) return state;
        const key = 'auralis-multimedia-expired-' + state.revision;
        let acknowledged = seen.has(key);
        try { acknowledged ||= !!localStorage.getItem(key); } catch (_) {}
        if (acknowledged || dialog) return state;
        seen.add(key); try { localStorage.setItem(key, '1'); } catch (_) {}
        const focus = document.activeElement;
        dialog = document.createElement('dialog');
        dialog.className = 'multimedia-token-dialog';
        dialog.setAttribute('aria-labelledby', 'multimediaTokenNoticeTitle');
        dialog.style.cssText = 'max-width:480px;width:calc(100% - 40px);box-sizing:border-box;background:var(--surface,#202323);color:var(--ink,#edf0f0);border:1px solid var(--line,#555);border-radius:12px;padding:24px;';
        dialog.innerHTML = '<h2 id="multimediaTokenNoticeTitle" style="font-size:18px;margin:0 0 12px">多媒体 Token 已失效</h2><p style="line-height:1.7">请打开多媒体平台，登录后点击右上角复制 Token，再到设置中粘贴保存，以继续使用 RG 视频模型。</p><div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center"><a href="' + LOGIN + '" target="_blank" rel="noopener" style="color:inherit">打开多媒体平台</a><button type="button" data-token-settings>填写 Token</button><button type="button" data-token-later>稍后</button></div>';
        const close = () => { const old = dialog; dialog = null; old?.close(); old?.remove(); if (focus?.isConnected) focus.focus(); };
        dialog.querySelector('[data-token-settings]').onclick = () => { close(); options.openSettings(); };
        dialog.querySelector('[data-token-later]').onclick = close;
        dialog.addEventListener('cancel', event => { event.preventDefault(); close(); });
        dialog.addEventListener('click', event => { if (event.target === dialog) { const r = dialog.getBoundingClientRect(); if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) close(); } });
        document.body.append(dialog); dialog.showModal();
        return state;
      } catch (_) { options.onStatus?.({ state: 'unavailable' }, labels.unavailable); }
      finally { busy = false; }
    }
    const focus = () => check(), visible = () => { if (document.visibilityState === 'visible') check(); };
    const timer = setInterval(() => check(), CHECK_INTERVAL);
    window.addEventListener('focus', focus); document.addEventListener('visibilitychange', visible);
    return { check, stop() { stopped = true; clearInterval(timer); window.removeEventListener('focus', focus); document.removeEventListener('visibilitychange', visible); dialog?.close(); dialog?.remove(); } };
  }
  return { BASE, LOGIN, CHECK_INTERVAL, MODELS, Client, specification, validateParams, task, taskId, status, media, watchToken, compareTokenVersions };
});
