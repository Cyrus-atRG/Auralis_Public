# Agent 上下文复核与精简

范围：只改 Agent 指令和资料表示。基线为仓库提交 `fb86269`；现场 1.2.10 启动输入仅作只读证据，不将两套版本的字符数混算。

## 取舍

| 候选 | 结论与实际改动 |
| --- | --- |
| A 规范去重 | 采纳。`turn.md` 保留独有的本轮作用域、采用正文和补读条件；公共资产发现、可选视觉描述、默认参数规则移入 `canvas-io.md`；设定角色保留原先依赖 turn 的沟通要求。制作角色已有沟通规范，无需再改。视频阶段去掉重复的描述等待/逐张复审说明，保留计划字段、参考/音频绑定、轮次依赖及全部创作设计要求。 |
| B 全文与按需指南分开 | 采纳。角色、公共规则、当前阶段及其创作指引显式全文加载；分镜/资产继续全文加载资产命名。其他引用只递归进入版本依赖和按需目录。修复指南仍保存完整快照和自定义覆盖；本地按 `promptsRoot` 读取，公司 API 的 `read_prompt` 只返回本轮列出的固定规范快照。 |
| C 纯展示冗余 | 部分采纳。`settingIndex` 只列 `settings` 未附正文的条目，保留 ID/标题/固定版本供发现和 inspect；沿用已有指纹增量机制。去掉用户 scope 中重复的 `loadedPrompts`，保留 developer/system 来源标注和界面 `run.inputManifest.prompts`。公共资产目录、参考目录、完整采用正文、总览 ID 映射全部保留。 |
| D 已有状态 | 不添加业务状态。已有 `reviewHandoff`、`acceptedIsCurrent`、固定版本与音色字段保留，并在精简后的 turn 中明确采用正文关系。代码没有权威字段能还原“用户主动不要药包/额外音色”等决定，不能把未绑定推断为主动省略；不抽旧聊天、不补账本、不修剧目资料。 |
| E Codex 外部注入 | 未改。官方文档列出 `memories.use_memories` 和技能目录预算，但本机离线渲染未验证记忆开关能消除现场注入；不据此推断 app-server 的实际效果。技能预算不能保证只裁无关技能，关闭工具又会改变能力，因此本轮不采用。 |

已确认无需修复：原先已按阶段选规范、已有 Set 文件去重；`completeDramaInstructions` 已避免重复附加 profile 的整套公共规则。短剧正文来源是 `drama-workbench/agents` 经 `PromptLibrary` 叠加覆盖后的快照，不是通用画布 `PROMPT_REGISTRY`。

## 字符数

以 Node.js 字符串 `.length` 统计；不是 tokens。使用仓库官方规范、无自定义覆盖。正文合计不含来源标签；装配文本包含来源/版本标签及新增按需目录，不含 Codex 系统注入、工具定义、用户 scope 或图片。

| 阶段 | 正文合计：改前 → 改后 | 装配文本：改前 → 改后 | 装配减少 |
| --- | ---: | ---: | ---: |
| 设定 | 5,682 → 4,310 | 6,165 → 4,793 | 1,372 |
| 梗概 | 5,863 → 4,426 | 6,462 → 5,025 | 1,437 |
| 分镜 | 6,623 → 5,186 | 7,330 → 5,893 | 1,437 |
| 资产 | 12,725 → 11,288 | 13,435 → 11,998 | 1,437 |
| 视频 | 9,381 → 7,289 | 10,091 → 8,069 | 2,022 |

现场导出 `02-工作台上下文.json` 的纯表示回放：11 条目录行的 ID、标题、固定版本与已附正文逐条相同。移除这些重复行后，context 紧凑 JSON 从 **39,776 → 38,121** 字符，减少 **1,655**；11 条设定正文、采用分镜、33 条本集资产、28 条公共资产目录均不变。另有 `loadedPrompts` 数组本身 933 字符，可避免重复发送。未修改导出文件或真实项目，也未用真实付费生成测量。

## 全文文件名单

路径均相对 `drama-workbench/agents`。除视频修复指南改为按需外，其余阶段全文文件名单不变；文件正文的去重见上表。

| 阶段 | 改前全文文件 | 改后全文文件 |
| --- | --- | --- |
| 设定 | `setting.md`, `canvas-io.md`, `turn.md`, `guides/development.md` | 同左 |
| 梗概 | `production.md`, `canvas-io.md`, `turn.md`, `stages/synopsis.md`, `guides/episode-writing.md` | 同左 |
| 分镜 | `production.md`, `canvas-io.md`, `turn.md`, `stages/storyboard.md`, `guides/shot-design.md`, `asset-naming.md` | 同左 |
| 资产 | `production.md`, `canvas-io.md`, `turn.md`, `stages/assets.md`, `guides/reference-assets.md`, `asset-naming.md` | 同左 |
| 视频 | `production.md`, `canvas-io.md`, `turn.md`, `stages/video.md`, `guides/video-direction.md`, `guides/repair.md` | `production.md`, `canvas-io.md`, `turn.md`, `stages/video.md`, `guides/video-direction.md` |

视频按需名单为 `guides/repair.md`。自定义规范引用其他已登记文件时，递归列入按需名单；循环引用去重。自定义当前阶段创作指引、turn 及按需指南均保留原文，未直接修改用户覆盖或历史快照。

## Codex 配置核对

[官方配置参考](https://developers.openai.com/codex/config-reference) 定义 `memories.use_memories=false` 用于跳过记忆注入，`skills.max_context_tokens` 是技能目录预算。[App-server 文档](https://learn.chatgpt.com/docs/app-server) 提供线程启动/恢复/派生及本机协议导出入口。

本机 `codex-cli 0.165.0-alpha.1.2` 的 `codex debug prompt-input` 在分别传入 `-c memories.use_memories=true` / `false` 时，均返回 48,609 字符的消息文本、相同工具命名空间，且两边都没有现场的全局记忆块。该离线检查不请求模型、不提交媒体生成，但不足以证明生产 app-server 的局部开关能去掉那 16,468 字符；因此没有改 `local-codex-bridge.js`、用户全局配置、CODEX_HOME、技能或工具权限。

## 验证

- 新增 `tests/drama-prompt-references-smoke.cjs`：各阶段全文指引保留；自定义正文不改写；递归依赖、循环引用、无关阶段版本隔离；旧快照不受新覆盖影响；公司 API 按需读取真实分发快照并拒绝未列出路径；设定目录、固定版本及勾选/取消勾选增量。
- 既有 Agent 输入、增量 context、局部写入确认、上下文效率、公司主控与续聊、编辑权限、工作台和接力审阅回归均通过。
- 仓库要求的 `git diff --check`、运行提示词同步检查、运行提示词同步 smoke 和单 HTML 构建通过。

阶段划分、会话和重置、审核采用、固定版本、生成授权、读写权限与生产流程保持原样。未新增跨阶段 history、交接持久化或设定分类流程。未部署、重启服务或向现场制作会话发送指令。
