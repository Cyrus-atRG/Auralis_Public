const fs = require('node:fs'), path = require('node:path');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const { resolve } = require('./media-references.js');
const run = promisify(execFile), pending = new Map();
const mediaInfo = Symbol('prepared reference media');

async function prepareReference(store, project, ref) {
  const source = resolve(project, ref), directory = path.dirname(store.file(project.id));
  const original = path.join(directory, source.version.media.path);
  if (!/^media\/[a-zA-Z0-9._-]+$/.test(source.version.media.path) || !fs.existsSync(original))
    throw new Error('参考原文件不存在');
  if (!ref.frame) return source.version.media.mime.startsWith('video/')
    ? require('./provider.cjs').probe(original, source.version.media.mime) : {};
  const output = path.join(directory, source.media.path);
  if (fs.existsSync(output)) return;
  if (!pending.has(output)) {
    const task = (async () => {
      const temporary = output + '.tmp';
      try {
        // Decode the end and reverse only that short window: this is the actual
        // last decoded frame, not an estimated duration-minus-one-frame seek.
        const { duration } = await require('./provider.cjs').probe(original, source.version.media.mime);
        await run(process.env.FFMPEG_PATH || 'ffmpeg', [
          '-v', 'error', '-threads', '1', '-sseof', String(-Math.min(2, duration)), '-i', original,
          '-an', '-vf', 'reverse', '-frames:v', '1', '-f', 'image2', '-c:v', 'png', '-y', temporary,
        ], { windowsHide: true, timeout: 60000 });
        if (!fs.existsSync(temporary) || !fs.statSync(temporary).size) throw new Error('视频没有可提取的尾帧');
        await fs.promises.rename(temporary, output);
      } catch (error) {
        throw new Error('提取视频尾帧失败：' + (error.code === 'ENOENT' ? '找不到 ffmpeg' : error.message));
      } finally { await fs.promises.rm(temporary, { force: true }); }
    })();
    pending.set(output, task);
    task.finally(() => pending.delete(output)).catch(() => {});
  }
  await pending.get(output);
}
async function prepareOperations(store, project, operations, actor) {
  for (const op of operations || []) {
    if (op.type !== 'addMediaReference') continue;
    if (actor) store.checkScope(project, op, actor);
    op[mediaInfo] = await prepareReference(store, project, op.source);
  }
}
module.exports = { prepareReference, prepareOperations, mediaInfo };
