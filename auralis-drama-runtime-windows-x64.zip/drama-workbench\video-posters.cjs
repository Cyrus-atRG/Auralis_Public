const fs = require("node:fs");
const path = require("node:path");
const { execFile } = require("node:child_process");

function createVideoPosters() {
  const pending = new Map();
  let queue = Promise.resolve();
  return async (file) => {
    const stat = await fs.promises.stat(file);
    const directory = path.join(path.dirname(path.dirname(file)), ".posters");
    const target = path.join(directory, path.basename(file) + "-" + stat.size + "-" + Math.floor(stat.mtimeMs) + ".jpg");
    if (fs.existsSync(target)) return target;
    if (!pending.has(target)) {
      // Decode one first frame at a time; a board can request many posters at once.
      const task = queue.then(async () => {
        await fs.promises.mkdir(directory, { recursive: true });
        const temporary = target + ".tmp";
        try {
          await new Promise((resolve, reject) => execFile(process.env.FFMPEG_PATH || "ffmpeg", [
            "-v", "error", "-threads", "1", "-i", file, "-frames:v", "1",
            "-vf", "scale=480:-2", "-q:v", "4", "-f", "image2", "-y", temporary,
          ], { windowsHide: true, timeout: 30000 }, error => error ? reject(error) : resolve()));
          await fs.promises.rename(temporary, target);
          return target;
        } finally {
          await fs.promises.rm(temporary, { force: true });
        }
      });
      pending.set(target, task);
      queue = task.catch(() => {}).finally(() => pending.delete(target));
    }
    return pending.get(target);
  };
}

module.exports = { createVideoPosters };
