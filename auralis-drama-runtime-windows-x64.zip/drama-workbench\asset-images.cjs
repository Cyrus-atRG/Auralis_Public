const fs = require("node:fs"), path = require("node:path"), crypto = require("node:crypto");
const { spawn } = require("node:child_process");

const digest = value => crypto.createHash("sha256").update(JSON.stringify(value)).digest("hex").slice(0, 32);
function mediaFile(projectDir, media) {
  if (!/^media\/[a-zA-Z0-9._-]+$/.test(media?.path || "")) throw new Error("图片路径无效");
  return path.join(projectDir, media.path);
}
function ffmpeg(args, cwd) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.env.AURALIS_FFMPEG_PATH || process.env.FFMPEG_PATH || "ffmpeg",
      ["-v", "error", "-nostdin", "-y", ...args], { cwd, windowsHide: true });
    let error = "";
    child.stderr.on("data", chunk => { error = (error + chunk).slice(-2000); });
    child.stdout.resume();
    const timer = setTimeout(() => child.kill(), 20000);
    child.once("error", reject);
    child.once("close", code => { clearTimeout(timer); code === 0 ? resolve() : reject(new Error(error || "图片预览处理失败")); });
  });
}
const inFlight = new Map();
async function cachedImage(file, render) {
  if (fs.existsSync(file)) return file;
  if (inFlight.has(file)) return inFlight.get(file);
  const promise = (async () => {
    const directory = path.dirname(file);
    fs.mkdirSync(directory, { recursive: true });
    const temp = fs.mkdtempSync(path.join(directory, ".image-"));
    try {
      const output = path.join(temp, "result" + path.extname(file));
      await render(output, temp);
      fs.renameSync(output, file);
      return file;
    } finally {
      if (path.dirname(path.resolve(temp)) !== path.resolve(directory)) throw new Error("图片缓存路径无效");
      fs.rmSync(temp, { recursive: true, force: true });
    }
  })().finally(() => inFlight.delete(file));
  inFlight.set(file, promise);
  return promise;
}
async function analysisImage(projectDir, version, cacheDir) {
  const source = mediaFile(projectDir, version.media);
  const file = path.join(cacheDir, digest([version.id, version.media.path, version.media.sha256]) + ".jpg");
  await cachedImage(file, output => ffmpeg(["-threads", "1", "-i", source,
    "-vf", "scale=768:768:force_original_aspect_ratio=decrease:force_divisible_by=2", "-frames:v", "1", "-q:v", "5", "-threads", "1", output]));
  return "data:image/jpeg;base64," + fs.readFileSync(file).toString("base64");
}
function labelText(name) {
  const lines = [""];
  let width = 0;
  for (const char of String(name).replace(/[\r\n\t]/g, " ")) {
    const size = char.codePointAt(0) > 255 ? 2 : 1;
    if (width + size > 42) { lines.push(""); width = 0; }
    lines[lines.length - 1] += char;
    width += size;
  }
  // Keep labels fully legible; long names wrap and use a smaller font.
  return lines.join("\n");
}
async function contactSheet(projectDir, items) {
  const sources = items.map(item => mediaFile(projectDir, item.media));
  const key = digest(["contact-v1", items.map((item, i) => [item.name, item.assetId, item.versionId,
    item.media.path, fs.statSync(sources[i]).size, fs.statSync(sources[i]).mtimeMs])]);
  const media = { path: "media/agent-sheet-" + key + ".jpg", mime: "image/jpeg" };
  await cachedImage(mediaFile(projectDir, media), async (output, temp) => {
    const font = [process.env.AURALIS_IMAGE_FONT,
      "C:/Windows/Fonts/msyh.ttc", "/System/Library/Fonts/PingFang.ttc", "/System/Library/Fonts/STHeiti Medium.ttc",
      "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"].find(file => file && fs.existsSync(file));
    if (!font) throw new Error("未找到图片标签中文字体");
    const fontOption = "fontfile='" + font.replace(/\\/g, "/").replace(/:/g, "\\:").replace(/'/g, "\\'") + "'";
    const filters = items.map((item, index) => {
      const label = labelText(item.name), lines = label.split("\n").length;
      fs.writeFileSync(path.join(temp, "label-" + index + ".txt"), label, "utf8");
      return `[${index}:v]scale=456:288:force_original_aspect_ratio=decrease,pad=480:368:(ow-iw)/2:(288-ih)/2+8:white,setsar=1,` +
        `drawtext=${fontOption}:textfile=label-${index}.txt:expansion=none:fontsize=${Math.min(20, Math.floor(56 / lines))}:fontcolor=black:x=(w-tw)/2:y=306:line_spacing=2[v${index}]`;
    });
    filters.push(items.length === 1 ? "[v0]null[out]" : items.map((_, i) => `[v${i}]`).join("") +
      `xstack=inputs=${items.length}:layout=` + items.map((_, i) => `${(i % 3) * 480}_${Math.floor(i / 3) * 368}`).join("|") + ":fill=white[out]");
    fs.writeFileSync(path.join(temp, "filters.txt"), filters.join(";\n"), "utf8");
    await ffmpeg([...sources.flatMap(file => ["-threads", "1", "-i", file]), "-filter_complex_threads", "1",
      "-filter_complex_script", "filters.txt", "-map", "[out]", "-frames:v", "1", "-q:v", "4", "-threads", "1", output], temp);
  });
  return { media, items: items.map(({ assetId, versionId, name }) => ({ assetId, versionId, name })) };
}
async function agentImageSheets(project, scope, projectDir, references) {
  if (!["assets", "video"].includes(scope.stage)) return { references, sheets: [] };
  const episode = project.episodes.find(e => e.id === scope.episodeId), items = [];
  const add = (asset, version, name = asset?.name) => {
    if (!asset || asset.deletedAt || !version || version.deletedAt || !/^image\//.test(version.media?.mime)) return;
    if (!fs.existsSync(mediaFile(projectDir, version.media)) || items.some(i => i.assetId === asset.id && i.versionId === version.id)) return;
    items.push({ name, assetId: asset.id, versionId: version.id, media: version.media });
  };
  for (const ref of references) {
    const source = ref.source || scope.assetReferences?.find(r => r.versionId && ref.id === "asset-" + r.versionId);
    const asset = project.assets.find(a => a.id === (source?.assetId || ref.importedAssetId));
    const version = asset?.versions.find(v => v.id === source?.versionId || (!source?.versionId && v.media?.path === ref.media.path));
    add(asset, version, ref.name);
  }
  const targets = scope.targetIds || [];
  const targetAssets = scope.stage === "video" && targets.length
    ? new Set(episode.clips.filter(c => targets.includes(c.id)).flatMap(c => c.plan.refs.map(r => r.assetId))) : null;
  for (const ref of episode.assetRefs) {
    if (targets.length && (scope.stage === "assets" ? !targets.includes(ref.assetId) : !targetAssets.has(ref.assetId))) continue;
    const asset = project.assets.find(a => a.id === ref.assetId);
    const version = asset?.versions.find(v => v.id === ref.versionId) ||
      (scope.stage === "assets" ? asset?.versions.findLast(v => !v.deletedAt && v.media) : null);
    add(asset, version);
  }
  const sheets = [];
  for (let offset = 0; offset < items.length; offset += 9) sheets.push(await contactSheet(projectDir, items.slice(offset, offset + 9)));
  const covered = new Set(items.map(i => i.media.path));
  return {
    references: [...sheets.map((sheet, i) => ({ name: `资产总览 ${i + 1}/${sheets.length}`, media: sheet.media })),
      ...references.filter(ref => !covered.has(ref.media.path))],
    sheets: sheets.map(sheet => ({ mediaPath: sheet.media.path, items: sheet.items })),
  };
}
module.exports = { analysisImage, agentImageSheets, contactSheet, mediaFile, cachedImage, ffmpeg };
