const fs = require("node:fs/promises");
const { fail, requireValue } = require("./store.cjs");

async function receiveUpload(req, file, max = 200 * 1024 * 1024) {
  const temporary = file + ".upload";
  let handle, created = false, size = 0;
  try {
    if (Number(req.headers["content-length"]) > max) fail("请求过大", "too_large", 413);
    handle = await fs.open(temporary, "wx");
    created = true;
    // Keep only one incoming chunk in memory and let disk writes apply backpressure.
    // Do not destroy the HTTP socket on a size error: it must receive the 413 response.
    for await (const part of req.iterator({ destroyOnReturn: false })) {
      size += part.length;
      if (size > max) fail("请求过大", "too_large", 413);
      await handle.writeFile(part);
    }
    requireValue(size > 0, "文件为空");
    await handle.close(); handle = null;
    await fs.rename(temporary, file);
    return size;
  } catch (error) {
    if (handle) await handle.close().catch(() => {});
    if (created) await fs.rm(temporary, { force: true });
    if (!req.destroyed) req.resume();
    throw error;
  }
}

module.exports = { receiveUpload };
