const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const {
  defaults,
  normalize,
  models,
  buildRequest,
} = require("./generation.cjs");

const id = (prefix) => prefix + "-" + crypto.randomUUID();
const now = () => new Date().toISOString();
const hash = (value) =>
  crypto.createHash("sha256").update(JSON.stringify(value)).digest("hex");
const clone = (value) => structuredClone(value);
const fail = (message, code = "invalid", status = 400) => {
  throw Object.assign(new Error(message), { code, status });
};
const requireValue = (value, message) => {
  if (!value) fail(message);
  return value;
};
const text = (value, label, max = 80000) => {
  requireValue(
    typeof value === "string" && value.trim() && value.length <= max,
    label + "不能为空或过长",
  );
  return value.trim();
};
const find = (items, key) =>
  requireValue(
    items.find((item) => item.id === key),
    "找不到 " + key,
  );
const latest = (doc) => doc.versions.at(-1);
const accepted = (doc) =>
  doc.versions.find((v) => v.id === doc.acceptedVersionId);
const currentApproved = (doc) =>
  !!accepted(doc) && latest(doc)?.id === doc.acceptedVersionId;
const normalizeName = (name) =>
  String(name || "")
    .normalize("NFKC")
    .trim()
    .replace(/\s+/g, " ");
const mentions = (value) => [
  ...new Set(
    [...String(value).matchAll(/\{([^{}\n]+)\}/g)].map((m) =>
      normalizeName(m[1]),
    ),
  ),
];
const revision = (value, extra = {}) => ({
  id: id("v"),
  createdAt: now(),
  status: "pending",
  ...value,
  ...extra,
});
const emptyDoc = () => ({ versions: [], acceptedVersionId: null });
const usableMedia = (v) =>
  v &&
  !v.deletedAt &&
  v.media &&
  (v.status === "accepted" || v.approvedAt || v.source === "import");
const assetKinds = ["character", "costume", "scene", "prop", "audio", "video"];
const voiceProfile = (value) => {
  requireValue(
    value && typeof value.hasDialogue === "boolean",
    "请明确角色是否有台词",
  );
  const profile = {
    hasDialogue: value.hasDialogue,
    description: value.hasDialogue
      ? text(value.description, "音色关键词", 200)
      : "",
    language: value.language || "en",
    gender: value.gender || "",
    age: value.age || "",
  };
  requireValue(
    /^[a-z]{2,3}$/.test(profile.language),
    "音色语言使用 en、zh 等语言代码",
  );
  requireValue(
    ["", "female", "male", "neutral"].includes(profile.gender),
    "音色性别无效",
  );
  requireValue(
    ["", "young", "middle_aged", "old"].includes(profile.age),
    "音色年龄无效",
  );
  return profile;
};
const terminal = new Set([
  "completed",
  "failed",
  "cancelled",
  "submission_unknown",
  "superseded",
]);

class Store {
  constructor(root) {
    this.root = root;
    fs.mkdirSync(root, { recursive: true });
  }
  file(projectId) {
    requireValue(/^project-[a-f0-9-]+$/.test(projectId), "项目 ID 无效");
    return path.join(this.root, projectId, "project.json");
  }
  read(projectId) {
    const p = JSON.parse(fs.readFileSync(this.file(projectId), "utf8"));
    p.generation ||= clone(defaults);
    p.references ||= [];
    // Upgrade legacy review labels without deleting any candidate or changing existing episode pins.
    for (const doc of [...p.assets, ...p.episodes.flatMap((e) => e.clips)]) {
      for (const v of doc.versions)
        if (v.status === "accepted")
          v.approvedAt ||= v.reviewedAt || v.createdAt;
      if (!doc.acceptedVersionId) {
        const imported = doc.versions.findLast(
          (v) => v.source === "import" && !v.canvasNodeId && !v.deletedAt,
        );
        if (imported) this.adoptMedia(p, doc, imported);
      }
      if (doc.acceptedVersionId)
        for (const v of doc.versions) {
          if (!v.deletedAt)
            v.status =
              v.id === doc.acceptedVersionId ? "accepted" : "alternative";
        }
    }
    return p;
  }
  save(project) {
    const target = this.file(project.id);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const temp = target + "." + crypto.randomUUID() + ".tmp";
    const fd = fs.openSync(temp, "wx");
    try {
      fs.writeFileSync(fd, JSON.stringify(project, null, 2) + "\n", "utf8");
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
    fs.renameSync(temp, target);
    return project;
  }
  list() {
    return fs
      .readdirSync(this.root)
      .filter((n) => /^project-[a-f0-9-]+$/.test(n))
      .map((n) => {
        const p = this.read(n);
        return {
          id: p.id,
          title: p.title,
          premise: p.premise,
          revision: p.revision,
          episodes: p.episodes.length,
          updatedAt: p.updatedAt,
        };
      });
  }
  create(title, premise) {
    return this.save({
      schemaVersion: "auralis.drama.v1",
      id: id("project"),
      title: text(title, "项目名称", 120),
      premise: text(premise, "初始设定"),
      revision: 1,
      createdAt: now(),
      updatedAt: now(),
      settings: [],
      generation: clone(defaults),
      references: [],
      settingComplete: false,
      episodes: [],
      assets: [],
      jobs: [],
      batches: [],
      receipts: {},
      reviews: [],
    });
  }
  mutate(projectId, body, actor = { role: "human" }) {
    const p = this.read(projectId),
      requestId = text(body.requestId, "requestId", 150),
      fingerprint = hash({
        actor: actor.sessionId || actor.role,
        expectedRevision: body.expectedRevision,
        operations: body.operations,
      });
    if (p.receipts[requestId]) {
      if (p.receipts[requestId].fingerprint !== fingerprint)
        fail("请求 ID 已用于其他内容", "request_conflict", 409);
      return clone(p.receipts[requestId].result);
    }
    const independentHumanActions =
      actor.role === "human" &&
      body.operations?.length &&
      body.operations.every(
        (op) =>
          [
            "generateAssetVariation",
            "generateClipVariation",
            "approveBatch",
            "deleteMediaVersion",
            "saveAssetCanvas",
            "saveCanvasLayout",
            "importAsset",
          ].includes(op.type) ||
          (op.type === "review" && ["asset", "clip"].includes(op.targetType)),
      );
    if (body.expectedRevision !== p.revision && !independentHumanActions)
      fail(
        "内容已更新，请刷新后保留并重新核对你的修改",
        "revision_conflict",
        409,
      );
    requireValue(
      Array.isArray(body.operations) &&
        body.operations.length > 0 &&
        body.operations.length <= 100,
      "操作数量无效",
    );
    const results = body.operations.map((op) => this.operation(p, op, actor));
    p.revision++;
    p.updatedAt = now();
    const result = { revision: p.revision, results };
    p.receipts[requestId] = { fingerprint, result };
    this.save(p);
    return result;
  }
  internal(projectId, fn) {
    const p = this.read(projectId);
    fn(p);
    p.revision++;
    p.updatedAt = now();
    this.save(p);
    return p;
  }
  allowed(scope) {
    if (scope.role === "human") return null;
    return (
      {
        setting: ["setSetting"],
        synopsis: ["setSynopsis"],
        storyboard: ["setStoryboard"],
        assets: [
          "ensureAsset",
          "bindAsset",
          "setAssetPrompt",
          "renameAsset",
          "generate",
          "retryJob",
          "cancelJob",
          "setVoiceProfile",
        ],
        video: ["planClip", "retryJob", "cancelJob"],
      }[scope.stage] || []
    );
  }
  checkScope(p, op, a) {
    if (a.role === "human") return;
    if (a.projectId !== p.id || !this.allowed(a).includes(op.type))
      fail("当前角色或阶段不能执行该操作", "scope_denied", 403);
    if (op.episodeId && op.episodeId !== a.episodeId)
      fail("不能修改其他集", "scope_denied", 403);
    const e = a.episodeId ? find(p.episodes, a.episodeId) : null;
    if (e && a.inputVersions) {
      for (const name of ["synopsis", "storyboard"]) {
        const v = latest(e[name]),
          before = a.inputVersions[name];
        if (
          e[name].acceptedVersionId !== before.acceptedVersionId ||
          (v?.id !== before.currentVersionId &&
            v?.authorSessionId !== a.sessionId)
        )
          fail(
            "创作者已更新或采用新版本，请从工作台开启新一轮，以最新正文继续",
            "context_changed",
            409,
          );
      }
    }
    if (
      op.assetId &&
      !e?.assetRefs.some((r) => r.assetId === op.assetId) &&
      op.type !== "bindAsset"
    )
      fail("资产不在本集范围", "scope_denied", 403);
    if (
      op.type === "generate" &&
      (op.targetType !== "asset" ||
        !e?.assetRefs.some((r) => r.assetId === op.targetId))
    )
      fail("仅可生成本集待审资产", "scope_denied", 403);
    if (op.jobId) {
      const j = find(p.jobs, op.jobId);
      if (j.episodeId !== a.episodeId)
        fail("任务不在本集范围", "scope_denied", 403);
    }
  }
  operation(p, op, a) {
    this.checkScope(p, op, a);
    const human = () => {
      if (a.role !== "human") fail("只能由用户操作", "human_required", 403);
    };
    const episode = () => find(p.episodes, op.episodeId || a.episodeId);
    switch (op.type) {
      case "setGeneration": {
        human();
        p.generation = {
          image: normalize("image", op.image, p.generation.image),
          video: normalize("video", op.video, p.generation.video),
        };
        return clone(p.generation);
      }
      case "addReference": {
        human();
        requireValue(
          op.media &&
            /^media\/[a-zA-Z0-9._-]+$/.test(op.media.path) &&
            /^image\/(png|jpeg|webp)$/.test(op.media.mime),
          "请先上传参考图片",
        );
        requireValue(
          fs.existsSync(
            path.join(path.dirname(this.file(p.id)), op.media.path),
          ),
          "参考图片不存在",
        );
        const reference = {
          id: id("reference"),
          name: text(op.name, "图片名称", 200),
          note: String(op.note || "").slice(0, 4000),
          media: clone(op.media),
          createdAt: now(),
        };
        p.references.push(reference);
        return { id: reference.id };
      }
      case "attachAssetReference": {
        human();
        const asset = find(p.assets, op.assetId),
          version = find(asset.versions, op.versionId);
        requireValue(
          version.media?.mime.startsWith("image/"),
          "请选择图片素材",
        );
        const existing = p.references.find(
          (r) =>
            r.source?.assetId === asset.id &&
            r.source?.versionId === version.id,
        );
        if (existing) return { id: existing.id };
        const reference = {
          id: id("reference"),
          name: asset.name + " · 版本 " + (asset.versions.indexOf(version) + 1),
          note: "",
          source: { assetId: asset.id, versionId: version.id },
          media: clone(version.media),
          createdAt: now(),
        };
        p.references.push(reference);
        return { id: reference.id };
      }
      case "updateReference": {
        human();
        const r = find(p.references, op.id);
        r.name = text(op.name, "图片名称", 200);
        r.note = String(op.note || "").slice(0, 4000);
        return { id: r.id };
      }
      case "removeReference": {
        human();
        find(p.references, op.id);
        p.references = p.references.filter((r) => r.id !== op.id);
        // Keep the bytes: earlier turns may still refer to this attachment.
        return { id: op.id };
      }
      case "setSetting": {
        let s = op.id ? find(p.settings, op.id) : null;
        if (!s) {
          s = {
            id: id("setting"),
            title: text(op.title, "设定标题", 150),
            ...emptyDoc(),
          };
          p.settings.push(s);
        }
        s.title = text(op.title || s.title, "设定标题", 150);
        const character =
          op.character === undefined ? latest(s)?.character : op.character;
        s.versions.push(
          revision({
            text: text(op.text, "设定"),
            ...(character
              ? {
                  character: {
                    name: text(character.name, "角色名称", 120),
                    ...voiceProfile(character),
                  },
                }
              : {}),
          }),
        );
        s.acceptedVersionId = latest(s).id;
        p.settingComplete = false;
        return { id: s.id, versionId: s.acceptedVersionId };
      }
      case "completeSetting":
        human();
        requireValue(p.settings.length, "先写好共享设定");
        p.settingComplete = true;
        return { complete: true };
      case "createEpisode": {
        human();
        requireValue(p.settingComplete, "先完成共享设定");
        requireValue(
          Number.isInteger(op.number) && op.number > 0,
          "集数必须为正整数",
        );
        if (p.episodes.some((e) => e.number === op.number))
          fail("这集已经存在", "duplicate_episode", 409);
        const selected = op.settingIds || p.settings.map((s) => s.id);
        const e = {
          id: id("episode"),
          number: op.number,
          title: op.title || "第 " + op.number + " 集",
          settingPins: selected.map((sid) => {
            const s = find(p.settings, sid);
            return { settingId: s.id, versionId: s.acceptedVersionId };
          }),
          synopsis: emptyDoc(),
          storyboard: emptyDoc(),
          assetRefs: [],
          bindings: {},
          clips: [],
          createdAt: now(),
        };
        p.episodes.push(e);
        return { id: e.id };
      }
      case "setSynopsis": {
        const e = episode();
        e.synopsis.versions.push(
          revision({
            text: text(op.text, "梗概"),
            authorRole: a.role,
            authorSessionId: a.sessionId || null,
            settingPins: clone(e.settingPins),
          }),
        );
        return { id: latest(e.synopsis).id };
      }
      case "setStoryboard": {
        const e = episode();
        requireValue(currentApproved(e.synopsis), "梗概须审核通过后才能写分镜");
        const body = text(op.text, "分镜");
        for (const [name, assetId] of Object.entries(op.bindings || {})) {
          find(p.assets, assetId);
          e.bindings[normalizeName(name)] = assetId;
        }
        e.storyboard.versions.push(
          revision({
            text: body,
            authorRole: a.role,
            authorSessionId: a.sessionId || null,
            synopsisVersionId: e.synopsis.acceptedVersionId,
            mentions: mentions(body),
          }),
        );
        return { id: latest(e.storyboard).id, mentions: mentions(body) };
      }
      case "ensureAsset": {
        const e = episode();
        this.storyboardGate(e);
        const name = normalizeName(text(op.name, "资产名称", 120));
        let matches = p.assets.filter(
          (x) => x.name === name || (x.aliases || []).includes(name),
        );
        if (matches.length > 1)
          fail(
            "资产同名，请通过 bindAsset 明确选择稳定 ID",
            "ambiguous_asset",
            409,
          );
        let asset = e.bindings[name]
          ? find(p.assets, e.bindings[name])
          : matches[0];
        if (
          asset &&
          op.kind &&
          asset.kind !== op.kind &&
          asset.kind !== "unclassified"
        )
          fail(
            "同名资产类型不同，请选择原资产或使用清晰的新名称",
            "ambiguous_asset",
            409,
          );
        if (!asset) {
          requireValue(assetKinds.includes(op.kind), "资产类型无效");
          if (op.parentAssetId) find(p.assets, op.parentAssetId);
          asset = {
            id: id("asset"),
            name,
            kind: op.kind,
            description: op.description || "",
            parentAssetId: op.parentAssetId || null,
            prompt: op.description || name,
            promptRevision: 1,
            ...emptyDoc(),
          };
          p.assets.push(asset);
        }
        if (op.kind) {
          requireValue(assetKinds.includes(op.kind), "资产类型无效");
          asset.kind = op.kind;
        }
        if (op.parentAssetId) {
          let parent = find(p.assets, op.parentAssetId);
          const seen = new Set([asset.id]);
          while (parent) {
            requireValue(!seen.has(parent.id), "对象不能循环归属");
            seen.add(parent.id);
            parent = parent.parentAssetId
              ? find(p.assets, parent.parentAssetId)
              : null;
          }
          asset.parentAssetId = op.parentAssetId;
        }
        if (op.purpose) asset.purpose = text(op.purpose, "用途", 100);
        e.bindings[name] = asset.id;
        this.link(e, asset);
        if (asset.kind === "character") {
          const settings = e.settingPins.map((pin) => ({
            id: pin.settingId,
            version: find(
              find(p.settings, pin.settingId).versions,
              pin.versionId,
            ),
          }));
          const source = op.settingId
            ? find(settings, op.settingId)
            : settings.find((s) => s.version.character?.name === asset.name);
          if (op.voice || (!asset.voice && source?.version.character)) {
            this.setVoice(p, asset, op.voice || source.version.character, e);
            if (source) asset.settingId = source.id;
          } else if (asset.voice?.hasDialogue && asset.voiceAssetId) {
            this.link(e, find(p.assets, asset.voiceAssetId));
          }
        }
        return {
          id: asset.id,
          versionId: e.assetRefs.find((r) => r.assetId === asset.id).versionId,
        };
      }
      case "bindAsset": {
        const e = episode();
        this.storyboardGate(e);
        const asset = find(p.assets, op.assetId);
        e.bindings[normalizeName(op.name)] = asset.id;
        this.link(e, asset);
        if (asset.voice?.hasDialogue && asset.voiceAssetId)
          this.link(e, find(p.assets, asset.voiceAssetId));
        return { id: asset.id };
      }
      case "setVoiceProfile": {
        const asset = find(p.assets, op.assetId);
        const e = op.episodeId || a.episodeId ? episode() : null;
        if (a.role !== "human") this.storyboardGate(e);
        this.setVoice(p, asset, op.voice, e);
        return { id: asset.id, voiceAssetId: asset.voiceAssetId || null };
      }
      case "searchVoices": {
        human();
        const asset = find(p.assets, op.assetId);
        requireValue(
          asset.voice?.hasDialogue && asset.voiceAssetId,
          "先填写角色的音色关键词",
        );
        const audio = find(p.assets, asset.voiceAssetId);
        requireValue(
          !["queued", "searching"].includes(audio.voiceSearch?.status),
          "音色搜索正在进行",
        );
        this.queueVoices(audio, asset.voice);
        return { id: audio.id, searchId: audio.voiceSearch.id };
      }
      case "renameAsset": {
        const asset = find(p.assets, op.assetId),
          name = normalizeName(text(op.name, "资产名称", 120));
        if (
          p.assets.some(
            (a) =>
              a.id !== asset.id &&
              (a.name === name || (a.aliases || []).includes(name)),
          )
        )
          fail(
            "已有同名或同别名资产，请使用明确的新名称",
            "ambiguous_asset",
            409,
          );
        asset.aliases = [
          ...new Set([...(asset.aliases || []), asset.name]),
        ].filter((x) => x !== name);
        asset.name = name;
        return { id: asset.id, name, aliases: asset.aliases };
      }
      case "setAssetPrompt": {
        const asset = find(p.assets, op.assetId);
        const e = episode();
        this.storyboardGate(e);
        for (const ref of op.refs || []) this.validateRef(p, e, ref);
        asset.prompt = text(op.prompt, "提示词");
        asset.refs = clone(op.refs || []);
        if (op.generation)
          asset.generation = normalize(
            "image",
            op.generation,
            p.generation.image,
          );
        asset.promptRevision++;
        return { id: asset.id, promptRevision: asset.promptRevision };
      }
      case "review": {
        human();
        requireValue(
          ["accepted", "rejected"].includes(op.decision),
          "审核决定无效",
        );
        let doc, e;
        if (["synopsis", "storyboard"].includes(op.targetType)) {
          e = episode();
          doc = e[op.targetType];
          if (op.targetType === "storyboard") {
            requireValue(currentApproved(e.synopsis), "先审核当前梗概");
          }
        } else if (op.targetType === "asset") doc = find(p.assets, op.targetId);
        else if (op.targetType === "clip") {
          e = episode();
          doc = find(e.clips, op.targetId);
        } else fail("审核目标无效");
        const v = find(doc.versions, op.versionId);
        requireValue(!v.deletedAt, "此备选已删除");
        requireValue(
          v.status !== "accepted" || op.decision === "accepted",
          "已采用版本不能反向撤销；请采用另一个版本",
        );
        if (["synopsis", "storyboard"].includes(op.targetType))
          requireValue(latest(doc).id === v.id, "请审核当前文本版本");
        if (op.targetType === "storyboard")
          requireValue(
            v.synopsisVersionId === e.synopsis.acceptedVersionId,
            "分镜基于旧梗概，先更新分镜",
          );
        v.status = op.decision;
        v.reviewedAt = now();
        if (op.decision === "accepted") {
          if (["asset", "clip"].includes(op.targetType))
            this.adoptMedia(p, doc, v, op.episodeId);
          else doc.acceptedVersionId = v.id;
        }
        p.reviews.push({
          id: id("review"),
          targetType: op.targetType,
          targetId: op.targetId || e.id,
          versionId: v.id,
          decision: op.decision,
          at: now(),
        });
        if (op.targetType === "storyboard" && op.decision === "accepted")
          this.resolveMentions(p, e, v);
        if (op.targetType === "asset" && op.decision === "accepted")
          for (const ep of p.episodes) {
            const r = ep.assetRefs.find((r) => r.assetId === doc.id);
            if (r && !r.versionId) r.versionId = v.id;
          }
        return { id: v.id, status: v.status };
      }
      case "repinAsset": {
        human();
        const e = episode(),
          asset = find(p.assets, op.assetId),
          v = find(asset.versions, op.versionId);
        requireValue(usableMedia(v), "只能引用通过或自行上传的素材");
        const r = find(
          e.assetRefs.map((r) => ({ ...r, id: r.assetId })),
          asset.id,
        );
        e.assetRefs.find((x) => x.assetId === r.id).versionId = v.id;
        this.resolvePendingVoices(p, e);
        return { id: asset.id, versionId: v.id };
      }
      case "repinSetting": {
        human();
        const e = episode(),
          s = find(p.settings, op.settingId);
        find(s.versions, op.versionId);
        const r = e.settingPins.find((r) => r.settingId === s.id);
        requireValue(r, "本集未引用该设定");
        r.versionId = op.versionId;
        return { id: s.id, versionId: op.versionId };
      }
      case "saveAssetCanvas": {
        human();
        const asset = find(p.assets, op.assetId);
        requireValue(
          Array.isArray(op.graph?.nodes) &&
            op.graph.nodes.length <= 500 &&
            Array.isArray(op.graph.links) &&
            op.graph.links.length <= 1000,
          "画布数据无效",
        );
        asset.canvasGraph = clone(op.graph);
        return { id: asset.id };
      }
      case "saveCanvasLayout": {
        human();
        const target =
          op.targetType === "asset"
            ? find(p.assets, op.targetId)
            : find(episode().clips, op.targetId);
        requireValue(
          Array.isArray(op.positions) && op.positions.length <= 500,
          "画布布局无效",
        );
        target.canvasLayout = Object.fromEntries(
          op.positions.map((item) => {
            requireValue(
              typeof item.id === "string" &&
                Number.isFinite(item.x) &&
                Number.isFinite(item.y),
              "节点位置无效",
            );
            return [item.id, { x: item.x, y: item.y }];
          }),
        );
        return { id: target.id };
      }
      case "importAsset": {
        human();
        const asset = find(p.assets, op.assetId);
        const imported =
          op.canvasNodeId &&
          asset.versions.find(
            (v) => v.canvasNodeId === op.canvasNodeId && !v.deletedAt,
          );
        if (imported) return { id: imported.id };
        requireValue(
          op.media && /^media\/[a-zA-Z0-9._-]+$/.test(op.media.path),
          "素材必须已存入本项目",
        );
        const v = revision({
          media: op.media,
          prompt: asset.prompt,
          promptRevision: asset.promptRevision,
          source: "import",
          ...(op.canvasNodeId ? { canvasNodeId: op.canvasNodeId } : {}),
        });
        asset.versions.push(v);
        if (op.canvasNodeId)
          v.status = asset.acceptedVersionId ? "alternative" : "pending";
        else this.adoptMedia(p, asset, v, op.episodeId);
        return { id: v.id };
      }
      case "deleteMediaVersion": {
        human();
        const doc =
          op.targetType === "asset"
            ? find(p.assets, op.targetId)
            : find(episode().clips, op.targetId);
        const v = find(doc.versions, op.versionId);
        requireValue(
          doc.acceptedVersionId !== v.id,
          "当前通过的版本不能作为备选删除",
        );
        const referenced =
          p.episodes.some(
            (e) =>
              e.assetRefs.some((r) => r.versionId === v.id) ||
              e.clips.some((c) =>
                c.plan.refs.some((r) => r.versionId === v.id),
              ),
          ) ||
          p.assets.some((a) => a.refs?.some((r) => r.versionId === v.id)) ||
          p.jobs.some(
            (j) =>
              !terminal.has(j.status) &&
              j.snapshot.refs.some((r) => r.versionId === v.id),
          );
        requireValue(!referenced, "此版本仍被其他内容引用，请先更换引用");
        v.deletedAt ||= now();
        v.status = "deleted";
        return { id: v.id };
      }
      case "generateAssetVariation": {
        human();
        const asset = find(p.assets, op.assetId),
          e = episode();
        this.storyboardGate(e);
        requireValue(
          !["audio", "video", "unclassified"].includes(asset.kind),
          "请先明确图片资产类型",
        );
        requireValue(
          e.assetRefs.some((r) => r.assetId === asset.id),
          "资产不在本集",
        );
        const refs = clone(op.refs || []);
        for (const ref of refs) this.validateCanvasRef(p, ref);
        const generation = normalize(
          "image",
          op.generation,
          p.generation.image,
        );
        const snapshot = {
          prompt: text(op.prompt, "提示词"),
          refs,
          ...generation,
          kind: "image",
          promptRevision: asset.promptRevision,
        };
        this.validateGeneration(p, snapshot, "image");
        return this.addJob(p, {
          targetType: "asset",
          targetId: asset.id,
          episodeId: e.id,
          independent: true,
          ...(op.canvasNodeId ? { canvasNodeId: op.canvasNodeId } : {}),
          snapshot,
        });
      }
      case "planClip": {
        const e = episode();
        this.storyboardGate(e);
        requireValue(Array.isArray(op.refs), "请明确提供参考列表");
        const refs = clone(op.refs);
        const knownVoices = refs.some((r) => {
          const a = find(p.assets, r.assetId);
          return (
            a.voice?.hasDialogue ||
            (a.parentAssetId &&
              find(p.assets, a.parentAssetId).voice?.hasDialogue)
          );
        });
        requireValue(
          !knownVoices || Array.isArray(op.speakingAssetIds),
          "请明确本片段说话角色 speakingAssetIds；无对白填 []",
        );
        requireValue(
          op.speakingAssetIds === undefined ||
            Array.isArray(op.speakingAssetIds),
          "speakingAssetIds 必须是角色 ID 数组",
        );
        const speakingAssetIds = [...new Set(op.speakingAssetIds || [])];
        const voiceBindings = [];
        const pendingVoiceAssetIds = [];
        for (const assetId of speakingAssetIds) {
          const character = find(p.assets, assetId);
          requireValue(
            character.kind === "character" && character.voice?.hasDialogue,
            "说话角色须先填写音色特质：" + character.name,
          );
          requireValue(
            e.assetRefs.some((r) => r.assetId === assetId),
            "说话角色不在本集",
          );
          const audio = find(p.assets, character.voiceAssetId);
          const pin = e.assetRefs.find((r) => r.assetId === audio.id);
          if (!pin?.versionId) {
            pendingVoiceAssetIds.push(audio.id);
            continue;
          }
          requireValue(
            !refs.some(
              (r) =>
                r.assetId === audio.id &&
                (r.versionId !== pin.versionId || r.role !== "audio"),
            ),
            "角色音色必须使用本集固定的音频版本",
          );
          if (!refs.some((r) => r.assetId === audio.id))
            refs.push({
              assetId: audio.id,
              versionId: pin.versionId,
              role: "audio",
              purpose: "voice",
            });
          voiceBindings.push({
            characterId: character.id,
            characterName: character.name,
            assetId: audio.id,
            versionId: pin.versionId,
          });
        }
        for (const ref of refs) {
          this.validateRef(p, e, ref);
          const audio = find(p.assets, ref.assetId);
          if (
            audio.purpose === "voice" &&
            audio.parentAssetId &&
            find(p.assets, audio.parentAssetId).voice
          )
            requireValue(
              speakingAssetIds.includes(audio.parentAssetId),
              "角色音色参考需要对应的说话角色",
            );
        }
        const needed = mentions(op.prompt);
        for (const name of needed) {
          const aid = e.bindings[name];
          requireValue(
            aid &&
              refs.some(
                (r) =>
                  r.assetId === aid ||
                  find(p.assets, r.assetId).parentAssetId === aid,
              ),
            "片段提及的资产缺少已采用参考：" + name,
          );
        }
        requireValue(
          Number.isFinite(op.duration) && op.duration >= 1 && op.duration <= 30,
          "片段时长无效",
        );
        let c = op.id ? find(e.clips, op.id) : null;
        if (!c) {
          c = {
            id: id("clip"),
            title: op.title || "片段 " + (e.clips.length + 1),
            planRevision: 0,
            ...emptyDoc(),
          };
          e.clips.push(c);
        }
        c.planRevision++;
        c.title = op.title || c.title;
        c.plan = {
          ...normalize(
            "video",
            {
              model: op.model,
              duration: op.duration,
              aspectRatio: op.aspectRatio,
              resolution: op.resolution,
            },
            { ...p.generation.video, ...c.plan },
          ),
          prompt: text(op.prompt, "视频提示词"),
          refs,
          speakingAssetIds,
          voiceBindings,
          pendingVoiceAssetIds,
          storyboardVersionId: e.storyboard.acceptedVersionId,
          settingPins: clone(e.settingPins),
        };
        this.validateGeneration(p, c.plan, "video");
        return { id: c.id, planRevision: c.planRevision };
      }
      case "generate": {
        requireValue(op.targetType === "asset", "视频须由用户批量同意生成");
        const asset = find(p.assets, op.targetId);
        const e =
          op.episodeId || a.episodeId
            ? episode()
            : p.episodes.find((e) =>
                e.assetRefs.some((r) => r.assetId === asset.id),
              );
        requireValue(e, "资产须属于一集");
        this.storyboardGate(e);
        requireValue(
          !["audio", "video"].includes(asset.kind),
          "音频或视频参考请先导入真实文件",
        );
        requireValue(
          asset.kind !== "unclassified",
          "先明确资产类型与生成提示词",
        );
        for (const ref of asset.refs || []) this.validateRef(p, e, ref);
        const generation = normalize(
          "image",
          { ...asset.generation, ...(op.model ? { model: op.model } : {}) },
          p.generation.image,
        );
        this.validateGeneration(
          p,
          { ...generation, prompt: asset.prompt, refs: asset.refs || [] },
          "image",
        );
        return this.addJob(p, {
          targetType: "asset",
          targetId: asset.id,
          episodeId: e.id,
          snapshot: {
            prompt: asset.prompt,
            promptRevision: asset.promptRevision,
            ...generation,
            kind: "image",
            refs: clone(asset.refs || []),
          },
        });
      }
      case "generateClipVariation": {
        human();
        const e = episode(),
          clip = find(e.clips, op.clipId);
        const sameInput =
          text(op.prompt, "视频提示词") === clip.plan.prompt &&
          hash(op.refs || []) === hash(clip.plan.refs) &&
          hash(op.speakingAssetIds ?? clip.plan.speakingAssetIds ?? []) === hash(clip.plan.speakingAssetIds || []) &&
          Object.entries(op.generation || {}).every(
            ([key, value]) => clip.plan[key] === value,
          );
        if (op.expectedPlanRevision !== clip.planRevision && !sameInput)
          fail("片段计划已更新，你的修改已保留，请核对后再生成", "plan_conflict", 409);
        if (!sameInput)
          this.operation(
            p,
            {
              ...clip.plan,
              ...op.generation,
              type: "planClip",
              id: clip.id,
              episodeId: e.id,
              prompt: op.prompt,
              refs: op.refs,
              speakingAssetIds: op.speakingAssetIds ?? clip.plan.speakingAssetIds,
            },
            a,
          );
        const batch = this.operation(
          p,
          {
            type: "approveBatch",
            independent: true,
            episodeId: e.id,
            items: [{ clipId: clip.id, planRevision: clip.planRevision }],
          },
          a,
        );
        const job = find(p.jobs, batch.items[0].jobId);
        return { id: job.id, planRevision: clip.planRevision };
      }
      case "approveBatch": {
        human();
        const e = episode();
        this.storyboardGate(e);
        requireValue(Array.isArray(op.items) && op.items.length, "请选择片段");
        const batch = {
          id: id("batch"),
          createdAt: now(),
          episodeId: e.id,
          items: [],
        };
        for (const item of op.items) {
          const c = find(e.clips, item.clipId);
          requireValue(
            c.planRevision === item.planRevision,
            "片段提示词或参考已改动，请重新确认",
          );
          requireValue(
            c.plan.storyboardVersionId === e.storyboard.acceptedVersionId,
            "片段基于旧分镜，请先更新计划",
          );
          requireValue(
            !c.plan.pendingVoiceAssetIds?.length,
            "请先在资产库选定本片段的角色音色",
          );
          const hasVoiceCharacters = c.plan.refs.some((ref) => {
            const asset = find(p.assets, ref.assetId);
            return asset.voice?.hasDialogue ||
              (asset.parentAssetId && find(p.assets, asset.parentAssetId).voice?.hasDialogue);
          });
          requireValue(
            !hasVoiceCharacters || Array.isArray(c.plan.speakingAssetIds),
            "请先在片段计划标明说话角色；无对白留空后保存",
          );
          for (const characterId of c.plan.speakingAssetIds || []) {
            const character = find(p.assets, characterId);
            const binding = c.plan.voiceBindings?.find((b) => b.characterId === characterId);
            requireValue(
              binding && binding.assetId === character.voiceAssetId &&
                c.plan.refs.some((r) => r.assetId === binding.assetId &&
                  r.versionId === binding.versionId && r.role === "audio"),
              "请先在片段计划补齐角色音色：" + character.name,
            );
          }
          for (const ref of c.plan.refs) this.validateRef(p, e, ref);
          this.validateGeneration(p, c.plan, "video");
          const job = this.addJob(p, {
            targetType: "clip",
            targetId: c.id,
            episodeId: e.id,
            batchId: batch.id,
            ...(op.independent ? { independent: true } : {}),
            snapshot: {
              ...clone(c.plan),
              planRevision: c.planRevision,
              kind: "video",
            },
          });
          batch.items.push({
            clipId: c.id,
            planRevision: c.planRevision,
            jobId: job.id,
          });
        }
        p.batches.push(batch);
        return batch;
      }
      case "retryJob": {
        const j = find(p.jobs, op.jobId);
        requireValue(
          ["failed", "cancelled"].includes(j.status),
          "此任务无须重试，提交未知时请先恢复任务",
        );
        if (j.targetType === "clip" && (!j.remoteId || j.remoteTerminal))
          fail("视频重新提交需要再次批量确认");
        if (j.remoteTerminal)
          return this.addJob(p, {
            targetType: j.targetType,
            targetId: j.targetId,
            episodeId: j.episodeId,
            snapshot: clone(j.snapshot),
            retryOf: j.id,
          });
        j.status = j.remoteId ? "polling" : "queued";
        j.error = null;
        delete j.cancelledAt;
        return { id: j.id, status: j.status };
      }
      case "resolveUnknownJob": {
        human();
        const j = find(p.jobs, op.jobId);
        requireValue(j.status === "submission_unknown", "此任务没有未知提交");
        if (op.remoteId) {
          requireValue(
            /^[a-zA-Z0-9_-]{5,150}$/.test(op.remoteId),
            "供应商任务 ID 无效",
          );
          j.remoteId = op.remoteId;
          j.status = "polling";
          j.error = null;
        } else {
          requireValue(op.notSubmitted === true, "请先核对供应商任务记录");
          j.status = "failed";
          j.error = "用户确认供应商没有收到，可重新提交";
          j.unknownResolvedAt = now();
        }
        return { id: j.id, status: j.status };
      }
      case "cancelJob": {
        const j = find(p.jobs, op.jobId);
        requireValue(!terminal.has(j.status), "任务已结束");
        j.status =
          j.status === "submitting" ? "submission_unknown" : "cancelled";
        if (j.status === "submission_unknown")
          j.error = "提交过程中停止，需核对供应商是否收到任务";
        j.cancelledAt = now();
        return { id: j.id, status: j.status };
      }
      case "promoteVariant": {
        if (op.targetType === "asset") {
          human();
          const source = find(p.assets, op.assetId),
            v = find(source.versions, op.versionId);
          requireValue(v.media, "候选没有真实素材");
          let suffix = 2,
            name = source.name + "-" + suffix;
          while (
            p.assets.some(
              (a) => a.name === name || (a.aliases || []).includes(name),
            )
          )
            name = source.name + "-" + ++suffix;
          const copy = {
            ...clone(source),
            id: id("asset"),
            name,
            aliases: [],
            prompt: v.snapshot?.prompt || v.prompt || source.prompt,
            refs: clone(v.snapshot?.refs || []),
            promptRevision: 1,
            source: { assetId: source.id, versionId: v.id },
            versions: [
              {
                ...clone(v),
                id: id("v"),
                status: "accepted",
                reviewedAt: now(),
              },
            ],
          };
          copy.acceptedVersionId = copy.versions[0].id;
          p.assets.push(copy);
          if (op.episodeId) this.link(episode(), copy);
          p.reviews.push({
            id: id("review"),
            targetType: "asset",
            targetId: copy.id,
            versionId: copy.acceptedVersionId,
            decision: "accepted",
            at: now(),
            action: "promote",
          });
          return { id: copy.id };
        }
        human();
        const e = episode(),
          c = find(e.clips, op.clipId),
          v = find(c.versions, op.versionId);
        requireValue(v.media, "候选没有真实素材");
        const copy = {
          id: id("clip"),
          title: op.title || c.title + "-2",
          planRevision: 1,
          plan: clone(v.snapshot || c.plan),
          versions: [
            { ...clone(v), id: id("v"), status: "accepted", reviewedAt: now() },
          ],
          source: { clipId: c.id, versionId: v.id },
          createdAt: now(),
        };
        copy.acceptedVersionId = copy.versions[0].id;
        e.clips.push(copy);
        p.reviews.push({
          id: id("review"),
          targetType: "clip",
          targetId: copy.id,
          versionId: copy.acceptedVersionId,
          decision: "accepted",
          at: now(),
          action: "promote",
        });
        return { id: copy.id };
      }
      default:
        fail("未知操作 " + op.type);
    }
  }
  storyboardGate(e) {
    requireValue(
      currentApproved(e.synopsis) && currentApproved(e.storyboard),
      "当前梗概、文字分镜均须审核通过",
    );
    requireValue(
      accepted(e.storyboard).synopsisVersionId === e.synopsis.acceptedVersionId,
      "分镜基于旧梗概",
    );
  }
  queueVoices(audio, profile) {
    audio.voiceSearch = {
      id: id("voice-search"),
      status: "queued",
      profile: clone(profile),
      resultVersionIds: [],
      createdAt: now(),
      error: null,
    };
  }
  setVoice(p, asset, input, e) {
    requireValue(asset.kind === "character", "只有人物资产可设置音色");
    const profile = voiceProfile(input),
      changed = hash(asset.voice || null) !== hash(profile);
    asset.voice = profile;
    if (!profile.hasDialogue) {
      if (asset.voiceAssetId) {
        const audio = find(p.assets, asset.voiceAssetId);
        if (["queued", "searching"].includes(audio.voiceSearch?.status))
          audio.voiceSearch = {
            ...audio.voiceSearch,
            id: id("voice-search"),
            status: "cancelled",
          };
        for (const ep of e ? [e] : p.episodes) {
          if (
            !ep.clips.some((c) =>
              c.plan.refs.some((r) => r.assetId === audio.id) ||
              c.plan.pendingVoiceAssetIds?.includes(audio.id),
            )
          )
            ep.assetRefs = ep.assetRefs.filter(
              (r) => r.assetId !== audio.id || r.versionId,
            );
        }
      }
      return;
    }
    let audio = asset.voiceAssetId ? find(p.assets, asset.voiceAssetId) : null;
    if (!audio) {
      audio = {
        id: id("asset"),
        name: asset.name + " · 音色",
        kind: "audio",
        purpose: "voice",
        parentAssetId: asset.id,
        description: profile.description,
        ...emptyDoc(),
      };
      p.assets.push(audio);
      asset.voiceAssetId = audio.id;
    }
    // Casting from the public library must also be usable by episodes that
    // already reference this character. link() preserves every existing pin.
    for (const ep of e ? [e] : p.episodes)
      if (ep.assetRefs.some((r) => r.assetId === asset.id))
        this.link(ep, audio);
    if (changed || (!audio.voiceSearch && !audio.versions.length))
      this.queueVoices(audio, profile);
  }
  link(e, asset) {
    if (!e.assetRefs.some((r) => r.assetId === asset.id))
      e.assetRefs.push({
        assetId: asset.id,
        versionId: asset.acceptedVersionId || null,
      });
  }
  resolveMentions(p, e, v) {
    for (const name of v.mentions) {
      const matches = p.assets.filter(
        (a) => a.name === name || (a.aliases || []).includes(name),
      );
      let a = e.bindings[name]
        ? p.assets.find((a) => a.id === e.bindings[name])
        : matches.length === 1
          ? matches[0]
          : null;
      if (!a && !matches.length) {
        a = {
          id: id("asset"),
          name,
          kind: "unclassified",
          description: "",
          prompt: name,
          promptRevision: 1,
          refs: [],
          ...emptyDoc(),
        };
        p.assets.push(a);
      }
      if (a) {
        e.bindings[name] = a.id;
        this.link(e, a);
        if (a.voice?.hasDialogue && a.voiceAssetId)
          this.link(e, find(p.assets, a.voiceAssetId));
      }
    }
  }
  unresolved(p, e) {
    return (accepted(e.storyboard)?.mentions || []).filter((name) => {
      const aid = e.bindings[name];
      return !aid || !e.assetRefs.find((r) => r.assetId === aid)?.versionId;
    });
  }
  validateCanvasRef(p, r) {
    const asset = find(p.assets, r.assetId),
      version = find(asset.versions, r.versionId);
    requireValue(
      r.role === "image" &&
        !version.deletedAt &&
        version.media?.mime.startsWith("image/"),
      "参考图片不存在或已删除",
    );
  }
  validateRef(p, e, r) {
    requireValue(["image", "audio", "video"].includes(r.role), "参考角色无效");
    const a = find(p.assets, r.assetId),
      v = find(a.versions, r.versionId);
    requireValue(usableMedia(v), "参考尚未通过");
    requireValue(
      e.assetRefs.some((x) => x.assetId === a.id && x.versionId === v.id),
      "参考版本不是本集采用的版本",
    );
    requireValue(
      v.media.mime.startsWith(r.role + "/"),
      "素材类型与参考角色不符",
    );
  }
  addJob(p, data) {
    const { buildRequest } = require("./provider.cjs");
    buildRequest(
      data.snapshot,
      data.snapshot.refs.map((r) => {
        const a = find(p.assets, r.assetId),
          v = find(a.versions, r.versionId);
        return {
          ...r,
          url: "https://pending.upload/" + v.id,
          duration: v.media?.duration,
        };
      }),
    );
    const fingerprint = hash(data.snapshot);
    requireValue(
      !p.jobs.some(
        (j) =>
          j.targetId === data.targetId &&
          j.fingerprint === fingerprint &&
          j.status === "submission_unknown",
      ),
      "相同输入已有提交结果未知的任务，请先恢复任务，避免重复生成",
    );
    const existing = p.jobs.find(
      (j) =>
        j.targetId === data.targetId &&
        j.fingerprint === fingerprint &&
        !terminal.has(j.status),
    );
    if (existing && !data.independent)
      return { id: existing.id, status: existing.status };
    const job = {
      id: id("job"),
      ...data,
      fingerprint,
      status: "queued",
      createdAt: now(),
      updatedAt: now(),
      remoteId: null,
    };
    p.jobs.push(job);
    return { id: job.id, status: job.status };
  }
  addResult(projectId, jobId, media) {
    return this.internal(projectId, (p) => {
      const j = find(p.jobs, jobId);
      if (j.resultVersionId) return;
      const doc =
        j.targetType === "asset"
          ? find(p.assets, j.targetId)
          : find(find(p.episodes, j.episodeId).clips, j.targetId);
      const v = revision({
        media,
        status: doc.acceptedVersionId ? "alternative" : "pending",
        snapshot: clone(j.snapshot),
        jobId: j.id,
        ...(j.canvasNodeId ? { canvasNodeId: j.canvasNodeId } : {}),
        prompt: j.snapshot.prompt,
        source: "generated",
        late:
          !!j.cancelledAt ||
          (j.targetType === "asset"
            ? !j.independent && doc.promptRevision !== j.snapshot.promptRevision
            : doc.planRevision !== j.snapshot.planRevision),
      });
      doc.versions.push(v);
      j.resultVersionId = v.id;
      j.status = "completed";
      j.updatedAt = now();
    });
  }
  adoptMedia(p, doc, version, episodeId) {
    doc.acceptedVersionId = version.id;
    version.approvedAt ||=
      version.source === "import" ? version.createdAt : now();
    for (const v of doc.versions)
      if (!v.deletedAt)
        v.status = v.id === version.id ? "accepted" : "alternative";
    for (const e of p.episodes) {
      const pin = e.assetRefs.find((r) => r.assetId === doc.id);
      if (pin && (!pin.versionId || e.id === episodeId))
        pin.versionId = version.id;
      if (doc.purpose === "voice") this.resolvePendingVoices(p, e);
    }
  }
  resolvePendingVoices(p, e) {
    for (const clip of e.clips) {
      const plan = clip.plan;
      if (!plan?.pendingVoiceAssetIds?.length) continue;
      const unresolved = [];
      for (const assetId of plan.pendingVoiceAssetIds) {
        const audio = find(p.assets, assetId);
        const character = find(p.assets, audio.parentAssetId);
        const pin = e.assetRefs.find((r) => r.assetId === assetId);
        if (!pin?.versionId) {
          unresolved.push(assetId);
          continue;
        }
        plan.refs.push({ assetId, versionId: pin.versionId, role: "audio", purpose: "voice" });
        plan.voiceBindings.push({
          characterId: character.id,
          characterName: character.name,
          assetId,
          versionId: pin.versionId,
        });
      }
      if (unresolved.length !== plan.pendingVoiceAssetIds.length) {
        plan.pendingVoiceAssetIds = unresolved;
        clip.planRevision++;
      }
    }
  }
  impacts(p, e) {
    const out = [];
    for (const pin of e.settingPins) {
      const s = find(p.settings, pin.settingId);
      if (s.acceptedVersionId !== pin.versionId)
        out.push({
          type: "setting",
          id: s.id,
          title: s.title,
          current: pin.versionId,
          latest: s.acceptedVersionId,
        });
    }
    for (const ref of e.assetRefs) {
      const a = find(p.assets, ref.assetId);
      if (ref.versionId && a.acceptedVersionId !== ref.versionId)
        out.push({
          type: "asset",
          id: a.id,
          title: a.name,
          current: ref.versionId,
          latest: a.acceptedVersionId,
        });
    }
    if (
      accepted(e.synopsis) &&
      hash(accepted(e.synopsis).settingPins) !== hash(e.settingPins)
    )
      out.push({ type: "synopsis", id: e.id, title: "梗概使用了先前设定" });
    if (
      accepted(e.storyboard) &&
      accepted(e.storyboard).synopsisVersionId !== e.synopsis.acceptedVersionId
    )
      out.push({
        type: "storyboard",
        id: e.id,
        title: "文字分镜使用了先前梗概",
      });
    for (const c of e.clips) {
      const v = accepted(c),
        plan = c.plan;
      const repinned = plan.refs.some(
        (r) =>
          !e.assetRefs.some(
            (pin) => pin.assetId === r.assetId && pin.versionId === r.versionId,
          ),
      );
      const changed =
        repinned ||
        plan.storyboardVersionId !== e.storyboard.acceptedVersionId ||
        hash(plan.settingPins) !== hash(e.settingPins) ||
        (v &&
          (hash(v.snapshot?.refs || []) !== hash(plan.refs) ||
            v.snapshot?.planRevision !== c.planRevision));
      if (changed) out.push({ type: "clip", id: c.id, title: c.title });
    }
    return out;
  }
  validateGeneration(p, plan, kind) {
    buildRequest(
      { ...plan, kind },
      (plan.refs || []).map((r) => ({
        ...r,
        url: "https://reference.invalid/validated-before-upload",
        duration: find(find(p.assets, r.assetId).versions, r.versionId).media
          ?.duration,
      })).concat((plan.pendingVoiceAssetIds || []).map((assetId) => ({
        assetId,
        role: "audio",
        url: "https://reference.invalid/pending-voice",
        duration: 5,
      }))),
    );
  }
  nextStage(p, e) {
    if (!currentApproved(e.synopsis)) return "synopsis";
    if (
      !currentApproved(e.storyboard) ||
      accepted(e.storyboard)?.synopsisVersionId !== e.synopsis.acceptedVersionId
    )
      return "storyboard";
    if (this.unresolved(p, e).length || e.assetRefs.some((r) => !r.versionId))
      return "assets";
    return "video";
  }
  context(p, s) {
    const e = s.episodeId ? find(p.episodes, s.episodeId) : null,
      stage = s.stage;
    const settings = p.settings
      .filter((d) => s.settingIds.includes(d.id))
      .map((d) => {
        const pin = e?.settingPins.find((x) => x.settingId === d.id);
        const v = pin ? find(d.versions, pin.versionId) : latest(d);
        return {
          id: d.id,
          title: d.title,
          versionId: v?.id,
          text: v?.text || "",
          ...(v?.character ? { character: v.character } : {}),
        };
      });
    const doc = (d, include) => ({
      acceptedVersionId: d.acceptedVersionId,
      currentVersionId: latest(d)?.id,
      ...(include ? { current: latest(d), accepted: accepted(d) } : {}),
    });
    return {
      schemaVersion: "auralis.drama-context.v1",
      revision: p.revision,
      scope: {
        projectId: p.id,
        role: s.role,
        episodeId: s.episodeId,
        stage: s.stage,
        settingIds: s.settingIds,
        targetIds: s.targetIds,
      },
      project: { id: p.id, title: p.title, premise: p.premise },
      reviewHandoff: e
        ? ["synopsis", "storyboard"].flatMap((name) => {
            const v = accepted(e[name]);
            if (!v) return [];
            return [
              {
                targetType: name,
                versionId: v.id,
                creatorEdited: v.authorRole === "human",
                notice:
                  v.authorRole === "human"
                    ? "创作者有改动，并已审核采用。以本轮 context 中采用版本的正文为准，不要沿用对话里的旧稿。"
                    : "创作者已审核采用此版本（旧项目可能包含未标记的手动修改）。以本轮 context 中的采用正文为准。",
              },
            ];
          })
        : [],
      generation: p.generation,
      generationModels: Object.fromEntries(
        Object.entries(p.generation).map(([kind, config]) => [
          kind,
          models[config.model],
        ]),
      ),
      references: (p.references || [])
        .filter((r) => (s.referenceIds || []).includes(r.id))
        .map((r) => ({
          id: r.id,
          name: r.name,
          note: r.note,
          source: r.source || null,
          mediaPath: r.media.path,
        }))
        .concat(
          (s.assetReferences || []).map((ref) => {
            const asset = find(p.assets, ref.assetId),
              version = find(asset.versions, ref.versionId);
            return {
              id: "asset-" + version.id,
              name: asset.name,
              source: ref,
              mediaPath: version.media.path,
            };
          }),
        ).concat((s.clipReferences || []).map(ref => {
          const clip = find(e.clips, ref.clipId);
          const version = ref.versionId ? find(clip.versions, ref.versionId) : null;
          return { id: "clip-" + clip.id, name: clip.title, kind: "clip", source: ref,
            mediaPath: version?.media?.path || null, mime: version?.media?.mime || null };
        })),
      settings,
      settingIndex: p.settings
        .filter((d) => !e || e.settingPins.some((x) => x.settingId === d.id))
        .map((d) => {
          const pin = e?.settingPins.find((x) => x.settingId === d.id);
          const v = pin ? find(d.versions, pin.versionId) : latest(d);
          return {
            id: d.id,
            title: d.title,
            versionId: v?.id,
            summary: v?.text.slice(0, 120),
            ...(v?.character ? { character: v.character } : {}),
          };
        }),
      episode: e
        ? {
            id: e.id,
            number: e.number,
            title: e.title,
            synopsis: doc(e.synopsis, stage !== "video"),
            storyboard:
              stage === "video"
                ? {
                    acceptedVersionId: e.storyboard.acceptedVersionId,
                    accepted: accepted(e.storyboard),
                  }
                : doc(e.storyboard, stage !== "synopsis"),
            unresolved: this.unresolved(p, e),
            bindings: e.bindings,
          }
        : null,
      assets:
        stage === "setting" || stage === "synopsis"
          ? []
          : p.assets
              .filter((a) => e?.assetRefs.some((r) => r.assetId === a.id))
              .map((a) => ({
                id: a.id,
                name: a.name,
                kind: a.kind,
                approvedVersionId: a.acceptedVersionId,
                parentAssetId: a.parentAssetId || null,
                purpose: a.purpose || null,
                ...(a.voice
                  ? { voice: a.voice, voiceAssetId: a.voiceAssetId || null }
                  : {}),
                ...(a.voiceSearch
                  ? {
                      voiceSearch: {
                        status: a.voiceSearch.status,
                        candidateCount: a.voiceSearch.resultVersionIds.length,
                        error: a.voiceSearch.error,
                      },
                    }
                  : {}),
                aliases: a.aliases || [],
                pinnedVersionId:
                  e?.assetRefs.find((r) => r.assetId === a.id)?.versionId ||
                  null,
              })),
      clips:
        stage === "video"
          ? e.clips.map((c) => ({
              id: c.id,
              title: c.title,
              planRevision: c.planRevision,
              acceptedVersionId: c.acceptedVersionId,
              pendingCount: c.versions.filter((v) => v.status === "pending")
                .length,
              summary: c.plan.prompt.slice(0, 120),
              ...(s.targetIds.includes(c.id)
                ? { plan: c.plan, accepted: accepted(c) }
                : {}),
            }))
          : [],
      jobs: p.jobs
        .filter(
          (j) =>
            j.episodeId === e?.id &&
            (!s.targetIds.length || s.targetIds.includes(j.targetId)),
        )
        .map((j) => ({
          id: j.id,
          targetId: j.targetId,
          status: j.status,
          error: j.error,
        })),
      allowedOperations: this.allowed(s),
    };
  }
  inspect(p, s, ids) {
    requireValue(
      Array.isArray(ids) && ids.length <= 20,
      "每次最多读取 20 个 ID",
    );
    const e = s.episodeId ? find(p.episodes, s.episodeId) : null;
    const settings = p.settings
      .filter((x) =>
        s.role === "setting"
          ? true
          : e?.settingPins.some((r) => r.settingId === x.id),
      )
      .map((x) => {
        const pin = e?.settingPins.find((r) => r.settingId === x.id);
        return pin
          ? {
              id: x.id,
              title: x.title,
              version: find(x.versions, pin.versionId),
            }
          : x;
      });
    const pool = [
      ...settings,
      ...(e && ["assets", "storyboard", "video"].includes(s.stage)
        ? p.assets.filter((x) => e.assetRefs.some((r) => r.assetId === x.id))
        : []),
      ...(s.stage === "video" ? e.clips : []),
    ];
    return ids.map((key) => {
      const item = clone(find(pool, key));
      if (item.versions)
        item.versions = item.versions.filter((v) => !v.deletedAt);
      return item;
    });
  }
}
module.exports = {
  Store,
  id,
  now,
  hash,
  find,
  fail,
  requireValue,
  accepted,
  currentApproved,
  latest,
  mentions,
  terminal,
};
