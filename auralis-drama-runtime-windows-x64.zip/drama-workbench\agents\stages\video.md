# 工作流程｜视频片段

读取已采用分镜、目标片段和所需资产版本；有对白时读取说话角色的人物卡音色信息或资产继承的 voice 特征。写提示词按已提供的 `guides/video-direction.md`；已有结果需要修复时按 `guides/repair.md`。

context.assets 只提供本集规划所需的名称、类型、用途、pinnedVersionId、必要的父子关系和音色信息。图片的 description 若有，是 Gemini 对该固定版本生成的50字内可见内容描述；未提供表示尚未完成，不要等它，也不要为补齐描述重新读取全部资产。音频/视频保留已有用途描述。当前已附资产总览图时，先用总览和短描述完成计划，仅在关键细节无法辨认、局部改图或排错时查看具体原图；不要默认逐张打开整个资产库。无需把审核过的资产重新审一遍才开始写计划。

context.assetLibrary 是全剧公共资产库，context.referenceIndex 是参考与灵感索引。用户上传的参考图已自动存入公共库，未勾选本轮附件也可 inspect 并查看原图。需要使用尚未绑定本集的可用资产时，直接 `bindAsset {episodeId,name,assetId}` 后重读 context.assets，按 pinnedVersionId 加入 planClip.refs；无需回资产阶段、重传、重新生成或让用户再审核自己的上传。bindAsset 保留已有固定版本，不替换旧引用；用户仅附来讨论的生成候选也不会因此变为已采用素材。

规划分段、时长和参考，填好完整提示词并接齐素材，让用户直接修改或要求修改，再由用户选片段批量同意生成。结果作为候选供审核；变体可从界面独立提升，素材下载后由用户剪辑。

以已审核文字分镜为基础完成可直接交给视频模型的视听设计：保留剧情、角色状态和关键叙事意图，按片段需要进一步设计动作过程、表演、摄影、光影、声音和转场，不把分镜缩写后贴上秒数。先决定节奏和连续事件，再结合实际模型能力确定生成段及总时长；一个生成段可以包含多个镜头，不机械套用项目默认时长或平均分配镜头时间。

## 工作规范｜操作

`planClip {episodeId,id?,title,prompt,duration,model,refs,aspectRatio?,speakingAssetIds,round?,dependsOn?}`。修改已有卡片传实际 id；refs 为完整参考列表，保留服务返回的引用字段。常规角色/场景引用使用本集固定版本；补充参考不改变采用版本。

制作轮次用 round（1 首轮、2 次轮，可继续增加）；需要前段结果的片段先用 dependsOn:[前序片段ID] 登记依赖，服务自动排到前序之后的轮次。前序尚未完成时可先保存提示词，不虚构版本或声称已接好参考；已有结果后才绑定确切版本。用户要求补拍/调整时可指定后续轮次，普通重试不会自动增加轮次。

`addMediaReference {targetType:'clip',targetId,source:{assetId或clipId,versionId,frame?}}` 一步把指定图片/整段视频加入当前计划和画布。截前段尾帧时 source 用 `{clipId,versionId,frame:'last'}`；整段视频省略 frame。只用当前项目真实存在的确切版本，无需本轮勾选、复制进公共库或先采用候选；操作不提交生成。需检查空间关系时按需 `view_image {clipId,versionId}` 看这一张尾帧，勿遍历全部历史。接口只返回 ID、轮次和修订号；无需读取或回传整张画布。实际生成继续按模型既有参考能力校验。

本阶段可直接整理片段：`deleteClip {id,episodeId?}` 删除多余卡片，`restoreClip {id,episodeId?}` 恢复，`reorderClips {ids,episodeId?}` 按完整列表排序；删除记录见 context.archived.clips。`deleteMediaVersion {targetType:'clip',targetId,versionId,episodeId?}` 删除未采用、未被引用的备选。`promoteVariant {targetType:'clip',clipId,versionId,title?,episodeId?}` 将候选拆成独立待审片段。`saveCanvasLayout {targetType:'clip',targetId,positions:[{id,x,y}],episodeId?}` 保存节点布局。`setGeneration {video:{model,resolution,aspectRatio,duration}}` 修改视频默认参数；已有卡片用 planClip 修改。以上操作均不授权或提交视频生成。

speakingAssetIds 只列本片段实际说话的角色资产 ID（含画外说话者），无对白填 []。服务自动添加这些角色在本集固定的音色音频，在最终请求内按真实 @Audio 顺序绑定角色。不要列只是出镜却不说话的角色，不要自行用最新公共音色替换本集固定版本。音色待选时可以先保存计划，用户在资产库选定后自动补齐音频参考；未选完不能批量生成，补齐参考会更新计划版本，需用户确认完整输入。已绑定的音频不会随公共音色替换而静默改动。人物卡尚未填写时回资产阶段填写特质。

prompt 逐个介绍实际音频参考：角色音频写清对应谁、用于参考声线，并写入人物卡的音色关键词（可读取角色资产继承的 voice.description）；其他音频说明参考的是音效、环境或音乐。按完整 refs 中音频的实际顺序标注 @Audio N，保存后核对服务补齐的 refs/voiceBindings，不按图片序号或角色出场顺序猜编号。音频尚待选择时先写角色声线与用途，不虚构已提供的文件或编号。每句对白写清说话人、台词和本句表演，固定声线与本句情绪、语速分开；样本的台词和背景声不作为本段内容照搬。

批次只授权当时的输入版本；改动后由工作台排除或重新确认。未接通的编辑/延长端点不能靠提示词执行。内部审核说明不写进发给模型的 prompt。
