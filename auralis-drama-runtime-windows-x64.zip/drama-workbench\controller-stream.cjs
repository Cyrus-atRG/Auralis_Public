// Gateways may return JSON even when streaming was requested. Keep that contract.
async function readResponse(response, onText, { onActivity = () => {}, onDelta = () => {}, signal } = {}) {
  const streaming = response.ok && /text\/event-stream/i.test(response.headers.get("content-type") || "");
  if (!response.body) throw new Error('公司 API 返回了空响应');
  const reader = response.body.getReader(), decoder = new TextDecoder();
  const cancel = () => { reader.cancel().catch(() => {}); };
  signal?.addEventListener("abort", cancel, { once: true });
  let buffer = "", choice = { message: { role: "assistant", content: "" }, finish_reason: null }, final = null, usage = null, ended = false;
  const calls = [];
  async function event(block) {
    const data = block.split("\n").filter(line => line.startsWith("data:")).map(line => line.slice(5).trimStart()).join("\n");
    if (!data) return;
    if (data === "[DONE]") { ended = true; return; }
    const value = JSON.parse(data);
    if (value.usage) usage = value.usage;
    if (value.error || value.type === "response.failed" || value.type === "error") throw new Error(value.error?.message || value.response?.error?.message || value.message || "公司 API 流式响应失败");
    if (value.type === "response.output_text.delta" || value.type === "response.refusal.delta") { await onText(value.delta || ""); await onDelta("text", value.delta || ""); }
    if (value.type === "response.reasoning_summary_text.delta") await onDelta("reasoning", value.delta || "");
    if (value.type === "response.function_call_arguments.delta") await onDelta("arguments", value.delta || "");
    if (["response.completed", "response.incomplete"].includes(value.type)) { final = value.response; ended = true; }
    const part = value.choices?.find(c => c.index === 0) || value.choices?.[0];
    if (!part) return;
    const delta = part.delta || {};
    if (delta.content) { choice.message.content += delta.content; await onText(delta.content); await onDelta("text", delta.content); }
    if (delta.refusal) { choice.message.content += delta.refusal; await onText(delta.refusal); await onDelta("text", delta.refusal); }
    if (delta.reasoning_content) { choice.message.reasoning_content = (choice.message.reasoning_content || "") + delta.reasoning_content; await onDelta("reasoning", delta.reasoning_content); }
    for (const call of delta.tool_calls || []) {
      const target = calls[call.index || 0] ||= { id: "", type: "function", function: { name: "", arguments: "" } };
      if (call.id) target.id = call.id;
      if (call.function?.name) target.function.name += call.function.name;
      if (call.function?.arguments) { target.function.arguments += call.function.arguments; await onDelta("arguments", call.function.arguments); }
    }
    if (part.finish_reason) choice.finish_reason = part.finish_reason;
  }
  try {
    while (true) {
      signal?.throwIfAborted();
      const { value, done } = await reader.read();
      signal?.throwIfAborted();
      if (value?.length) await onActivity();
      buffer = (buffer + decoder.decode(value, { stream: !done })).replace(/\r\n/g, "\n");
      if (!streaming) { if (done) return JSON.parse(buffer); continue; }
      let end;
      while ((end = buffer.indexOf("\n\n")) >= 0) {
        const block = buffer.slice(0, end); buffer = buffer.slice(end + 2); await event(block);
        if (ended) break;
      }
      if (done || ended) break;
    }
    if (!ended && buffer.trim()) await event(buffer);
    if (!ended || (!final && !choice.finish_reason)) throw new Error("公司 API 流式响应中断；已保留收到的正文，未执行不完整工具调用");
    if (final) return final;
    if (calls.length) choice.message.tool_calls = calls.filter(Boolean);
    return { choices: [choice], ...(usage ? { usage } : {}) };
  } finally { signal?.removeEventListener("abort", cancel); await reader.cancel().catch(() => {}); reader.releaseLock(); }
}
// A live stream has no wall-clock deadline. Only prolonged silence times out;
// SSE keepalives and reasoning bytes also renew the connection watchdog.
async function requestResponse(request, endpoint, options, onText, onUpdate = () => {}) {
  const idle = new AbortController(), signal = AbortSignal.any([options.signal, idle.signal]);
  let timer;
  const touch = () => {
    clearTimeout(timer);
    timer = setTimeout(() => idle.abort(new DOMException('模型连接连续 15 分钟没有返回新数据，已停止等待；已收到的内容仍保留。', 'TimeoutError')), 15 * 60 * 1000);
    timer.unref?.();
  };
  touch();
  try {
    const response = await request(endpoint, { ...options, signal });
    signal.throwIfAborted(); touch(); await onUpdate('connected', '');
    const data = await readResponse(response, onText, { signal,
      onActivity: async () => { touch(); await onUpdate('activity', ''); }, onDelta: onUpdate });
    return { response, data };
  } catch (error) { signal.throwIfAborted(); throw error; }
  finally { clearTimeout(timer); }
}
module.exports = { readResponse, requestResponse };
