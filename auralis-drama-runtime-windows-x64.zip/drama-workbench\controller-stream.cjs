// Gateways may return JSON even when streaming was requested. Keep that contract.
async function readResponse(response, onText) {
  if (!response.ok || !/text\/event-stream/i.test(response.headers.get("content-type") || "")) return response.json();
  const reader = response.body.getReader(), decoder = new TextDecoder();
  let buffer = "", choice = { message: { role: "assistant", content: "" }, finish_reason: null }, final = null, ended = false;
  const calls = [];
  async function event(block) {
    const data = block.split("\n").filter(line => line.startsWith("data:")).map(line => line.slice(5).trimStart()).join("\n");
    if (!data) return;
    if (data === "[DONE]") { ended = true; return; }
    const value = JSON.parse(data);
    if (value.error || value.type === "response.failed" || value.type === "error") throw new Error(value.error?.message || value.response?.error?.message || value.message || "公司 API 流式响应失败");
    if (value.type === "response.output_text.delta" || value.type === "response.refusal.delta") await onText(value.delta || "");
    if (["response.completed", "response.incomplete"].includes(value.type)) { final = value.response; ended = true; }
    const part = value.choices?.find(c => c.index === 0) || value.choices?.[0];
    if (!part) return;
    const delta = part.delta || {};
    if (delta.content) { choice.message.content += delta.content; await onText(delta.content); }
    if (delta.refusal) { choice.message.content += delta.refusal; await onText(delta.refusal); }
    if (delta.reasoning_content) choice.message.reasoning_content = (choice.message.reasoning_content || "") + delta.reasoning_content;
    for (const call of delta.tool_calls || []) {
      const target = calls[call.index || 0] ||= { id: "", type: "function", function: { name: "", arguments: "" } };
      if (call.id) target.id = call.id;
      if (call.function?.name) target.function.name += call.function.name;
      if (call.function?.arguments) target.function.arguments += call.function.arguments;
    }
    if (part.finish_reason) choice.finish_reason = part.finish_reason;
  }
  try {
    while (true) {
      const { value, done } = await reader.read();
      buffer = (buffer + decoder.decode(value, { stream: !done })).replace(/\r\n/g, "\n");
      let end;
      while ((end = buffer.indexOf("\n\n")) >= 0) {
        const block = buffer.slice(0, end); buffer = buffer.slice(end + 2); await event(block);
        if (ended) break;
      }
      if (done || ended) break;
    }
    if (!ended && buffer.trim()) await event(buffer);
    if (!ended || (!final && !choice.finish_reason)) throw new Error("公司 API 流式响应中断；已保留收到的正文，未执行不完整工具调用");
    if (final) return final;
    if (calls.length) choice.message.tool_calls = calls.filter(Boolean);
    return { choices: [choice] };
  } finally { await reader.cancel().catch(() => {}); reader.releaseLock(); }
}
module.exports = { readResponse };
