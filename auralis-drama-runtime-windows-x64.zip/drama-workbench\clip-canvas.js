// Video canvases use the native request builder; durable jobs and variants belong to the workbench.
function clipCanvasTarget(scope) {
  return scope.project.episodes.find(e => e.id === scope.eid).clips.find(c => c.id === scope.clipId);
}
function clipCanvasPatch(scope, version, nodeId = version.canvasNodeId || version.id) {
  const clip = clipCanvasTarget(scope), url = '/media/' + scope.pid + '/' + version.media.path.split('/').at(-1);
  return { id: nodeId, type: 'video', family: 'Luna', role: 'genVideo', title: clip.title,
    assetUrl: url, displayUrl: url, mime: version.media.mime, status: 'completed', error: '', progressText: '',
    assetState: clip.acceptedVersionId === version.id ? 'official' : 'candidate',
    meta: { dramaVersionId: version.id, dramaCanvasMedia: version.media } };
}
async function persistCanvasMedia(scope, node) {
  if (node.meta?.dramaCanvasMedia) return node.meta.dramaCanvasMedia;
  const ref = node.meta?.dramaRef;
  if (ref) {
    const media = DramaReferences.resolve(scope.project, ref).media;
    if (media) return media;
  }
  const version = clipCanvasTarget(scope).versions.find(v => v.id === node.meta?.dramaVersionId);
  if (version?.media) return version.media;
  const url = node.displayUrl || node.assetUrl;
  if (!url || node.status !== 'completed') throw new Error('参考素材尚未准备好：' + node.title);
  if (!scope.imports.has(node.id)) scope.imports.set(node.id, (async () => {
    const response = await fetch(url);
    if (!response.ok) throw new Error('无法读取画布参考素材：' + node.title);
    return api('projects/' + scope.pid + '/upload', await response.blob(), true);
  })().catch(error => { scope.imports.delete(node.id); throw error; }));
  return scope.imports.get(node.id);
}
function saveClipCanvasDraft(scope) {
  clearTimeout(scope.timer);
  const graph = { ...canvasSnapshot(scope), planRevision: scope.planRevision };
  S.canvasDrafts.set(scope.clipId, graph);
  const task = async () => {
    for (const node of graph.nodes) {
      if (!/^(image|video|audio)\//.test(node.mime || '') || node.status !== 'completed') continue;
      const media = await persistCanvasMedia(scope, node);
      node.meta = { ...node.meta, dramaCanvasMedia: media };
      delete node.meta.localAssetId;
      node.assetUrl = node.displayUrl = '/media/' + scope.pid + '/' + media.path.split('/').at(-1);
      scope.api.updateCanvasNodes([{ id: node.id, meta: node.meta }]);
    }
    const content = { nodes: graph.nodes, links: graph.links, planRevision: graph.planRevision, referenceRevision: graph.referenceRevision }, signature = JSON.stringify(content);
    if (signature === scope.saved) return;
    await canvasApply(scope, [{ type: 'saveClipCanvas', episodeId: scope.eid, clipId: scope.clipId, graph: content }]);
    scope.saved = signature;
  };
  const pending = (scope.saving || Promise.resolve()).then(task);
  scope.saving = pending.catch(error => toast(error.message, true));
  return pending;
}
function canvasInputRole(execution, nodeId, role) {
  for (const [key, value] of [['firstFrameNodeId', 'first_frame'], ['lastFrameNodeId', 'last_frame'], ['editVideoNodeId', 'video_edit'], ['extendVideoNodeId', 'video_extend']])
    if (execution[key] === nodeId) return value;
  return role === 'video' ? 'reference_video' : role === 'audio' ? 'reference_audio' : 'ref';
}
async function queueCanvasVideo(scope, request, saveGraph = true) {
  // Capture before any save/upload can yield to another user edit.
  const graph = request.graph || canvasSnapshot(scope), execution = structuredClone(request.execution);
  const canvasRequest = await scope.api.videoRequest(request.model, request.prompt, execution, graph);
  const canvasInputs = [];
  const inputIds = [...new Set([...execution.inputNodeIds,
    ...graph.links.filter(link => link.toNodeId === execution.promptNodeId && graph.nodes.find(node => node.id === link.fromNodeId)?.mime?.startsWith('audio/')).map(link => link.fromNodeId),
  ])];
  for (const nodeId of inputIds) {
    const node = graph.nodes.find(n => n.id === nodeId), media = await persistCanvasMedia(scope, node);
    canvasInputs.push({ ...node.meta?.dramaRef, nodeId, name: node.title, media, role: media.mime.split('/')[0], inputRole: canvasInputRole(execution, nodeId, media.mime.split('/')[0]) });
  }
  if (saveGraph) await saveClipCanvasDraft(scope);
  const settings = execution.mediaSettings;
  const result = await canvasApply(scope, [{ type: 'generateCanvasVideo', episodeId: scope.eid, clipId: scope.clipId, expectedPlanRevision: scope.planRevision,
    canvasNodeId: request.nodeId, prompt: request.prompt, canvasRequest, canvasInputs, canvasExecution: execution,
    generation: { model: request.model, resolution: settings.videoResolution, aspectRatio: settings.videoAspectRatio, duration: settings.segmentDurationSeconds } }]);
  return result.results[0].id;
}
async function generateCanvasVideo(scope, request) {
  const jobId = await queueCanvasVideo(scope, request);
  for (;;) {
    const job = scope.project.jobs.find(j => j.id === jobId);
    if (job?.resultVersionId) {
      const version = clipCanvasTarget(scope).versions.find(v => v.id === job.resultVersionId);
      const patch = clipCanvasPatch(scope, version, request.nodeId);
      return { url: patch.assetUrl, mime: patch.mime, raw: {}, workbenchMeta: patch.meta };
    }
    if (job && ['failed', 'cancelled', 'superseded', 'submission_unknown'].includes(job.status)) throw new Error(job.error || '生成未完成，请在制作任务中恢复');
    await new Promise(resolve => setTimeout(resolve, 1500));
    updateCanvasProject(scope, await api('projects/' + scope.pid));
  }
}
function mountClipCanvas(frame, target, initial, draft) {
  const scope = { api: frame.contentWindow.AuralisCanvas, frame, pid: S.project.id, eid: ep().id,
    clipId: target.id, planRevision: target.planRevision, project: S.project, revision: S.project.revision, imports: new Map() };
  S.modal.canvasScope = scope;
  const saved = savedCanvas(target);
  scope.referenceKeys = new Set(target.plan.refs.map(DramaReferences.nodeId));
  scope.referenceRevision = target.referenceRevision || 0;
  const graph = saved ? structuredClone(saved) : initial;
  if (saved && (draft || saved.planRevision !== target.planRevision)) {
    if (!draft) {
      // Keep an older edited prompt and its links as history when the plan changed outside the canvas.
      const previous = graph.nodes.find(node => node.id === 'prompt');
      if (previous) {
        const priorId = 'previous-plan-' + crypto.randomUUID();
        previous.id = priorId;
        previous.title = '先前计划';
        for (const link of graph.links) {
          if (link.fromNodeId === 'prompt') link.fromNodeId = priorId;
          if (link.toNodeId === 'prompt') link.toNodeId = priorId;
        }
      }
    }
    const prompt = initial.nodes.find(n => n.id === 'prompt');
    graph.nodes = graph.nodes.filter(n => n.id !== 'prompt');
    graph.nodes.push(prompt);
    const links = initial.links.filter(l => l.toNodeId === 'prompt');
    graph.links = graph.links.filter(l => l.toNodeId !== 'prompt').concat(links);
    for (const link of links) if (!graph.nodes.some(n => n.id === link.fromNodeId)) graph.nodes.push(initial.nodes.find(n => n.id === link.fromNodeId));
  }
  scope.api.mount({ ...graph, id: target.id, title: target.title,
    allowedModels: Object.keys(S.models), videoGeneration: target.plan }, {
    referenceUrl: node => 'https://canvas-input.invalid/' + encodeURIComponent(node.id),
    generateVideo: request => generateCanvasVideo(scope, request),
    changed: () => { clearTimeout(scope.timer); scope.timer = setTimeout(() => saveClipCanvasDraft(scope).catch(() => {}), 600); },
  });
  refreshClipCanvas(scope);
}
function refreshClipCanvas(scope) {
  const graph = scope.api.snapshot(), clip = clipCanvasTarget(scope), patches = [], removed = [];
  syncCanvasReferences(scope, clip);
  for (const version of clip.versions) {
    const existing = graph.nodes.filter(n => n.meta?.dramaVersionId === version.id || n.id === version.canvasNodeId);
    if (version.deletedAt) { removed.push(...existing.map(n => n.id)); continue; }
    if (!existing.length) patches.push({ ...clipCanvasPatch(scope, version), x: 940, y: 80 + clip.versions.indexOf(version) * 280 });
    for (const node of existing) {
      const patch = clipCanvasPatch(scope, version, node.id);
      if (node.meta?.dramaVersionId !== version.id || node.assetState !== patch.assetState || node.status !== 'completed')
        patches.push({ ...patch, meta: { ...node.meta, ...patch.meta } });
    }
  }
  scope.api.updateCanvasNodes(patches, removed);
}
