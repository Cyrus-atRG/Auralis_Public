const fs = require("node:fs"), path = require("node:path"), crypto = require("node:crypto");
const digest = text => crypto.createHash("sha256").update(text).digest("hex");
const cache = new Map();
const nodes = new WeakMap();
let cacheBytes = 0;
function remember(file, text, value) {
  if (cache.has(file)) return;
  const size = Buffer.byteLength(text);
  if (size > 32 * 1024 * 1024) return;
  cache.set(file, { size, value }); cacheBytes += size;
  while (cacheBytes > 32 * 1024 * 1024) {
    const first = cache.keys().next().value; cacheBytes -= cache.get(first).size; cache.delete(first);
  }
}
function atomic(file, text) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const temporary = file + "." + crypto.randomUUID() + ".tmp", fd = fs.openSync(temporary, "wx");
  try {
    try { fs.writeFileSync(fd, text, "utf8"); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
    fs.renameSync(temporary, file);
  } finally { if (fs.existsSync(temporary)) fs.unlinkSync(temporary); }
}
function readProject(file, { lazy = false, source } = {}) {
  const root = JSON.parse(source ?? fs.readFileSync(file, "utf8"));
  if (root._storage !== "parts-v1") return root;
  const directory = path.join(path.dirname(file), "parts");
  const expand = value => {
    if (!value || typeof value !== "object") return value;
    const encoded = value;
    if (Object.keys(value).length === 1 && typeof value.$part === "string") {
      if (!/^[a-f0-9]{64}$/.test(value.$part)) throw new Error("项目分块标识无效");
      const part = path.join(directory, value.$part + ".json");
      let stored = cache.get(part)?.value;
      if (stored === undefined) {
        const text = fs.readFileSync(part, "utf8");
        if (digest(text) !== value.$part) throw new Error("项目分块校验失败");
        stored = JSON.parse(text); remember(part, text, stored);
      }
      value = stored;
    }
    if (!value || typeof value !== "object") return value;
    if (Object.keys(value).length === 1 && value.$literal) value = value.$literal;
    if (!lazy) return Array.isArray(value) ? value.map(expand) : Object.fromEntries(Object.entries(value).map(([k, v]) => [k, expand(v)]));
    const result = Array.isArray(value) ? [] : {}, fields = new Map();
    nodes.set(result, { encoded, directory, fields });
    for (const [key, raw] of Object.entries(value)) {
      const field = { raw, loaded: false };
      field.get = () => {
        if (!field.loaded) { field.value = expand(raw); field.original = field.value; field.loaded = true; field.read = true; }
        return field.value;
      };
      fields.set(key, field);
      Object.defineProperty(result, key, { enumerable: true, configurable: true, get: field.get,
        set: next => { field.value = next; field.loaded = true; } });
    }
    return result;
  };
  const normalized = root._storeVersion === 2;
  delete root._storage;
  delete root._storeVersion;
  const project = expand(root);
  if (lazy) nodes.get(project).normalized = normalized;
  return project;
}
function isNormalized(project) { return nodes.get(project)?.normalized === true; }
function markNormalized(project) {
  if (!nodes.has(project)) nodes.set(project, { fields: new Map() });
  nodes.get(project).normalized = true;
}
// Compare immutable on-disk subtrees without expanding their historical contents.
function sameStored(a, b) {
  const left = nodes.get(a), right = nodes.get(b);
  return !!(left && right && left.directory === right.directory && left.encoded?.$part && left.encoded.$part === right.encoded?.$part);
}
function fieldStamp(project, key) {
  const field = nodes.get(project)?.fields.get(key);
  return field ? JSON.stringify(field.raw) : null;
}
function fieldUntouched(project, key) { return nodes.get(project)?.fields.get(key)?.loaded === false; }
function writeProject(file, project, { normalized = false } = {}) {
  const directory = path.join(path.dirname(file), "parts");
  // A one-time original-file copy makes the legacy format conversion recoverable.
  if (fs.existsSync(file) && JSON.parse(fs.readFileSync(file, "utf8"))._storage !== "parts-v1") {
    const backup = path.join(path.dirname(file), "before-parts", "project.json");
    if (!fs.existsSync(backup)) {
      fs.mkdirSync(path.dirname(backup), { recursive: true });
      fs.copyFileSync(file, backup, fs.constants.COPYFILE_EXCL);
    }
  }
  const pack = (value, root = false) => {
    if (value === undefined) return value;
    const node = nodes.get(value);
    const field = key => {
      const known = node?.directory === directory && node.fields.get(key);
      if (known && Object.getOwnPropertyDescriptor(value, key)?.get === known.get) {
        if (!known.loaded || (known.read && typeof known.value !== "object" && known.original === known.value)) return known.raw;
      }
      return pack(value[key]);
    };
    let packed = value && typeof value === "object" ? Array.isArray(value) ? Array.from({ length: value.length }, (_, i) => field(String(i)))
      : Object.fromEntries(Object.keys(value).map(k => [k, field(k)]).filter(([, v]) => v !== undefined)) : value;
    if (packed && typeof packed === "object" && !Array.isArray(packed) && Object.keys(packed).length === 1 && (Object.hasOwn(packed, "$part") || Object.hasOwn(packed, "$literal"))) packed = { $literal: packed };
    const text = JSON.stringify(packed);
    if (root || text.length < 2048) return packed;
    const hash = digest(text), part = path.join(directory, hash + ".json");
    // Publish immutable parts before replacing the single atomic project pointer.
    if (!fs.existsSync(part)) atomic(part, text);
    remember(part, text, packed);
    return { $part: hash };
  };
  atomic(file, JSON.stringify({ ...pack(project, true), _storage: "parts-v1", ...(normalized ? { _storeVersion: 2 } : {}) }) + "\n");
  scheduleCollection(file);
}
const collectedAt = new Map();
const stamp = file => { const s = fs.statSync(file, { bigint: true }); return [s.dev, s.ino, s.size, s.mtimeNs, s.ctimeNs].join(":"); };
async function collectProjectParts(file, minimumAge = 86400000) {
  const originalStamp = stamp(file), root = JSON.parse(fs.readFileSync(file, "utf8"));
  if (root._storage !== "parts-v1") return;
  const directory = path.join(path.dirname(file), "parts"), reachable = new Set();
  const visit = value => {
    if (!value || typeof value !== "object") return;
    if (Object.keys(value).length === 1 && value.$literal) { Object.values(value.$literal).forEach(visit); return; }
    if (Object.keys(value).length === 1 && typeof value.$part === "string") {
      if (!/^[a-f0-9]{64}$/.test(value.$part)) throw new Error("项目分块标识无效");
      if (reachable.has(value.$part)) return;
      reachable.add(value.$part);
      const part = path.join(directory, value.$part + ".json");
      visit(cache.get(part)?.value ?? JSON.parse(fs.readFileSync(part, "utf8"))); return;
    }
    Object.values(value).forEach(visit);
  };
  visit(root);
  const entries = await fs.promises.readdir(directory).catch(error => { if (error.code === "ENOENT") return []; throw error; });
  for (const name of entries) {
    if (!/^[a-f0-9]{64}\.json$/.test(name) || reachable.has(name.slice(0, -5))) continue;
    const part = path.join(directory, name), stat = await fs.promises.stat(part);
    if (Date.now() - stat.mtimeMs < minimumAge) continue;
    // A concurrent save may have revived an old part. Recheck before each removal.
    if (stamp(file) !== originalStamp) return;
    fs.unlinkSync(part);
    const cached = cache.get(part); if (cached) { cacheBytes -= cached.size; cache.delete(part); }
  }
}
function scheduleCollection(file) {
  if (Date.now() - (collectedAt.get(file) || 0) < 3600000) return;
  collectedAt.set(file, Date.now());
  if (collectedAt.size > 256) collectedAt.delete(collectedAt.keys().next().value);
  const timer = setTimeout(() => collectProjectParts(file).catch(() => {}), 5000);
  timer.unref();
}
module.exports = { readProject, writeProject, collectProjectParts, isNormalized, markNormalized, sameStored, fieldStamp, fieldUntouched };
