﻿[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$RuntimeRoot,
  [Parameter(Mandatory = $true)][string]$DataRoot,
  [Parameter(Mandatory = $true)][string]$HtmlPath,
  [int]$Port = 17887
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object Text.UTF8Encoding $false
$RuntimeRoot = [IO.Path]::GetFullPath($RuntimeRoot)
$DataRoot = [IO.Path]::GetFullPath($DataRoot)
$nodePath = Join-Path $RuntimeRoot 'node\node.exe'
$serverPath = Join-Path $RuntimeRoot 'drama-workbench\server.cjs'
if (!(Test-Path -LiteralPath $nodePath) -or !(Test-Path -LiteralPath $serverPath)) { throw '短剧工作台安装不完整，请重新更新。' }
$base = "http://127.0.0.1:$Port"
function Get-DramaStatus {
  try { return Invoke-RestMethod -Uri "$base/launcher/status" -TimeoutSec 3 } catch { return $null }
}
$pointer = Join-Path $env:LOCALAPPDATA 'Auralis\.launcher\drama-data.json'
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $pointer) | Out-Null
$status = Get-DramaStatus
if ($status -and $status.app -eq 'auralis-drama') {
  # Keep the established data root across updates, including an existing development installation.
  if ($status.dataRoot) {
    $DataRoot = [IO.Path]::GetFullPath([string]$status.dataRoot)
    [IO.File]::WriteAllText($pointer, (@{ root = $DataRoot } | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
  }
  if ($status.runtimeRoot -eq $RuntimeRoot -or $status.active) { Write-Output '短剧工作台已在运行'; exit 0 }
  $bootstrap = Invoke-RestMethod -Uri "$base/api/bootstrap" -TimeoutSec 3
  Invoke-RestMethod -Method Post -Uri "$base/api/shutdown" -Headers @{ Authorization = "Bearer $($bootstrap.token)" } -ContentType 'application/json' -Body '{}' -TimeoutSec 30 | Out-Null
  $deadline = [DateTime]::UtcNow.AddSeconds(30)
  while ((Get-DramaStatus) -and [DateTime]::UtcNow -lt $deadline) { Start-Sleep -Milliseconds 200 }
  if (Get-DramaStatus) { throw '旧工作台尚未关闭，请稍后重试。' }
} else {
  try { $legacy = Invoke-RestMethod -Uri "$base/api/bootstrap" -TimeoutSec 2 } catch { $legacy = $null }
  if ($legacy) { Write-Output '现有短剧工作台仍在运行，保留当前服务'; exit 0 }
}
New-Item -ItemType Directory -Force -Path $DataRoot | Out-Null
if (Test-Path -LiteralPath $pointer) {
  $saved = Get-Content -LiteralPath $pointer -Raw -Encoding UTF8 | ConvertFrom-Json
  if ($saved.root -and (Test-Path -LiteralPath $saved.root -PathType Container)) { $DataRoot = [IO.Path]::GetFullPath([string]$saved.root) }
}
[IO.File]::WriteAllText($pointer, (@{ root = $DataRoot } | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
$env:AURALIS_DRAMA_PORT = [string]$Port
$env:AURALIS_DRAMA_DATA_DIR = $DataRoot
$env:AURALIS_DRAMA_HTML = [IO.Path]::GetFullPath($HtmlPath)
# Preserve the user's selected execution permission; start.cmd's default is not silently reapplied.
try {
  $mediaRoot = if ($env:AURALIS_MEDIA_BRIDGE_URL) { $env:AURALIS_MEDIA_BRIDGE_URL.TrimEnd('/') } else { 'http://127.0.0.1:17877' }
  $mediaStatus = Invoke-RestMethod -Uri ($mediaRoot + '/status') -Headers @{ Authorization = "Bearer $env:AURALIS_MEDIA_BRIDGE_TOKEN" } -TimeoutSec 2
  if ($mediaStatus.ffmpegPath) {
    $mediaTools = Split-Path -Parent $mediaStatus.ffmpegPath
    $env:PATH = "$mediaTools;$env:PATH"
  }
} catch {}
$env:PATH = "$(Join-Path $RuntimeRoot 'tools');$(Join-Path $RuntimeRoot 'node');$env:PATH"
$launch = & $nodePath (Join-Path $RuntimeRoot 'drama-workbench\start-service.cjs')
if ($LASTEXITCODE -ne 0) { throw '短剧工作台后台启动失败。' }
$serviceInfo = $launch | ConvertFrom-Json
$process = Get-Process -Id $serviceInfo.pid -ErrorAction Stop
$deadline = [DateTime]::UtcNow.AddSeconds(30)
while ([DateTime]::UtcNow -lt $deadline) {
  $process.Refresh()
  if ($process.HasExited) { throw '短剧工作台启动失败，请查看数据文件夹中的 server-error.log。' }
  $ready = Get-DramaStatus
  if ($ready -and $ready.runtimeRoot -eq $RuntimeRoot) { Write-Output '短剧工作台已启动'; exit 0 }
  Start-Sleep -Milliseconds 250
}
throw '短剧工作台启动超时，请稍后重试。'
