const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawnSync } = require('node:child_process');

const fields = ['baseUrl', 'apiKey', 'wavespeedApiKey', 'elevenLabsApiKey'];
const defaultFile = () => process.env.AURALIS_SHARED_API_FILE || path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), '.config'), 'Auralis', 'credentials', 'shared-api.json');
function protect(value, decrypt = false) {
  const script = 'Add-Type -AssemblyName System.Security; $v=[Console]::In.ReadToEnd(); ' + (decrypt
    ? '$b=[Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($v),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Write([Text.Encoding]::UTF8.GetString($b))'
    : '$b=[Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($v),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Write([Convert]::ToBase64String($b))');
  const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { input: value, encoding: 'utf8', windowsHide: true, timeout: 15000 });
  if (r.error || r.status !== 0 || !r.stdout.trim()) throw new Error('无法读写本机共享 API 配置');
  return r.stdout.trim();
}
class SharedApiSettings {
  constructor(file = defaultFile()) { this.file = file; this.cached = null; this.stamp = ''; }
  read() {
    if (!fs.existsSync(this.file)) return {};
    const stat = fs.statSync(this.file), stamp = stat.mtimeMs + ':' + stat.size;
    if (this.cached && stamp === this.stamp) return { ...this.cached };
    const saved = JSON.parse(fs.readFileSync(this.file, 'utf8'));
    const data = JSON.parse(saved.encoding === 'dpapi' ? protect(saved.value, true) : saved.value);
    this.cached = Object.fromEntries(fields.filter(k => typeof data[k] === 'string').map(k => [k, data[k]]));
    this.stamp = stamp;
    return { ...this.cached };
  }
  save(patch, { missingOnly = false } = {}) {
    fs.mkdirSync(path.dirname(this.file), { recursive: true, mode: 0o700 });
    const lock = this.file + '.lock', deadline = Date.now() + 20000;
    let fd;
    while (fd == null) {
      try { fd = fs.openSync(lock, 'wx'); fs.writeSync(fd, JSON.stringify({ pid: process.pid })); }
      catch (error) {
        if (error.code !== 'EEXIST' || Date.now() > deadline) throw new Error('共享配置正在保存，请稍后重试');
        try {
          const owner = JSON.parse(fs.readFileSync(lock, 'utf8'));
          try { process.kill(owner.pid, 0); } catch (probe) { if (probe.code === 'ESRCH') { fs.unlinkSync(lock); continue; } }
        } catch (_) {
          try { if (Date.now() - fs.statSync(lock).mtimeMs > 60000) { fs.unlinkSync(lock); continue; } } catch (_) {}
        }
        Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 30);
      }
    }
    try {
      const data = this.read(), previous = JSON.stringify(data);
      for (const key of fields) {
        if (!Object.hasOwn(patch, key) || (missingOnly && Object.hasOwn(data, key))) continue;
        if (typeof patch[key] !== 'string' || patch[key].length > 4096) throw new Error('API 配置无效');
        const value = patch[key].trim();
        if (missingOnly && !value) continue;
        if (key === 'baseUrl' && value && !/^https?:\/\//.test(value)) throw new Error('RG 地址须为 HTTP 或 HTTPS URL');
        data[key] = value;
      }
      if (JSON.stringify(data) === previous) return data;
      const encoding = process.platform === 'win32' ? 'dpapi' : 'private-file';
      const serialized = JSON.stringify(data);
      const value = encoding === 'dpapi' ? protect(serialized) : serialized;
      fs.writeFileSync(this.file + '.tmp', JSON.stringify({ encoding, value }), { encoding: 'utf8', mode: 0o600 });
      fs.renameSync(this.file + '.tmp', this.file);
      this.cached = null;
      return data;
    } finally { fs.closeSync(fd); fs.unlinkSync(lock); }
  }
  status() {
    const c = this.read();
    return { baseUrl: c.baseUrl || '', companyReady: !!(c.baseUrl && c.apiKey), wavespeedReady: !!c.wavespeedApiKey, elevenLabsReady: !!c.elevenLabsApiKey };
  }
}
module.exports = { SharedApiSettings, defaultFile, fields };
