const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { readProject } = require('./project-storage.cjs');
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const mediaStamp = stat => [stat.dev, stat.ino, stat.size, stat.mtimeNs, stat.ctimeNs].join(':');
function child(root, name) {
  const result = path.resolve(root, name);
  if (!result.startsWith(path.resolve(root) + path.sep)) throw new Error('备份路径无效');
  return result;
}
function atomic(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file + '.tmp', JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(file + '.tmp', file);
}
class DramaBackup {
  constructor(root, prompts, options = {}) {
    this.root = root; this.prompts = prompts; this.file = path.join(root, 'backup-settings.json');
    this.defaultDirectory = options.directory || path.join(os.homedir(), 'Documents', 'AuralisBackups', 'Drama');
    this.interval = options.interval || 600000; this.busy = false; this.error = '';
    this.mediaDigests = new Map();
  }
  config() { return fs.existsSync(this.file) ? JSON.parse(fs.readFileSync(this.file, 'utf8')) : { enabled: true, directory: this.defaultDirectory }; }
  configure(value) {
    const c = this.config();
    if (typeof value.enabled === 'boolean') c.enabled = value.enabled;
    if (value.directory != null) {
      if (!path.isAbsolute(value.directory)) throw new Error('请选择备份文件夹的完整路径');
      const resolved = path.resolve(value.directory), projects = path.join(this.root, 'projects');
      if (resolved === projects || resolved.startsWith(projects + path.sep)) throw new Error('备份文件夹不能放在项目素材内');
      c.directory = resolved;
    }
    atomic(this.file, c); return this.status();
  }
  status(includeSnapshots = true) {
    const c = this.config();
    let snapshots = [];
    if (includeSnapshots) {
      try { snapshots = this.snapshots(); }
      catch (e) { this.error ||= '无法读取已有备份，请检查备份文件夹。' + e.message; }
    }
    return { ...c, busy: this.busy, error: this.error, ...(includeSnapshots ? { snapshots } : {}) };
  }
  snapshots() {
    const dir = path.join(this.config().directory, 'snapshots');
    if (!fs.existsSync(dir)) return [];
    const indexFile = path.join(dir, 'index.json');
    let previous = {};
    try { previous = JSON.parse(fs.readFileSync(indexFile, 'utf8')); } catch {}
    const index = {}, result = [];
    for (const name of fs.readdirSync(dir).filter(name => /^\d{13}-[a-f0-9]+\.json$/.test(name)).sort().reverse()) {
      const file = path.join(dir, name), stamp = mediaStamp(fs.statSync(file, { bigint: true }));
      let entry = previous[name];
      if (entry?.stamp !== stamp) {
        const snapshot = JSON.parse(fs.readFileSync(file, 'utf8'));
        entry = { stamp, summary: { id: name, createdAt: snapshot.createdAt, projectCount: snapshot.projects.length, files: snapshot.files.length } };
      }
      index[name] = entry; result.push(entry.summary);
    }
    if (JSON.stringify(index) !== JSON.stringify(previous)) atomic(indexFile, index);
    return result;
  }
  start() { this.timer = setInterval(() => this.write(false).catch(() => {}), this.interval); this.timer.unref(); }
  stop() { clearInterval(this.timer); }
  async write(manual = true) {
    if (this.busy) throw new Error('备份正在进行');
    if (!manual && !this.config().enabled) return;
    this.busy = true; this.error = '';
    try {
      const c = this.config(), projectsRoot = path.join(this.root, 'projects');
      const projectFiles = fs.existsSync(projectsRoot) ? fs.readdirSync(projectsRoot).filter(id => /^project-[a-f0-9-]+$/.test(id) && fs.existsSync(path.join(projectsRoot, id, 'project.json'))).sort().map(id => path.join(projectsRoot, id, 'project.json')) : [];
      const prompts = this.prompts.overrides(), official = this.prompts.list().map(p => ({ id: p.id, text: p.official }));
      const sourceStamp = hash(JSON.stringify({ files: projectFiles.map(file => [file, mediaStamp(fs.statSync(file, { bigint: true }))]), prompts, official, directory: c.directory }));
      if (!manual && this.sourceStamp === sourceStamp) return;
      const projects = projectFiles.map(file => readProject(file));
      const fingerprint = hash(JSON.stringify({ projects, prompts, official }));
      if (!manual && c.fingerprint === fingerprint) { this.sourceStamp = sourceStamp; return; }
      const blobRoot = path.join(c.directory, 'assets');
      fs.mkdirSync(blobRoot, { recursive: true });
      const files = [], mediaDigests = new Map();
      for (const project of projects) {
        const mediaRoot = path.join(projectsRoot, project.id, 'media');
        if (!fs.existsSync(mediaRoot)) continue;
        const names = new Set();
        const collect = value => {
          if (!value || typeof value !== 'object') return;
          if (typeof value.path === 'string' && /^media\/[^/\\]+$/.test(value.path)) names.add(value.path.slice(6));
          for (const item of Object.values(value)) if (item && typeof item === 'object') collect(item);
        };
        collect(project);
        for (const name of names) {
          const source = child(mediaRoot, name);
          const stat = await fs.promises.stat(source, { bigint: true }), stamp = mediaStamp(stat);
          const cached = this.mediaDigests.get(source);
          let sha256 = cached?.stamp === stamp ? cached.sha256 : null;
          if (!sha256) {
            const digest = crypto.createHash('sha256');
            for await (const bytes of fs.createReadStream(source)) digest.update(bytes);
            sha256 = digest.digest('hex');
            if (mediaStamp(await fs.promises.stat(source, { bigint: true })) !== stamp) throw new Error('素材正在更新，请稍后重新备份');
          }
          const destination = child(blobRoot, sha256);
          if (!fs.existsSync(destination)) {
            try {
              await fs.promises.copyFile(source, destination + '.tmp');
              if (mediaStamp(await fs.promises.stat(source, { bigint: true })) !== stamp) throw new Error('素材正在更新，请稍后重新备份');
              await fs.promises.rename(destination + '.tmp', destination);
            } catch (error) { await fs.promises.rm(destination + '.tmp', { force: true }); throw error; }
          }
          mediaDigests.set(source, { stamp, sha256 });
          files.push({ projectId: project.id, name, sha256, size: Number(stat.size) });
        }
      }
      const snapshot = { schemaVersion: 1, createdAt: new Date().toISOString(), projects, prompts, official, files };
      const id = Date.now() + '-' + crypto.randomBytes(4).toString('hex') + '.json';
      atomic(path.join(c.directory, 'snapshots', id), snapshot);
      atomic(this.file, { ...c, fingerprint, lastBackupAt: snapshot.createdAt });
      this.mediaDigests = mediaDigests;
      this.sourceStamp = sourceStamp;
      return { id, ...this.status() };
    } catch (e) {
      const help = {
        EACCES: '备份无法访问文件或文件夹，请检查该位置的权限。' + (e.path ? '位置：' + e.path : ''),
        EPERM: '备份无法访问文件或文件夹，请检查权限或安全软件拦截。' + (e.path ? '位置：' + e.path : ''),
        ENOSPC: '备份时磁盘空间不足，请清理磁盘或换一个有足够空间的备份文件夹。',
        ENOTDIR: '备份位置不是可用文件夹，请在自动备份设置中换一个文件夹。',
        EEXIST: '备份位置被同名文件占用，请在自动备份设置中换一个文件夹。',
      };
      this.error = help[e.code] || e.message;
      e.message = this.error;
      throw e;
    }
    finally { this.busy = false; }
  }
  async restore(id) {
    if (!this.snapshots().some(s => s.id === id)) throw new Error('备份不存在');
    if (this.busy) throw new Error('备份正在进行');
    const c = this.config();
    const snapshot = JSON.parse(fs.readFileSync(child(path.join(c.directory, 'snapshots'), id), 'utf8'));
    if (snapshot.schemaVersion !== 1 || !Array.isArray(snapshot.projects) || !Array.isArray(snapshot.files)) throw new Error('备份格式无效');
    this.restoring = true;
    try { await this.write(true); } catch (e) { this.restoring = false; throw e; } // Preserve current content first.
    this.busy = true;
    const stage = path.join(this.root, 'restore-' + crypto.randomBytes(8).toString('hex'));
    try {
      fs.mkdirSync(stage, { recursive: true });
      const ids = new Set();
      for (const project of snapshot.projects) {
        if (!/^project-[a-f0-9-]+$/.test(project.id) || ids.has(project.id)) throw new Error('备份项目标识无效');
        ids.add(project.id);
        // Restoring must not silently submit a previously queued paid job.
        for (const job of project.jobs || []) if (['queued', 'preparing', 'submitting', 'polling', 'downloading'].includes(job.status)) {
          job.status = job.remoteId ? 'failed' : job.submittedAt ? 'submission_unknown' : 'cancelled';
          job.error = '已从备份恢复；需要时手动恢复任务';
        }
        project.agentRuns = {};
        for (const asset of project.assets || []) if (['queued', 'searching', 'running'].includes(asset.voiceSearch?.status)) asset.voiceSearch.status = 'cancelled';
        atomic(path.join(stage, project.id, 'project.json'), project);
      }
      for (const file of snapshot.files) {
        if (!ids.has(file.projectId) || !/^[a-f0-9]{64}$/.test(file.sha256) || path.basename(file.name) !== file.name) throw new Error('备份素材记录无效');
        const source = child(path.join(c.directory, 'assets'), file.sha256), destination = child(path.join(stage, file.projectId, 'media'), file.name);
        const digest = crypto.createHash('sha256');
        for await (const bytes of fs.createReadStream(source)) digest.update(bytes);
        if (digest.digest('hex') !== file.sha256 || fs.statSync(source).size !== file.size) throw new Error('备份素材校验失败');
        fs.mkdirSync(path.dirname(destination), { recursive: true });
        await fs.promises.copyFile(source, destination);
      }
      const current = path.join(this.root, 'projects'), previous = path.join(this.root, 'before-restore-' + Date.now() + '-' + crypto.randomBytes(4).toString('hex'));
      const promptStage = stage + '.prompts.json', promptPrevious = previous + '.prompts.json';
      atomic(promptStage, snapshot.prompts || {});
      let movedProjects = false, installedProjects = false, movedPrompts = false;
      try {
        if (fs.existsSync(current)) { fs.renameSync(current, previous); movedProjects = true; }
        if (fs.existsSync(this.prompts.file)) { fs.renameSync(this.prompts.file, promptPrevious); movedPrompts = true; }
        fs.renameSync(stage, current); installedProjects = true;
        fs.renameSync(promptStage, this.prompts.file);
      } catch (error) {
        if (installedProjects) fs.renameSync(current, stage);
        if (movedProjects) fs.renameSync(previous, current);
        if (movedPrompts) fs.renameSync(promptPrevious, this.prompts.file);
        throw error;
      }
      return this.status();
    } finally { this.busy = false; this.restoring = false; }
  }
}
module.exports = { DramaBackup };
