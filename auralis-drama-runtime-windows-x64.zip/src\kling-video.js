(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.KlingVideo = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  // WaveSpeed Kling 4.0 contract, verified 2026-10-22:
  // https://wavespeed.ai/models/kwaivgi/kling-v4.0/reference-to-video
  function request(config, input) {
    const { prompt, resolution, duration, aspectRatio, first, last, source,
      images = [], videos = [], audios = [] } = input;
    const check = (ok, message) => { if (!ok) throw new Error('Kling 4.0：' + message); };
    const mode = input.mode === 'video_edit' ? 'edit' : input.mode === 'video_extend' ? 'extend'
      : first ? 'image' : images.length || videos.length || audios.length ? 'reference' : 'text';
    check(config.videoResolutions.includes(resolution), '清晰度请选择 720p 或 1080p');
    check(Number.isInteger(duration) && duration >= config.durationMin && duration <= config.durationMax, '时长须为 3–30 整数秒');
    check(config.videoAspectRatios.includes(aspectRatio), '比例请选择 16:9、9:16、1:1 或 21:9');
    check(images.length <= config.maxReferenceImages, '最多接收 10 张参考图');
    check(videos.length <= config.maxReferenceVideos, '最多接收 5 段参考视频');
    check(audios.length <= config.maxReferenceAudios, '最多接收 3 段参考音频');
    check(images.length + videos.length + audios.length <= config.maxReferenceInputs, '参考素材合计不能超过 15 个');
    for (const audio of audios) {
      if (audio.duration > 0) check(audio.duration >= 5 && audio.duration <= 30, '每段参考音频须为 5–30 秒');
    }
    check(videos.reduce((sum, video) => sum + (video.duration || 0), 0) <= 30, '参考视频总时长不能超过 30 秒');
    if (/^image_to_video/.test(input.mode || '')) check(first, '图生视频需要首帧');
    check(!last || first || mode === 'extend', '尾帧需要首帧或视频延长源视频');
    check(!source || mode === 'edit' || mode === 'extend', '源视频必须用于编辑或延长');
    const body = { prompt, resolution, duration };
    let endpoint;
    if (mode === 'edit' || mode === 'extend') {
      check(source?.url, '请连接要' + (mode === 'edit' ? '编辑' : '延长') + '的源视频');
      check(!first && !videos.length && !audios.length, '视频编辑/延长不能混用首帧、参考视频或参考音频');
      body.video = source.url;
      if (mode === 'edit') {
        check(!last, '视频编辑不接收尾帧');
        if (source.duration > 0) check(source.duration >= 3 && source.duration <= 30, '编辑源视频须为 3–30 秒');
        body.aspect_ratio = aspectRatio;
        body.keep_original_sound = true;
        if (images.length) body.images = images;
        endpoint = config.editEndpointModel;
      } else {
        check(!images.length, '视频延长只接收源视频和可选尾帧');
        if (last) body.last_image = last;
        endpoint = config.extendEndpointModel;
      }
    } else {
      body.aspect_ratio = aspectRatio;
      if (mode === 'image') {
        check(!images.length && !videos.length && !audios.length, '首尾帧与参考素材不能混用，请选择一种生成模式');
        body.image = first;
        if (last) body.last_image = last;
        endpoint = config.imageEndpointModel;
      } else if (mode === 'reference') {
        if (images.length) body.images = images;
        if (videos.length) body.videos = videos.map(item => item.url);
        if (audios.length) body.audios = audios.map(item => item.url);
        body.keep_original_sound = false;
        endpoint = config.referenceEndpointModel;
      } else endpoint = config.textEndpointModel;
    }
    // Accept the canvas's canonical aliases and reference-map labels.
    const token = (kind, number) => '@' + ({ image: 'Image', video: 'Video', audio: 'Audio', music: 'Audio' })[kind.toLowerCase()] + number;
    body.prompt = String(prompt || '')
      .replace(/@(Image|Video|Audio|Music)[_\s]*(\d+)\b/gi, (_, kind, number) => token(kind, number))
      .replace(/\[(Image|Video|Audio) (\d+)\]/g, (_, kind, number) => token(kind, number));
    return { endpoint, body };
  }
  return { request };
});
