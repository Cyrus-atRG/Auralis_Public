// The native editor owns editing; the workbench owns credentials, files and jobs.
S.canvasDrafts = new Map();
function canvasMediaPatch(
  asset,
  version,
  pid,
  nodeId = version.canvasNodeId || version.id,
) {
  const ref = {
    assetId: asset.id,
    versionId: version.id,
    role: version.media.mime.split("/")[0],
  };
  const url = "/media/" + pid + "/" + version.media.path.split("/").at(-1);
  return {
    id: nodeId,
    type: "image",
    family: "Sol",
    role: "genImage",
    title: asset.name,
    assetUrl: url,
    displayUrl: url,
    mime: version.media.mime,
    status: "completed",
    error: "",
    progressText: "",
    assetState:
      mediaApprovedId("asset", asset) === version.id ? "official" : "candidate",
    meta: { dramaVersionId: version.id, dramaRef: ref },
  };
}
async function canvasApply(scope, operations) {
  const result = await api("projects/" + scope.pid + "/apply", {
    requestId: crypto.randomUUID(),
    expectedRevision: scope.revision,
    operations,
  });
  updateCanvasProject(scope, await api("projects/" + scope.pid));
  return result;
}
function updateCanvasProject(scope, project) {
  if (project.revision < scope.revision) return;
  scope.project = project;
  scope.revision = project.revision;
  if (S.modal?.clipCanvasScope === scope) S.modal.revision = project.revision;
  if (acceptProjectSnapshot(project)) refreshProductionUI();
}
function canvasSnapshot(scope) {
  return { ...structuredClone(scope.api.snapshot()), referenceRevision: scope.referenceRevision || 0 };
}
function syncCanvasReferences(scope, target) {
  const refs = target.plan?.refs || target.refs || [], keys = new Set(refs.map(DramaReferences.nodeId));
  const added = refs.filter(ref => !scope.referenceKeys?.has(DramaReferences.nodeId(ref)));
  if (scope.referenceRevision !== (target.referenceRevision || 0) && added.length) {
    const graph = scope.api.snapshot(), prompt = graph.nodes.find(n => n.id === 'prompt');
    if (prompt) {
      const nodes = [], links = [];
      for (const [i, ref] of added.entries()) {
        const source = DramaReferences.resolve(scope.project, ref), id = DramaReferences.nodeId(ref), type = ref.role;
        if (!graph.nodes.some(n => n.id === id)) nodes.push({ id, type: type === 'audio' ? 'spokenAudio' : type,
          family: type === 'image' ? 'Sol' : type === 'video' ? 'Luna' : 'Meteor', role: type === 'image' ? 'refImage' : type === 'video' ? 'refVideo' : 'spokenAudio',
          title: source.name, mime: source.media.mime, assetUrl: mediaUrl(source.media), displayUrl: mediaUrl(source.media), status: 'completed',
          x: prompt.x - 400, y: prompt.y + i * 200, meta: { dramaRef: ref, dramaCanvasMedia: source.media } });
        links.push({ id: 'reference-' + id, fromNodeId: id, toNodeId: 'prompt', relation: 'input',
          inputRole: type === 'video' ? 'reference_video' : type === 'audio' ? 'reference_audio' : 'ref' });
      }
      scope.api.updateCanvasNodes(nodes, [], links);
      if (scope.clipId) scope.planRevision = target.planRevision;
    }
  }
  scope.referenceKeys = keys;
  scope.referenceRevision = target.referenceRevision || 0;
}
function savedCanvas(target) {
  const draft = S.canvasDrafts.get(target.id);
  return draft && (draft.referenceRevision || 0) >= (target.referenceRevision || 0) ? draft : target.canvasGraph;
}
function saveCanvasDraft(scope) {
  if (scope.clipId) return saveClipCanvasDraft(scope);
  clearTimeout(scope.timer);
  const graph = canvasSnapshot(scope);
  S.canvasDrafts.set(scope.assetId, graph);
  // Serialize saves so a slow upload cannot overwrite a later edit.
  const task = async () => {
    const patches = [];
    for (const node of graph.nodes) {
      if (!node.mime?.startsWith("image/")) continue;
      let ref = node.meta?.dramaRef || scope.imports.get(node.id);
      const url = node.displayUrl || node.assetUrl || node.meta?.remoteAssetUrl;
      if (!ref && url && node.status !== "running") {
        if (!/^(blob:|data:image\/|\/media\/)/.test(url))
          throw new Error("请先把参考图保存到画布，再生成");
        const response = await fetch(url);
        if (!response.ok) throw new Error("无法读取画布参考图");
        const blob = await response.blob();
        const media = await api(
          "projects/" + scope.pid + "/upload",
          blob,
          true,
        );
        const result = await canvasApply(scope, [
          {
            type: "importAsset",
            assetId: scope.assetId,
            episodeId: scope.eid,
            canvasNodeId: node.id,
            media,
          },
        ]);
        ref = {
          assetId: scope.assetId,
          versionId: result.results[0].id,
          role: "image",
        };
        scope.imports.set(node.id, ref);
      }
      if (!ref) continue;
      const resolved = DramaReferences.resolve(scope.project, ref);
      const asset = resolved.target;
      const version = { ...resolved.version, media: resolved.media };
      if (!version) continue;
      const patch = canvasMediaPatch(asset, version, scope.pid, node.id);
      patch.meta.dramaRef = ref;
      // Keep native node role/title/layout; use durable local media URLs.
      node.assetUrl = patch.assetUrl;
      node.displayUrl = patch.displayUrl;
      const previousMeta = JSON.stringify(node.meta);
      node.meta = { ...node.meta, ...patch.meta };
      delete node.meta.localAssetId;
      if (JSON.stringify(node.meta) !== previousMeta)
        patches.push({ id: node.id, meta: node.meta });
    }
    if (patches.length) scope.api.updateCanvasNodes(patches);
    const content = { nodes: graph.nodes, links: graph.links, referenceRevision: graph.referenceRevision };
    const signature = JSON.stringify(content);
    if (signature !== scope.saved) {
      await canvasApply(scope, [
        { type: "saveAssetCanvas", assetId: scope.assetId, graph: content },
      ]);
      scope.saved = signature;
    }
  };
  const pending = (scope.saving || Promise.resolve()).then(task);
  scope.saving = pending.catch((error) => toast(error.message, true));
  return pending;
}
function stashCanvasDraft() {
  const scope = S.modal?.canvasScope;
  if (scope) saveCanvasDraft(scope).catch(() => {});
}
async function generateCanvasImage(scope, request) {
  await saveCanvasDraft(scope);
  const graph = scope.api.snapshot();
  const refs = request.execution.inputNodeIds.map((id) => {
    const node = graph.nodes.find((n) => n.id === id);
    const ref = node?.meta?.dramaRef || scope.imports.get(id);
    if (!ref) throw new Error("参考图片还未保存，请稍后重试");
    return ref;
  });
  const settings = request.execution.mediaSettings;
  const result = await canvasApply(scope, [
    {
      type: "generateAssetVariation",
      assetId: scope.assetId,
      episodeId: scope.eid,
      canvasNodeId: request.nodeId,
      prompt: request.prompt,
      refs,
      generation: {
        model: request.model,
        resolution: settings.imageResolution,
        aspectRatio: settings.imageAspectRatio,
      },
    },
  ]);
  const jid = result.results[0].id;
  // This request survives closing the editor; the server keeps producing its candidate.
  for (;;) {
    const job = scope.project.jobs.find((j) => j.id === jid);
    if (job?.resultVersionId) {
      const asset = scope.project.assets.find((a) => a.id === scope.assetId);
      const version = asset.versions.find((v) => v.id === job.resultVersionId);
      const patch = canvasMediaPatch(asset, version, scope.pid, request.nodeId);
      scope.imports.set(request.nodeId, patch.meta.dramaRef);
      return {
        url: patch.assetUrl,
        mime: patch.mime,
        raw: {},
        workbenchMeta: patch.meta,
      };
    }
    if (
      job &&
      ["failed", "cancelled", "superseded", "submission_unknown"].includes(
        job.status,
      )
    )
      throw new Error(job.error || "生成未完成，请在制作任务中重试");
    await new Promise((resolve) => setTimeout(resolve, 1500));
    updateCanvasProject(scope, await api("projects/" + scope.pid));
  }
}
async function generateCanvasVideo(scope, request) {
  const graph = scope.api.snapshot();
  const prompt = graph.nodes.find((n) => n.id === request.execution.promptNodeId);
  // Keep audio links too: the native video execution list only includes visual inputs.
  const inputIds = [...new Set([
    ...request.execution.inputNodeIds,
    ...graph.links.filter((l) => l.toNodeId === prompt?.id).map((l) => l.fromNodeId),
  ])];
  const refs = inputIds.map((id) => {
    const ref = graph.nodes.find((n) => n.id === id)?.meta?.dramaRef;
    if (!ref) throw new Error("参考素材还未保存，请先在工作台资产库导入并固定版本");
    return ref;
  });
  const settings = request.execution.mediaSettings;
  const result = await canvasApply(scope, [{
    type: "generateClipVariation",
    episodeId: scope.eid,
    clipId: scope.clipId,
    expectedPlanRevision: scope.planRevision,
    prompt: prompt?.content || request.prompt,
    speakingAssetIds: prompt?.meta?.dramaSpeakingAssetIds || [],
    refs,
    generation: {
      model: request.model,
      resolution: settings.videoResolution,
      aspectRatio: settings.videoAspectRatio,
      duration: settings.segmentDurationSeconds,
    },
  }]);
  const { id: jid, planRevision } = result.results[0];
  scope.planRevision = planRevision;
  // Closing the canvas leaves the server job and its candidate on the original card.
  for (;;) {
    const job = scope.project.jobs.find((j) => j.id === jid);
    if (job?.resultVersionId) {
      const clip = scope.project.episodes.find((e) => e.id === scope.eid)
        .clips.find((c) => c.id === scope.clipId);
      const version = clip.versions.find((v) => v.id === job.resultVersionId);
      return {
        url: "/media/" + scope.pid + "/" + version.media.path.split("/").at(-1),
        mime: version.media.mime,
        raw: "",
        workbenchMeta: { dramaVersionId: version.id, dramaTargetId: clip.id, dramaKind: "clip" },
      };
    }
    if (job && ["failed", "cancelled", "superseded", "submission_unknown"].includes(job.status))
      throw new Error(job.error || "生成未完成，请在制作任务中重试");
    await new Promise((resolve) => setTimeout(resolve, 1500));
    updateCanvasProject(scope, await api("projects/" + scope.pid));
  }
}
function mountClipCanvas(frame, target, graph) {
  const scope = {
    api: frame.contentWindow.AuralisCanvas,
    pid: S.project.id,
    eid: ep().id,
    clipId: target.id,
    project: S.project,
    revision: S.project.revision,
    planRevision: target.planRevision,
  };
  S.modal.clipCanvasScope = scope;
  scope.api.mount({
    ...graph,
    id: target.id,
    title: target.title,
    allowedModels: Object.keys(S.models),
  }, { generateVideo: (request) => generateCanvasVideo(scope, request) });
}
function mountAssetCanvas(frame, target, initial) {
  const api = frame.contentWindow.AuralisCanvas;
  const scope = {
    api,
    frame,
    pid: S.project.id,
    eid: ep()?.id,
    assetId: target.id,
    project: S.project,
    revision: S.project.revision,
    imports: new Map(),
  };
  S.modal.canvasScope = scope;
  const saved = savedCanvas(target);
  scope.referenceKeys = new Set((target.refs || []).map(DramaReferences.nodeId));
  scope.referenceRevision = target.referenceRevision || 0;
  const graph = saved
    ? {
        nodes: structuredClone(saved.nodes),
        links: structuredClone(saved.links),
      }
    : initial;
  api.mount(
    {
      ...graph,
      id: target.id,
      title: target.name,
      allowedModels: Object.keys(S.models),
      imageGeneration: target.generation || S.project.generation.image,
    },
    {
      generateImage: (request) => generateCanvasImage(scope, request),
      changed: () => {
        clearTimeout(scope.timer);
        scope.timer = setTimeout(
          () => saveCanvasDraft(scope).catch(() => {}),
          600,
        );
      },
    },
  );
  refreshAssetCanvas();
}
function refreshAssetCanvas() {
  const scope = S.modal?.canvasScope;
  if (!scope || scope.pid !== S.project?.id || !$("dialog").open) return;
  scope.project = S.project;
  if (scope.clipId) return refreshClipCanvas(scope);
  const asset = S.project.assets.find((a) => a.id === scope.assetId),
    graph = scope.api.snapshot();
  syncCanvasReferences(scope, asset);
  const patches = [],
    removed = [];
  for (const v of asset.versions) {
    if (!v.media?.mime.startsWith("image/")) continue;
    const existing = graph.nodes.filter(
      (n) =>
        n.meta?.dramaVersionId === v.id ||
        (v.canvasNodeId && n.id === v.canvasNodeId),
    );
    if (v.deletedAt) {
      removed.push(...existing.map((n) => n.id));
      continue;
    }
    if (!existing.length)
      patches.push({
        ...canvasMediaPatch(asset, v, scope.pid),
        x: 940,
        y: 80 + asset.versions.indexOf(v) * 280,
      });
    else
      for (const node of existing) {
        const state =
          mediaApprovedId("asset", asset) === v.id ? "official" : "candidate";
        if (node.status !== "completed" || node.meta?.dramaVersionId !== v.id)
          patches.push({
            ...canvasMediaPatch(asset, v, scope.pid, node.id),
            meta: {
              ...node.meta,
              ...canvasMediaPatch(asset, v, scope.pid, node.id).meta,
            },
          });
        else if (node.assetState !== state)
          patches.push({ id: node.id, assetState: state });
      }
  }
  for (const job of S.project.jobs.filter(
    (j) => j.targetId === asset.id && j.canvasNodeId && !j.resultVersionId,
  )) {
    const node = graph.nodes.find((n) => n.id === job.canvasNodeId);
    if (!node) continue;
    const status = activeMediaStates.has(job.status) ? "running" : "failed";
    const progressText = statusNames[job.status] || job.status;
    if (node.status !== status || node.progressText !== progressText)
      patches.push({
        id: node.id,
        status,
        progressText,
        error: job.error || "",
      });
  }
  if (patches.length || removed.length)
    scope.api.updateCanvasNodes(patches, removed);
}
