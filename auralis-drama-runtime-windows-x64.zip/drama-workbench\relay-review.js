// The review owns one modal and one immutable stage; it never becomes a chat turn.
(() => {
  const running = run => ['summarizing', 'reviewing'].includes(run?.status);
  const route = scope => 'projects/' + scope.pid + '/relay-review';
  const scopeBody = scope => ({ stage: scope.stage, episodeId: scope.episodeId });
  const query = scope => '?stage=' + encodeURIComponent(scope.stage) + '&episodeId=' + encodeURIComponent(scope.episodeId || '');
  const current = scope => S.modal?.relayReview === scope && $('dialog').open;
  const storageKey = scope => 'relay/' + scope.pid + '/' + (scope.episodeId || 'setting') + '/' + scope.stage;
  const pending = scope => scope.run?.changes?.some(c => c.status === 'pending');
  const modelLabel = model => model === 'local-codex' ? '本地 Codex' : model;
  const modelHint = scope => scope.draft.model === 'local-codex'
    ? '使用本机 Codex 的登录、模型和主控推理深度，独立审查本轮内容。'
    : scope.companyReady ? '先整理用户偏好，再审查' + stageNames[scope.stage] + '。' : '请先在设置 → 共享 API 配置公司 API。';
  const sameRef = (a, b) => ['assetId', 'clipId', 'versionId', 'frame', 'role'].every(k => a[k] === b[k]);
  const referenceLabel = (scope, ref) => {
    const item = scope.run.referenceCatalog.find(c => sameRef(c.ref, ref));
    return item ? item.name + ' · 版本 ' + item.version + ' · ' + ({ image: '图片', video: '视频', audio: '音频' }[ref.role] || ref.role)
      : '原参考 · ' + (ref.assetId || ref.clipId) + ' · ' + ref.versionId;
  };
  function persist(scope) { writeLocalDraft(storageKey(scope), scope.draft); }
  function draftValue(scope, item) {
    return scope.draft.runId === scope.run.id && Object.hasOwn(scope.draft.edits || {}, item.id)
      ? scope.draft.edits[item.id] : item.after;
  }
  function setDraft(scope, item, value) {
    if (scope.draft.runId !== scope.run.id) { scope.draft.runId = scope.run.id; scope.draft.edits = {}; scope.draft.pairedEdits = {}; }
    (scope.draft.edits ||= {})[item.id] = value; persist(scope);
  }
  const pairedValue = (scope, item) => scope.draft.runId === scope.run.id && Object.hasOwn(scope.draft.pairedEdits || {}, item.id)
    ? scope.draft.pairedEdits[item.id] : item.newText;
  function refList(scope, refs) {
    return refs.length ? '<ul class="relay-ref-list">' + refs.map(r => '<li>' + esc(referenceLabel(scope, r)) + '</li>').join('') + '</ul>' : '<p class="muted">无参考</p>';
  }
  function optionsFor(scope, item) {
    const binding = scope.run.targets.find(t => t.targetId === item.targetId).binding;
    return scope.run.referenceCatalog.filter(c => c.ref.clipId !== binding.id && (scope.stage !== 'assets' || c.ref.role === 'image'));
  }
  function referenceEditor(scope, item, refs) {
    const options = optionsFor(scope, item);
    return '<div class="relay-ref-editor">' + refs.map((ref, index) => '<div class="relay-ref-row"><select data-relay-ref="' + index + '" aria-label="修改版参考 ' + (index + 1) + '">' +
      (!options.some(c => sameRef(c.ref, ref)) ? '<option value="-1">' + esc(referenceLabel(scope, ref)) + '</option>' : '') +
      options.map((c, i) => '<option value="' + i + '" ' + (sameRef(c.ref, ref) ? 'selected' : '') + '>' + esc(referenceLabel(scope, c.ref)) + '</option>').join('') +
      '</select><button type="button" class="quiet" data-relay-remove-ref="' + index + '" aria-label="删除参考 ' + (index + 1) + '">删除</button></div>').join('') +
      '<button type="button" class="quiet" data-relay-add-ref ' + (!options.length ? 'disabled' : '') + '>＋ 新增参考</button></div>';
  }
  function dependencyNames(scope, ids) {
    return ids.map(id => scope.run.dependencies.find(c => c.id === id)?.title || id).join('、') || '无前序依赖';
  }
  const diffWords = new Intl.Segmenter('zh-CN', { granularity: 'word' });
  function textDiff(before, after) {
    const words = text => Array.from(diffWords.segment(text), part => part.segment);
    const a = words(before), b = words(after), parts = [];
    const append = (kind, text) => {
      if (!text) return;
      if (parts.at(-1)?.kind === kind) parts.at(-1).text += text;
      else parts.push({ kind, text });
    };
    function compare(left, right) {
      let start = 0, end = 0;
      while (start < Math.min(left.length, right.length) && left[start] === right[start]) start++;
      while (end < Math.min(left.length, right.length) - start && left[left.length - 1 - end] === right[right.length - 1 - end]) end++;
      append('same', left.slice(0, start).join(''));
      const x = left.slice(start, left.length - end), y = right.slice(start, right.length - end);
      if (x.length * y.length > 1000000) {
        // Bound work for unusually large rewrites; use shared paragraphs as anchors first.
        const linesX = x.join('').split(/(?<=\n)/), linesY = y.join('').split(/(?<=\n)/);
        if (linesX.length * linesY.length <= 1000000 && (linesX.length < x.length || linesY.length < y.length)) compare(linesX, linesY);
        else { append('delete', x.join('')); append('insert', y.join('')); }
      } else {
        const width = y.length + 1, lengths = new Uint32Array((x.length + 1) * width);
        for (let i = x.length - 1; i >= 0; i--) for (let j = y.length - 1; j >= 0; j--) {
          lengths[i * width + j] = x[i] === y[j] ? 1 + lengths[(i + 1) * width + j + 1]
            : Math.max(lengths[(i + 1) * width + j], lengths[i * width + j + 1]);
        }
        let i = 0, j = 0;
        while (i < x.length || j < y.length) {
          if (i < x.length && j < y.length && x[i] === y[j]) { append('same', x[i++]); j++; }
          else if (i < x.length && (j === y.length || lengths[(i + 1) * width + j] >= lengths[i * width + j + 1])) append('delete', x[i++]);
          else append('insert', y[j++]);
        }
      }
      if (end) append('same', left.slice(-end).join(''));
    }
    compare(a, b);
    const html = side => parts.filter(part => part.kind !== (side === 'before' ? 'insert' : 'delete')).map(part => {
      const text = esc(part.text);
      return part.kind === 'same' ? text : '<' + (part.kind === 'insert' ? 'ins' : 'del') + '>' + text + '</' + (part.kind === 'insert' ? 'ins' : 'del') + '>';
    }).join('');
    return { before: html('before'), after: html('after') };
  }
  function textComparison(before, after, attribute, label, done) {
    const diff = textDiff(before, after);
    return {
      before: '<pre class="relay-diff-before" data-relay-before><span></span>' + diff.before + '</pre>',
      after: '<div class="relay-diff-editor"><pre class="relay-diff-highlight" aria-hidden="true"><span></span>' + diff.after + '\n</pre>' +
        '<textarea ' + attribute + ' aria-label="' + esc(label) + '" spellcheck="false" ' + (done ? 'readonly' : '') + '>\n' + esc(after) + '</textarea></div>'
    };
  }
  function syncHighlight(input) {
    const highlight = input.previousElementSibling;
    highlight.scrollTop = input.scrollTop; highlight.scrollLeft = input.scrollLeft;
  }
  function updateDiff(article, item, input) {
    const diff = textDiff(item.kind === 'text' ? item.before : item.oldText, input.value);
    article.querySelector('[data-relay-before]').innerHTML = diff.before;
    input.previousElementSibling.innerHTML = diff.after + '\n';
    syncHighlight(input);
  }
  function card(scope, item) {
    const done = item.status !== 'pending', value = done ? item.after : draftValue(scope, item);
    let before, after;
    if (item.kind === 'text') {
      ({ before, after } = textComparison(item.before, value, 'data-relay-text', '修改版 ' + item.id, done));
    } else if (item.kind === 'refs') {
      before = refList(scope, item.before); after = done ? refList(scope, value) : referenceEditor(scope, item, value);
      if (item.textTargetId) {
        const paired = textComparison(item.oldText, done ? item.newText : pairedValue(scope, item), 'data-relay-paired-text', '关联提示词修改版 ' + item.id, done);
        before += '<h4 class="relay-paired-label">关联提示词</h4>' + paired.before;
        after += '<h4 class="relay-paired-label">关联提示词 · 一起采纳</h4>' + paired.after;
      }
    } else {
      before = '<p>' + esc(dependencyNames(scope, item.before)) + '</p>';
      const binding = scope.run.targets.find(t => t.targetId === item.targetId).binding;
      after = done ? '<p>' + esc(dependencyNames(scope, value)) + '</p>' : '<div class="relay-dependencies">' + scope.run.dependencies.filter(c => c.id !== binding.id).map(c =>
        '<label><input type="checkbox" data-relay-dependency="' + esc(c.id) + '" ' + (value.includes(c.id) ? 'checked' : '') + '> ' + esc(c.title) + '</label>').join('') + '</div>';
    }
    return '<article class="relay-change" data-relay-item="' + item.id + '" data-status="' + item.status + '">' +
      '<header><span class="relay-number">' + item.id.padStart(2, '0') + '</span><h3>' + esc(item.title) + '</h3>' +
      (done ? '<span class="relay-decision">' + (item.status === 'accepted' ? '已采纳' : '已忽略') + '</span>' : '') + '</header>' +
      '<p class="relay-reason">' + esc(item.reason) + '</p><div class="relay-compare"><section><h4>原文' + (item.kind === 'text' ? '' : ' · 当前绑定') + '</h4>' + before +
      '</section><section><h4>修改版' + (!done ? '<span>可编辑</span>' : '') + '</h4>' + after + '</section></div>' +
      (!done ? '<footer><span class="relay-item-error" role="alert">' + esc(scope.errors[item.id] || '') + '</span><button type="button" class="quiet" data-relay-decide="ignore">忽略</button><button type="button" class="primary" data-relay-decide="accept">采纳修改</button></footer>' : '') + '</article>';
  }
  const duration = ms => { const seconds = Math.max(0, Math.floor(ms / 1000)); return Math.floor(seconds / 60) + '分' + String(seconds % 60).padStart(2, '0') + '秒'; };
  const stableRun = run => { if (!run) return run; const { stream, ...rest } = run; return rest; };
  function updateLive(scope) {
    const run = scope.run, stream = run?.stream || {}, live = $('relayLive');
    if (!live) return;
    const elapsed = duration((run.finishedAt ? Date.parse(run.finishedAt) : Date.now()) - Date.parse(run.phaseStartedAt || run.createdAt));
    const age = stream.lastActivityAt ? Math.max(0, Math.floor((Date.now() - Date.parse(stream.lastActivityAt)) / 1000)) : null;
    const phase = scope.error ? '工作台连接中断，正在重连' : !running(run) ? '本步用时 ' + elapsed :
      ({ thinking: '正在推理', writing: '正在生成内容' }[stream.phase] || (stream.connectedAt ? '已连接，等待模型内容' : '等待接口响应')) + ' · 本步 ' + elapsed;
    $('relayLiveState').textContent = phase;
    $('relayLiveCount').textContent = (stream.receivedCharacters ? '已收到 ' + stream.receivedCharacters.toLocaleString() + ' 字符' : '') +
      (running(run) && age !== null ? (stream.receivedCharacters ? ' · ' : '') + (age < 3 ? '刚收到数据' : age + ' 秒前收到数据') : '');
    const fill = (id, text) => {
      const el = $(id), follow = (el.parentElement.hidden || el.scrollHeight - el.scrollTop - el.clientHeight < 36) && window.getSelection().isCollapsed;
      el.parentElement.hidden = !text;
      if (el.textContent !== text) {
        if (text.startsWith(el.textContent)) el.append(document.createTextNode(text.slice(el.textContent.length)));
        else el.textContent = text;
        if (follow) el.scrollTop = el.scrollHeight;
      }
    };
    fill('relayLiveReasoning', stream.reasoning || '');
    fill('relayLiveOutput', [stream.text, stream.preview].filter(Boolean).join('\n\n'));
    $('relayLiveEmpty').hidden = !!(stream.reasoning || stream.text || stream.preview);
    $('relayLiveEmpty').textContent = stream.connectedAt ? '接口已连接，尚未返回可显示的文本。' : '收到模型内容后会在这里实时显示。';
    $('relayError').textContent = scope.error || run?.error || '';
  }
  function render(scope) {
    if (!current(scope)) return;
    const scroll = $('dialog').scrollTop, run = scope.run;
    const expanded = ['relay-preferences', 'relay-options'].filter(name => $('dialog').querySelector('details.' + name)?.open);
    const liveOpen = $('relayLive')?.open;
    scope.busy = running(run) || !!scope.starting || !!scope.saving;
    const local = scope.draft.model === 'local-codex', ready = local || scope.companyReady;
    const config = '<form id="relayReviewForm"><div class="relay-config"><label>审查模型<select name="model" ' + (scope.busy ? 'disabled' : '') + '>' +
      '<option value="local-codex" ' + (local ? 'selected' : '') + '>本地 Codex</option><optgroup label="公司 API">' +
      scope.models.map(model => '<option value="' + esc(model) + '" ' + (model === scope.draft.model ? 'selected' : '') + '>' + esc(model) + '</option>').join('') + '</optgroup>' +
      '</select></label><label>额外要求 <span class="muted">选填</span><textarea name="requirements" rows="3" maxlength="20000" placeholder="例如：从第一次观看的观众角度，检查哪里看不懂。" ' +
      (scope.busy ? 'disabled' : '') + '>' + esc(scope.draft.requirements || '') + '</textarea></label></div>' +
      '<div class="relay-start-row"><span class="muted" id="relayModelHint">' + modelHint(scope) +
      '</span>' + (scope.busy ? '<button type="button" data-relay-stop ' + (scope.starting || scope.saving ? 'disabled' : '') + '>停止审查</button>' :
      '<button class="primary" type="submit" ' + (!ready || pending(scope) ? 'disabled' : '') + '>' + (run ? '重新审查' : '开始审查') + '</button>') + '</div></form>';
    const status = scope.busy ? '<div class="relay-progress" role="status" aria-live="polite"><span class="relay-pulse" aria-hidden="true"></span>' +
      esc(scope.saving ? '正在写回修改…' : run?.progress || '正在准备审查…') + '<small>' + (run ? '覆盖本项目 ' + run.messageCount + ' 条用户消息' : '准备当前正文') + '</small></div>' : '';
    const live = run?.stream ? '<details id="relayLive" class="relay-live" ' + ((liveOpen ?? running(run)) ? 'open' : '') + '><summary>模型实时返回 <span>思考强度 · ' + esc(run.stream.effort || '') + '</span></summary>' +
      '<div class="relay-live-meta"><span id="relayLiveState" role="status"></span><span id="relayLiveCount"></span></div>' +
      '<p id="relayLiveEmpty" class="muted"></p><section hidden><h4>推理 / 思考摘要</h4><pre id="relayLiveReasoning" tabindex="0" aria-label="模型返回的推理或思考摘要"></pre></section>' +
      '<section hidden><h4>正在写出的内容</h4><pre id="relayLiveOutput" tabindex="0" aria-label="模型正在写出的内容"></pre></section></details>' : '';
    const preferences = run?.preferences?.length ? '<details class="relay-preferences"><summary>本轮提取的用户偏好 · ' + run.preferences.length + '</summary><ul>' +
      run.preferences.map(p => '<li><span>' + (p.kind === 'explicit' ? '明确要求' : '推测') + '</span>' + esc(p.text) + '</li>').join('') + '</ul></details>' : '';
    const completed = run?.status === 'completed';
    const configuration = completed ? '<details class="relay-options"><summary>审查模型 · ' + esc(modelLabel(run.model)) + ' <span>查看要求 / 再次审查</span></summary>' + config + '</details>' : config;
    const results = completed ? '<div class="relay-results-heading"><h3>修改建议</h3><span class="muted">' + run.changes.filter(c => c.status !== 'pending').length + ' / ' + run.changes.length + ' 已处理</span></div>' +
      (run.summary ? '<p class="relay-summary">' + esc(run.summary) + '</p>' : '') +
      (run.changes.length ? run.changes.map(item => card(scope, item)).join('') : '<p class="relay-empty">这轮没有需要直接替换的修改。</p>') +
      '<section class="relay-advice"><div class="row spread"><label for="relayAdvice">需要其他 Agent 处理</label><button type="button" class="quiet" data-relay-copy ' + (!run.advice ? 'disabled' : '') + '>复制建议</button></div>' +
      '<textarea id="relayAdvice" rows="5" readonly placeholder="这轮没有额外建议。">' + esc(run.advice) + '</textarea></section>' : '';
    openDialog('接力拷打 · ' + stageNames[scope.stage], '<div class="relay-review">' + configuration + status +
      '<p id="relayError" class="relay-error" role="alert">' + esc(scope.error || run?.error || '') + '</p>' + live + preferences + results + '</div>', true);
    $('dialog').classList.add('relay-dialog');
    for (const name of expanded) $('dialog').querySelector('details.' + name)?.setAttribute('open', '');
    $('dialogBody').querySelector('[data-action="close"]').disabled = scope.busy;
    updateLive(scope);
    $('dialog').scrollTop = scroll;
  }
  async function poll(scope) {
    if (!current(scope) || !running(scope.run)) return;
    const epoch = scope.pollEpoch;
    try {
      const run = await api(route(scope) + query(scope));
      if (!current(scope) || epoch !== scope.pollEpoch) return;
      const changed = JSON.stringify(stableRun(run)) !== JSON.stringify(stableRun(scope.run));
      scope.run = run; scope.error = '';
      if (changed) render(scope); else updateLive(scope);
    } catch (error) { if (epoch !== scope.pollEpoch) return; scope.error = error.message; updateLive(scope); }
    if (current(scope) && running(scope.run)) scope.timer = setTimeout(() => poll(scope), 750);
  }
  async function open() {
    if (!S.project || S.stage === 'library') return;
    const scope = { pid: S.project.id, episodeId: S.episodeId, stage: S.stage, errors: {}, busy: false, models: [], companyReady: false, pollEpoch: 0 };
    const saved = readLocalDraft(storageKey(scope));
    scope.draft = saved && typeof saved === 'object' ? saved : { model: S.controller?.mode === 'local-codex' ? 'local-codex' : S.controller?.companyModel, requirements: '' };
    S.modal = { relayReview: scope };
    openDialog('接力拷打 · ' + stageNames[scope.stage], '<p class="muted" role="status">正在读取审查记录…</p>', true);
    try {
      const [settings, run] = await Promise.all([api('controller-settings'), api(route(scope) + query(scope))]);
      if (!current(scope)) return;
      scope.models = settings.companyModels; scope.companyReady = settings.companyReady; scope.run = run;
      scope.draft.model = settings.companyModelAliases?.[scope.draft.model] || scope.draft.model;
      if (scope.draft.model !== 'local-codex' && !scope.models.includes(scope.draft.model)) scope.draft.model = settings.mode === 'local-codex' ? 'local-codex' : settings.companyModel;
      render(scope); if (running(run)) scope.timer = setTimeout(() => poll(scope), 750);
    } catch (error) { if (current(scope)) { scope.error = error.message; render(scope); } }
  }
  $('agentRelayReview').addEventListener('click', () => open().catch(error => toast(error.message)));
  document.addEventListener('input', event => {
    const scope = S.modal?.relayReview; if (!scope || !current(scope)) return;
    if (event.target.closest('#relayReviewForm')) {
      const form = $('relayReviewForm'); scope.draft.model = form.elements.model.value; scope.draft.requirements = form.elements.requirements.value; persist(scope);
      if (event.target.name === 'model') {
        $('relayModelHint').textContent = modelHint(scope);
        form.querySelector('[type="submit"]').disabled = (scope.draft.model !== 'local-codex' && !scope.companyReady) || pending(scope);
      }
    }
    const article = event.target.closest('[data-relay-item]');
    if (article && event.target.matches('[data-relay-text]')) setDraft(scope, scope.run.changes.find(c => c.id === article.dataset.relayItem), event.target.value);
    if (article && event.target.matches('[data-relay-paired-text]')) {
      const item = scope.run.changes.find(c => c.id === article.dataset.relayItem);
      setDraft(scope, item, draftValue(scope, item)); (scope.draft.pairedEdits ||= {})[item.id] = event.target.value; persist(scope);
    }
    if (article && event.target.matches('[data-relay-text], [data-relay-paired-text]')) {
      updateDiff(article, scope.run.changes.find(c => c.id === article.dataset.relayItem), event.target);
    }
  });
  document.addEventListener('scroll', event => {
    if (event.target.matches?.('.relay-diff-editor textarea')) syncHighlight(event.target);
  }, true);
  document.addEventListener('change', event => {
    const scope = S.modal?.relayReview, article = event.target.closest('[data-relay-item]');
    if (!scope || !article || !current(scope)) return;
    const item = scope.run.changes.find(c => c.id === article.dataset.relayItem);
    if (event.target.matches('[data-relay-ref]')) {
      const refs = structuredClone(draftValue(scope, item)), option = optionsFor(scope, item)[Number(event.target.value)];
      if (option) { refs[Number(event.target.dataset.relayRef)] = structuredClone(option.ref); setDraft(scope, item, refs); }
    }
    if (event.target.matches('[data-relay-dependency]')) setDraft(scope, item,
      [...article.querySelectorAll('[data-relay-dependency]:checked')].map(el => el.dataset.relayDependency));
  });
  document.addEventListener('submit', async event => {
    if (event.target.id !== 'relayReviewForm') return;
    event.preventDefault(); const scope = S.modal?.relayReview;
    if (!scope || scope.busy || pending(scope)) return;
    const form = event.target, draft = captureDocumentDraft();
    scope.draft.model = form.elements.model.value; scope.draft.requirements = form.elements.requirements.value; persist(scope);
    scope.starting = true; scope.error = ''; scope.pollEpoch++; render(scope);
    try {
      await saveDocumentDraft(draft);
      scope.run = await api(route(scope), { ...scopeBody(scope), model: scope.draft.model, requirements: scope.draft.requirements });
      scope.draft.runId = scope.run.id; scope.draft.edits = {}; scope.draft.pairedEdits = {}; persist(scope);
    } catch (error) {
      scope.error = error.message;
      // A disconnected response is not evidence that the accepted review stopped.
      try { scope.run = await api(route(scope) + query(scope)); } catch { /* Keep the original error visible. */ }
    }
    finally { scope.starting = false; render(scope); if (running(scope.run)) scope.timer = setTimeout(() => poll(scope), 750); }
  });
  document.addEventListener('click', async event => {
    const button = event.target.closest('button'), scope = S.modal?.relayReview;
    if (!button || !scope || !current(scope)) return;
    const article = button.closest('[data-relay-item]'), item = article && scope.run.changes.find(c => c.id === article.dataset.relayItem);
    try {
      if (button.hasAttribute('data-relay-stop')) {
        button.disabled = true; clearTimeout(scope.timer); scope.pollEpoch++;
        scope.run = await api(route(scope) + '/stop', scopeBody(scope)); render(scope); return;
      }
      if (button.hasAttribute('data-relay-copy')) {
        try { await navigator.clipboard.writeText(scope.run.advice); toast('建议已复制'); }
        catch { $('relayAdvice').focus(); $('relayAdvice').select(); toast('已选中建议，可按 Ctrl+C 复制'); }
        return;
      }
      if (!item || item.status !== 'pending' || scope.busy) return;
      if (button.hasAttribute('data-relay-add-ref')) {
        const refs = structuredClone(draftValue(scope, item)), option = optionsFor(scope, item).find(c => !refs.some(r => sameRef(c.ref, r)));
        if (option) { refs.push(structuredClone(option.ref)); setDraft(scope, item, refs); render(scope); } return;
      }
      if (button.hasAttribute('data-relay-remove-ref')) {
        const refs = structuredClone(draftValue(scope, item)); refs.splice(Number(button.dataset.relayRemoveRef), 1); setDraft(scope, item, refs); render(scope); return;
      }
      if (button.dataset.relayDecide) {
        if (button.dataset.relayDecide === 'accept' && captureDocumentDraft()) throw new Error('正文还有未保存的修改，请先关闭弹窗并保存正文，再核对建议。');
        scope.saving = true; delete scope.errors[item.id]; render(scope);
        try {
          scope.run = await api(route(scope) + '/decision', { ...scopeBody(scope), runId: scope.run.id, itemId: item.id, decision: button.dataset.relayDecide, after: draftValue(scope, item),
            ...(item.textTargetId ? { newText: pairedValue(scope, item) } : {}) });
          if (button.dataset.relayDecide === 'accept' && S.project?.id === scope.pid) await loadProject(scope.pid);
        } catch (error) { scope.errors[item.id] = error.message; }
        finally { scope.saving = false; render(scope); }
      }
    } catch (error) {
      if (item) scope.errors[item.id] = error.message; else scope.error = error.message;
      render(scope);
    }
  });
})();
