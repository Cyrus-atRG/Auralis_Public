// Gateways may put the upstream JSON error inside a JSON string in `message`.
function errorDetails(value, depth = 0) {
  if (depth > 6 || value == null) return {};
  if (typeof value === "string") {
    try { return errorDetails(JSON.parse(value), depth + 1); }
    catch { return { message: value }; }
  }
  if (typeof value !== "object") return {};
  const nested = errorDetails(value.error || value.message || value.detail, depth + 1);
  return { code: nested.code || value.code, message: nested.message || "" };
}
async function responseError(response, provider, secrets = []) {
  let details = {};
  try { details = errorDetails((await response.text()).slice(0, 64000)); } catch {}
  const hint = details.code === "InputImageSensitiveContentDetected.PrivacyInformation"
    ? "参考图被供应商判定可能包含真人。" : "";
  let message = provider + " 返回 HTTP " + response.status;
  if (details.message || details.code) message += "：" + hint + [details.code, details.message].filter(Boolean).join(" · ");
  for (const secret of secrets.filter(Boolean)) message = message.replaceAll(secret, "[Key]");
  message = message.replace(/data:[^\s,]+;base64,[a-zA-Z0-9+/=]+/g, "[素材]").replace(/\s+/g, " ").slice(0, 600);
  return Object.assign(new Error(message), { definite: response.status >= 400 && response.status < 500, httpStatus: response.status });
}
function transportError(error, provider, secrets = []) {
  const code = typeof error.cause?.code === "string" ? error.cause.code : error.code || error.name;
  const hints = {
    UND_ERR_HEADERS_TIMEOUT: "等待供应商响应头超时",
    UND_ERR_BODY_TIMEOUT: "读取供应商响应超时",
    UND_ERR_CONNECT_TIMEOUT: "连接供应商超时",
    UND_ERR_SOCKET: "与供应商的连接中断",
    ECONNRESET: "与供应商的连接被重置",
    ECONNREFUSED: "供应商连接被拒绝",
    ENOTFOUND: "无法解析供应商地址",
    ETIMEDOUT: "网络连接超时",
    AbortError: "请求已中止或超过等待时限",
    TimeoutError: "请求超过等待时限",
    ABORT_ERR: "请求已中止或超过等待时限",
  };
  let message = provider + " 请求失败：" + (hints[code] || error.message);
  if (/^[A-Z][A-Z0-9_]{1,63}$/.test(code || "")) message += "（" + code + "）";
  for (const secret of secrets.filter(Boolean)) message = message.replaceAll(secret, "[Key]");
  return Object.assign(new Error(message.slice(0, 600), { cause: error }), {
    ...(error.code ? { code: error.code } : {}),
    ...(error.definite != null ? { definite: error.definite } : {}),
  });
}
module.exports = { responseError, transportError };
