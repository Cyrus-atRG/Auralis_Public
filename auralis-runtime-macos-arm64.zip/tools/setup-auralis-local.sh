#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MEDIA_STATUS_URL="http://127.0.0.1:17877/v1/status"
CODEX_STATUS_URL="http://127.0.0.1:17876/v1/status"
NO_INSTALL="${NO_INSTALL:-0}"
LOG_DIR="${PROJECT_ROOT}/.auralis-local"

step() {
  printf "\n==> %s\n" "$1"
}

ok() {
  printf "OK: %s\n" "$1"
}

warn() {
  printf "WARN: %s\n" "$1"
}

has_status() {
  curl -fsS --max-time 2 "$1" >/dev/null 2>&1
}

command_path() {
  command -v "$1" 2>/dev/null || true
}

find_ffmpeg() {
  local candidates=()
  [[ -n "${AURALIS_FFMPEG_PATH:-}" ]] && candidates+=("$AURALIS_FFMPEG_PATH")
  [[ -n "${FFMPEG_PATH:-}" ]] && candidates+=("$FFMPEG_PATH")
  local from_path
  from_path="$(command_path ffmpeg)"
  [[ -n "$from_path" ]] && candidates+=("$from_path")
  candidates+=("${PROJECT_ROOT}/tools/bin/ffmpeg")
  candidates+=("/opt/homebrew/bin/ffmpeg")
  candidates+=("/usr/local/bin/ffmpeg")
  candidates+=("/usr/bin/ffmpeg")

  local candidate
  for candidate in "${candidates[@]}"; do
    if [[ -n "$candidate" && -x "$candidate" ]]; then
      printf "%s\n" "$candidate"
      return 0
    fi
  done
  return 1
}

install_homebrew_if_needed() {
  if command -v brew >/dev/null 2>&1; then
    return 0
  fi
  if [[ "$NO_INSTALL" == "1" ]]; then
    return 1
  fi
  warn "Homebrew is required to install ffmpeg on macOS."
  printf "Install Homebrew now? [y/N] "
  read -r answer
  case "$answer" in
    y|Y|yes|YES)
      /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
      ;;
    *)
      return 1
      ;;
  esac
}

install_ffmpeg() {
  if [[ "$NO_INSTALL" == "1" ]]; then
    echo "ffmpeg was not found and NO_INSTALL=1 was set." >&2
    return 1
  fi
  step "Installing ffmpeg"
  install_homebrew_if_needed || {
    echo "Cannot install ffmpeg without Homebrew. Install ffmpeg, then rerun this script." >&2
    return 1
  }
  brew install ffmpeg
}

find_node() {
  command_path node
}

install_node() {
  if [[ "$NO_INSTALL" == "1" ]]; then
    echo "Node.js was not found and NO_INSTALL=1 was set." >&2
    return 1
  fi
  step "Installing Node.js for the local Auralis bridges"
  install_homebrew_if_needed || {
    echo "Node.js is required to start Auralis local bridges. Install Node.js LTS, then rerun this script." >&2
    return 1
  }
  brew install node
}

find_codex_cli() {
  local candidates=()
  [[ -n "${CODEX_CLI_PATH:-}" ]] && candidates+=("$CODEX_CLI_PATH")
  local from_path
  from_path="$(command_path codex)"
  [[ -n "$from_path" ]] && candidates+=("$from_path")
  candidates+=("/Applications/Codex.app/Contents/MacOS/codex")

  local openai_bin="${HOME}/Library/Application Support/OpenAI/Codex/bin"
  if [[ -d "$openai_bin" ]]; then
    while IFS= read -r found; do
      candidates+=("$found")
    done < <(find "$openai_bin" -type f -name codex 2>/dev/null | sort -r)
  fi

  local candidate
  for candidate in "${candidates[@]}"; do
    if [[ -n "$candidate" && -x "$candidate" ]]; then
      printf "%s\n" "$candidate"
      return 0
    fi
  done
  return 1
}

codex_is_running() {
  ps -axo comm=,command= | grep -Eiq '[C]odex|[c]odex' || return 1
}

start_node_bridge() {
  local script_rel="$1"
  local status_url="$2"
  local log_name="$3"

  if has_status "$status_url"; then
    ok "$status_url is already running"
    return 0
  fi

  local node_path
  node_path="$(find_node)"
  if [[ -z "$node_path" ]]; then
    install_node
    node_path="$(find_node)"
  fi
  if [[ -z "$node_path" ]]; then
    echo "Node.js is still not available after install attempt." >&2
    return 1
  fi

  local script_path="${PROJECT_ROOT}/${script_rel}"
  if [[ ! -f "$script_path" ]]; then
    echo "Missing bridge script: $script_path" >&2
    return 1
  fi

  mkdir -p "$LOG_DIR"
  nohup "$node_path" "$script_path" >"${LOG_DIR}/${log_name}.log" 2>&1 &
  local pid="$!"
  sleep 1.2

  if has_status "$status_url"; then
    ok "Started $script_rel on $status_url (pid $pid)"
  else
    echo "Started $script_rel, but $status_url did not respond. Log: ${LOG_DIR}/${log_name}.log" >&2
    return 1
  fi
}

step "Checking ffmpeg"
ffmpeg_path="$(find_ffmpeg || true)"
if [[ -z "$ffmpeg_path" ]]; then
  install_ffmpeg
  ffmpeg_path="$(find_ffmpeg || true)"
fi
if [[ -z "$ffmpeg_path" ]]; then
  echo "ffmpeg is still not available after install attempt." >&2
  exit 1
fi
ok "ffmpeg: $ffmpeg_path"

step "Connecting ffmpeg to Auralis"
export AURALIS_FFMPEG_PATH="$ffmpeg_path"
export AURALIS_MEDIA_BRIDGE_MAX_BODY_BYTES="1073741824"
start_node_bridge "tools/local-media-bridge.js" "$MEDIA_STATUS_URL" "media-bridge"

step "Checking local Codex"
if codex_is_running; then
  codex_cli="$(find_codex_cli || true)"
  if [[ -n "$codex_cli" ]]; then
    ok "Codex appears to be running; CLI: $codex_cli"
    export CODEX_CLI_PATH="$codex_cli"
    start_node_bridge "tools/local-codex-bridge.js" "$CODEX_STATUS_URL" "codex-bridge"
    warn "Auralis LLM mode was not changed. In Auralis settings, manually switch LLM mode to Local Codex when you want to use it."
  else
    warn "Codex appears to be running, but codex CLI was not found. Local Codex bridge was not started."
  fi
else
  warn "No running Codex process found. Local Codex bridge was not started, and Auralis LLM mode was not changed."
fi

step "Done"
printf "Media bridge: %s\n" "$MEDIA_STATUS_URL"
printf "Local Codex bridge: %s\n" "$CODEX_STATUS_URL"
