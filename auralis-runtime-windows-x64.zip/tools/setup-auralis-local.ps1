[CmdletBinding()]
param(
  [string]$ProjectRoot = "",
  [switch]$NoInstall,
  [switch]$RestartCodex
)

$ErrorActionPreference = "Stop"

if (-not $ProjectRoot) {
  $scriptDir = if ($PSScriptRoot) {
    $PSScriptRoot
  } else {
    Split-Path -Parent $MyInvocation.MyCommand.Path
  }
  $ProjectRoot = (Resolve-Path (Join-Path $scriptDir "..")).Path
}

if (-not $env:AURALIS_MEDIA_BRIDGE_URL) {
  $env:AURALIS_MEDIA_BRIDGE_URL = "http://127.0.0.1:17877"
}
$MediaStatusUrl = $env:AURALIS_MEDIA_BRIDGE_URL.TrimEnd("/") + "/v1/status"
$releaseParent = Split-Path -Parent $ProjectRoot
$runtimeRootFromRelease = if ((Split-Path -Leaf $releaseParent) -eq "releases") { Split-Path -Parent $releaseParent } else { "" }
$RuntimeSupportRoot = if ($runtimeRootFromRelease -and (Split-Path -Leaf $runtimeRootFromRelease) -eq "runtime") { Split-Path -Parent $runtimeRootFromRelease } else { "" }
if (-not $env:AURALIS_BRIDGE_URL) {
  $env:AURALIS_BRIDGE_URL = "http://127.0.0.1:17876"
}
if (-not $env:AURALIS_DATA_DIR) {
  $env:AURALIS_DATA_DIR = if ($RuntimeSupportRoot) { Join-Path $RuntimeSupportRoot "data" } else { Join-Path $ProjectRoot ".auralis-local" }
}
if (-not $env:AURALIS_BRIDGE_TOKEN_FILE) {
  $env:AURALIS_BRIDGE_TOKEN_FILE = Join-Path $env:AURALIS_DATA_DIR "bridge-token"
}
if (-not (Test-Path -LiteralPath $env:AURALIS_BRIDGE_TOKEN_FILE)) {
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $env:AURALIS_BRIDGE_TOKEN_FILE) | Out-Null
  $bytes = New-Object byte[] 32
  $random = [System.Security.Cryptography.RandomNumberGenerator]::Create()
  try {
    $random.GetBytes($bytes)
  } finally {
    $random.Dispose()
  }
  $generatedToken = [Convert]::ToBase64String($bytes).TrimEnd("=").Replace("+", "-").Replace("/", "_")
  try {
    $stream = [System.IO.File]::Open($env:AURALIS_BRIDGE_TOKEN_FILE, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
    try {
      $tokenBytes = (New-Object System.Text.UTF8Encoding $false).GetBytes($generatedToken)
      $stream.Write($tokenBytes, 0, $tokenBytes.Length)
    } finally {
      if ($stream) { $stream.Dispose() }
    }
  } catch [System.IO.IOException] {
  }
}
if (-not $env:AURALIS_MEDIA_BRIDGE_TOKEN -and (Test-Path -LiteralPath $env:AURALIS_BRIDGE_TOKEN_FILE)) {
  $env:AURALIS_MEDIA_BRIDGE_TOKEN = (Get-Content -LiteralPath $env:AURALIS_BRIDGE_TOKEN_FILE -Raw -Encoding UTF8).Trim()
}
$CodexStatusUrl = $env:AURALIS_BRIDGE_URL.TrimEnd("/") + "/v1/status"

function Write-Step($Message) {
  Write-Host ""
  Write-Host "==> $Message"
}

function Write-Ok($Message) {
  Write-Host "OK: $Message"
}

function Write-Warn($Message) {
  Write-Host "WARN: $Message"
}

function Get-Status($Url, $TokenFile = "") {
  try {
    $headers = @{}
    if ($TokenFile -and (Test-Path -LiteralPath $TokenFile)) {
      $token = (Get-Content -LiteralPath $TokenFile -Raw -Encoding UTF8).Trim()
      if ($token) {
        $headers.Authorization = "Bearer $token"
      }
    }
    return Invoke-RestMethod -Uri $Url -TimeoutSec 2 -Headers $headers
  } catch {
    return $null
  }
}

function Test-StatusUrl($Url, $TokenFile = "") {
  return [bool](Get-Status $Url $TokenFile)
}

function Stop-OwnedLegacyBridge($StatusUrl, $ScriptRelativePath) {
  if (-not (Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue)) {
    return $false
  }

  $port = ([Uri]$StatusUrl).Port
  $scriptName = Split-Path -Leaf $ScriptRelativePath
  $connections = Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue
  foreach ($connection in $connections) {
    $ownerId = [int]$connection.OwningProcess
    $processInfo = Get-CimInstance Win32_Process -Filter "ProcessId = $ownerId" -ErrorAction SilentlyContinue
    $commandLine = [string]$processInfo.CommandLine
    $hasBridgeScriptArgument = $false
    foreach ($match in [regex]::Matches($commandLine, '"([^"]*)"|(\S+)')) {
      $argument = if ($match.Groups[1].Success) { $match.Groups[1].Value } else { $match.Groups[2].Value }
      try {
        if ([System.IO.Path]::GetFileName($argument) -ieq $scriptName) {
          $hasBridgeScriptArgument = $true
          break
        }
      } catch {}
    }
    if ([string]$processInfo.Name -ieq "node.exe" -and $hasBridgeScriptArgument) {
      Stop-Process -Id $ownerId -Force -ErrorAction Stop
      foreach ($attempt in 1..25) {
        $stillListening = Get-NetTCPConnection -State Listen -LocalPort $port -ErrorAction SilentlyContinue |
          Where-Object { [int]$_.OwningProcess -eq $ownerId }
        if (-not $stillListening) { return $true }
        Start-Sleep -Milliseconds 200
      }
      throw "The older Auralis bridge on $StatusUrl did not stop."
    }
  }
  return $false
}

function Stop-BridgeForRuntimeSwitch($StatusUrl, $TokenFile, $ScriptRelativePath, [switch]$ForceRestart) {
  $status = Get-Status $StatusUrl $TokenFile
  if (-not $status) { return }

  $actualRuntime = [string]$status.runtimeRoot
  if ($actualRuntime -and -not $ForceRestart) {
    try {
      if ([System.IO.Path]::GetFullPath($actualRuntime) -eq [System.IO.Path]::GetFullPath($ProjectRoot)) {
        return
      }
    } catch {}
  }

  $headers = @{}
  if ($TokenFile -and (Test-Path -LiteralPath $TokenFile)) {
    $token = (Get-Content -LiteralPath $TokenFile -Raw -Encoding UTF8).Trim()
    if ($token) { $headers.Authorization = "Bearer $token" }
  }
  $shutdownUrl = $StatusUrl -replace "/status$", "/shutdown"
  try {
    Invoke-RestMethod -Method Post -Uri $shutdownUrl -TimeoutSec 3 -Headers $headers | Out-Null
  } catch {
    if (-not $actualRuntime) {
      Stop-OwnedLegacyBridge $StatusUrl $ScriptRelativePath | Out-Null
    }
  }

  foreach ($attempt in 1..25) {
    if (-not (Test-StatusUrl $StatusUrl $TokenFile)) { return }
    Start-Sleep -Milliseconds 200
  }
  throw "An older Auralis bridge is still using $StatusUrl. Close it before reconnecting."
}

function Command-Source($Name) {
  $cmd = Get-Command $Name -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  return ""
}

function Find-Ffmpeg {
  $candidates = @()
  if ($env:AURALIS_FFMPEG_PATH) { $candidates += $env:AURALIS_FFMPEG_PATH }
  if ($env:FFMPEG_PATH) { $candidates += $env:FFMPEG_PATH }
  $fromPath = Command-Source "ffmpeg"
  if ($fromPath) { $candidates += $fromPath }
  $candidates += Join-Path $ProjectRoot "tools\bin\ffmpeg.exe"
  $candidates += "C:\Program Files\ffmpeg\bin\ffmpeg.exe"
  $candidates += "C:\Program Files (x86)\ffmpeg\bin\ffmpeg.exe"

  $winGetRoot = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Packages"
  if (Test-Path -LiteralPath $winGetRoot) {
    try {
      $found = Get-ChildItem -LiteralPath $winGetRoot -Recurse -Filter ffmpeg.exe -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($found) { $candidates += $found.FullName }
    } catch {}
  }

  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path -LiteralPath $candidate)) {
      return (Resolve-Path -LiteralPath $candidate).Path
    }
  }
  return ""
}

function Install-Ffmpeg {
  if ($NoInstall) { throw "ffmpeg was not found and -NoInstall was set." }
  Write-Step "Installing ffmpeg"
  if (Command-Source "winget") {
    $ids = @("Gyan.FFmpeg.Essentials", "Gyan.FFmpeg", "BtbN.FFmpeg.GPL")
    foreach ($id in $ids) {
      winget install --id $id -e --accept-package-agreements --accept-source-agreements
      if ($LASTEXITCODE -eq 0) { return }
    }
  }
  if (Command-Source "choco") {
    choco install ffmpeg -y
    return
  }
  if (Command-Source "scoop") {
    scoop install ffmpeg
    return
  }
  throw "No supported installer found. Install winget, Chocolatey, or Scoop, then rerun this script."
}

function Find-Node {
  $candidates = @()
  if ($env:AURALIS_NODE_PATH) { $candidates += $env:AURALIS_NODE_PATH }
  $candidates += Join-Path $ProjectRoot "node\node.exe"
  $fromPath = Command-Source "node"
  if ($fromPath) { $candidates += $fromPath }

  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path -LiteralPath $candidate)) {
      return (Resolve-Path -LiteralPath $candidate).Path
    }
  }
  return ""
}

function Install-Node {
  if ($NoInstall) { throw "Node.js was not found and -NoInstall was set." }
  Write-Step "Installing Node.js LTS for the local Auralis bridges"
  if (Command-Source "winget") {
    winget install --id OpenJS.NodeJS.LTS -e --accept-package-agreements --accept-source-agreements
    return
  }
  if (Command-Source "choco") {
    choco install nodejs-lts -y
    return
  }
  if (Command-Source "scoop") {
    scoop install nodejs-lts
    return
  }
  throw "Node.js is required to start Auralis local bridges. Install Node.js LTS, then rerun this script."
}

function Find-CodexCli {
  $candidates = @()
  if ($env:CODEX_CLI_PATH) { $candidates += $env:CODEX_CLI_PATH }
  try {
    $fromPath = Get-Command "codex" -All -ErrorAction SilentlyContinue
    foreach ($command in $fromPath) {
      if ($command.Source) { $candidates += $command.Source }
    }
  } catch {}

  $localBin = Join-Path $env:LOCALAPPDATA "OpenAI\Codex\bin"
  if (Test-Path -LiteralPath $localBin) {
    try {
      $found = Get-ChildItem -LiteralPath $localBin -Recurse -Filter codex.exe -File -ErrorAction SilentlyContinue
      foreach ($item in $found) { $candidates += $item.FullName }
    } catch {}
  }

  $checked = @{}
  $working = @()
  foreach ($candidate in $candidates) {
    if (-not $candidate) { continue }
    try {
      if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { continue }
      $resolved = (Resolve-Path -LiteralPath $candidate).Path
      if ($checked.ContainsKey($resolved)) { continue }
      $checked[$resolved] = $true

      $startInfo = New-Object System.Diagnostics.ProcessStartInfo
      $startInfo.FileName = $resolved
      $startInfo.Arguments = "--version"
      $startInfo.UseShellExecute = $false
      $startInfo.CreateNoWindow = $true
      $startInfo.RedirectStandardOutput = $true
      $startInfo.RedirectStandardError = $true
      $process = New-Object System.Diagnostics.Process
      $process.StartInfo = $startInfo
      try {
        if (-not $process.Start()) { continue }
        if (-not $process.WaitForExit(5000)) {
          try { $process.Kill() } catch {}
          continue
        }
        $versionText = ($process.StandardOutput.ReadToEnd() + " " + $process.StandardError.ReadToEnd()).Trim()
        if ($process.ExitCode -ne 0) { continue }
      } finally {
        $process.Dispose()
      }

      $version = New-Object System.Version 0, 0
      if ($versionText -match '(\d+\.\d+(?:\.\d+){0,2})') {
        try { $version = [System.Version]$matches[1] } catch {}
      }
      $item = Get-Item -LiteralPath $resolved
      $working += [pscustomobject]@{
        Path = $resolved
        Version = $version
        LastWriteTimeUtc = $item.LastWriteTimeUtc
      }
    } catch {
      continue
    }
  }

  $selected = $working |
    Sort-Object @{ Expression = { $_.Version }; Descending = $true }, @{ Expression = { $_.LastWriteTimeUtc }; Descending = $true } |
    Select-Object -First 1
  return [string]$selected.Path
}

function Start-NodeBridge($ScriptRelativePath, $StatusUrl, $EnvVars, $TokenFile = "", [switch]$ForceRestart) {
  $existingStatus = Get-Status $StatusUrl $TokenFile
  if (-not $existingStatus -and (Stop-OwnedLegacyBridge $StatusUrl $ScriptRelativePath)) {
    Write-Step "Taking over $StatusUrl from an older Auralis bridge"
  }
  if ($existingStatus) {
    $existingRuntime = [string]$existingStatus.runtimeRoot
    if ($existingRuntime) {
      try {
        if ([System.IO.Path]::GetFullPath($existingRuntime) -eq [System.IO.Path]::GetFullPath($ProjectRoot)) {
          if (-not $ForceRestart) {
            Write-Ok "$StatusUrl is already running from the current release"
            return
          }
        }
      } catch {}
    }
    $action = if ($ForceRestart) { "Restarting" } else { "Switching" }
    Write-Step "$action $StatusUrl with the current Auralis runtime"
    Stop-BridgeForRuntimeSwitch $StatusUrl $TokenFile $ScriptRelativePath -ForceRestart:$ForceRestart
  }

  $node = Find-Node
  if (-not $node) {
    Install-Node
    $node = Find-Node
  }
  if (-not $node) { throw "Node.js is still not available after install attempt." }

  foreach ($key in $EnvVars.Keys) {
    [Environment]::SetEnvironmentVariable($key, [string]$EnvVars[$key], "Process")
  }

  $scriptPath = Join-Path $ProjectRoot $ScriptRelativePath
  if (-not (Test-Path -LiteralPath $scriptPath)) { throw "Missing bridge script: $scriptPath" }

  $process = Start-Process -FilePath $node -ArgumentList @("`"$scriptPath`"") -WorkingDirectory $ProjectRoot -WindowStyle Hidden -PassThru
  Start-Sleep -Milliseconds 1200

  if (Test-StatusUrl $StatusUrl $TokenFile) {
    Write-Ok "Started $ScriptRelativePath on $StatusUrl (pid $($process.Id))"
  } else {
    throw "Started $ScriptRelativePath, but $StatusUrl did not respond."
  }
}

Write-Step "Checking ffmpeg"
$ffmpeg = Find-Ffmpeg
if (-not $ffmpeg) {
  Install-Ffmpeg
  $ffmpeg = Find-Ffmpeg
}
if (-not $ffmpeg) { throw "ffmpeg is still not available after install attempt." }
Write-Ok "ffmpeg: $ffmpeg"

Write-Step "Connecting ffmpeg to Auralis"
Start-NodeBridge "tools\local-media-bridge.js" $MediaStatusUrl @{ AURALIS_FFMPEG_PATH = $ffmpeg; AURALIS_MEDIA_BRIDGE_MAX_BODY_BYTES = "1073741824"; AURALIS_MEDIA_BRIDGE_TOKEN = $env:AURALIS_MEDIA_BRIDGE_TOKEN } $env:AURALIS_BRIDGE_TOKEN_FILE

Write-Step "Checking local Codex"
$codexCli = Find-CodexCli
if ($codexCli) {
  Write-Ok "Codex CLI: $codexCli"
  Start-NodeBridge "tools\local-codex-bridge.js" $CodexStatusUrl @{ CODEX_CLI_PATH = $codexCli } $env:AURALIS_BRIDGE_TOKEN_FILE -ForceRestart:$RestartCodex
  Write-Warn "Auralis LLM mode was not changed. In Auralis settings, manually switch LLM mode to Local Codex when you want to use it."
} else {
  Write-Warn "Codex CLI was not found. Install or sign in to Codex, then reconnect. Auralis LLM mode was not changed."
}

Write-Step "Done"
Write-Host "Media bridge: $MediaStatusUrl"
Write-Host "Local Codex bridge: $CodexStatusUrl"
