#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { defaultDataDir } = require("./local-codex-bridge.js");

const DEFAULT_BRIDGE_URL = "http://127.0.0.1:17876";
const TERMINAL_STATUSES = new Set(["completed", "error"]);

function usage() {
  return `Auralis Canvas CLI

Usage:
  auralis-canvas context --aura-id <id> [--include nodes,links,actions] [--node-offset <n>] [--node-limit <n>]
  auralis-canvas inspect --aura-id <id> (--astra <id> | --action-run <id> | --link <id> | --selector-json <object>)
  auralis-canvas apply --aura-id <id> --operations-file <path|-> --request-id <id> [--no-wait]
  auralis-canvas wait --aura-id <id> --request-id <id>
  auralis-canvas cancel --aura-id <id> --request-id <id>

Shared options:
  --bridge <url>       Defaults to AURALIS_BRIDGE_URL or ${DEFAULT_BRIDGE_URL}
  --token <token>      Defaults to AURALIS_BRIDGE_TOKEN
  --token-file <path>  Defaults to AURALIS_BRIDGE_TOKEN_FILE or Auralis data/bridge-token
  --timeout <ms>       Defaults to 120000
  --json <object>      Submit one raw operation; use '-' to read stdin
  --node-offset <n>    Context directory offset; defaults to 0
  --node-limit <n>     Context directory page size; capped by Auralis
  --selector-json      Inspect Astra matching a selector object
  --operations-file    Apply an {operations:[...]} plan from a UTF-8 file or '-'
  --no-wait            Submit context/inspect/apply without waiting for a browser response

Compatibility aliases: --aura for --aura-id.
`;
}

function parseArgs(argv) {
  const [verb, ...rest] = argv;
  const options = { verb, positional: [] };
  for (let index = 0; index < rest.length; index += 1) {
    const value = rest[index];
    if (!value.startsWith("--")) {
      options.positional.push(value);
      continue;
    }
    const key = value.slice(2).replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
    if (["noWait", "help"].includes(key)) {
      options[key] = true;
      continue;
    }
    if (index + 1 >= rest.length) throw new Error(`missing value for ${value}`);
    options[key] = rest[++index];
  }
  return options;
}

function readStdin() {
  return new Promise((resolve, reject) => {
    const chunks = [];
    process.stdin.on("data", chunk => chunks.push(chunk));
    process.stdin.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    process.stdin.on("error", reject);
  });
}

async function parseJsonOption(value) {
  const text = value === "-" ? await readStdin() : value;
  if (!text) throw new Error("--json requires a JSON object");
  const parsed = JSON.parse(text);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("--json must be an object");
  return parsed;
}

async function parseJsonFile(value) {
  if (!value) throw new Error("--operations-file requires a path or '-'");
  const text = value === "-" ? await readStdin() : fs.readFileSync(path.resolve(value), "utf8");
  if (!text.trim()) throw new Error("operations file is empty");
  const parsed = JSON.parse(text);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("operations file must contain a JSON object");
  return parsed;
}

function normalizeApplyDocument(document) {
  if (document.type) return document;
  const plan = document.plan && typeof document.plan === "object" ? document.plan : document;
  const ops = plan.operations || plan.ops;
  if (!Array.isArray(ops)) throw new Error("apply document requires an operations array");
  return {
    type: "executePlan",
    plan: {
      summary: String(plan.summary || "Auralis Canvas CLI plan"),
      requiresConfirmation: plan.requiresConfirmation === true,
      ops
    }
  };
}

function resolveToken(options) {
  const direct = String(options.token || process.env.AURALIS_BRIDGE_TOKEN || process.env.CREATION_CRAZE_BRIDGE_TOKEN || "").trim();
  if (direct) return direct;
  const tokenFile = options.tokenFile || process.env.AURALIS_BRIDGE_TOKEN_FILE || path.join(process.env.AURALIS_DATA_DIR || defaultDataDir(__dirname), "bridge-token");
  try {
    const token = fs.readFileSync(tokenFile, "utf8").trim();
    if (token) return token;
  } catch (_) {}
  throw new Error(`bridge token not found; set AURALIS_BRIDGE_TOKEN or --token-file (${tokenFile})`);
}

function requestId(options) {
  return String(options.requestId || `cli-${crypto.randomUUID()}`);
}

async function requestJson(url, token, options = {}) {
  const timeoutMs = Number(options.timeoutMs || 30_000);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: options.method || "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        ...(options.body === undefined ? {} : { "Content-Type": "application/json" })
      },
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      signal: controller.signal
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      const error = new Error(payload.error?.message || `bridge returned HTTP ${response.status}`);
      error.code = payload.error?.code || `http_${response.status}`;
      error.status = response.status;
      throw error;
    }
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

function operationFor(options) {
  if (options.verb === "context") {
    const nodeOffset = Number(options.nodeOffset ?? options.offset);
    const nodeLimit = Number(options.nodeLimit ?? options.limit);
    return {
      type: "getAuraContext",
      ...(options.include ? { include: String(options.include).split(",").map(value => value.trim()).filter(Boolean) } : {}),
      ...(Number.isFinite(nodeOffset) && nodeOffset >= 0 ? { nodeOffset } : {}),
      ...(Number.isFinite(nodeLimit) && nodeLimit > 0 ? { nodeLimit } : {})
    };
  }
  if (options.astra) return { type: "inspectAstra", astraId: String(options.astra) };
  if (options.actionRun) return { type: "inspectActionRun", actionRunId: String(options.actionRun) };
  if (options.link) return { type: "inspectLinks", linkId: String(options.link) };
  return null;
}

async function waitForOperation({ bridge, token, auraId, requestId: id, timeoutMs }) {
  const deadline = Date.now() + timeoutMs;
  let record;
  while (Date.now() < deadline) {
    const remaining = deadline - Date.now();
    const waitMs = Math.min(25_000, Math.max(1, remaining));
    record = await requestJson(`${bridge}/v1/operations/${encodeURIComponent(id)}?auraId=${encodeURIComponent(auraId)}&waitMs=${waitMs}`, token, { timeoutMs: waitMs + 5000 });
    if (TERMINAL_STATUSES.has(record.status)) return record;
  }
  return {
    ...(record || { auraId, requestId: id, status: "pending" }),
    waitTimedOut: true,
    message: `operation is still pending after ${timeoutMs}ms; keep the same requestId and wait again`
  };
}

async function submitOperation(options, bridge, token, auraId, timeoutMs) {
  const id = requestId(options);
  let operation;
  if (options.operationsFile) {
    if (options.verb !== "apply") throw new Error("--operations-file is only valid with apply");
    operation = normalizeApplyDocument(await parseJsonFile(options.operationsFile));
  } else if (options.selectorJson) {
    if (options.verb !== "inspect") throw new Error("--selector-json is only valid with inspect");
    operation = { type: "inspectAstra", target: await parseJsonOption(options.selectorJson) };
  } else if (options.json) {
    const parsed = await parseJsonOption(options.json);
    operation = options.verb === "apply" ? normalizeApplyDocument(parsed) : parsed;
  } else {
    operation = operationFor(options);
  }
  if (!operation) throw new Error(`${options.verb} requires a target or --json`);
  const record = await requestJson(`${bridge}/v1/operations`, token, {
    method: "POST",
    body: { auraId, requestId: id, verb: options.verb, operation },
    timeoutMs: Math.min(timeoutMs, 30_000)
  });
  if (options.noWait || TERMINAL_STATUSES.has(record.status)) return record;
  return waitForOperation({ bridge, token, auraId, requestId: id, timeoutMs });
}

async function run(argv = process.argv.slice(2)) {
  if (argv[0] === "--help" || argv[0] === "-h") {
    process.stdout.write(usage());
    return 0;
  }
  const options = parseArgs(argv);
  if (options.help || !options.verb) {
    process.stdout.write(usage());
    return options.verb ? 0 : 2;
  }
  if (!["context", "inspect", "apply", "wait", "cancel"].includes(options.verb)) throw new Error(`unknown verb: ${options.verb}`);
  const auraId = String(options.auraId || options.aura || "").trim();
  if (!auraId) throw new Error("--aura-id is required");
  const bridge = String(options.bridge || process.env.AURALIS_BRIDGE_URL || DEFAULT_BRIDGE_URL).replace(/\/+$/, "");
  const token = resolveToken(options);
  const timeoutMs = Math.max(1000, Number(options.timeout || 120_000));
  let result;
  if (["context", "inspect", "apply"].includes(options.verb)) {
    result = await submitOperation(options, bridge, token, auraId, timeoutMs);
  } else {
    const id = String(options.requestId || options.actionId || "").trim();
    if (!id) throw new Error("--request-id is required");
    if (options.verb === "wait") {
      result = await waitForOperation({ bridge, token, auraId, requestId: id, timeoutMs });
    } else {
      result = await requestJson(`${bridge}/v1/operations/${encodeURIComponent(id)}/cancel`, token, {
        method: "POST",
        body: { auraId },
        timeoutMs: Math.min(timeoutMs, 30_000)
      });
    }
  }
  process.stdout.write(`${JSON.stringify(result)}\n`);
  if (result.status === "error") return 1;
  if (result.status === "pending" && !options.noWait) return 2;
  return 0;
}

if (require.main === module) {
  run().then(code => {
    process.exitCode = code;
  }).catch(error => {
    process.stderr.write(`${JSON.stringify({ error: { code: error.code || "cli_error", message: error.message } })}\n`);
    process.exitCode = 1;
  });
}

module.exports = {
  operationFor,
  normalizeApplyDocument,
  parseArgs,
  parseJsonFile,
  requestJson,
  resolveToken,
  run,
  waitForOperation
};
