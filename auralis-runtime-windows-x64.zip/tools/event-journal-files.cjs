const fs = require("node:fs"), path = require("node:path");
function tailEvents(file, limit) {
  const fd = fs.openSync(file, "r"), chunks = [];
  let position = fs.fstatSync(fd).size, lines = 0;
  try {
    while (position > 0 && lines <= limit) {
      const size = Math.min(position, 65536), buffer = Buffer.allocUnsafe(size);
      position -= size; fs.readSync(fd, buffer, 0, size, position); chunks.unshift(buffer);
      for (const byte of buffer) if (byte === 10) lines++;
    }
  } finally { fs.closeSync(fd); }
  const text = Buffer.concat(chunks).toString("utf8"), records = (position ? text.slice(text.indexOf("\n") + 1) : text).split(/\r?\n/);
  const events = [];
  for (const line of records) {
    if (!line.trim()) continue;
    try { events.push(JSON.parse(line)); } catch { /* A partial last record must not hide later complete records. */ }
  }
  return events.slice(-limit);
}
function readEvents(file, limit = 10000) {
  let events = tailEvents(file, limit);
  const directory = file + ".parts";
  if (events.length < limit && fs.existsSync(directory)) {
    const names = fs.readdirSync(directory).filter(n => /^\d{20}\.jsonl$/.test(n)).sort().reverse();
    for (const name of names) {
      if (events.length >= limit) break;
      events = [...tailEvents(path.join(directory, name), limit - events.length), ...events];
    }
  }
  return [...new Map(events.map(event => [event.eventId, event])).values()].sort((a, b) => a.eventId - b.eventId).slice(-limit);
}
function rotateEvents(file, lastId) {
  const directory = file + ".parts", archive = path.join(directory, String(lastId).padStart(20, "0") + ".jsonl");
  fs.mkdirSync(directory, { recursive: true });
  // Keep the original inode available until the new current file is published.
  if (!fs.existsSync(archive)) {
    try { fs.linkSync(file, archive); } catch { fs.copyFileSync(file, archive); }
  }
  const temporary = file + ".rotate.tmp";
  fs.writeFileSync(temporary, "", { encoding: "utf8", mode: 0o600 });
  fs.renameSync(temporary, file);
}
module.exports = { readEvents, rotateEvents };
