@echo off
setlocal
set "AURALIS_CANVAS_TOOLS=%~dp0"
if exist "%AURALIS_CANVAS_TOOLS%..\node\node.exe" (
  "%AURALIS_CANVAS_TOOLS%..\node\node.exe" "%AURALIS_CANVAS_TOOLS%auralis-canvas-cli.js" %*
) else (
  node "%AURALIS_CANVAS_TOOLS%auralis-canvas-cli.js" %*
)
exit /b %ERRORLEVEL%
