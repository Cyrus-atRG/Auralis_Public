// GPT-6.1 tools require Responses. Other RG models use Chat Completions.
const usesResponses = model => model === "gpt-6.1-sol";
// Second-highest supported effort, with Gemini explicitly raised to high by the user.
// The company New API gateway maps Chat reasoning_effort to Claude output_config.effort.
const reasoningEffort = model => ({
  "claude-sonnet-5-5": "xhigh", "claude-opus-5-5": "xhigh", "gpt-6.1-sol": "xhigh",
  "gemini-4-argon": "high", "deepseek-v4-1-flash-1017": "high", "kimi-k3-260716": "high",
})[model];
function geminiToolSchema(value) {
  if (Array.isArray(value)) return value.map(geminiToolSchema);
  if (!value || typeof value !== "object") return value;
  const result = Object.fromEntries(Object.entries(value).map(([key, child]) => [key, geminiToolSchema(child)]));
  // Gemini rejects empty enum values. Keep the accepted values in the description;
  // the workbench still validates them, including an explicit empty/unknown value.
  if (result.enum?.includes("")) {
    result.description = [result.description, "Allowed values: " + JSON.stringify(result.enum)].filter(Boolean).join(". ");
    delete result.enum;
  }
  return result;
}
function requestBody(model, messages, tools) {
  if (!usesResponses(model)) return { model, messages, tools: model === "gemini-4-argon" ? geminiToolSchema(tools) : tools, tool_choice: "auto",
    ...(reasoningEffort(model) ? { reasoning_effort: reasoningEffort(model) } : {}),
    ...(model.startsWith("claude-") ? { thinking: { type: "adaptive", display: "summarized" } } : {}) };
  const input = messages.flatMap(message => {
    if (message.responseOutput) return message.responseOutput;
    if (message.role === "tool") return [{ type: "function_call_output", call_id: message.tool_call_id, output: message.content }];
    const content = typeof message.content === "string" ? message.content : message.content.map(part => part.type === "image_url"
      ? { type: "input_image", image_url: part.image_url.url }
      : { type: "input_text", text: part.text });
    return [{ role: message.role, content }];
  });
  return { model, input, tools: tools.map(t => ({ type: "function", ...t.function, strict: false })), tool_choice: "auto",
    store: false, include: ["reasoning.encrypted_content"], reasoning: { effort: reasoningEffort(model), summary: "auto" } };
}
function responseChoice(model, data) {
  if (!usesResponses(model)) {
    const choice = data.choices?.[0];
    // Claude's stream can finish a no-argument call with "". Its gateway drops
    // that tool_use on replay unless the arguments are valid JSON ({}).
    for (const call of choice?.message?.tool_calls || []) if (call.function && !call.function.arguments) call.function.arguments = "{}";
    return choice;
  }
  const output = data.output || [];
  const content = output.filter(item => item.type === "message").flatMap(item => item.content || [])
    .map(part => part.type === "output_text" ? part.text : part.type === "refusal" ? part.refusal : "").join("");
  const calls = output.filter(item => item.type === "function_call").map(item => ({
    id: item.call_id, type: "function", function: { name: item.name, arguments: item.arguments },
  }));
  const length = data.status === "incomplete" && data.incomplete_details?.reason === "max_output_tokens";
  return { finish_reason: length ? "length" : calls.length ? "tool_calls" : "stop",
    error: data.error?.message || (data.status === "incomplete" && !length ? "公司 API 未完成响应：" + data.incomplete_details?.reason : null),
    message: { role: "assistant", content, tool_calls: calls, responseOutput: output } };
}
module.exports = { usesResponses, requestBody, responseChoice, reasoningEffort };
