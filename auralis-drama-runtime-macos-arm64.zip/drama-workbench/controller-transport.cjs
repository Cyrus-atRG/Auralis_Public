// GPT-6.1 tools require Responses. Other RG models use Chat Completions.
const usesResponses = model => model === "gpt-6.1-sol";
function requestBody(model, messages, tools) {
  if (!usesResponses(model)) return { model, messages, tools, tool_choice: "auto" };
  const input = messages.flatMap(message => {
    if (message.responseOutput) return message.responseOutput;
    if (message.role === "tool") return [{ type: "function_call_output", call_id: message.tool_call_id, output: message.content }];
    const content = typeof message.content === "string" ? message.content : message.content.map(part => part.type === "image_url"
      ? { type: "input_image", image_url: part.image_url.url }
      : { type: "input_text", text: part.text });
    return [{ role: message.role, content }];
  });
  return { model, input, tools: tools.map(t => ({ type: "function", ...t.function, strict: false })), tool_choice: "auto",
    store: false, include: ["reasoning.encrypted_content"] };
}
function responseChoice(model, data) {
  if (!usesResponses(model)) return data.choices?.[0];
  const output = data.output || [];
  const content = output.filter(item => item.type === "message").flatMap(item => item.content || [])
    .map(part => part.type === "output_text" ? part.text : part.type === "refusal" ? part.refusal : "").join("");
  const calls = output.filter(item => item.type === "function_call").map(item => ({
    id: item.call_id, type: "function", function: { name: item.name, arguments: item.arguments },
  }));
  const length = data.status === "incomplete" && data.incomplete_details?.reason === "max_output_tokens";
  return { finish_reason: length ? "length" : calls.length ? "tool_calls" : "stop",
    error: data.error?.message || (data.status === "incomplete" && !length ? "公司 API 未完成响应：" + data.incomplete_details?.reason : null),
    message: { role: "assistant", content, tool_calls: calls, responseOutput: output } };
}
module.exports = { usesResponses, requestBody, responseChoice };
