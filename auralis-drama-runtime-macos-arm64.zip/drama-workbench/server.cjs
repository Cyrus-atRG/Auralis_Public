const { discussionHistory, inputManifest, rememberContext, writeContextSelection, acknowledgeWrites, incrementalContext, incrementalPolicy } = require("./agent-inputs.cjs");
const { discussionMessages, readDiscussion } = require("./agent-history.cjs");
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { Store, id, find, fail, requireValue, latest } = require("./store.cjs");
const { Provider, models, probe } = require("./provider.cjs");
const { VoiceProvider } = require("./voices.cjs");
const { saveKey } = require("./voice-credentials.cjs");
const { defaults } = require("./generation.cjs");
const { ControllerSettings, CompanyController, imageContent } = require("./controller.cjs");
const { stages, scopeKey, conversation, recordReply, documentSnapshot, changeNotice } = require("./conversations.cjs");
const { clipDownloads, sendClipZip, disposition, filename } = require("./clip-download.cjs");
const { version: appVersion } = require("./version.json");
const { createMediaViewerPage } = require("./media-viewer-page.cjs");
const { AssetDescriptions } = require("./asset-descriptions.cjs");
const { agentImageSheets } = require("./asset-images.cjs");
const { imagePreview } = require("./media-preview.cjs");
const { receiveUpload } = require("./media-upload.cjs");
const runtimeRoot = path.resolve(__dirname, "..");
const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".jpg": "image/jpeg",
  ".webp": "image/webp",
  ".mp4": "video/mp4",
  ".mp3": "audio/mpeg",
  ".wav": "audio/wav",
};
async function body(req, max = 1048576) {
  const parts = [];
  let size = 0;
  for await (const part of req) {
    size += part.length;
    if (size > max) fail("请求过大", "too_large", 413);
    parts.push(part);
  }
  return Buffer.concat(parts);
}
async function jsonBody(req, max) {
  try {
    return JSON.parse((await body(req, max)).toString("utf8"));
  } catch (e) {
    if (e.code) throw e;
    fail("JSON 格式无效");
  }
}
function createWorkbench(options = {}) {
  const mediaViewerPage = createMediaViewerPage(runtimeRoot);
  const videoPoster = require("./video-posters.cjs").createVideoPosters();
  const port = options.port ?? Number(process.env.AURALIS_DRAMA_PORT || 17887),
    root =
      options.root || process.env.AURALIS_DRAMA_DATA_DIR || path.join(runtimeRoot, ".auralis", "drama-workbench"),
    store = new Store(path.join(root, "projects"));
  const prompts = new (require("./prompts.cjs").PromptLibrary)(root);
  const controllerSettings = new ControllerSettings(root);
  const companyController = new CompanyController({ fetch: options.companyFetch });
  const backups = new (require("./backup.cjs").DramaBackup)(root, prompts, options.backupOptions);
  const sharedApi = new (require("../tools/shared-api-settings.cjs").SharedApiSettings)(options.sharedApiFile || (options.root ? path.join(root, "shared-api.local.json") : undefined));
  const descriptions = new AssetDescriptions(store, { credentials: () => sharedApi.read(), ...options.descriptionOptions });
  store.imageDescription = (projectId, version) => descriptions.description(projectId, version);
  const userToken = crypto.randomBytes(32).toString("hex"),
    instanceId = crypto.randomUUID(),
    sessionsFile = path.join(root, "controller-sessions.json"),
    sessions = new Map(
      fs.existsSync(sessionsFile)
        ? JSON.parse(fs.readFileSync(sessionsFile, "utf8"))
        : [],
    ),
    provider = options.provider || new Provider(store, { credentials: () => sharedApi.read(), promptLibrary: prompts }),
    voices = options.voices || new VoiceProvider(store, { credentials: () => sharedApi.read(), ...options.voiceOptions }),
    bridgePort = options.bridgePort || 17888;
  if (!options.root && !options.provider && !options.voiceOptions?.key && !fs.existsSync(sharedApi.file)) {
    const legacy = { wavespeedApiKey: provider.key || "", elevenLabsApiKey: voices.key || "" };
    if (Object.values(legacy).some(Boolean)) sharedApi.save(legacy, { missingOnly: true });
  }
  const saveSessions = () => {
    const temporary = sessionsFile + ".tmp";
    fs.writeFileSync(temporary, JSON.stringify([...sessions]), "utf8");
    fs.renameSync(temporary, sessionsFile);
  };
  let bridge = null,
    base = "", agentTimer = null, agentPoll = null;
  const startingTurns = new Set();
  const agentSnapshots = new Map();
  const agentEpochs = new Map();
  const copyingProjects = new Set();
  const projectSync = new (require("./project-sync.cjs").ProjectSync)(store);
  let jobsScheduled = null;
  const scheduleJobs = () => {
    if (options.runJobs === false || jobsScheduled) return;
    jobsScheduled = setImmediate(() => {
      jobsScheduled = null;
      provider.tick(); voices.tick();
    });
  };
  const json = (res, status, value) => {
    res.writeHead(status, {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    });
    res.end(JSON.stringify(value));
  };
  const sendFile = (res, file, mime, download = false, name = path.basename(file), mediaRequest = null) => {
    requireValue(fs.existsSync(file), "文件不存在");
    const stat = fs.statSync(file);
    const cacheable = mediaRequest && !download;
    // Immutable version files need a strong validator so browsers can reuse byte ranges.
    const etag = `"${stat.size.toString(16)}-${stat.mtimeMs.toString(16)}"`;
    const modified = stat.mtime.toUTCString();
    const headers = {
      "Content-Type":
        mime || mimeTypes[path.extname(file)] || "application/octet-stream",
      // Each upload/generated version has its own immutable URL. Drafts and API data stay uncached.
      "Cache-Control": cacheable ? "private, max-age=31536000, immutable" : "no-store",
      ...(cacheable ? { ETag: etag, "Last-Modified": modified, "Accept-Ranges": "bytes" } : {}),
      "X-Content-Type-Options": "nosniff",
      ...(download
        ? {
            "Content-Disposition": disposition(name),
          }
        : {}),
    };
    if (cacheable && mediaRequest.headers["if-none-match"] === etag) {
      res.writeHead(304, headers);
      return res.end();
    }
    let start = 0, end = stat.size - 1, partial = false;
    const ifRange = mediaRequest?.headers["if-range"];
    const range = cacheable && mediaRequest.method === "GET" && (!ifRange || ifRange === etag || ifRange === modified)
      ? /^bytes=(\d*)-(\d*)$/.exec(mediaRequest.headers.range || "") : null;
    if (range && (range[1] || range[2])) {
      start = range[1] ? Number(range[1]) : Math.max(0, stat.size - Number(range[2]));
      end = range[1] && range[2] ? Math.min(Number(range[2]), end) : end;
      if (!Number.isSafeInteger(start) || start > end || start >= stat.size) {
        res.writeHead(416, { ...headers, "Content-Range": `bytes */${stat.size}`, "Content-Length": 0 });
        return res.end();
      }
      partial = true;
    }
    res.writeHead(partial ? 206 : 200, {
      ...headers,
      "Content-Length": partial ? end - start + 1 : stat.size,
      ...(partial ? { "Content-Range": `bytes ${start}-${end}/${stat.size}` } : {}),
    });
    if (mediaRequest?.method === "HEAD") return res.end();
    const stream = fs.createReadStream(file, partial ? { start, end } : undefined);
    // Browsers cancel metadata/seek requests; do not leave their file streams open.
    res.once("close", () => stream.destroy());
    stream.once("error", (error) => res.destroy(error));
    stream.pipe(res);
  };
  const user = (req) => {
    if (req.headers.authorization !== "Bearer " + userToken)
      fail("需要工作台会话", "unauthorized", 401);
  };
  const controller = (req) => {
    const s = sessions.get(req.headers["x-drama-session"]);
    if (!s || s.revokedAt || !s.capability || req.headers.authorization !== "Bearer " + s.capability)
      fail("工作台作用域失效，请重新发起本阶段", "scope_expired", 401);
    return s;
  };
  async function ensureBridge() {
    if (bridge) return bridge;
    const { createBridge } = require("../tools/local-codex-bridge.js");
    bridge = createBridge({
      port: bridgePort,
      runtimeRoot,
      workspace: runtimeRoot,
      dataDir: path.join(root, "bridge"),
      dramaRoot: root,
      appServerEnv: { AURALIS_DRAMA_URL: base },
    });
    await bridge.listen();
    return bridge;
  }
  async function bridgeCall(route, payload) {
    if (options.bridgeCall) return options.bridgeCall(route, payload);
    const b = await ensureBridge();
    const token = fs.readFileSync(b.tokenFile, "utf8").trim();
    const r = await fetch("http://127.0.0.1:" + bridgePort + "/v1/" + route, {
      method: payload ? "POST" : "GET",
      headers: {
        Authorization: "Bearer " + token,
        "Content-Type": "application/json",
      },
      ...(payload ? { body: JSON.stringify(payload) } : {}),
      signal: AbortSignal.timeout(30000),
    });
    const value = await r.json();
    if (!r.ok)
      fail(
        value.error?.message || "侧载 agent 连接失败",
        value.error?.code || "bridge",
        r.status,
      );
    return value;
  }
  function agentKey(eid, stage) {
    requireValue(eid ? stages.includes(stage) : !stage || stage === "setting", "请选择对应的 Agent 阶段");
    return scopeKey(eid, stage);
  }
  async function controllerOperation(s, verb, input, local = false) {
    requireValue(sessions.has(s.id) && !s.revokedAt, "本轮作用域已失效，请发送新消息继续");
    const p = store.read(s.projectId);
    if (verb === "history") return readDiscussion(discussionMessages(p.agentConversations?.[scopeKey(s.episodeId, s.stage)], s.historyStartIndex), input);
    if (verb === "context") {
      requireValue(input?.full === undefined || typeof input.full === "boolean", "full 必须为布尔值");
      const context = store.context(p, s);
      const result = incrementalContext(context, input?.full ? null : s.inputState);
      if (s.inputState) { rememberContext(s.inputState, context); saveSessions(); }
      return result;
    }
    if (verb === "inspect") return { revision: p.revision, items: store.inspect(p, s, input.ids, input) };
    if (verb === "view_image") {
      if (input.clipId) {
        const ref = { clipId: input.clipId, versionId: input.versionId, frame: 'last' };
        requireValue(s.stage === 'video' || s.stage === 'assets', '本阶段不查看视频尾帧');
        await require('./reference-frames.cjs').prepareReference(store, p, ref);
        const projectDir = path.dirname(store.file(p.id));
        const media = await imagePreview(projectDir, require('./media-references.js').resolve(p, ref).media);
        return local ? { path: path.join(projectDir, media.path) } : { image: imageContent(projectDir, media) };
      }
      const asset = store.inspect(p, s, [input.assetId], { versionIds: [input.versionId], historyLimit: 0 })[0];
      const version = find(asset.versions || [], input.versionId);
      const projectDir = path.dirname(store.file(p.id));
      const media = await imagePreview(projectDir, version.media);
      return local ? { path: path.join(projectDir, media.path) } : { image: imageContent(projectDir, media) };
    }
    if (verb === "job") {
      const job = find(p.jobs, input.id);
      if (job.episodeId !== s.episodeId || !["assets", "video"].includes(s.stage) || job.targetType !== (s.stage === "video" ? "clip" : "asset"))
        fail("任务不在本阶段", "scope_denied", 403);
      requireValue(input.includeInput === undefined || typeof input.includeInput === "boolean", "includeInput 必须为布尔值");
      if (input.includeInput) return job;
      const { snapshot, request, ...status } = job;
      return { ...status, inputOmitted: !!(snapshot || request) };
    }
    if (verb === "apply") {
      await require('./reference-frames.cjs').prepareOperations(store, p, input.operations, s);
      const selection = writeContextSelection(input.operations);
      // A receipt replay performs no write and must not acknowledge intervening edits.
      const before = s.inputState && !p.receipts[input.requestId] ? store.context(p, s, selection) : null;
      const result = store.mutate(p.id, input, s);
      if (s.role === "setting") {
        for (const r of result.results)
          if (r.id?.startsWith("setting-") && !s.settingIds.includes(r.id)) s.settingIds.push(r.id);
      }
      s.referenceIds ||= [];
      for (const r of result.results) {
        if (r.id?.startsWith("reference-") && !s.referenceIds.includes(r.id)) s.referenceIds.push(r.id);
      }
      if (before) {
        const afterSelection = writeContextSelection(input.operations, result.results);
        acknowledgeWrites(s.inputState, before, store.context(store.read(p.id), s, afterSelection), [input.operations, result], input.operations, afterSelection);
      }
      saveSessions();
      scheduleJobs();
      return result;
    }
    fail("未知 controller 操作");
  }
  async function interruptAgent(run) {
    try {
      return await (run.provider === "company" ? companyController.interrupt(run)
        : bridgeCall("auras/" + run.auraId + "/interrupt", { requestId: id("stop"), turnId: run.turnId }));
    } catch (error) {
      if (error.code === "thread_not_found" || /^thread not found:/i.test(error.message)) return { status: "interrupted" };
      throw error;
    }
  }
  function revokeAgentScope(pid, key) {
    for (const [id, scope] of sessions)
      if (scope.projectId === pid && scopeKey(scope.episodeId, scope.stage) === key) {
        companyController.forget(scope.inputState?.auraId);
        sessions.delete(id);
      }
    saveSessions();
  }
  async function agentState(pid, eid, stage) {
    const key = agentKey(eid, stage);
    const initialProject = store.read(pid);
    const run = initialProject.agentRuns?.[key];
    if (!run?.turnId) return { run: run || null };
    if (run.stopRequestedAt) return { run };
    // Share only in-flight reads of the exact observed run. A stop, reset or new
    // turn must never join a pending snapshot from an earlier state.
    const requestKey = JSON.stringify([pid, key, run]);
    if (agentSnapshots.has(requestKey)) return agentSnapshots.get(requestKey);
    const pending = reconcileAgentState(pid, key, run, initialProject);
    agentSnapshots.set(requestKey, pending);
    try { return await pending; }
    finally { if (agentSnapshots.get(requestKey) === pending) agentSnapshots.delete(requestKey); }
  }
  async function reconcileAgentState(pid, key, run, initialProject) {
    const snapshot = run.provider === "company" ? companyController.snapshot(run, initialProject.agentConversations[key]?.messages) : await bridgeCall(
      "auras/" + run.auraId + "/turns/" + run.turnId,
    );
    // A stop/completion/new turn may have been persisted while the bridge was awaiting a snapshot.
    // Only reconcile the run that was actually observed when this request began.
    const observedProject = store.read(pid);
    const observed = observedProject.agentRuns?.[key];
    if (JSON.stringify(observed) !== JSON.stringify(run)) return { run: observed || null };
    // Missing bridge history cannot undo a terminal state already saved by the workbench.
    if ((!snapshot.status || snapshot.status === "unknown") && ["completed", "failed", "interrupted"].includes(run.status))
      return { run };
    const status = snapshot.status === "active" ? "running" : snapshot.status;
    const next = {
      ...run,
      status: status || "unknown",
      error: snapshot.error?.message || null,
    };
    if (snapshot.terminal && !next.finishedAt)
      next.finishedAt = new Date().toISOString();
    const savedReply = observedProject.agentConversations[key]?.messages.find(m => m.id === "reply-" + run.turnId);
    if (JSON.stringify(next) !== JSON.stringify(run) || (snapshot.terminal && snapshot.finalText && savedReply?.text !== snapshot.finalText))
      store.activity(pid, (p) => {
        if (p.agentRuns?.[key]?.turnId === run.turnId) {
          p.agentRuns[key] = next;
          recordReply(p, key, next, snapshot);
        } else return false;
      });
    const current = store.read(pid).agentRuns?.[key];
    return current?.turnId === run.turnId ? { run: next, snapshot } : { run: current || null };
  }
  const projectActive = p => [...startingTurns].some(key => key.startsWith(p.id + "/")) ||
    p.jobs.some(j => provider.active?.has(j.id) || ["queued", "preparing", "submitting", "polling", "downloading"].includes(j.status)) ||
    p.assets.some(a => voices.active?.has(a.id) || ["queued", "searching", "running"].includes(a.voiceSearch?.status)) ||
    Object.values(p.agentRuns || {}).some(r => ["running", "starting"].includes(r.status));
  const activeWork = () => copyingProjects.size > 0 || startingTurns.size > 0 || provider.active?.size > 0 || voices.active?.size > 0 || store.projectIds().some(projectId => projectActive(store.read(projectId)));
  const server = http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, base || "http://127.0.0.1:" + port),
        route = url.pathname;
      if (req.headers.origin && req.headers.origin !== base)
        fail("来源不匹配", "origin", 403);
      if (req.headers.host !== new URL(base || "http://127.0.0.1:" + port).host)
        fail("Host 不匹配", "host", 403);
      if (route === "/api/health" && req.method === "GET") return json(res, 200, { app: "auralis-drama", instanceId });
      if (route === "/launcher/status" && req.method === "GET") return json(res, 200, { app: "auralis-drama", runtimeRoot, dataRoot: root, active: activeWork(), pid: process.pid });
      if (route === "/api/bootstrap" && req.method === "GET")
        return json(res, 200, {
          token: userToken,
          appVersion,
          models,
          defaults,
          controller: controllerSettings.status(),
          providerReady: !!(sharedApi.read().wavespeedApiKey || provider.key),
          companyReady: sharedApi.status().companyReady,
          elevenLabsReady: !!(sharedApi.read().elevenLabsApiKey || voices.key),
          projects: store.list(),
        });
      if (backups.restoring && route.startsWith("/api/controller/") && req.method !== "GET") fail("正在恢复备份，请稍后重试", "backup_busy", 409);
      if (route.startsWith("/api/controller/")) {
        const s = controller(req),
          verb = route.split("/").at(-1),
          input = req.method === "POST" ? await jsonBody(req) : {};
        return json(res, 200, await controllerOperation(s, verb, input, input.localPath === true));
      }
      if (route.startsWith("/api/")) {
        user(req);
        if (route === "/api/shutdown" && req.method === "POST") {
          requireValue(!activeWork() && !backups.busy, "正在制作，请等待完成后更新服务");
          json(res, 200, { ok: true });
          setImmediate(async () => {
            clearImmediate(jobsScheduled);
            clearInterval(agentTimer);
            if (agentPoll) await agentPoll;
            backups.stop(); provider.stop(); await voices.stop(); await descriptions.stop(); await companyController.close(); if (bridge) await bridge.close();
            server.close(() => { if (require.main === module) process.exit(0); });
          });
          return;
        }
        if (backups.restoring && req.method !== "GET" && !route.startsWith("/api/backup")) fail("正在备份或恢复，请稍后重试", "backup_busy", 409);
        if (route === "/api/backup" && req.method === "GET") return json(res, 200, backups.status(url.searchParams.get("summary") !== "1"));
        if (route === "/api/media-trash" && req.method === "GET") {
          requireValue(!backups.restoring, "正在恢复备份，请稍后打开回收站");
          return json(res, 200, require("./media-trash.cjs").pruneMediaTrash(store));
        }
        if (route === "/api/backup" && req.method === "POST") {
          const b = await jsonBody(req);
          if (b.action === "save") return json(res, 200, backups.configure(b));
          if (b.action === "write") { await backups.write(); return json(res, 200, backups.status()); }
          if (b.action === "restore") {
            requireValue(!activeWork(), "请先等待当前制作任务完成，再恢复备份");
            const restored = await backups.restore(b.id);
            store.reindexWork();
            return json(res, 200, restored);
          }
          fail("未知备份操作");
        }
        if (route === "/api/prompts" && req.method === "GET") return json(res, 200, prompts.list());
        if (route === "/api/controller-settings" && req.method === "GET") return json(res, 200, { ...controllerSettings.status(), companyReady: sharedApi.status().companyReady });
        if (route === "/api/controller-settings" && req.method === "POST") return json(res, 200, controllerSettings.save(await jsonBody(req)));
        if (route === "/api/prompts" && req.method === "POST") {
          const b = await jsonBody(req);
          return json(res, 200, prompts.save(b.id, b.custom, b.mode));
        }
        if (route === '/api/multimedia-token' && req.method === 'POST') {
          const body = await jsonBody(req);
          return json(res, 200, await provider.aigc.check(body.force === true));
        }
        if (route === "/api/shared-api" && req.method === "GET") return json(res, 200, sharedApi.status());
        if (route === "/api/shared-api" && req.method === "POST") {
          const b = await jsonBody(req);
          sharedApi.save(b);
          const values = sharedApi.read();
          provider.key = values.wavespeedApiKey || provider.key;
          voices.key = values.elevenLabsApiKey || voices.key;
          return json(res, 200, sharedApi.status());
        }
        if (route === "/api/company-chat" && req.method === "POST") {
          // Embedded media tools use the same live credentials as the production Agent.
          const credentials = sharedApi.read();
          requireValue(credentials.baseUrl, "请在短剧工作台的「设置 → 共享 API」填写公司 API 地址；该配置与自由画布共用。");
          requireValue(credentials.apiKey, "请在短剧工作台的「设置 → 共享 API」填写公司 API Key；已保存的地址会保留。");
          // Match the 200 MiB media import limit after base64 expansion, with room for the prompt.
          const input = await jsonBody(req, 280 * 1024 * 1024);
          requireValue(typeof input.model === "string" && input.model.length <= 200 && Array.isArray(input.messages) && input.messages.length, "素材解析请求无效");
          const endpoint = new URL(credentials.baseUrl.replace(/\/+$/, "") + "/chat/completions");
          requireValue(["http:", "https:"].includes(endpoint.protocol), "公司 API 地址须为 HTTP 或 HTTPS URL");
          const abort = new AbortController(), stop = () => abort.abort();
          res.once("close", stop);
          try {
            const response = await companyController.fetch(endpoint, {
              method: "POST", headers: { Authorization: "Bearer " + credentials.apiKey, "Content-Type": "application/json" },
              body: JSON.stringify({ ...input, stream: false }),
              signal: AbortSignal.any([abort.signal, AbortSignal.timeout(300000)]),
            });
            let result;
            try { result = await response.json(); } catch { throw new Error("公司 API 返回了无法解析的响应（HTTP " + response.status + "）"); }
            if (!response.ok) throw new Error("公司 API：" + (result.error?.message || "HTTP " + response.status));
            return json(res, 200, result);
          } catch (error) {
            throw new Error(String(error.message).replaceAll(credentials.apiKey, "[Key]"));
          } finally { res.off("close", stop); }
        }
        if (route === "/api/projects" && req.method === "GET")
          return json(res, 200, store.list());
        if (route === "/api/projects" && req.method === "POST") {
          const b = await jsonBody(req);
          return json(res, 201, store.create(b.title, b.premise));
        }
        if (route === "/api/provider" && req.method === "POST") {
          const b = await jsonBody(req);
          sharedApi.save({ wavespeedApiKey: String(b.key || "").trim() });
          provider.key = String(b.key || "").trim();
          return json(res, 200, { ready: !!provider.key });
        }
        if (route === "/api/voice-provider" && req.method === "POST") {
          const b = await jsonBody(req);
          saveKey(b.key, options.voiceCredentialFile);
          sharedApi.save({ elevenLabsApiKey: b.key.trim() });
          voices.key = b.key.trim();
          return json(res, 200, { ready: true });
        }
        const match = route.match(
          /^\/api\/projects\/(project-[a-f0-9-]+)(?:\/(.+))?$/,
        );
        if (!match) fail("未知路径", "not_found", 404);
        const pid = match[1],
          action = match[2] || "";
        if (!action && req.method === "GET") {
          // Every store write atomically replaces this file, including activity-only updates.
          // An unchanged poll needs neither the project body nor its derived view data.
          const etag = projectSync.tag(pid);
          res.setHeader("ETag", etag);
          if (req.headers["if-none-match"] === etag) {
            res.writeHead(304, { "Cache-Control": "no-store" });
            return res.end();
          }
        }
        let p = store.read(pid);
        if (action === "rename" && req.method === "POST") {
          const b = await jsonBody(req);
          store.rename(pid, b.title, b.expectedTitle);
          return json(res, 200, { ok: true });
        }
        if (action === "duplicate" && req.method === "POST") {
          requireValue(!copyingProjects.has(pid), "项目正在复制，请稍候");
          copyingProjects.add(pid);
          try { return json(res, 201, { id: (await store.duplicate(pid)).id }); }
          finally { copyingProjects.delete(pid); }
        }
        if (action === "remove" && req.method === "POST") {
          const b = await jsonBody(req);
          requireValue(b.confirmed === true, "请确认删除项目");
          requireValue(!copyingProjects.has(pid), "项目正在复制，请稍候再删除");
          requireValue(!projectActive(store.read(pid)), "项目正在制作，请先停止 Agent 并等待素材任务完成，再删除项目");
          store.remove(pid, b.expectedRevision);
          for (const [key, scope] of sessions) if (scope.projectId === pid) sessions.delete(key);
          saveSessions();
          return json(res, 200, { ok: true });
        }
        if (!action && req.method === "GET")
          return json(res, 200, projectSync.project(p, url.searchParams.get("delta") === "1" ? req.headers["if-none-match"] : null, res.getHeader("ETag")));
        if (action === "job" && req.method === "GET")
          return json(res, 200, find(p.jobs, url.searchParams.get("id")));
        if (action === "apply" && req.method === "POST") {
          const input = await jsonBody(req);
          await require('./reference-frames.cjs').prepareOperations(store, p, input.operations);
          for (const operation of input.operations || []) {
            if (operation.type === "generateCanvasVideo")
              operation.canvasInputs = await require("./canvas-video.cjs").probeInputs(store, p, operation.canvasInputs);
          }
          const result = store.mutate(pid, input);
          scheduleJobs();
          return json(res, 200, result);
        }
        if (action === "upload" && req.method === "POST") {
          const mime = String(req.headers["content-type"] || "").split(";")[0];
          const ext = {
            "image/png": ".png",
            "image/jpeg": ".jpg",
            "image/webp": ".webp",
            "audio/mpeg": ".mp3",
            "audio/wav": ".wav",
            "audio/x-wav": ".wav",
            "video/mp4": ".mp4",
            "video/quicktime": ".mov",
          }[mime];
          requireValue(ext, "仅支持 PNG/JPG/WebP、MP3/WAV、MP4/MOV");
          const relative = "media/" + id("import") + ext,
            file = path.join(path.dirname(store.file(pid)), relative);
          fs.mkdirSync(path.dirname(file), { recursive: true });
          const size = await receiveUpload(req, file);
          try {
            return json(res, 200, {
              path: relative,
              mime,
              size,
              ...await probe(file, mime),
            });
          } catch (e) {
            await fs.promises.rm(file, { force: true });
            throw e;
          }
        }
        if (action === "agent" && req.method === "POST") {
          const b = await jsonBody(req),
            role = b.episodeId ? "production" : "setting";
          requireValue(
            ["setting", "synopsis", "storyboard", "assets", "video"].includes(
              b.stage,
            ),
            "阶段无效",
          );
          let e = role === "production" ? find(p.episodes, b.episodeId) : null;
          if (e && b.advance) b.stage = store.nextStage(p, e);
          if (!e) b.stage = "setting";
          const runKey = agentKey(e?.id, b.stage),
            lockKey = pid + "/" + runKey;
          requireValue(!startingTurns.has(lockKey), "Agent 正在启动，请稍候");
          startingTurns.add(lockKey);
          const epoch = agentEpochs.get(lockKey) || 0;
          const stillCurrent = () => (agentEpochs.get(lockKey) || 0) === epoch;
          const checkCurrent = () => requireValue(stillCurrent(), "Agent 已重置，请重新发送消息");
          let sourceLockKey = null;
          try {
            const requestId = b.requestId || id("turn");
            if (p.agentConversations[runKey]?.messages.some(m => m.requestId === requestId)) {
              const run = p.agentRuns[runKey];
              return json(res, 200, { ...run, run, conversation: p.agentConversations[runKey], reused: true });
            }
            let advanceKey = null;
            if (b.advance) {
              requireValue(e, "请选择要继续的一集");
              const { targetType, targetId, versionId } = b.advance;
              const doc = ["synopsis", "storyboard"].includes(targetType)
                ? e[targetType]
                : targetType === "asset" &&
                    e.assetRefs.some((r) => r.assetId === targetId)
                  ? find(p.assets, targetId)
                  : targetType === "clip"
                    ? find(e.clips, targetId)
                    : null;
              requireValue(
                doc && versionId && doc.acceptedVersionId === versionId,
                "采用版本已变化，请刷新后继续",
              );
              advanceKey =
                targetType + "/" + (targetId || e.id) + "/" + versionId;
              const previous = p.agentRuns?.[runKey];
              if (previous?.advanceKey === advanceKey) {
                const { run } = await agentState(pid, e.id, b.stage);
                if (["running", "completed"].includes(run.status))
                  return json(res, 200, { ...run, reused: true });
              }
              const sourceStage = { synopsis: "synopsis", storyboard: "storyboard", asset: "assets", clip: "video" }[targetType];
              const sourceKey = scopeKey(e.id, sourceStage);
              if (sourceKey !== runKey && p.agentRuns?.[sourceKey]?.turnId) {
                const sourceLock = pid + "/" + sourceKey;
                requireValue(!startingTurns.has(sourceLock), "上一阶段 Agent 正在启动或停止，请稍候");
                sourceLockKey = sourceLock;
                startingTurns.add(sourceLockKey);
                const { run } = await agentState(pid, e.id, sourceStage);
                for (const old of sessions.values())
                  if (old.projectId === pid && old.episodeId === e.id && old.stage === sourceStage) {
                    // Revoke tools, but keep the fingerprints for a return to this same thread.
                    // Stop/reset and a successful replacement session still delete this record.
                    old.revokedAt = new Date().toISOString();
                    delete old.capability;
                  }
                saveSessions();
                if (run.status === "running") {
                  await interruptAgent(run);
                  store.activity(pid, doc => Object.assign(doc.agentRuns[sourceKey], { status: "interrupted", finishedAt: new Date().toISOString() }));
                }
              }
            }
            let activeRun = null;
            if (p.agentRuns?.[runKey]?.turnId) {
              const { run } = await agentState(pid, e?.id, b.stage);
              if (run.status === "running") {
                requireValue(!b.advance && !b.freshSession, "Agent 正在运行，请先停止本轮再切换会话");
                activeRun = run;
              }
            }
            const execution = controllerSettings.read();
            checkCurrent();
            if (activeRun) execution.mode = activeRun.provider || "local-codex";
            const credentials = execution.mode === "company" && !activeRun ? sharedApi.read() : null;
            if (credentials) requireValue(credentials.baseUrl && credentials.apiKey, "请先在设置 → 共享 API 配置公司 API 地址和 Key");
            p = store.read(pid);
            e = e ? find(p.episodes, e.id) : null;
            if (
              b.advance &&
              ["synopsis", "storyboard"].includes(b.advance.targetType)
            ) {
              const adopted = e[b.advance.targetType];
              requireValue(
                adopted.acceptedVersionId === b.advance.versionId &&
                  latest(adopted)?.id === b.advance.versionId,
                "创作者又修改了正文，请先审核最新版本再继续",
              );
            }
            const settingIds = b.settingIds || [];
            settingIds.forEach((key) => {
              const setting = find(p.settings, key);
              requireValue(!setting.deletedAt || e?.settingPins.some((pin) => pin.settingId === key), "所选设定已删除，请刷新后重选");
              if (e && !e.settingPins.some((x) => x.settingId === key))
                fail("本集未固定该设定");
            });
            const referenceIds = [...new Set(b.referenceIds || [])];
            requireValue(
              referenceIds.length + (b.assetReferences?.length || 0) + (b.clipReferences?.length || 0) <= 100,
              "本轮选择的素材过多，请分批发送",
            );
            const references = referenceIds.map((key) =>
              find(p.references, key),
            );
            const assetReferences = (b.assetReferences || []).map((ref) => {
              const asset = find(p.assets, ref.assetId),
                version = find(asset.versions, ref.versionId);
              requireValue(
                !asset.deletedAt && !version.deletedAt && version.media?.mime.startsWith("image/"),
                "所选图片已删除或不可用",
              );
              return {
                id: "asset-" + version.id,
                name: asset.name,
                note: "",
                source: { assetId: asset.id, versionId: version.id },
                media: version.media,
              };
            });
            references.push(...assetReferences);
            const clipReferences = (b.clipReferences || []).map(ref => {
              requireValue(e && b.stage === "video", "视频引用须在本集视频阶段使用");
              const clip = find(e.clips, ref.clipId);
              requireValue(!clip.deletedAt, "所选片段已删除，请刷新后重选");
              const version = ref.versionId ? find(clip.versions, ref.versionId) : null;
              requireValue(!version || (!version.deletedAt && version.media?.mime.startsWith("video/")), "所选视频已删除或不可用");
              return { clipId: clip.id, versionId: version?.id || null };
            });
            const session = {
              id: id("session"),
              sessionId: id("scope"),
              capability: crypto.randomBytes(32).toString("hex"),
              projectId: pid,
              role,
              episodeId: e?.id || null,
              stage: b.stage,
              settingIds,
              referenceIds,
              assetReferences: assetReferences.map((r) => r.source),
              clipReferences,
              targetIds: b.targetIds || [],
              documentPatchBase: store.documentPatchBase(p, { episodeId: e?.id, stage: b.stage }),
              inputVersions: e
                ? Object.fromEntries(
                    (b.stage === "synopsis" ? ["synopsis"] : b.stage === "storyboard" ? ["synopsis", "storyboard"] : ["storyboard"]).map((name) => [
                      name,
                      {
                        currentVersionId: latest(e[name])?.id,
                        acceptedVersionId: e[name].acceptedVersionId,
                      },
                    ]),
                  )
                : null,
            };
            if (activeRun) {
              const previousSession = sessions.get(activeRun.sessionId) || [...sessions.values()].find(s =>
                !s.revokedAt && s.projectId === pid && s.episodeId === session.episodeId && s.stage === session.stage);
              // A running conversation keeps access to earlier attachments. A new capability
              // makes stale tool calls re-read the appended scope and current document versions.
              if (previousSession) {
                for (const key of ["settingIds", "referenceIds", "targetIds"])
                  session[key] = [...new Set([...(previousSession[key] || []), ...session[key]])];
                for (const key of ["assetReferences", "clipReferences"])
                  session[key] = [...new Map([...(previousSession[key] || []), ...session[key]].map(ref => [JSON.stringify(ref), ref])).values()];
              }
            }
            sessions.set(session.id, session);
            saveSessions();
            const promptSnapshot = prompts.snapshot();
            const stagePrompt = promptSnapshot.forStage(b.stage);
            const promptsRoot = activeRun?.promptsRoot || promptSnapshot.root;
            const previousRun = p.agentRuns?.[runKey];
            const sameProvider = (previousRun?.provider || "local-codex") === execution.mode;
            // Setting threads and v2 production threads already have a known stage.
            // Resume those on upgrade; never reuse an older mixed production thread.
            const compatibleLegacy = previousRun &&
              (previousRun.contextVersion === 2 || (!e && !previousRun.contextVersion)) &&
              (!previousRun.promptRevision || previousRun.promptRevision === promptSnapshot.revision);
            const auraId = activeRun ? activeRun.auraId :
              !b.freshSession &&
              !previousRun?.stopRequestedAt &&
              sameProvider &&
              previousRun?.stage === b.stage &&
              ((previousRun.contextVersion === 4 && previousRun.promptRevision === stagePrompt.revision) || compatibleLegacy)
                ? previousRun.auraId
                : id("drama-" + b.stage);
            const continued = execution.mode === "local-codex" ? auraId === previousRun?.auraId : !!activeRun || (!b.freshSession && auraId === previousRun?.auraId && companyController.canResume(auraId, execution, credentials));
            const previousState = continued ? sessions.get(previousRun?.sessionId)?.inputState : null;
            const inheritedState = previousState?.version === 1 && previousState.auraId === auraId ? structuredClone(previousState) : null;
            session.inputState = inheritedState || { version: 1, auraId, known: {}, images: [] };
            const documents = documentSnapshot(p, session);
            const notice = changeNotice(p.agentConversations[runKey]?.seenDocuments, documents);
            const messageText = String(b.message || "请推进当前阶段，准备好后等待用户审核。");
            session.historyStartIndex = b.freshSession ? p.agentConversations[runKey]?.messages.length || 0 : p.agentConversations[runKey]?.historyStartIndex || 0;
            const history = discussionHistory(discussionMessages(p.agentConversations[runKey], session.historyStartIndex));
            const turnText = (notice ? notice + "\n\n" : "") + messageText + (b.advance
              ? "\n创作者刚刚采用了版本 " + b.advance.versionId + "。已切换到当前可继续的阶段，请直接推进下一项工作；先核对 context.reviewHandoff 和最新采用正文。" : "");
            const fullContext = store.context(p, session),
              stagePath =
                role === "production"
                  ? path.join(promptsRoot, "stages", b.stage + ".md")
                  : null;
            let visualInputs = { references, sheets: [] };
            try { visualInputs = await agentImageSheets(p, session, path.dirname(store.file(pid)), references); }
            catch { /* Optional local previews must not prevent starting the requested work. */ }
            checkCurrent();
            session.imageSheets = visualInputs.sheets;
            const seenImages = new Set(session.inputState.images);
            visualInputs.references = visualInputs.references.filter(ref => !seenImages.has(ref.media.path));
            const attachedImages = new Set(visualInputs.references.map(ref => ref.media.path));
            fullContext.imageSheets = visualInputs.sheets.filter(sheet => attachedImages.has(sheet.mediaPath));
            const context = incrementalContext(fullContext, inheritedState);
            context.selected = Object.fromEntries(Object.entries({ settingIds, referenceIds,
              assetReferences: b.assetReferences || [], clipReferences: b.clipReferences || [], targetIds: b.targetIds || [] }).filter(([, values]) => values.length));
            rememberContext(session.inputState, fullContext);
            session.inputState.images = [...new Set([...seenImages, ...attachedImages])];
            saveSessions();
            const manifest = inputManifest(stagePrompt.manifest, context, continued ? [] : history,
              execution.mode === "local-codex" && !!previousRun && !continued, fullContext);
            manifest.history.continued = continued;
            const imagePreviews = await Promise.all(visualInputs.references.map(ref => ref.media.path.startsWith("media/agent-sheet-") ? ref.media : imagePreview(path.dirname(store.file(pid)), ref.media).catch(() => ref.media)));
            checkCurrent();
            const input = [
              {
                type: "text",
                text:
                  turnText +
                  (execution.mode === "local-codex" && auraId !== previousRun?.auraId && history.length
                    ? "\n\n[本环节先前讨论；作品以当前工作台文档为准]\n" + JSON.stringify(history.map(({ role, text }) => ({ role, text }))) : "") +
                  "\n\n[Trusted workbench scope]\n" +
                  JSON.stringify({
                    auraId,
                    cli: path.join(__dirname, "cli.cjs"),
                    server: base,
                    projectDir: path.dirname(store.file(pid)),
                    session: session.id,
                    capability: session.capability,
                    inputPolicy: incrementalPolicy + "相同版本无需重读；仅缺项、409 冲突或核对保存结果时按需读取。acceptedIsCurrent 表示采用正文就是 current。较早讨论可用 history 按关键词或消息 ID 查询；不要猜测历史决定。",
                    promptsRoot,
                    ...(context.delivery !== "delta" ? {
                      loadedPrompts: stagePrompt.manifest,
                      stageFile: stagePath,
                      assetNamingFile: path.join(promptsRoot, "asset-naming.md"),
                    } : {}),
                    context,
                  }),
              },
              ...imagePreviews.map((media) => ({
                type: "localImage",
                path: path.join(path.dirname(store.file(pid)), media.path),
              })),
            ];
            if (visualInputs.references.length)
              input[0].text +=
                "\n\n本轮图片按下列顺序附上：\n" +
                visualInputs.references
                  .map(
                    (r, i) =>
                      i + 1 + ". " + r.name + (r.note ? " — " + r.note : ""),
                  )
                  .join("\n");
            if (clipReferences.length)
              input[0].text += "\n\n视频引用及具体版本见 context.references；未生成项引用当前计划。视频文件未直接提供画面，需要查看成片时读取对应 mediaPath。";
            const execute = (verb, input) => controllerOperation(session, verb, verb === "apply" ? { ...input, requestId: input.requestId || id("api-write") } : input);
            const companyInput = {
              text: turnText + (visualInputs.references.length ? "\n本轮图片顺序：\n" + visualInputs.references.map((r, i) => (i + 1) + ". " + r.name + (r.note ? " — " + r.note : "")).join("\n") : ""),
              context, references: visualInputs.references.map((ref, i) => ({ ...ref, media: imagePreviews[i] })), projectDir: path.dirname(store.file(pid)), execute,
            };
            const companyTurn = execution.mode === "company" && !activeRun ? companyController.prepare({
              settings: execution, credentials, instructions: stagePrompt.apiInstructions, history,
              conversationId: auraId,
              ...companyInput,
              finish: snapshot => store.activity(pid, doc => {
                const run = doc.agentRuns?.[runKey];
                if (run?.turnId !== companyTurn.turnId || run.stopRequestedAt) return false;
                Object.assign(run, { status: snapshot.status === "active" ? "running" : snapshot.status, error: snapshot.error?.message || null });
                if (snapshot.terminal) run.finishedAt = new Date().toISOString();
                recordReply(doc, runKey, run, snapshot);
              }),
            }) : null;
            const started = execution.mode === "company" && activeRun ? companyController.steer(activeRun, companyInput)
              : companyTurn ? { turnId: companyTurn.turnId, threadId: companyTurn.threadId }
              : await bridgeCall("auras/" + auraId + "/turn", {
              requestId,
              profile: "drama-" + role,
              input,
              mode: "auto",
              ...(!activeRun ? {
                ...(execution.reasoningEffort !== "inherit" ? { reasoningEffort: execution.reasoningEffort } : {}),
                completeDramaInstructions: true,
                developerInstructions: stagePrompt.instructions,
              } : {}),
            });
            if (!stillCurrent()) {
              sessions.delete(session.id);
              saveSessions();
              if (!companyTurn) interruptAgent({ ...started, auraId }).catch(() => {});
              checkCurrent();
            }
            for (const [key, old] of sessions)
              if (
                key !== session.id &&
                old.projectId === pid &&
                old.episodeId === session.episodeId &&
                old.stage === session.stage
              )
                sessions.delete(key);
            saveSessions();
            store.activity(pid, (doc) => {
              doc.agentRuns = doc.agentRuns || {};
              doc.agentRuns[runKey] = {
                auraId,
                provider: execution.mode,
                model: activeRun?.model || (execution.mode === "company" ? execution.companyModel : "local-codex/app-server"),
                contextVersion: 4,
                inputManifest: manifest,
                threadTurnCount: auraId === previousRun?.auraId ? (previousRun.threadTurnCount || 1) + 1 : 1,
                threadInputCharacters: (auraId === previousRun?.auraId ? previousRun.threadInputCharacters || 0 : 0) + input[0].text.length,
                promptRevision: activeRun?.promptRevision || stagePrompt.revision,
                promptsRoot,
                sessionId: session.id,
                turnId: started.turnId,
                threadId: started.threadId,
                stage: b.stage,
                status: "running",
                error: null,
                startedAt: activeRun?.turnId === started.turnId ? activeRun.startedAt : new Date().toISOString(),
                referenceIds: session.referenceIds,
                advanceKey: advanceKey || activeRun?.advanceKey || null,
              };
              const chat = conversation(doc, runKey);
              if (b.freshSession) chat.historyStartIndex = session.historyStartIndex;
              if (notice) chat.messages.push({ id: "notice-" + requestId, turnId: started.turnId, role: "notice", text: notice });
              chat.messages.push({ id: "user-" + requestId, requestId, turnId: started.turnId, role: "user", text: messageText,
                references: [...references, ...clipReferences.map(ref => {
                  const clip = find(e.clips, ref.clipId), version = clip.versions.find(v => v.id === ref.versionId);
                  return { name: clip.title, source: ref, media: version?.media || null };
                })] });
              chat.seenDocuments = documents;
            });
            companyTurn?.launch();
            const startedProject = store.read(pid);
            return json(res, 200, {
              ...started,
              auraId,
              sessionId: session.id,
              stage: b.stage,
              revision: startedProject.revision,
              activityRevision: startedProject.activityRevision || 0,
              run: startedProject.agentRuns[runKey],
              conversation: { messages: startedProject.agentConversations[runKey].messages },
            });
          } finally {
            if (stillCurrent()) startingTurns.delete(lockKey);
            if (sourceLockKey) startingTurns.delete(sourceLockKey);
          }
        }
        if (action === "agent-events" && req.method === "GET") {
          const eid = url.searchParams.get("episodeId");
          if (eid) find(p.episodes, eid);
          const stage = url.searchParams.get("stage");
          const key = agentKey(eid, stage);
          const state = await agentState(pid, eid, stage);
          const current = store.read(pid);
          const revision = current.revision, activityRevision = current.activityRevision || 0;
          const messageUpdate = projectSync.messages(current, key, url.searchParams.get("messagesSince"), projectSync.tag(pid));
          if (!state.run?.turnId)
            return json(res, 200, { ...state, revision, activityRevision, ...messageUpdate, events: [], nextEventId: 0 });
          const auraId = state.run.auraId;
          const response = state.run.provider === "company" ? { events: [], nextEventId: 0 } : await bridgeCall(
            "events?auraId=" +
              auraId +
              "&after=" +
              (Number(url.searchParams.get("after")) || 0),
          );
          return json(res, 200, { ...response, ...state, revision, activityRevision, ...messageUpdate });
        }
        if (action === "agent-reset" && req.method === "POST") {
          const b = await jsonBody(req);
          if (b.episodeId) find(p.episodes, b.episodeId);
          const key = agentKey(b.episodeId, b.stage), lockKey = pid + "/" + key;
          const run = store.read(pid).agentRuns?.[key];
          agentEpochs.set(lockKey, (agentEpochs.get(lockKey) || 0) + 1);
          startingTurns.delete(lockKey);
          revokeAgentScope(pid, key);
          store.activity(pid, doc => {
            delete doc.agentRuns[key];
            const chat = conversation(doc, key);
            chat.seenDocuments = null;
            chat.historyStartIndex = chat.messages.length;
          });
          // Reset is local and immediate even when the execution connection is broken.
          if (run?.turnId) interruptAgent(run).catch(() => {});
          const current = store.read(pid);
          return json(res, 200, { run: null, revision: current.revision, activityRevision: current.activityRevision || 0 });
        }
        if (action === "agent-stop" && req.method === "POST") {
          const b = await jsonBody(req);
          if (b.episodeId) find(p.episodes, b.episodeId);
          const key = agentKey(b.episodeId, b.stage);
          const lockKey = pid + "/" + key;
          requireValue(!startingTurns.has(lockKey), "Agent 正在启动或停止，请稍候");
          startingTurns.add(lockKey);
          const stopEpoch = agentEpochs.get(lockKey) || 0;
          try {
          const activeRun =
            store.read(pid).agentRuns?.[key];
          requireValue(activeRun?.auraId, "没有正在运行的 Agent");
          requireValue(!b.turnId || b.turnId === activeRun.turnId, "Agent 已开始新一轮，请刷新后再停止");
          revokeAgentScope(pid, key);
          store.activity(pid, doc => Object.assign(doc.agentRuns[key], {
            status: "stopping", stopRequestedAt: new Date().toISOString(), error: null,
          }));
          let stopped, interruptError;
          try { stopped = await interruptAgent(activeRun); }
          catch (error) { interruptError = error.message; }
          store.activity(pid, (doc) => {
            const run = doc.agentRuns?.[key];
            if (run?.turnId === activeRun.turnId)
              Object.assign(run, {
                status: interruptError ? "stop_failed" : "interrupted",
                error: interruptError ? "停止未确认：" + interruptError + "。可重置 Agent 后继续。" : null,
                finishedAt: new Date().toISOString(),
              });
            else return false;
          });
          const current = store.read(pid);
          return json(res, 200, { ...stopped, run: current.agentRuns[key] || null, revision: current.revision, activityRevision: current.activityRevision || 0 });
          } finally { if ((agentEpochs.get(lockKey) || 0) === stopEpoch) startingTurns.delete(lockKey); }
        }
        fail("未知项目操作", "not_found", 404);
      }
      const downloads = route.match(/^\/downloads\/(project-[a-f0-9-]+)\/(episode-[a-f0-9-]+)$/);
      if (downloads && req.method === "GET") {
        const project = store.read(downloads[1]);
        const selections = (url.searchParams.get("items") || "").split(",").filter(Boolean).map(value => {
          const [clipId, versionId] = value.split(":");
          return { clipId, versionId };
        });
        const files = clipDownloads(store, project, downloads[2], selections);
        if (files.length === 1) return sendFile(res, files[0].file, files[0].mime, true, files[0].name);
        return await sendClipZip(res, files, filename(project.title) + "_第" + find(project.episodes, downloads[2]).number + "集_视频片段.zip");
      }
      // Media is local, opaque project/id URLs; no arbitrary filesystem path routes.
      const media = route.match(
        /^\/media\/(project-[a-f0-9-]+)\/([a-zA-Z0-9._-]+)$/,
      );
      if (media && url.searchParams.has("thumb") && !url.searchParams.has("download")) {
        const mime = mimeTypes[path.extname(media[2]).toLowerCase()];
        if (/^image\/(png|jpeg|webp)$/.test(mime)) {
          const projectDir = path.dirname(store.file(media[1]));
          const preview = await imagePreview(projectDir, { path: "media/" + media[2], mime }, "thumb");
          return sendFile(res, path.join(projectDir, preview.path), preview.mime, false, null, req);
        }
      }
      if (media) {
        const file = path.join(path.dirname(store.file(media[1])), "media", media[2]);
        if (url.searchParams.has("poster") && /\.(mp4|mov|webm)$/i.test(media[2])) {
          requireValue(fs.existsSync(file), "文件不存在");
          try { return sendFile(res, await videoPoster(file), "image/jpeg", false, media[2], req); }
          catch {
            // A damaged clip or unavailable decoder must not leave a broken image.
            res.writeHead(200, { "Content-Type": "image/svg+xml", "Cache-Control": "no-store" });
            return res.end('<svg xmlns="http://www.w3.org/2000/svg" width="480" height="270" viewBox="0 0 480 270"><rect width="480" height="270" fill="#272c28"/><path d="M222 113v44l38-22z" fill="#9da79b"/></svg>');
          }
        }
        return sendFile(res, file, null, url.searchParams.has("download"), media[2], req);
      }
      if (route === "/media-viewer") {
        const html = mediaViewerPage();
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-cache" });
        return res.end(html);
      }
      if (route === "/canvas") {
        const html = fs
          .readFileSync(path.join(runtimeRoot, "Auralis.html"), "utf8")
          .replace(
            "</body>",
            '<script src="/canvas.js"></script><script src="/media-viewer.js"></script></body>',
          );
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        return res.end(html);
      }
      const files = {
        "/": "index.html",
        "/index.html": "index.html",
        "/app.js": "app.js",
        "/text-annotations.js": "text-annotations.js",
        "/media-references.js": "media-references.js",
        "/update-reminder.js": "update-reminder.js",
        "/asset-board.js": "asset-board.js",
        "/video-board.js": "video-board.js",
        "/voice-board.js": "voice-board.js",
        "/canvas-bridge.js": "canvas-bridge.js",
        "/clip-canvas.js": "clip-canvas.js",
        "/production-updates.js": "production-updates.js",
        "/production-status.js": "production-status.js",
        "/style.css": "style.css",
        "/preferences.js": "preferences.js",
        "/service-health.js": "service-health.js",
        "/canvas.js": "canvas.js",
        "/media-viewer.js": "media-viewer.js",
        "/media-review.js": "media-review.js",
      };
      if (files[route])
        return sendFile(res, files[route] === "index.html" && process.env.AURALIS_DRAMA_HTML ? process.env.AURALIS_DRAMA_HTML : path.join(__dirname, files[route]));
      if (
        /^\/(assets|src)\/[a-zA-Z0-9_/. -]+$/.test(route) &&
        !route.includes("..")
      )
        return sendFile(res, path.join(runtimeRoot, route.slice(1)));
      fail("未找到", "not_found", 404);
    } catch (e) {
      if (res.headersSent) { res.destroy(e); return; }
      json(res, e.status || 500, {
        error: { code: e.code || "error", message: e.message },
      });
    }
  });
  return {
    server,
    store,
    provider,
    voices,
    descriptions,
    async listen() {
      await new Promise((resolve) => server.listen(port, "127.0.0.1", resolve));
      base = "http://127.0.0.1:" + server.address().port;
      if (options.runBackups !== false) backups.start();
      if (options.runJobs !== false) provider.start();
      if (options.runJobs !== false) voices.start();
      if (options.runDescriptions ?? (options.runJobs !== false)) descriptions.start();
      if (options.runAgentPolling !== false) {
        agentTimer = setInterval(() => {
          if (agentPoll) return;
          agentPoll = (async () => {
            const pending = [];
            for (const projectId of store.pendingProjectIds("agents")) {
              const project = store.read(projectId);
              for (const [key, run] of Object.entries(project.agentRuns)) {
                if (run.status !== "running") continue;
                const episodeId = key === "setting" ? null : key.split("/")[0];
                pending.push([projectId, episodeId, run.stage]);
              }
            }
            // One slow bridge read should not hold up every other agent. Limit
            // background concurrency; individual failures do not stop the queue.
            let cursor = 0;
            await Promise.all(Array.from({ length: Math.min(3, pending.length) }, async () => {
              while (cursor < pending.length) await agentState(...pending[cursor++]).catch(() => {});
            }));
          })().catch(() => {}).finally(() => { agentPoll = null; });
        }, 2500);
        agentTimer.unref();
      }
      return base;
    },
    async close() {
      clearImmediate(jobsScheduled);
      clearInterval(agentTimer);
      if (agentPoll) await agentPoll;
      backups.stop();
      provider.stop();
      await voices.stop();
      await descriptions.stop();
      await companyController.close();
      store.close();
      if (bridge) await bridge.close();
      await new Promise((resolve) => server.close(resolve));
    },
  };
}
if (require.main === module) {
  const app = createWorkbench();
  app.listen().then((url) => console.log("Auralis 短剧工作台 " + url));
  for (const signal of ["SIGINT", "SIGTERM"])
    process.once(signal, () => app.close().finally(() => process.exit()));
}
module.exports = { createWorkbench };
