const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const { id, find, latest, requireValue, fail } = require('./store.cjs');
const { scopeKey, documentSnapshot } = require('./conversations.cjs');
const { applyTextEdits } = require('./document-edits.cjs');
const { usesResponses, requestBody, responseChoice, reasoningEffort } = require('./controller-transport.cjs');
const { requestResponse } = require('./controller-stream.cjs');
const { operationProperties } = require('./operation-schema.cjs');

const stages = ['setting', 'synopsis', 'storyboard', 'assets', 'video'];
const names = { setting: '共享设定', synopsis: '梗概', storyboard: '文字分镜', assets: '资产提示词', video: '视频提示词与参考' };
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const clone = value => structuredClone(value);
const tool = (name, description, properties, required) => ({ type: 'function', function: { name, description,
  parameters: { type: 'object', properties, required, additionalProperties: false } } });
const preferenceTool = tool('submit_preferences', '提交从用户原话提取的偏好。区分明确要求和推测；保留适用范围、后续修正和矛盾，引用消息 ID。', {
  preferences: { type: 'array', items: { type: 'object', properties: {
    text: { type: 'string' }, kind: { type: 'string', enum: ['explicit', 'inferred'] },
    sources: { type: 'array', items: { type: 'string' } },
  }, required: ['text', 'kind', 'sources'], additionalProperties: false } },
}, ['preferences']);
const reviewTool = tool('submit_review', '将建议交给专用对照编辑器，尚不写回作品。每条独立、可直接采纳；没有必要修改时 changes 为空。', {
  summary: { type: 'string' },
  advice: { type: 'string', description: '无法直接修改的建议，例如新制作参考图、补生成素材。写成可复制给对应环节 Agent 的独立请求，交代目标、位置、原因和已知素材；没有则空串。不要在 changes 中虚构不存在的素材。' },
  changes: { type: 'array', maxItems: 100, items: { type: 'object', properties: {
    targetId: { type: 'string', description: 'editableContent 中的真实 targetId，只可改这些正文。' },
    reason: { type: 'string', description: '指出具体问题、观众影响和改法，不为空泛建议。' },
    oldText: { type: 'string', description: '逐字摘录唯一原文，带足定位上下文；不得与其他建议重叠。仅空正文可填空串。refs 修改必须同步改提示词时，可同时给出该资产/片段提示词的 oldText/newText，作为同一条建议原子采纳。' },
    newText: { type: 'string', description: '文字修改：完整替换文本；空串删除这一段。' },
    refs: { ...operationProperties(['planClip']).refs, description: '参考修改：修改后的完整列表，可新增、删除、替换。只能使用 referenceCatalog 中的确切来源；沿用其 ref 字段。' },
    dependsOn: { type: 'array', items: { type: 'string' }, description: '依赖修改：完整的本集前序片段 ID 列表。' },
  }, required: ['targetId', 'reason'], additionalProperties: false } },
}, ['summary', 'advice', 'changes']);

function userMessages(project) {
  return Object.entries(project.agentConversations || {}).flatMap(([scope, chat]) =>
    (chat.messages || []).flatMap((message, index) => message.role === 'user' && typeof message.text === 'string' && message.text.trim()
      ? [{ id: scope + '/' + (message.id || index), scope, messageIndex: index, text: message.text, createdAt: message.createdAt || null }] : []));
}
function reviewInput(project, scope, store) {
  const e = scope.episodeId ? find(project.episodes, scope.episodeId) : null, targets = [];
  const add = (targetId, title, kind, value, binding) => targets.push({ targetId, title, kind, value: clone(value), binding });
  if (scope.stage === 'setting') for (const s of project.settings.filter(s => !s.deletedAt))
    add('setting/' + s.id, s.title, 'text', latest(s)?.text || '', { type: 'setting', id: s.id });
  if (['synopsis', 'storyboard'].includes(scope.stage))
    add(scope.stage, '第 ' + e.number + ' 集 · ' + names[scope.stage], 'text', latest(e[scope.stage])?.text || '', { type: scope.stage });
  if (scope.stage === 'assets') for (const a of project.assets.filter(a => !a.deletedAt && e.assetRefs.some(r => r.assetId === a.id))) {
    if (['audio', 'video'].includes(a.kind)) continue;
    add('asset/' + a.id + '/prompt', a.name + ' · 提示词', 'text', a.prompt || '', { type: 'asset', id: a.id });
    add('asset/' + a.id + '/refs', a.name + ' · 参考', 'refs', a.refs || [], { type: 'asset', id: a.id });
  }
  if (scope.stage === 'video') for (const c of e.clips.filter(c => !c.deletedAt)) {
    add('clip/' + c.id + '/prompt', c.title + ' · 提示词', 'text', c.plan.prompt, { type: 'clip', id: c.id });
    add('clip/' + c.id + '/refs', c.title + ' · 参考', 'refs', c.plan.refs, { type: 'clip', id: c.id });
    add('clip/' + c.id + '/dependsOn', c.title + ' · 前序依赖', 'dependsOn', c.plan.dependsOn || [], { type: 'clip', id: c.id });
  }
  const referenceCatalog = [];
  if (['assets', 'video'].includes(scope.stage)) {
    for (const asset of project.assets.filter(a => !a.deletedAt)) for (const v of asset.versions.filter(v => !v.deletedAt && v.media)) {
      const role = v.media.mime.split('/')[0];
      if (!['image', 'audio', 'video'].includes(role) || (scope.stage === 'assets' && role !== 'image')) continue;
      const pinned = e.assetRefs.some(r => r.assetId === asset.id && r.versionId === v.id);
      referenceCatalog.push({ name: asset.name, version: asset.versions.indexOf(v) + 1, pinned,
        description: store.imageDescription?.(project.id, v) || asset.description || '',
        ref: { assetId: asset.id, versionId: v.id, role, ...(!pinned ? { referenceOnly: true } : {}), ...(asset.purpose ? { purpose: asset.purpose } : {}) } });
    }
    for (const episode of project.episodes) for (const c of episode.clips.filter(c => !c.deletedAt))
      for (const v of c.versions.filter(v => !v.deletedAt && v.media?.mime.startsWith('video/'))) {
        const item = { name: '第 ' + episode.number + ' 集 · ' + c.title, version: c.versions.indexOf(v) + 1 };
        if (scope.stage === 'video') referenceCatalog.push({ ...item, ref: { clipId: c.id, versionId: v.id, role: 'video' } });
        referenceCatalog.push({ ...item, name: item.name + ' · 尾帧', ref: { clipId: c.id, versionId: v.id, frame: 'last', role: 'image' } });
      }
  }
  const documents = documentSnapshot(project, scope);
  // Bodies appear only in editableContent, not conflated with read-only background.
  for (const target of targets) {
    const binding = target.binding;
    if (binding.type === 'setting') delete documents['setting/' + binding.id];
    else if (['synopsis', 'storyboard'].includes(binding.type)) delete documents[binding.type];
    else if (binding.type === 'asset') delete documents['asset-plan/' + binding.id];
    else delete documents['clip/' + binding.id];
  }
  return { targets, projectContext: { project: { title: project.title, premise: project.premise }, documents,
    episode: e ? { id: e.id, number: e.number, title: e.title, bindings: e.bindings, settingPins: e.settingPins } : null,
    plans: scope.stage === 'video' ? e.clips.filter(c => !c.deletedAt).map(c => { const { prompt, refs, dependsOn, ...parameters } = c.plan; return { id: c.id, title: c.title, parameters }; }) : [],
    referenceCatalog }, referenceCatalog };
}
function targetState(project, scope, target) {
  const b = target.binding, e = scope.episodeId ? find(project.episodes, scope.episodeId) : null;
  if (b.type === 'setting') { const s = find(project.settings, b.id); return { deleted: !!s.deletedAt, version: latest(s)?.id, value: latest(s)?.text || '' }; }
  if (['synopsis', 'storyboard'].includes(b.type)) return { version: latest(e[b.type])?.id, value: latest(e[b.type])?.text || '',
    ...(b.type === 'storyboard' ? { synopsis: e.synopsis.acceptedVersionId } : {}) };
  const entity = b.type === 'asset' ? find(project.assets, b.id) : find(e.clips, b.id), plan = b.type === 'asset' ? entity : entity.plan;
  return { deleted: !!entity.deletedAt, member: b.type !== 'asset' || e.assetRefs.some(r => r.assetId === b.id),
    value: clone(target.kind === 'refs' ? plan.refs || [] : target.kind === 'dependsOn' ? plan.dependsOn || [] : plan.prompt || '') };
}
function normalizeChanges(result, input) {
  requireValue(typeof result.summary === 'string' && Array.isArray(result.changes) && result.changes.length <= 100, '审查结果格式无效');
  return result.changes.map((change, index) => {
    requireValue(change && typeof change === 'object' && !Array.isArray(change), '审查建议格式无效');
    const target = input.targets.find(t => t.targetId === change.targetId);
    requireValue(target && typeof change.reason === 'string' && change.reason.trim(), '审查建议没有有效的正文位置或原因');
    const item = { id: String(index + 1), targetId: target.targetId, kind: target.kind, title: target.title, reason: change.reason, status: 'pending' };
    if (target.kind === 'text') {
      requireValue(typeof change.oldText === 'string' && typeof change.newText === 'string', '文字建议须提供原文和改文');
      if (target.value) applyTextEdits(target.value, [change]);
      else requireValue(change.oldText === '' && change.newText.trim(), '空正文须提供完整新稿');
      return { ...item, before: change.oldText, after: change.newText };
    }
    const after = change[target.kind];
    requireValue(Array.isArray(after) && !same(after, target.value), '参考或依赖建议须提供变更后的完整列表');
    if (target.kind === 'refs' && (change.oldText !== undefined || change.newText !== undefined)) {
      const textTarget = input.targets.find(t => t.kind === 'text' && same(t.binding, target.binding));
      requireValue(textTarget && typeof change.oldText === 'string' && typeof change.newText === 'string', '关联提示词修改须提供有效原文和改文');
      if (textTarget.value) applyTextEdits(textTarget.value, [change]);
      else requireValue(change.oldText === '' && change.newText.trim(), '空提示词须提供完整新稿');
      Object.assign(item, { textTargetId: textTarget.targetId, oldText: change.oldText, newText: change.newText });
    }
    return { ...item, before: clone(target.value), after: clone(after) };
  });
}
function prepareReview(result, input) {
  requireValue(typeof result.summary === 'string' && typeof result.advice === 'string' && Array.isArray(result.changes) && result.changes.length <= 100, '审查结果格式无效');
  const changes = [], unappliedChanges = [];
  for (const [index, change] of result.changes.entries()) {
    try {
      const [item] = normalizeChanges({ ...result, changes: [change] }, input);
      changes.push({ ...item, id: String(changes.length + 1) });
    } catch (error) {
      if (!['invalid', 'document_conflict'].includes(error.code)) throw error;
      unappliedChanges.push({ index: index + 1, error: error.message, change });
    }
  }
  const notes = unappliedChanges.map(({ index, error, change }) => ['第 ' + index + ' 条建议未能直接替换：' + error,
    change?.reason, typeof change?.oldText === 'string' ? '模型引用的原文：\n' + change.oldText : '',
    typeof change?.newText === 'string' ? '模型建议的改文：\n' + change.newText : ''].filter(Boolean).join('\n'));
  return { changes, unappliedChanges, advice: [result.advice, ...notes].filter(Boolean).join('\n\n') };
}

class RelayReview {
  constructor({ store, controller, settings, credentials, prompts }) {
    Object.assign(this, { store, controller, settings, credentials, prompts }); this.active = new Map(); this.applying = new Set();
  }
  scope(input) {
    requireValue(stages.includes(input.stage) && (input.stage === 'setting' ? !input.episodeId : typeof input.episodeId === 'string' && !!input.episodeId), '审查环节无效');
    return { stage: input.stage, episodeId: input.episodeId || null };
  }
  key(pid, scope) { return pid + '/' + scopeKey(scope.episodeId, scope.stage); }
  file(pid, scope) {
    const hash = crypto.createHash('sha256').update(scopeKey(scope.episodeId, scope.stage)).digest('hex');
    return path.join(path.dirname(this.store.file(pid)), 'relay-reviews', hash + '.json');
  }
  save(pid, run) {
    const file = this.file(pid, run.scope); fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file + '.tmp', JSON.stringify(run), 'utf8'); fs.renameSync(file + '.tmp', file);
  }
  read(pid, scope) {
    const file = this.file(pid, scope); if (!fs.existsSync(file)) return null;
    const run = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (['summarizing', 'reviewing'].includes(run.status) && !this.active.has(this.key(pid, scope))) {
      run.status = 'interrupted'; run.error = '服务已重启，本次审查已停止。'; this.save(pid, run);
    }
    // Recover an apply that committed just before shutdown, without duplicating it.
    if (run.applying) {
      const project = this.store.read(pid), pending = run.applying, item = run.changes.find(c => c.id === pending.itemId);
      if (project.receipts[pending.requestId]) {
        item.status = 'accepted'; item.after = pending.after;
        if (pending.newText !== undefined) item.newText = pending.newText;
        this.refreshBases(run, project, item);
      }
      delete run.applying; this.save(pid, run);
    }
    return run;
  }
  view(run) {
    if (!run) return null;
    const { bases, applying, ...visible } = run; return visible;
  }
  async request(model, credentials, instructions, payload, outputTool, abort, images = [], onUpdate = () => {}) {
    const startedAt = Date.now();
    const endpoint = new URL(credentials.baseUrl.replace(/\/+$/, '') + (usesResponses(model) ? '/responses' : '/chat/completions'));
    requireValue(['https:', 'http:'].includes(endpoint.protocol), '公司 API 地址无效');
    const messages = [{ role: 'system', content: instructions }, { role: 'user', content: [
      { type: 'text', text: JSON.stringify(payload) }, ...images,
    ] }];
    const body = requestBody(model, messages, [outputTool]);
    body.tool_choice = usesResponses(model) ? { type: 'function', name: outputTool.function.name }
      : { type: 'function', function: { name: outputTool.function.name } };
    const { response, data } = await requestResponse(this.controller.request.bind(this.controller), endpoint, { method: 'POST', headers: { Authorization: 'Bearer ' + credentials.apiKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...body, stream: true }), signal: abort.signal }, async () => {}, onUpdate).finally(() => onUpdate.flush?.());
    abort.signal.throwIfAborted();
    requireValue(response.ok, '公司 API：' + (data.error?.message || 'HTTP ' + response.status));
    const choice = responseChoice(model, data);
    requireValue(choice && !choice.error && choice.finish_reason !== 'length', choice?.error || '审查响应不完整，请重新发起审查');
    const calls = choice.message?.tool_calls || [];
    requireValue(calls.length === 1 && calls[0].function.name === outputTool.function.name, '模型未提交完整的结构化审查结果');
    try { return JSON.parse(calls[0].function.arguments); } catch (cause) {
      const error = new Error('模型返回的审查结果格式错误，原始结果已保留，正文未改动。');
      error.reviewResponse = { model, tool: outputTool.function.name, finishReason: choice.finish_reason,
        elapsedMs: Date.now() - startedAt, reasoningCharacters: choice.message.reasoning_content?.length || 0,
        parseError: cause.message, arguments: calls[0].function.arguments };
      throw error;
    }
  }
  start(pid, input) {
    const scope = this.scope(input), key = this.key(pid, scope), project = this.store.read(pid), model = input.model;
    requireValue(!this.active.has(key) && !this.applying.has(key), '这个环节正在审查或保存');
    const previous = this.read(pid, scope);
    requireValue(!previous?.changes?.some(c => c.status === 'pending'), '请先逐条处理上一轮建议，再开始新的审查');
    requireValue(this.settings.status().companyModels.includes(model), '请选择可用的审查模型');
    requireValue(typeof input.requirements === 'string' && input.requirements.length <= 20000, '额外要求最多 20000 字符');
    const credentials = clone(this.credentials());
    requireValue(credentials.baseUrl && credentials.apiKey, '请先在设置 → 共享 API 配置公司 API 地址和 Key');
    const packet = reviewInput(project, scope, this.store);
    requireValue(packet.targets.some(t => t.kind === 'text' && t.value.trim()), '当前环节还没有可审查的正文');
    const run = { id: id('relay'), scope, model, requirements: input.requirements, status: 'summarizing', createdAt: new Date().toISOString(),
      preferences: [], changes: [], summary: '', advice: '', targets: packet.targets, referenceCatalog: packet.referenceCatalog,
      dependencies: scope.stage === 'video' ? find(project.episodes, scope.episodeId).clips.filter(c => !c.deletedAt).map(c => ({ id: c.id, title: c.title })) : [],
      bases: Object.fromEntries(packet.targets.map(t => [t.targetId, targetState(project, scope, t)])) };
    const messages = userMessages(project); run.messageCount = messages.length;
    const snapshot = this.prompts.snapshot();
    const variables = { stageName: names[scope.stage], stageGuidance: snapshot.forStage(scope.stage).instructions };
    const instructions = { preferences: snapshot.text('relay/preferences.md'),
      review: snapshot.text('relay/review.md').replace(/\{\{(stageName|stageGuidance)\}\}/g, (_, key) => variables[key]) };
    run.promptRevision = snapshot.revision;
    const abort = new AbortController(), job = { abort, done: null };
    this.active.set(key, job); this.save(pid, run);
    job.done = this.run(pid, run, project, messages, packet, instructions, credentials, abort).catch(error => {
      if (error.reviewResponse) fs.writeFileSync(path.join(path.dirname(this.file(pid, scope)), run.id + '-failure.json'),
        JSON.stringify({ runId: run.id, scope, createdAt: new Date().toISOString(), ...error.reviewResponse }), 'utf8');
      run.status = abort.signal.aborted ? 'interrupted' : 'failed';
      run.finishedAt = new Date().toISOString();
      run.error = abort.signal.aborted ? '本次审查已停止，已完成的内容仍保留。' : error.name === 'TimeoutError' && !error.message.startsWith('模型连接')
        ? '模型连接超时，已收到的内容仍保留。' : String(error.message).replaceAll(credentials.apiKey, '[Key]');
      this.save(pid, run);
    }).finally(() => this.active.delete(key));
    job.done.catch(() => {});
    return this.view(run);
  }
  streamProgress(pid, run) {
    const stream = run.stream = { phase: 'waiting', effort: reasoningEffort(run.model), connectedAt: null,
      lastActivityAt: null, reasoning: '', text: '', preview: '', receivedCharacters: 0 };
    let argumentsText = '', lastSave = 0, pendingSave;
    const flush = () => { clearTimeout(pendingSave); pendingSave = null; stream.preview = previewArguments(argumentsText); this.save(pid, run); lastSave = Date.now(); };
    const update = (kind, delta) => {
      const now = new Date().toISOString(), previous = stream.phase;
      if (kind === 'connected') stream.connectedAt = now;
      else stream.lastActivityAt = now;
      if (delta) {
        stream.receivedCharacters += delta.length;
        stream.phase = kind === 'reasoning' ? 'thinking' : 'writing';
        if (kind === 'arguments') argumentsText += delta;
        else { const key = kind === 'reasoning' ? 'reasoning' : 'text'; stream[key] = (stream[key] + delta).slice(-16000); }
      }
      if (previous !== stream.phase || Date.now() - lastSave >= 500) flush();
      else if (!pendingSave) { pendingSave = setTimeout(flush, 500 - (Date.now() - lastSave)); pendingSave.unref?.(); }
    };
    update.flush = flush;
    return update;
  }
  async run(pid, run, project, messages, packet, instructions, credentials, abort) {
    const validIds = new Set(messages.map(m => m.id));
    {
      run.progress = '1/2 · 整理全部用户消息'; run.phaseStartedAt = new Date().toISOString();
      const update = this.streamProgress(pid, run); this.save(pid, run);
      const result = await this.request(run.model, credentials,
        instructions.preferences,
        { userMessages: messages }, preferenceTool, abort, [], update);
      requireValue(Array.isArray(result.preferences), '偏好总结格式无效');
      for (const p of result.preferences) {
        requireValue(typeof p.text === 'string' && p.text.trim() && ['explicit', 'inferred'].includes(p.kind) && Array.isArray(p.sources) && p.sources.length && p.sources.every(id => validIds.has(id)), '偏好总结缺少有效的用户消息依据');
        run.preferences.push({ text: p.text, kind: p.kind, sources: p.sources });
      }
    }
    run.status = 'reviewing'; run.progress = '2/2 · 审查' + names[run.scope.stage]; run.phaseStartedAt = new Date().toISOString();
    const update = this.streamProgress(pid, run); this.save(pid, run);
    let images = [];
    if (['assets', 'video'].includes(run.scope.stage)) {
      const projectDir = path.dirname(this.store.file(pid));
      try {
        const visuals = await require('./asset-images.cjs').agentImageSheets(project, { ...run.scope, targetIds: [] }, projectDir, []);
        images = visuals.references.map(r => require('./controller.cjs').imageContent(projectDir, r.media));
        packet.projectContext.imageSheets = visuals.sheets;
      } catch { packet.projectContext.imageNote = '本轮资产总览图不可用，仅依据正文、参考来源和已有描述审查，不声称看过画面。'; }
    }
    abort.signal.throwIfAborted();
    const result = await this.request(run.model, credentials,
      instructions.review,
      { userPreferences: run.preferences, extraRequirements: run.requirements, projectContext: packet.projectContext,
        editableContent: packet.targets.map(({ binding, ...target }) => target) }, reviewTool, abort, images, update);
    Object.assign(run, prepareReview(result, packet)); run.summary = result.summary; run.status = 'completed';
    run.finishedAt = new Date().toISOString(); delete run.progress; this.save(pid, run);
  }
  refreshBases(run, project, item) {
    for (const targetId of [item.targetId, item.textTargetId].filter(Boolean)) {
      const target = run.targets.find(t => t.targetId === targetId);
      run.bases[targetId] = targetState(project, run.scope, target);
    }
  }
  async decide(pid, input) {
    const scope = this.scope(input), key = this.key(pid, scope);
    requireValue(!this.applying.has(key), '建议正在保存，请稍候');
    this.applying.add(key);
    try {
      const run = this.read(pid, scope);
      requireValue(run?.id === input.runId && run.status === 'completed', '审查已更新，请重新打开');
      const item = run.changes.find(c => c.id === input.itemId);
      requireValue(item && ['accept', 'ignore'].includes(input.decision), '建议或处理方式无效');
      if (item.status !== 'pending') return this.view(run);
      if (input.decision === 'ignore') { item.status = 'ignored'; this.save(pid, run); return this.view(run); }
      const target = run.targets.find(t => t.targetId === item.targetId), project = this.store.read(pid);
      if (!same(targetState(project, scope, target), run.bases[target.targetId])) fail('这处正文已在审查后修改。建议已保留，请核对当前正文后忽略此条并重新审查。', 'review_conflict', 409);
      const after = input.after === undefined ? item.after : input.after, b = target.binding;
      const pairedTarget = item.textTargetId && run.targets.find(t => t.targetId === item.textTargetId);
      const pairedText = input.newText === undefined ? item.newText : input.newText;
      let value;
      if (item.kind === 'text') {
        requireValue(typeof after === 'string' && after.length <= 80000, '改文须为文本，最多 80000 字符');
        const body = run.bases[target.targetId].value;
        value = body ? applyTextEdits(body, [{ oldText: item.before, newText: after }]) : after;
      } else {
        if (!same(run.bases[target.targetId].value, item.before)) fail('此前采纳的建议已修改这个列表，请核对后忽略重叠建议。', 'review_conflict', 409);
        requireValue(Array.isArray(after) && after.length <= 100, '参考或依赖列表无效'); value = clone(after);
        if (item.kind === 'refs') for (const ref of value) {
          requireValue(run.referenceCatalog.some(c => sameRef(c.ref, ref)), '请从本轮参考目录选择确切的素材版本');
          requireValue(b.type !== 'clip' || ref.clipId !== b.id, '片段不能引用自身');
          if (ref.frame) await require('./reference-frames.cjs').prepareReference(this.store, project, ref);
        }
      }
      // Recheck after asynchronous frame preparation and before the synchronous store transaction.
      const current = this.store.read(pid);
      if (!same(targetState(current, scope, target), run.bases[target.targetId])) fail('正文已变化，建议保留，请重新核对。', 'review_conflict', 409);
      let prompt;
      if (pairedTarget) {
        if (!same(targetState(current, scope, pairedTarget), run.bases[pairedTarget.targetId])) fail('关联提示词已变化，请重新核对这条建议。', 'review_conflict', 409);
        requireValue(typeof pairedText === 'string' && pairedText.length <= 80000, '关联提示词改文无效');
        const body = run.bases[pairedTarget.targetId].value;
        prompt = body ? applyTextEdits(body, [{ oldText: item.oldText, newText: pairedText }]) : pairedText;
      }
      const e = scope.episodeId ? find(current.episodes, scope.episodeId) : null;
      let operation;
      if (b.type === 'setting') operation = { type: 'setSetting', id: b.id, text: value };
      else if (['synopsis', 'storyboard'].includes(b.type)) operation = { type: 'saveDocument', episodeId: e.id, targetType: b.type, text: value,
        baseVersionId: latest(e[b.type])?.id || null, baseSynopsisVersionId: e.synopsis.acceptedVersionId };
      else if (b.type === 'asset') { const a = find(current.assets, b.id); operation = { type: 'setAssetPrompt', episodeId: e.id, assetId: a.id, prompt: a.prompt, refs: a.refs, [item.kind === 'text' ? 'prompt' : 'refs']: value }; }
      else { const c = find(e.clips, b.id); operation = { ...c.plan, type: 'planClip', episodeId: e.id, id: c.id, title: c.title, [item.kind === 'text' ? 'prompt' : item.kind]: value }; }
      if (pairedTarget) operation.prompt = prompt;
      if (item.kind === 'refs' && b.type === 'clip') {
        // planClip can automatically restore mandatory voice refs. Do not label
        // a requested removal accepted when the persisted plan would undo it.
        const trial = clone(current); this.store.operation(trial, operation, { role: 'human' });
        requireValue(same(find(find(trial.episodes, e.id).clips, b.id).plan.refs, value),
          '片段仍需要说话角色的音色参考。请保留必要音色，或先在片段计划调整说话角色。');
      }
      const requestId = run.id + '-' + item.id;
      run.applying = { requestId, itemId: item.id, after, ...(pairedTarget ? { newText: pairedText } : {}) }; this.save(pid, run);
      this.store.mutate(pid, { requestId, expectedRevision: current.revision, operations: [operation] });
      item.status = 'accepted'; item.after = after; if (pairedTarget) item.newText = pairedText;
      this.refreshBases(run, this.store.read(pid), item);
      delete run.applying; this.save(pid, run); return this.view(run);
    } finally { this.applying.delete(key); }
  }
  async stop(pid, input) {
    const scope = this.scope(input), job = this.active.get(this.key(pid, scope));
    if (job) { job.abort.abort(); await job.done; }
    return this.view(this.read(pid, scope));
  }
  async close() { const jobs = [...this.active.values()]; jobs.forEach(j => j.abort.abort()); await Promise.allSettled(jobs.map(j => j.done)); }
}
function sameRef(a, b) {
  const keys = ['assetId', 'clipId', 'versionId', 'frame', 'role'];
  return b && typeof b === 'object' && keys.every(k => a[k] === b[k]) &&
    Object.keys(b).every(k => [...keys, 'purpose', 'referenceOnly'].includes(k)) &&
    (b.purpose === undefined || typeof b.purpose === 'string') && (b.referenceOnly === undefined || typeof b.referenceOnly === 'boolean');
}
// Display only the human-readable fields of unfinished tool JSON. This preview
// never participates in validation or project edits; the full arguments do.
function previewArguments(text) {
  const labels = { text: '用户偏好', summary: '审阅概述', reason: '修改理由', newText: '修改后', advice: '其他建议' }, parts = [];
  for (const match of text.matchAll(/"(text|summary|reason|newText|advice)"\s*:\s*"((?:\\(?:u[0-9a-fA-F]{4}|["\\/bfnrt])|[^"\\])*)/g)) {
    const raw = match[2];
    try { const value = JSON.parse('"' + raw + '"'); if (value) parts.push(labels[match[1]] + '：\n' + value); } catch { /* Wait for a complete escape. */ }
  }
  return parts.join('\n\n').slice(-16000);
}
module.exports = { RelayReview, reviewInput, userMessages, normalizeChanges, prepareReview, previewArguments };
