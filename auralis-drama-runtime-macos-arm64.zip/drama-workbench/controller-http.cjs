const http = require('node:http'), https = require('node:https');
const { Readable } = require('node:stream');
const { createGunzip, createInflate, createBrotliDecompress } = require('node:zlib');

// Native fetch imposes a separate five-minute headers/body timeout. Model
// requests use the review/controller's abort signal and inactivity watchdog,
// including while a provider thinks before sending its first response byte.
function modelFetch(url, options, redirects = 0) {
  const target = new URL(url), headers = new Headers(options.headers);
  return new Promise((resolve, reject) => {
    const request = (target.protocol === 'https:' ? https : http).request(target,
      { method: options.method, headers: Object.fromEntries(headers), signal: options.signal }, response => {
        if ([301, 302, 303, 307, 308].includes(response.statusCode) && response.headers.location) {
          response.resume();
          if (redirects >= 5) return reject(new Error('公司 API 重定向次数过多'));
          const next = new URL(response.headers.location, target);
          if (!['http:', 'https:'].includes(next.protocol)) return reject(new Error('公司 API 重定向地址无效'));
          if (next.origin !== target.origin) { headers.delete('authorization'); headers.delete('cookie'); }
          const useGet = response.statusCode === 303 || ([301, 302].includes(response.statusCode) && options.method === 'POST');
          if (useGet) { headers.delete('content-type'); headers.delete('content-length'); }
          return resolve(modelFetch(next, { ...options, headers, ...(useGet ? { method: 'GET', body: undefined } : {}) }, redirects + 1));
        }
        const responseHeaders = new Headers();
        for (const [name, value] of Object.entries(response.headers)) {
          for (const item of Array.isArray(value) ? value : [value]) if (item !== undefined) responseHeaders.append(name, item);
        }
        const decompress = { gzip: createGunzip, deflate: createInflate, br: createBrotliDecompress }[response.headers['content-encoding']];
        let body = response;
        if (decompress) {
          body = response.pipe(decompress());
          response.on('error', error => body.destroy(error));
          body.on('close', () => response.destroy());
          responseHeaders.delete('content-encoding'); responseHeaders.delete('content-length');
        }
        const empty = [204, 205, 304].includes(response.statusCode) || options.method === 'HEAD';
        if (empty) response.resume();
        resolve(new Response(empty ? null : Readable.toWeb(body), { status: response.statusCode, headers: responseHeaders }));
      });
    request.on('error', reject);
    request.end(options.body);
  });
}
module.exports = { modelFetch };
